#!/usr/bin/python
# -*- coding: utf-8 -*-
# *   Copyright (C) 2016 TDW
# */
import os, cookielib, urllib2, urllib, urlparse
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

siteUrl = 'www.lostfilm.tv'

h = int(sys.argv[1])
handle = int(sys.argv[1])

PLUGIN_NAME   = 'LostFilm2'

addon = xbmcaddon.Addon(id='plugin.video.LostFilm2')
__settings__ = xbmcaddon.Addon(id='plugin.video.LostFilm2')
CT = __settings__.getSetting("ConType")
if CT=="0": httpSiteUrl = 'http://' + siteUrl
else:httpSiteUrl = 'https://' + siteUrl
xbmcplugin.setContent(int(sys.argv[1]), 'movies')
xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')

icon = os.path.join(addon.getAddonInfo('path'), 'icon.png')
thumb = os.path.join( addon.getAddonInfo('path'), "icon.png" )
icon2 = os.path.join( addon.getAddonInfo('path'), "cover.png" )
fanart = os.path.join( addon.getAddonInfo('path'), "fanart.jpg" )
LstDir = os.path.join( addon.getAddonInfo('path'), "playlists" )
dbDir = os.path.join( addon.getAddonInfo('path'), "db" )
ImgPath = os.path.join( addon.getAddonInfo('path'), "logo" )
playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

sid_file = os.path.join(xbmc.translatePath('special://temp/'), 'plugin.video.LostFilm2.cookies.sid')
fcookies = os.path.join(addon.getAddonInfo('path'), r'cookies.txt')


def construct_request(params):
	return '%s?%s' % (sys.argv[0], urllib.urlencode(params))

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def inputbox():
	skbd = xbmc.Keyboard()
	skbd.setHeading('Поиск:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return ""

headers = {'User-Agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.0.13) Gecko/2009073022 Firefox/3.0.13',
	'Host' : 'vkontakte.ru',
	'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8',
	'Connection' : 'close',
}

def fs(s):return s.decode('windows-1251').encode('utf-8')
def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)


def GET(target, referer='http://lostfilm.tv/', post=None):
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		#xbmc.log( '[%s]: GET EXCEPT [%s]' % (addon_id, e), 4 )
		showMessage('HTTP ERROR', e, 5000)


#-------------------------------------------------------------------------------
# get cookies from last session
cj = cookielib.FileCookieJar(fcookies)
hr  = urllib2.HTTPCookieProcessor(cj)
if __settings__.getSetting("immunicity") == "1": 
	#import antizapret
	url='https://antizapret.prostovpn.org/proxy.pac'
	pac=GET(url)
	prx=pac[pac.find('PROXY ')+6:pac.find('; DIRECT')]
	if prx.find('http')<0 : prx="http://"+prx
	proxy_support = urllib2.ProxyHandler({"http" : prx})
	opener = urllib2.build_opener(proxy_support, hr)
	#antizapret.config_add(siteUrl)
	#opener = urllib2.build_opener(antizapret.AntizapretProxyHandler(), hr)
	print "Immunicity "+prx
elif __settings__.getSetting("immunicity") == "2": 
	prx=__settings__.getSetting("Proxy")
	if prx.find('http')<0 : prx="http://"+prx
	proxy_support = urllib2.ProxyHandler({"http" : prx})
	#proxy_support = urllib2.ProxyHandler({"http" : "http://n17-03-01.opera-mini.net:443"})
	opener = urllib2.build_opener(proxy_support, hr)
	print "Proxy "+__settings__.getSetting("Proxy")
else: 
	opener = urllib2.build_opener(hr)
	print "NO Proxy"
urllib2.install_opener(opener)



def play(url, ind=0, id='0', cse='(0,0,0)'):
	#print cse
	engine=__settings__.getSetting("Engine")
	if engine=="0": play_ace (url, ind)
	if engine=="1": play_t2h (url, ind, __settings__.getSetting("DownloadDirectory"))
	if engine=="2": play_yatp(url, ind)
	H=__settings__.getSetting("History")
	if H=='': HL=[]
	else: HL=eval(H)
	if cse.replace(".00","") not in HL and cse!='(0,0,0)': 
		HL.append(cse.replace(".00",""))
		__settings__.setSetting("History", repr(HL))
	xbmc.executebuiltin("Container.Refresh")


def play_ace(torr_link, ind=0):
	title=get_item_name(torr_link, ind)
	from TSCore import TSengine as tsengine
	TSplayer=tsengine()
	out=TSplayer.load_torrent(torr_link,'TORRENT')
	#print out
	if out=='Ok': TSplayer.play_url_ind(int(ind),title, icon, icon, True)
	TSplayer.end()
	return out

def play_t2h(uri, file_id=0, DDir=""):
	try:
		sys.path.append(os.path.join(xbmc.translatePath("special://home/"),"addons","script.module.torrent2http","lib"))
		from torrent2http import State, Engine, MediaType
		progressBar = xbmcgui.DialogProgress()
		from contextlib import closing
		if DDir=="": DDir=os.path.join(xbmc.translatePath("special://home/"),"userdata")
		progressBar.create('Torrent2Http', 'Запуск')
		# XBMC addon handle
		# handle = ...
		# Playable list item
		# listitem = ...
		# We can know file_id of needed video file on this step, if no, we'll try to detect one.
		# file_id = None
		# Flag will set to True when engine is ready to resolve URL to XBMC
		ready = False
		# Set pre-buffer size to 15Mb. This is a size of file that need to be downloaded before we resolve URL to XMBC 
		pre_buffer_bytes = 15*1024*1024
		engine = Engine(uri, download_path=DDir)
		with closing(engine):
			# Start engine and instruct torrent2http to begin download first file, 
			# so it can start searching and connecting to peers  
			engine.start(file_id)
			progressBar.update(0, 'Torrent2Http', 'Загрузка торрента', "")
			while not xbmc.abortRequested and not ready:
				xbmc.sleep(500)
				status = engine.status()
				# Check if there is loading torrent error and raise exception 
				engine.check_torrent_error(status)
				# Trying to detect file_id
				if file_id is None:
					# Get torrent files list, filtered by video file type only
					files = engine.list(media_types=[MediaType.VIDEO])
					# If torrent metadata is not loaded yet then continue
					if files is None:
						continue
					# Torrent has no video files
					if not files:
						break
						progressBar.close()
					# Select first matching file                    
					file_id = files[0].index
					file_status = files[0]
				else:
					# If we've got file_id already, get file status
					file_status = engine.file_status(file_id)
					# If torrent metadata is not loaded yet then continue
					if not file_status:
						continue
				if status.state == State.DOWNLOADING:
					# Wait until minimum pre_buffer_bytes downloaded before we resolve URL to XBMC
					if file_status.download >= pre_buffer_bytes:
						ready = True
						break
					#print file_status
					progressBar.update(100*file_status.download/pre_buffer_bytes, 'Torrent2Http', xt('Предварительная буферизация: '+str(file_status.download/1024/1024)+" MB"), "")
					
				elif status.state in [State.FINISHED, State.SEEDING]:
					#progressBar.update(0, 'T2Http', 'We have already downloaded file', "")
					# We have already downloaded file
					ready = True
					break
				
				if progressBar.iscanceled():
					progressBar.update(0)
					progressBar.close()
					break
				# Here you can update pre-buffer progress dialog, for example.
				# Note that State.CHECKING also need waiting until fully finished, so it better to use resume_file option
				# for engine to avoid CHECKING state if possible.
				# ...
			progressBar.update(0)
			progressBar.close()
			if ready:
				# Resolve URL to XBMC
				item = xbmcgui.ListItem(path=file_status.url)
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
				xbmc.sleep(3000)
				# Wait until playing finished or abort requested
				while not xbmc.abortRequested and xbmc.Player().isPlaying():
					xbmc.sleep(500)
	except: pass


def play_yatp(url, ind):
	purl ="plugin://plugin.video.yatp/?action=play&torrent="+ urllib.quote_plus(url)+"&file_index="+str(ind)
	item = xbmcgui.ListItem(path=purl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def get_item_name(url, ind):
	torrent_data = GETtorr(url)
	if torrent_data != None:
		import bencode
		torrent = bencode.bdecode(torrent_data)
		try:
			L = torrent['info']['files']
			name=L[ind]['path'][-1]
		except:
			name=torrent['info']['name']
		return name
	else:
		return ' '

def OpenTorrent(url, id='0', cse='(0,0,0)'):
	#print url
	torrent_data = GETtorr(url)
	if torrent_data != None:
		import bencode
		torrent = bencode.bdecode(torrent_data)
		cover = icon#get_info(id)['cover']
		try:
			L = torrent['info']['files']
			ind=0
			for i in L:
				name=ru(i['path'][-1])
				#size=i['length']
				listitem = xbmcgui.ListItem(name, iconImage=cover, thumbnailImage=cover)
				listitem.setProperty('IsPlayable', 'true')
				uri = sys.argv[0]+'?mode=PlayTorrent&id='+id+'&ind='+str(ind)+'&url='+urllib.quote_plus(url)
				xbmcplugin.addDirectoryItem(handle, uri, listitem)
				ind+=1
		except:
				ind=0
				name=torrent['info']['name']
				listitem = xbmcgui.ListItem(name, iconImage=cover, thumbnailImage=cover)
				listitem.setProperty('IsPlayable', 'true')
				#listitem.addContextMenuItems([('[B]Сохранить фильм(STRM)[/B]', 'Container.Update("plugin://plugin.video.KinoPoisk.ru/?mode=Save_strm&id='+id+'&url='+urllib.quote_plus(url)+'")'),])
				uri =sys.argv[0]+'?mode=PlayTorrent&id='+id+'&ind='+str(ind)+'&url='+urllib.quote_plus(url)+'&cse='+urllib.quote_plus(cse)
				play(url,0,id, cse)
				#xbmcplugin.addDirectoryItem(handle, uri, listitem)

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param


def GETtorr(target):
	try:
			req = urllib2.Request(url = target)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			return resp.read()
	except Exception, e:
			print 'HTTP ERROR ' + str(e)
			return None

def debug(s):
	fl = open(os.path.join(ru(addon.getAddonInfo('path')),"test.txt"), "w")
	fl.write(s)
	fl.close()

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def GETimg(target, referer=None, post=None):
	lfimg=os.listdir(ru(LstDir))
	nmi =os.path.basename(target)

	if nmi in lfimg and os.path.getsize(os.path.join(ru(LstDir),nmi))>0:
		return os.path.join( ru(LstDir),nmi)
	elif __settings__.getSetting("Picture") == "true":
		try:
			req = urllib2.Request(url = target, data = post)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			fl = open(os.path.join( ru(LstDir),nmi), "wb")
			fl.write(resp.read())
		#resp.close()
			fl.close()
			return os.path.join( ru(LstDir),nmi)
		except Exception, e:
			#xbmc.log( '[%s]: GET EXCEPT [%s]' % (addon_id, e), 4 )
			return target
			print 'HTTP ERROR ' + str(e)
	else:
		return target

def GETtorr2(target, referer=None, post=None):
	lfimg=os.listdir(ru(LstDir))
	#print target
	nmi =target.replace('http://tracktor.in/td.php?s=','')

	if nmi in lfimg and os.path.getsize(os.path.join(ru(LstDir),nmi))>0:
		return os.path.join( ru(LstDir),nmi)
	else:
		try:
			req = urllib2.Request(url = target, data = post)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			fl = open(os.path.join( ru(LstDir),nmi), "wb")
			fl.write(resp.read())
		#resp.close()
			fl.close()
			return os.path.join( ru(LstDir),nmi)
		except Exception, e:
			#xbmc.log( '[%s]: GET EXCEPT [%s]' % (addon_id, e), 4 )
			return target
			print 'HTTP ERROR ' + str(e)


def get_HTML(url, post = None, ref = None, get_redirect = False):
    if url.find('http')<0 :
        if CT=="0": url='http:'+url
        else: url='https:'+url
    #url="http://translate.googleusercontent.com/translate_c?u="+url
    request = urllib2.Request(url, post)

    host = urlparse.urlsplit(url).hostname
    if ref==None:
        try:
           ref='http://'+host
        except:
            ref='localhost'

    request.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
    request.add_header('Host',   host)
    request.add_header('Accept', 'text/html, application/xhtml+xml, */*')
    request.add_header('Accept-Language', 'ru-RU')
    request.add_header('Referer',             ref)
    request.add_header('Content-Type','application/x-www-form-urlencoded')

    try:
        f = urllib2.urlopen(request)
    except IOError, e:
        if hasattr(e, 'reason'):
           print('We failed to reach a server.')
        elif hasattr(e, 'code'):
           print('The server couldn\'t fulfill the request.')
        return 'We failed to reach a server.'

    if get_redirect == True:
        html = f.geturl()
    else:
        html = f.read()

    return html


def Login():
	from BeautifulSoup  import BeautifulSoup
	url1 = 'http://login1.bogi.ru/login.php?referer=http%3A%2F%2Fwww.lostfilm.tv%2F'
	login = __settings__.getSetting("login")
	passw = __settings__.getSetting("password")
	if login =="" or passw == '': showMessage('lostfilm', "Проверьте логин и пароль", times = 50000)

	values = {
				'login'     : login,
				'password'  : passw,
				'module'    : 1,
				'target'    : 'http://lostfilm.tv/',
				'repage'    : 'user',
				'act'       : 'login'
		}
	post = urllib.urlencode(values)
	html = get_HTML(url1, post, 'http://www.lostfilm.tv/')
	soup = BeautifulSoup(html, fromEncoding="utf-8")
	#-- step 2
	ref = url1
	url1 = soup.find('form')['action']
	values={}
	for rec in soup.findAll('input'):
		try:values[rec['name'].encode('utf-8')] = rec['value'].encode('utf-8')
		except:print "err: value"
	post = urllib.urlencode(values)
	html = get_HTML(url1, post, ref)
	#-- ok


def AddItem(Title = "", mode = "", info={}, url='', total=15, cse='(0,0,0)'):
			#info=get_info(id)
			try:id = info['id']
			except: id='0'
			try:e = info['episode']
			except: e ='0'
			
			#print mode+": "+cse
			
			try:    cover = GETimg(info["cover"])
			except: cover = os.path.join( addon.getAddonInfo('path'), "cover.png" )
			if cover =="": cover = os.path.join( addon.getAddonInfo('path'), "cover.png" )
			try:    fanart = info["fanart"]
			except: fanart = os.path.join( addon.getAddonInfo('path'), "fanart.jpg" )
			if fanart =='':fanart = os.path.join( addon.getAddonInfo('path'), "fanart.jpg" )
			
			listitem = xbmcgui.ListItem(Title, iconImage=cover, thumbnailImage=fanart)
			listitem.setInfo(type = "Video", infoLabels = info)
			try: listitem.setArt({ 'poster': cover, 'fanart' : fanart})
			except: pass
			listitem.setProperty('fanart_image', fanart)
			
			purl = sys.argv[0] + '?mode='+mode+'&id='+id+'&cse='+cse
			if url !="": purl = purl +'&url='+urllib.quote_plus(url)
			
			try:
				lf_name=info['originaltitle']
				lf_url='plugin://plugin.video.LostFilm2/?mode=TC&id='+urllib.quote_plus(id)+'&title='+urllib.quote_plus(lf_name)
			except: pass
			
			if mode=="Getlist":
				listitem.addContextMenuItems([('[B]Отслеживать в ТС[/B]', 'Container.Update("plugin://plugin.video.torrent.checker/?mode=add&url='+urllib.quote_plus(lf_url)+'&name='+lf_name+'")'),])
			
			folder=True
			
			if mode=="OpenTorrent" and e !="99":
				listitem.setProperty('IsPlayable', 'true')
				folder=False
			
			if __settings__.getSetting("Quality") != '0' and mode=="Releases":# and 'сезон.' not in xt(Title):
				listitem.addContextMenuItems([('[B]Обновить список[/B]', 'Container.Refresh'), ('[B]Выбрать качество[/B]', 'Container.Update("plugin://plugin.video.LostFilm2/?mode=Releases2&cse='+urllib.quote_plus(cse)+'&id='+id+'")'), ('[B]Все серии[/B]', 'Container.Update("plugin://plugin.video.LostFilm2/?mode=Getlist&id='+id+'")'),('[B]Отслеживать в ТС[/B]', 'Container.Update("plugin://plugin.video.torrent.checker/?mode=add&url='+urllib.quote_plus(lf_url)+'&name='+lf_name+'")'),])
				listitem.setProperty('IsPlayable', 'true')
				purl = sys.argv[0] + '?mode=Autoplay&id='+id+'&cse='+urllib.quote_plus(cse)
				if 'сезон.' not in xt(Title):folder=False
			elif mode=="Releases":
				listitem.addContextMenuItems([('[B]Обновить список[/B]', 'Container.Refresh'),('[B]Все серии[/B]', 'Container.Update("plugin://plugin.video.LostFilm2/?mode=Getlist&id='+id+'")'),('[B]Отслеживать в ТС[/B]', 'Container.Update("plugin://plugin.video.torrent.checker/?mode=add&url='+urllib.quote_plus(lf_url)+'&name='+lf_name+'")'),])
			
			try:
				if cse.replace(".00","") in eval(__settings__.getSetting("History")): listitem.select(True)
			except:
				pass
			
			xbmcplugin.addDirectoryItem(handle, purl, listitem, folder, total)

def TC(id, name):
	Login()
	sys.path.append(os.path.join(xbmc.translatePath("special://home/"),"addons","plugin.video.torrent.checker"))
	import updatetc
	LD=updatetc.file_list(name)
	
	url=xt(httpSiteUrl + '/browse.php?cat='+id)
	http=fs(GET(url)).replace(chr(13),'')
	ss='<table cellspacing="0"'
	es='false;"></a>'
	L=mfindal(http,ss,es)
	for i in L:
				ss='ShowAllReleases'
				es='" onMouseOver'
				cse=mfindal(i,ss,es)[0][len(ss):]
				
				s=eval(cse)[1]
				e=str(eval(cse)[2])
				if "." in s: s=s[:s.find(".")]
				if "-" in e: e=e[:e.find("-")]
				if e!="99":
					if len(s)<2:s="0"+s
					if len(e)<2:e="0"+e
					nm=name+".s"+s+".e"+e+'.strm'
					if nm not in LD:
						L2=Releases(cse, id, False)
						q=['dfth','hd','1080','sd','dfth']
						quality=q[int(__settings__.getSetting("Quality"))]
						uri=L2[0][1]
						pic=L2[0][2]
						for j in L2:
							pic=j[2]
							if quality in pic: uri=j[1]
						updatetc.save_strm(name, nm, uri, 0)
	xbmc.executebuiltin('UpdateLibrary("video")')


def autoplay(cse, id='0'):
		L=Releases(cse, "0", False)
		q=['dfth','hd','1080','sd']
		qs=int(__settings__.getSetting("Quality"))
		
		url=L[0][1]
		pic=L[0][2]
		
		if qs == 4: # вызов диалога
			lbl=[]
			for j in L:
				lbl.append(j[0])
			sel = xbmcgui.Dialog()
			r = sel.select("Качество:", lbl)
			if r < 0 : return
			url=L[r][1]
			pic=L[r][2]
		else:       # автовыбор
			quality=q[qs]
			for i in L:
				pic=i[2]
				if quality in pic: 
					#print pic
					url=i[1]
		
		e=str(eval(cse)[2])
		if e=="99": 
			OpenTorrent(url, id)
			xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
			xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
			xbmcplugin.endOfDirectory(handle)
		else: 
			play(url,0,id,cse)


def get_info(id):
	try:
		#if __settings__.getSetting('UpdLib')=='true': rem_inf_db(ID)
		info=eval(xt(get_inf_db(id)))
		return info
	except:
		url=httpSiteUrl + '/browse.php?cat='+id
		#print url
		http=fs(GET(url)).replace(chr(13),'').replace('</b><br>'+chr(10),'').replace('</h4>'+chr(10),'').replace('<div st', chr(10)+'<div st')
		http=http.replace('<div oncopy="return false" oncontextmenu="return false" onselectstart="return false" style="position: relative; width: 100%; height: 100%;">'+chr(10),'')
		#debug(http)
		ss='<h1>'
		es='</span>'+chr(10)+'</div>'+chr(10)+'<div>'
		if 'Контент недоступен на территории Российской Федерации' in http: es = 'Контент недоступен на территории Российской Федерации'
		
		inf=mfindal(http,ss,es)[0]
		L=inf.splitlines()
		
		
		ru_title =''
		en_title =''
		studio =''
		year =''
		genre =''
		fanart =''
		plot_1 =''
		plot_2 =''
		actors =''
		director =''
		
		for i in L:
			try:
				if '<h1>'       in i: ru_title =i[4:i.find(' (')]
				if '<h1>'       in i: en_title =i[i.find(' (')+2:i.find(')')]
				if 'Страна:'    in i:   studio =i[i.find('Страна: ')+14:i.find('<br />')]
				if 'Год выхода' in i:     year =i[i.find('<span>')+6:i.find('</span>')]
				if 'Жанр'       in i:    genre =i[i.find('<span>')+6:i.find('</span>')]
				if '<img src='  in i:   fanart =httpSiteUrl + i[i.find('<img src="')+10:i.find('" alt="')]
				if '\t<span>'   in i:   plot_1 =i[i.find('<span>')+6:i.find('<br><br>')]
				if 'Сюжет:'     in i:   plot_2 =i[i.find('Сюжет:')+11:]
				if 'Актеры:'    in i:   actors =clear_text(i[i.find('Актеры:')+13:i.find('<br><br>')])
				if 'Режиссеры:' in i: director =i[i.find('Режиссеры:')+19:i.find('<br><br>')]
			except:
				pass
				
		#if ru_title=='': debug(inf)
		try:castandrole=eval('["'+actors.replace(' (',' | ').replace(')','"').replace(',',',"')+']')
		except: castandrole=[]
		
		ss='details.php?id='
		es='" class="a_details'
		cover_id=mfindal(http,ss,es)[0][len(ss):]
		cover=get_cover(cover_id)
		
		#print ru_title
		#print en_title
		#print year
		#print genre
		#print studio
		#print fanart
		
		info = {"title": clear_text(ru_title),
				"originaltitle":clear_text(en_title),
				"year":year,
				"genre":genre,
				"studio":studio,
				"director":clear_text(director),
				"castandrole":castandrole,
				"cover":cover,
				"fanart":fanart,
				"plot":clear_text(plot_2+chr(10)+plot_1),
				"id":id
				}

		#debug(repr(info))
		add_to_db(id, repr(info))
		return info

def clear_text(t):
	if len(t)>1:
		t=t.replace('<div style="position: relative; width: 100%; height: 100%;" onselectstart="return false" oncontextmenu="return false" oncopy="return false">','')
		t=t.replace('<br>','')
		t=t.replace('<br','')
		t=t.replace('</b>','')
		t=t.replace('<b>','')
		t=t.replace('<br />','')
		t=t.replace('<br /','')
		t=t.replace('/>','')
		t=t.replace('"',"”")
		try: 
			if t[0]==chr(10):  t=t[1:]
		except: pass
		t=t.strip()
	return t

def get_cover(id):
	try:
		url=httpSiteUrl + '/details.php?id='+id
		http=fs(GET(url))
		ss='http&#58'
		es='" alt="" /><br />'
		if es not in http: es='" alt="" /> <br />'
		cover=mfindal(http,ss,es)[0].replace('&#58;',':').replace('&#46;','.')
		return cover
	except:
		return ''
		#debug (http)


def Serials():
	url = xt(httpSiteUrl + '/serials.php')
	http = fs(GET(url))
	ss='<div class="content_head">'
	es='<div class="right"'
	http=http[http.find(ss):http.find(es)]
	ss='href="/browse'
	es='</a>'
	L=mfindal(http,ss,es)
	for i in L:
		ss='php?cat='
		es='" class='
		id=mfindal(i,ss,es)[0][len(ss):]
		
		ss='bb_a">'
		es='<br><span>'
		title=mfindal(i,ss,es)[0][len(ss):]
		
		info=get_info(id)
		title2=info['title']
		if title2 == "": info['title']=title
		
		AddItem("[B]"+xt(title)+"[/B]", "Getlist", info, '', len(L))



def NEW():
	AddItem("[B]Все сериалы[/B]", "Serials", {}, "")
	url=httpSiteUrl + '/browse.php'
	http=fs(GET(url))
	http=http[:http.find('<span class="d_pages_link_selected">')]
	#debug (http)
	ss='<span style='
	es='<div style="float'
	L=mfindal(http,ss,es)
	#print L
	for i in L:
		if 'browse' in i:
			#debug(i)
			ss='browse.php?cat='
			es='"><img src="'
			id=mfindal(i,ss,es)[0][len(ss):]
			
			ss='<span class="torrent_title"><b>'
			es='</b></span>'
			sr_title=ru(mfindal(i,ss,es)[0][len(ss):])
			
			ss='ShowAllReleases'
			es=')"></a>'
			cse=mfindal(i,ss,es)[0][len(ss):]+")"
			
			s=eval(cse)[1]
			s=s[:s.find(".")]
			e=str(eval(cse)[2])
			if e=="99": se=" "+s+" с. "
			else: se=s+"."+e
			
			info=get_info(id)
			title=info['title']
			if title == "":
				ss='title="'
				es='" align="left"'
				title=ru(mfindal(i,ss,es)[0][len(ss):])
				info['title']=title
				
			info['episode']=e
			info['season']=s
			AddItem(se+" [B][COLOR FFFFFFFF]"+xt(title)+":[/COLOR][/B] "+xt(sr_title), "Releases", info, '', 15, cse)

def Releases(cse, id='0', add=True):
	Login()
	c,s,e=eval(cse)
	trurl = xt(httpSiteUrl + '/nrdr.php?c='+c+'&s='+s+'&e='+e)
	#url = get_HTML(url = categoryUrl, get_redirect = True) #-- do not redirect
	#http = get_HTML(url)
	http=fs(GET(trurl))
	#debug (http)
	http=http.replace(chr(10),"")
	ss='valign="top"><img src="img'
	es='</a></nobr></div>'
	L=mfindal(http, ss, es)
	LL=[]
	for i in L:
		ss='src="img'
		es='.png"'
		pic=mfindal(i, ss, es)[0][len(ss):]
		fpic="http://retre.org/img"+pic+".png"
		#print pic
		
		ss='href="http://tracktor'
		es='" style="font-size:18px;font-weight:bold;'
		tor=mfindal(i, ss, es)[0][6:]
		#print tor
		
		#ss='style="font-size:18px;font-weight:bold;">'
		#es='</a><br />\t<span style="font-size:12px; color:black;">'
		#label=mfindal(i, ss, es)[0][len(ss):]
		
		ss='</a><br />\t<span style="font-size:12px; color:black;">'
		es='<br />\t<div style="overflow:'
		label=mfindal(i, ss, es)[0][len(ss):]#+" "+ label
		
		#print label
		try: info=get_info(id)
		except:info={}
		info['cover']=fpic
		info['title']=label
		info['episode']=e
		info['season']=s
		
		if add: AddItem("[B]"+xt(label)+":[/B]", "OpenTorrent", info, tor, 3, cse)
		LL.append([label, tor, fpic])
	return LL

def Getlist(id):
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
		Login()
		url=httpSiteUrl + '/browse.php?cat='+id
		#print url
		http=fs(GET(url)).replace(chr(13),'')
		ss='<table cellspacing="0"'
		es='false;"></a>'
		L=mfindal(http,ss,es)
		for i in L:
			#try:
				#debug (i)
				ss='style="color:#4b4b4b">'
				es='</span><br />'
				sr_title=mfindal(i,ss,es)[0][len(ss):]
				
				ss='><span><b>'
				es='</b></span></label>'
				try:rat=mfindal(i,ss,es)[0][len(ss):]
				except:rat=""
				
				ss='ShowAllReleases'
				es='" onMouseOver'
				cse=mfindal(i,ss,es)[0][len(ss):]
				
				s=eval(cse)[1]
				if "." in s: s=s[:s.find(".")]
				e=str(eval(cse)[2])
				if e=="99": se="[B][COLOR FF55FF55]"+s+" сезон.[/COLOR][/B]"
				else: se=s+"."+e
				
				info=get_info(id)
				info['rating']=float(rat)
				info['episode']=e
				info['season']=s
				AddItem(se+" - [B]"+xt(sr_title)+"[/B]", "Releases", info, '',len(L), cse)
			#except:
				#print i

import sqlite3 as db
db_name = os.path.join( addon.getAddonInfo('path'), "move_info.db" )
c = db.connect(database=db_name)
cu = c.cursor()
def add_to_db(n, item):
		item=item.replace("'","XXCC").replace('"',"XXDD")
		err=0
		tor_id="n"+n
		litm=str(len(item))
		try:
			cu.execute("CREATE TABLE "+tor_id+" (db_item VARCHAR("+litm+"), i VARCHAR(1));")
			c.commit()
		except: 
			err=1
			print "Ошибка БД"
			#debug(item)
		if err==0:
			cu.execute('INSERT INTO '+tor_id+' (db_item, i) VALUES ("'+item+'", "1");')
			c.commit()
			#c.close()

def get_inf_db(n):
		tor_id="n"+n
		cu.execute(str('SELECT db_item FROM '+tor_id+';'))
		c.commit()
		Linfo = cu.fetchall()
		info=Linfo[0][0].replace("XXCC","'").replace("XXDD",'"')
		return info

def rem_inf_db(n):
		tor_id="n"+n
		try:
			cu.execute("DROP TABLE "+tor_id+";")
			c.commit()
		except: pass


params = get_params()
mode     = 'New'
url      = '0'
title    = ''
ref      = ''
img      = ''
id       = '0'
cse      = '(0,0,0)'
info  = {}

try: mode  = urllib.unquote_plus(params["mode"])
except: pass

try: url  = urllib.unquote_plus(params["url"])
except: pass

try: dir  = urllib.unquote_plus(params["dir"])
except: dir = "."

try: title  = urllib.unquote_plus(params["title"])
except: pass

try: cse  = urllib.unquote_plus(params["cse"])
except: pass

try: img  = urllib.unquote_plus(params["img"])
except: pass

try: id  = urllib.unquote_plus(params["id"])
except: pass

try:    ind = int(get_params()["ind"])
except: ind = 0

try: info  = eval(urllib.unquote_plus(params["info"]))
except: pass



if mode == None or mode == "New":
	NEW()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	
elif mode == 'Serials':
	Serials()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

elif mode == 'OpenTorrent':
	OpenTorrent(url, id, cse)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(handle)

elif mode == 'Releases' or mode == 'Releases2':
	Releases(cse, id)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(handle)

if mode == "PlayTorrent":
	play(url, ind, id, cse)


if mode == 'Getlist':
	Getlist(id)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
if mode == "Autoplay":
	autoplay(cse, id)

if mode == "TC":
	TC(id, title)


c.close()