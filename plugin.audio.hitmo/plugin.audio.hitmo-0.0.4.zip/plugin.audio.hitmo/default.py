#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys, os, time
import xbmcplugin, xbmcgui, xbmcaddon
import hitmo #Модуль с функциями для сайта
import ssl
try: # Игнорирование SSl сертификата
	ctx = ssl.create_default_context()
	ctx.check_hostname = False
	ctx.verify_mode = ssl.CERT_NONE
except: pass

# ========================= получение/установка данных о плагине =================
plugin_id = 'plugin.audio.hitmo'
addon = xbmcaddon.Addon(id=plugin_id)
pluginhandle = int(sys.argv[1])
xbmcplugin.setContent(int(sys.argv[1]), 'songs')
__settings__ = xbmcaddon.Addon(id=plugin_id)
thumb = os.path.join( addon.getAddonInfo('path'), 'icon.png')

# =========================функции для совместимости с коди 19 ===============================
if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2

def b2s(s):
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		return s
	else:
		return s

# ============================== текстовые функции ====================================
def ru(x):
	try: x=unicode(x,'utf8', 'ignore')
	except: pass
	return x
def xt(x):return xbmc.translatePath(x)
def rt(x):
	L=[('&#39;','’'), ('&#145;','‘'), ('&#146;','’'), ('&#147;','“'), ('&#148;','”'), ('&#149;','•'), ('&#150;','–'), ('&#151;','—'), ('&#152;','?'), ('&#153;','™'), ('&#154;','s'), ('&#155;','›'), ('&#156;','?'), ('&#157;',''), ('&#158;','z'), ('&#159;','Y'), ('&#160;',''), ('&#161;','?'), ('&#162;','?'), ('&#163;','?'), ('&#164;','¤'), ('&#165;','?'), ('&#166;','¦'), ('&#167;','§'), ('&#168;','?'), ('&#169;','©'), ('&#170;','?'), ('&#171;','«'), ('&#172;','¬'), ('&#173;',''), ('&#174;','®'), ('&#175;','?'), ('&#176;','°'), ('&#177;','±'), ('&#178;','?'), ('&#179;','?'), ('&#180;','?'), ('&#181;','µ'), ('&#182;','¶'), ('&#183;','·'), ('&#184;','?'), ('&#185;','?'), ('&#186;','?'), ('&#187;','»'), ('&#188;','?'), ('&#189;','?'), ('&#190;','?'), ('&#191;','?'), ('&#192;','A'), ('&#193;','A'), ('&#194;','A'), ('&#195;','A'), ('&#196;','A'), ('&#197;','A'), ('&#198;','?'), ('&#199;','C'), ('&#200;','E'), ('&#201;','E'), ('&#202;','E'), ('&#203;','E'), ('&#204;','I'), ('&#205;','I'), ('&#206;','I'), ('&#207;','I'), ('&#208;','?'), ('&#209;','N'), ('&#210;','O'), ('&#211;','O'), ('&#212;','O'), ('&#213;','O'), ('&#214;','O'), ('&#215;','?'), ('&#216;','O'), ('&#217;','U'), ('&#218;','U'), ('&#219;','U'), ('&#220;','U'), ('&#221;','Y'), ('&#222;','?'), ('&#223;','?'), ('&#224;','a'), ('&#225;','a'), ('&#226;','a'), ('&#227;','a'), ('&#228;','a'), ('&#229;','a'), ('&#230;','?'), ('&#231;','c'), ('&#232;','e'), ('&#233;','e'), ('&#234;','e'), ('&#235;','e'), ('&#236;','i'), ('&#237;','i'), ('&#238;','i'), ('&#239;','i'), ('&#240;','?'), ('&#241;','n'), ('&#242;','o'), ('&#243;','o'), ('&#244;','o'), ('&#245;','o'), ('&#246;','o'), ('&#247;','?'), ('&#248;','o'), ('&#249;','u'), ('&#250;','u'), ('&#251;','u'), ('&#252;','u'), ('&#253;','y'), ('&#254;','?'), ('&#255;','y'), ('&amp;','&')]
	for i in L:
		x=x.replace(i[0], i[1])
	return x

# =====================================================================================

def debug(s): # Отладочная функция сохраняет текст в файл test.txt
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "wb")
	fl.write(s)
	fl.close()

def inputbox(): # Функция открывает окно ввода текста. 
	skbd = xbmc.Keyboard()
	skbd.setHeading('Поиск:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return ""

def showMessage(heading, message, times = 3000): #Функция показывает текстовое сообщение
	heading = heading.encode('utf-8')
	message = message.encode('utf-8')
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, thumb))

def get_params(): #техническая функция парсинга параметров
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def GET(url, Referer = ''): # Загружает данные из сети по URL
	print (url)
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	try:    response = urllib2.urlopen(req)
	except: response = urllib2.urlopen(req, context=ctx)
	link=b2s(response.read())
	response.close()
	return link


def Root(): #==== Главное меню плагина =====================================
		AddItem("[COLOR F0E0E067][B][ Поиск ][/B][/COLOR]", "serch")
		AddItem("Жанры", "cat_genres")
		AddItem("Чарты", "cat_top_charts")
		AddItem("Коллекции", "cat_collections")
		AddItem("Новинки", "songs/new")
		AddItem("Популярные", "songs/top-rated")
		AddItem("Хиты", "songs/top-today")
		#AddItem("Избранное", "favorites")
		xbmcplugin.endOfDirectory(pluginhandle)


def AddItem(title = "", mode = "", info={}, purl="", total=100): # Добавляет пункт меню или файл.
			folder=False
			
			try:    img=info['cover']
			except: img=thumb
			
			try:tracknumber=info['tracknumber']
			except:tracknumber=''
			
			try:year=info['year']
			except:year=''
			
			try:stitle=info['title']
			except:stitle=''
			
			try:artist=info['artist']
			except:artist=''
			
			try:album=info['album']
			except:album=''
			
			try:genre=info['genre']
			except:genre=''
			
			try:dict={'title':stitle, 'artist':artist, 'album':album, 'genre':genre, 'year':year, 'tracknumber':tracknumber}
			except:dict={}
			
			try:    item = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
			except: item = xbmcgui.ListItem(title)
			item.setInfo(type="Music", infoLabels=dict)
			try: item.setArt({ 'poster': img, 'fanart' : img, 'thumb': img, 'icon': img})
			except: pass
			
			context=[]
			if mode=='play':
				uri2=sys.argv[0] + '?mode=serch3&name='+quote(artist)
				context.append(('[COLOR F030F0F0] Исполнитель [/COLOR]', 'Container.Update("'+uri2+'")'))
				uri=sys.argv[0] + '?mode=save&info='+quote(repr(info))
				context.append(('[COLOR F0F0F050] Сохранить трек [/COLOR]', 'Container.Update("'+uri+'")'))
			
			if purl=="":
				purl = sys.argv[0] + '?mode='+mode
				purl = purl+'&info='+quote(repr(info))
				folder=True
			else:
				item.setProperty('IsPlayable', 'true')
				
			item.addContextMenuItems(context)
			xbmcplugin.addDirectoryItem(pluginhandle, purl, item, folder, total)


def Serch(t=''):# Поиск 
		if t=='': t=inputbox()
		Lst=hitmo.serch(t)
		Serch2(Lst)

def Serch2(L):#Обработка поискового списка
	for info in L:
			title = 	info['title']
			artist = 	info['artist']
			url = 		info['url']
			AddItem(TR+artist+" - [B]"+title+"[/B]", "play", info, url, len(L))
	xbmcplugin.endOfDirectory(pluginhandle)


def Catalogue(cat):# Меню с альбомами и коллекциями
	cat=cat[4:]
	L=hitmo.get_catalogue(cat)
	for i in L:
		AddItem(i["title"],i["url"], i)
	xbmcplugin.endOfDirectory(pluginhandle)


def OpenList(cat): # Вывод списка треков из каталога cat
	L=hitmo.get_list(cat)
	for info in L:
			title = info['title']
			url   = info['url']
			artist= info['artist']
			AddItem(TR+artist+" - [B]"+title+"[/B]", "play", info, url, len(L))
	xbmcplugin.endOfDirectory(pluginhandle)


def Save(dict, update=False): # Скачивание трека 
	xbmcplugin.endOfDirectory(pluginhandle, False, False)
	target	=dict["url"]
	artist	=dict["artist"]
	title	=dict["title"]
	try:img	=dict["cover"]
	except: img=''
	try:album=dict["album"]
	except: album=''
	
	try:
		pDialog = xbmcgui.DialogProgressBG()
		pDialog.create('Сохранение:', artist+" - "+title)
	except: pass
	
	
	Dldir = __settings__.getSetting("DownloadDirectory")
	if Dldir == "":Dldir = os.path.join( addon.getAddonInfo('path'), "mp3" )
	
	fp = os.path.join(ru(Dldir), ru(artist.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"")))
	#fp = os.path.join(fp, ru(album.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"")))
	if os.path.exists(fp)== False: os.makedirs(fp)
	cp=os.path.join(fp, "cover.jpg")
	fp = os.path.join(fp, ru(title.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"")+".mp3"))
	try:
	#if 1==1:
			req = urllib2.Request(url = target, data = None)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			fl = open(fp, "wb")
			fl.write(resp.read())
			fl.close()
			if os.path.exists(cp)== False and img !="":
				req = urllib2.Request(url = img, data = None)
				req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
				resp = urllib2.urlopen(req)
				fl = open(cp, "wb")
				fl.write(resp.read())
				fl.close()
			
			if __settings__.getSetting("Retag") == 'true': retag(fp, dict)
			#print "Update"
			try:pDialog.close()
			except: pass
			
			if update: 
				xbmc.sleep(3000)
				xbmc.executebuiltin('UpdateLibrary("music")')
			return fp
	except:
			try:pDialog.close()
			except: pass
			return target


# ------------------ получение параметров для текущего запроса -----------------

params = get_params()
url  =	''
mode =	None
name =	''
img =	' '
info =	{}
Lst=[]
id = ''
AL="[COLOR 663333DD][B][ A ][/B][/COLOR] "
TR=''

try: id = unquote(params["id"])
except: pass
try: url = unquote(params["url"])
except: pass
try: mode = unquote(params["mode"])
except: pass
try: name = unquote(params["name"])
except: pass
try: img = unquote(params["img"])
except: pass
try: info = eval(unquote(params["info"]))
except: pass
try: Lst = eval(unquote(params["Lst"]))
except: pass

# --------------- Навигация по плагину в зависимости от параметра mode ---------------

if   mode == None:				Root()
elif mode == 'serch':			Serch()
elif mode == 'serch2':			Serch2(Lst)
elif mode == 'serch3':			Serch(name)
elif mode == 'genres':			Genres()
elif mode == 'save':			Save(info)
else: 							
	if 'cat_' in mode: Catalogue(mode)
	else: OpenList(mode)

