# -*- coding: utf-8 -*-
# *  Copyright (C) 2020 TDW

import urllib2, urllib, time
api_key='ef17a1e0c9df7d0c6a926a0c94627e93'
api_url='https://api.themoviedb.org/3'
api_lang='ru-RU'

def JSON(j):
	null = None
	false = False
	true = True
	return eval(j.replace('\\/','/'))

def GET(url, Referer = ''):
	req = urllib2.Request(url)
	#req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36 OPR/46.0.2597.39')
	#req.add_header('Accept', 'application/xml, application/xhtml+xml')
	#req.add_header('Accept-Language', 'ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4')
	#req.add_header('Referer', Referer)
	#req.add_header('x-requested-with', 'XMLHttpRequest')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link
	
def deb_print(t):
	print t
	time.sleep(10)

#=============== API ==================
#sort_by=
#popularity.desc/.asc
#vote_average.desc/.asc
#first_air_date.desc/.asc

#with_genres=18
#include_null_first_air_dates=false
#first_air_date_year=2000
#vote_count.gte=50
#vote_average.gte=6
def discover(param):
	head = api_url+'/discover/tv?api_key='+api_key+'&language='+api_lang
	tail = ''
	for key in param.keys():
		tail = tail+'&'+key+'='+param[key]
	url = head + tail
	print url
	j=GET(url)
	D=JSON(j)
	return D

def search(q):
	q=urllib.quote_plus(q)
	url = api_url+'/search/tv?api_key='+api_key+'&query='+q+'&language='+api_lang
	j=GET(url)
	L=JSON(j)['results']
	LL=[]
	for i in L:
		LL.append(kodi_info(i))
	return LL


def seasons(id):
	url = api_url+'/tv/'+str(id)+'?api_key='+api_key+'&language='+api_lang
	#deb_print(url)
	j=GET(url)
	#deb_print(j)
	L=JSON(j)['seasons']
	Ls=[]
	for i in L:
		Ls.append({'season':i['season_number'], 'title':i['name'], 'plot':i['overview'], 'cover':i['poster_path'], 'id':i['id']})
	return Ls

def episodes(id, sn):
	url = api_url+'/tv/'+str(id)+'/season/'+str(sn)+'?api_key='+api_key+'&language='+api_lang
	#deb_print(url)
	j=GET(url)
	#deb_print(j)
	L=JSON(j)['episodes']
	Le=[]
	for i in L:
		
		Le.append(kodi_info(i))
	return Le

def get_info(id):
	url = api_url+'/tv/'+str(id)+'?api_key='+api_key+'&language='+api_lang
	#deb_print(url)
	j=GET(url)
	#deb_print(j)
	D=JSON(j)
	return kodi_info(D)
#====================================

def kodi_info(mdb_info):
	key_dict = {'title':'name', 'originaltitle': 'original_name', 'rating': 'vote_average', 'plot': 'overview', 'cover': 'poster_path', 'fanart': 'backdrop_path', 'year': 'first_air_date', 'episode':'episode_number', 'season':'season_number', 'thumb':'still_path', 'premiered':'air_date', 'id':'id'}
	info={}
	for key in key_dict.keys():
		try: info[key]=mdb_info[key_dict[key]]
		except: pass
	
	return info

def get_genre_list():
	url = api_url+'/genre/tv/list?api_key='+api_key+'&language='+api_lang
	j=GET(url)
	L=JSON(j)['genres']
	return L

def get_genre(id):
	LL=[]
	for p in range(5):
		param = {'include_null_first_air_dates':'false', 'sort_by':'vote_average.desc', 'vote_count.gte':'150', 'vote_average.gte':'4', 'with_genres':str(id),'page':str(p+1)}
		L=discover(param)['results']
		for i in L:
			LL.append(kodi_info(i))
	return LL

def similar(id):
	url = api_url+'/tv/'+id+'/similar?api_key='+api_key+'&language='+api_lang
	j=GET(url)
	L=JSON(j)['results']
	LL=[]
	for i in L:
		LL.append(kodi_info(i))
	return LL

def new():
	param = {'include_null_first_air_dates':'false', 'sort_by':'first_air_date.desc', 'vote_count.gte':'10','vote_average.gte':'5'}
	L=discover(param)['results']
	LL=[]
	for i in L:
		LL.append(kodi_info(i))
	return LL

def top():
	LL=[]
	for p in range(5):
		param = {'include_null_first_air_dates':'false', 'sort_by':'vote_average.desc', 'vote_count.gte':'500','vote_average.gte':'5','page':str(p+1)}
		L=discover(param)['results']
		for i in L:
			LL.append(kodi_info(i))
	return LL

def popular():
	LL=[]
	for p in range(5):
		param = {'include_null_first_air_dates':'false', 'sort_by':'popularity.desc', 'vote_count.gte':'80','vote_average.gte':'5','page':str(p+1)}
		L=discover(param)['results']
		for i in L:
			LL.append(kodi_info(i))
	return LL


def on_the_air():
	LL=[]
	for p in range(5):
		url = api_url+'/tv/on_the_air?api_key='+api_key+'&language='+api_lang+'&page='+str(p+1)
		j=GET(url)
		L=JSON(j)['results']
		for i in L:
			LL.append(kodi_info(i))
	return LL



def country(c):
	param = {'include_null_first_air_dates':'false', 'sort_by':'popularity.desc', 'vote_count.gte':'3','vote_average.gte':'4', 'with_original_language':c}
	L=discover(param)['results']
	LL=[]
	for i in L:
		LL.append(kodi_info(i))
	return LL

def person(id):
	url = api_url+'/person/'+id+'/tv_credits?api_key='+api_key+'&language='+api_lang
	j=GET(url)
	L=JSON(j)['cast']
	LL=[]
	for i in L:
		LL.append(kodi_info(i))
	return LL

def person_list(id):
	url = api_url+'/tv/'+str(id)+'/credits?api_key='+api_key+'&language='+api_lang
	j=GET(url)
	L=JSON(j)['cast']
	LL=[]
	for i in L:
		LL.append({'id':i['id'],'title':i['name'],'cover':i['profile_path']})
	return LL

#id=new()[1]['id']
#print seasons(id)
#time.sleep(10)