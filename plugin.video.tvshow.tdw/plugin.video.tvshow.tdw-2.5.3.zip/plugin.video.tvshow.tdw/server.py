# coding: utf-8
# Module: server

import sys, time
import xbmc, xbmcgui, xbmcaddon
__settings__ = xbmcaddon.Addon(id='plugin.video.tvshow.tdw')
if __settings__.getSetting("test")!='1': __settings__.setSetting("test",'1')
import settings

print('----- tvshow.tdw server started -----')
start_trigger = False
xbmc.sleep(15000)
monitor = xbmc.Monitor()

while not monitor.abortRequested():
		tm = time.time()
		try: ctm = int(settings.get("check_tm"))
		except: ctm = 0
		if tm - ctm > 6*3600:
			xbmc.executebuiltin('RunPlugin("plugin://plugin.video.tvshow.tdw/?mode=check2")')
			settings.set("check_tm", tm)
		monitor.waitForAbort(5*60*60)


print('----- tvshow.tdw server stopped -----')

