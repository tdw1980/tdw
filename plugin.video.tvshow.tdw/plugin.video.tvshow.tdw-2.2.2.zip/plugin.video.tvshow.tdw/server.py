# coding: utf-8
# Module: server

import sys, time, settings
import xbmc, xbmcgui, xbmcaddon
__settings__ = xbmcaddon.Addon(id='plugin.video.tvshow.tdw')

print('----- tvshow.tdw server started -----')
start_trigger = False
xbmc.sleep(15000)

def abortRequested():
	if sys.version_info.major > 2: return xbmc.Monitor().abortRequested()
	else: return xbmc.abortRequested


while not abortRequested():
		tm = time.time()
		try: ctm = int(settings.get("check_tm"))
		except: ctm = 0
		if tm - ctm > 86400: 
			xbmc.executebuiltin('RunPlugin("plugin://plugin.video.tvshow.tdw/?mode=check2")')
			settings.set("check_tm", tm)
		for i in range(0, 6000):
				xbmc.sleep(3000)
				if abortRequested(): break

print('----- tvshow.tdw server stopped -----')

