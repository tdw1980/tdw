#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys, json, time

serv = 'https://lam.maxvol.pro/lite/'
D_UA='Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 OPR/77.0.4054.203'

if sys.version_info.major > 2:  # Python 3 or later
	import urllib.request
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
	from urllib.parse import urlencode
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2


def b2s(s):
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def is_libreelec():
	try:
		if os.path.isfile('/etc/os-release'):
			f = open('/etc/os-release', 'r')
			str = f.read()
			f.close()
			if "LibreELEC" in str and "Generic" in str: return True
	except: pass
	return False

def rt(s):
	if sys.version_info.major > 2: return s
	try:s=s.decode('utf-8')
	except: pass
	if not is_libreelec():
		try:s=s.decode('windows-1251')
		except: pass
	try:s=s.encode('utf-8')
	except: pass
	return s

def test_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False

def CRC32(buf):
		import binascii
		if sys.version_info.major > 2: buf = (binascii.crc32(buf.encode('utf-8')) & 0xFFFFFFFF)
		else: buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		r=str("%08X" % buf)
		return r

def add_ch(id, D):
	try:
		import settings
		settings.set(prov+str(len(serv))+'_ch_'+id, {'ch':D, 'tm': time.time()})
	except: pass


def get_ch(id):
	try:
		import settings
		Dch  = settings.get(prov+str(len(serv))+'_ch_'+id)
		D  = Dch['ch']
		tm = Dch['tm']
		if (time.time()-tm<3600*2): return D
		else: return None
	except:
		return None


def add_EXID(id, ex_id):
	try:
		import settings
		try: Dch  = settings.get('EX.db')
		except: Dch  = {}
		Dch[id] = ex_id
		settings.set('EX.db', Dch)
	except: pass


def get_EXID(id):
	try:
		import settings
		Dch  = settings.get('EX.db')
		ex_id  = Dch[id]
		return ex_id
	except:
		return None


def unlock(url):
	try:
		import xbmcaddon
		tam_settings = xbmcaddon.Addon(id='plugin.video.tam')
		tam_port = int(tam_settings.getSetting("serv_port"))
	except:
		tam_port = 8095
	url='http://127.0.0.1:'+str(tam_port)+'/proxy/'+url
	return url


def findall(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	if e=='': r2=r
	else: r2=r[:r.find(e)]
	return r2


def GET2(target, referer='', post=None):
		import requests
		s = requests.session()
		r=s.get(target, timeout=(0.6, 4), verify=False).text
		return r


def GET(target, referer='', post=None):
	print (target)
	urllib2.install_opener(urllib2.build_opener())
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', D_UA)
		resp = urllib2.urlopen(req, timeout = 10)
		http = resp.read()
		resp.close()
		return b2s(http)
	except:
		return GET2(target)

def is_libreelec():
	try:
		if os.path.isfile('/etc/os-release'):
			f = open('/etc/os-release', 'r')
			str = f.read()
			f.close()
			if "LibreELEC" in str and "Generic" in str: return True
	except: pass
	return False

def rt(s):
	if sys.version_info.major > 2: return s
	try:s=s.decode('utf-8')
	except: pass
	if not is_libreelec():
		try:s=s.decode('windows-1251')
		except: pass
	try:s=s.encode('utf-8')
	except: pass
	return s


def get_torrents(info={}):
	Lr=[]
	try:
		en_title = quote(info['originaltitle'])
		ru_title = quote(info['title'])
		year = str(info['year'])
		if '-' in year: year=year.split('-')[0]
		
		#try:imdb_id = str(info['imdb_id'])
		#except: imdb_id =''
		#try: kp_id = str(info['id'])
		#except: kp_id = ''
		
		#if imdb_id =='': imdb_id = get_imdb_id(kp_id)
		#if kp_id =='':   kp_id = get_kp_id(imdb_id)
		
		url='https://lam.maxvol.pro/api/v2.0/indexers/all/results?apikey=1&title='+ru_title+'&title_original='+en_title+'&year='+year+'&is_serial=2&Category[]=5000'
	except: 
		print ('err 1')
		return []
	#print (url)
	j=GET(url)
	try: D=json.loads(j)
	except: return []
	L = D['Results']
	Lout = []
	for i in L:
		try:
			sids=str(i['Seeders'])
			try: 
				size=(str(i['Size']/1024/1024/1024*8)[:4]+' Gb').replace('. Gb',' Gb')
				#size=size
			except: size=''
			title=i['Title']
			url=i['MagnetUri']
			try: quality=str(i['ffprobe'][0]['height'])
			except: quality=''
			Lout.append({"sids":sids, "size":size, "title":title, "url":url, "quality": quality})
		except:
			pass
	
	return Lout

#print (get_torrents({'id':'4365427','imdb_id':'tt13443470','title':'Уэнздей','originaltitle':'Wednesday','year':2022}))


class Tracker:
	def Search(self, info):
		id=info['id']
		Dc=get_ch(id)
		if Dc!=None: return Dc
		#print (info)
		Lout = []
		#if info['type']=='': Lout = get_movie(info)
		#else:                Lout = get_serial(info)
		Lout = get_torrents(info)
		if Lout != []: add_ch(id, Lout)
		return Lout
		
	def Episodes(self, url):
		id=CRC32(url)
		Dc=get_ch(id)
		if Dc!=None: return Dc
		
		Lout = []
		Lout = get_episodes(url)
		
		if Lout != []: add_ch(id, Lout)
		return Lout

