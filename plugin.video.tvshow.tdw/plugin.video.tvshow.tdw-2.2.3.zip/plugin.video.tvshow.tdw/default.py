#!/usr/bin/python
# -*- coding: utf-8 -*-

# *  Copyright (C) 2016 TDW

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, sys, time, uscode, xbmcvfs
import themoviedb
import settings
from nvsrc import*

if sys.version_info.major > 2:  # Python 3 or later
	import urllib.request
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote_plus as unquote
	import urllib2


PLUGIN_NAME   = 'tvfeed'
siteUrl = 'tvfeed.in'
httpSiteUrl = 'https://' + siteUrl
handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.tvshow.tdw')
__settings__ = xbmcaddon.Addon(id='plugin.video.tvshow.tdw')
xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')# movies
icon  = os.path.join( addon.getAddonInfo('path'), 'icon.png')

def xt(x):
	try: r = xbmc.translatePath(x)
	except: r = xbmcvfs.translatePath(x)
	return r

dbDir = os.path.join(xt("special://masterprofile/"),"addon_data","plugin.video.tvshow.tdw")


if __settings__.getSetting("antizapret2")=='true': themoviedb.antizapret = True

L_studio=['LostFilm', 'iTunes', 'Novamedia', 'Amedia', 'Пифагор', 'Кубик в кубе', 'Jaskier', 'NewStudio', 'IdeaFilm', 'Gears Media', 'AlexFilm', 'HDRezka', 'TVShows', 'OMSKBIRD', 'Good People', 'Profix Media', 'Mallorn', 'Lucky Production', 'HELLYWOOD', 'Generalfilm', 'New-Team', 'TUMBLER Studio', 'Baibako', 'Sunshine', 'Кураж-Бамбей', 'ColdFilm', 'Kerob', 'Octopus', 'AniDub', 'AniLibria', 'AniMedia', 'SHIZA project', 'KANSAI', 'AniFilm', 'AniPlague', 'Hamsterstudio', 'ViruseProject', 'VGM Studio', 'LakeFilms', 'NewStation', 'Flarrow Films', 'WestFilm', 'Ultradox', 'BigSinema', 'Jimmy J', 'LE-Production', 'Кравец', 'Jetvis', 'VSI Moscow', 'Невафильм', 'NovaFilm', 'FoxCrime', 'EniaHD']

def b2s(s):
	if err_torrent(s)==False: return s
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		if not is_libreelec():
			try:s=s.decode('windows-1251')
			except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def err_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False

def is_libreelec():
	try:
		if os.path.isfile('/etc/os-release'):
			f = open('/etc/os-release', 'r')
			str = f.read()
			f.close()
			if "LibreELEC" in str and "Generic" in str: return True
	except: pass
	return False


def CRC32(buf):
		import binascii
		if sys.version_info.major > 2: 
			try:buf = (binascii.crc32(buf.encode('utf-8')) & 0xFFFFFFFF)
			except:
				buf=repr(buf)
				buf = (binascii.crc32(buf.encode('utf-8')) & 0xFFFFFFFF)
		else:
			try:buf = (binascii.crc32(buf) & 0xFFFFFFFF)
			except:
				buf=repr(buf)
				buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		return str("%08X" % buf)

def CRC32_2(buf):
		import binascii
		if sys.version_info.major > 2: buf = (binascii.crc32(buf.encode('utf-8')) & 0xFFFFFFFF)
		else: buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		r=str("%08X" % buf)
		return r

Lthread=[]
LtID=''
def update_Lt(d, id):
	global Lthread, LtID
	if d == 'reset':
		Lthread=[]
		LtID = id
	elif LtID == id:
		Lthread.append(d)

from threading import Thread
class MyThread(Thread):
	def __init__(self, param):
		Thread.__init__(self)
		self.param = param
	
	def run(self):
		i=self.param['i']
		try:
			exec ("global skp; import "+i[:-3]+"; skp="+i[:-3]+".Tracker()")
			L = skp.Search(self.param['info'])
		except: 
			L=[]
		update_Lt(L, self.param['id'])

def create_thread(param):
		my_thread = MyThread(param)
		my_thread.start()


def add_ch(info, Lt):
	deb_print('=== add_ch ===')
	SID = 'lst'+str(CRC32(info['originaltitle']))
	if len(Lt)<5:
		try:
			D=eval(settings.get(SID))
			L=D['list']
		except:
			D={}
			L=[]
	else:
			D={}
			L=[]
	#upd=False
	for i in Lt:
		if i not in L: 
			L.append(i)
			#upd=True
	#if upd:
	D['list'] = L
	D['tm']=time.time()
	settings.set(SID, repr(D))


def get_ch(info):
	SID = 'lst'+str(CRC32(info['originaltitle']))
	try:
		D  = eval(settings.get(SID))
		L  = D['list']
		tm = D['tm']
	except:
		D={}
		L=[]
		tm=0
	return {'tm':tm, 'list':L}


def add_td(url, L, ttl=''):
	deb_print('=== add_td ===')
	SID = 'td'+str(CRC32(url))
	D={}
	D['list'] = L
	D['tm']=time.time()
	D['ttl']=ttl
	settings.set(SID, repr(D))


def get_td(url, ttl=''):
	try:
		SID = 'td'+str(CRC32(url))
		D  = eval(settings.get(SID))
		L  = D['list']
		tm = D['tm']
		try:   ott = D['ttl']
		except:ott =''
		if (ott!='' and ott == ttl) or ttl == 'fast' or (time.time()-tm<3600*3) or ('magnet:' in url): return L
		else: return None
	except:
		return None

def get_magnet_hash(url):
	if 'magnet:' in url: 
		url += '&'
		hash=url[url.find('btih:')+5:url.find('&')].lower()
	else: hash = ''
	return  hash
#======================== стандартные функции ==========================
def fs_dec(path):
	try:
		sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
		return path.decode(sys_enc).encode('utf-8')
	except:
		return path

def fs_enc(path):
	path=xt(path)
	sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
	try:path2=path.decode('utf-8')
	except: pass
	try:path2=path2.encode(sys_enc)
	except: 
		try: path2=path2.encode(sys_enc)
		except: path2=path
	return path2

def fs(s):return s.decode('windows-1251').encode('utf-8')
def win(s):return s.decode('utf-8').encode('windows-1251')
def ru(x):return unicode(x,'utf8', 'ignore')
def rt(x):#('&#39;','’'), ('&#145;','‘')
	L=[('&amp;',"&"),('&#133;','…'),('&#38;','&'),('&#34;','"'), ('&#39;','"'), ('&#145;','"'), ('&#146;','"'), ('&#147;','“'), ('&#148;','”'), ('&#149;','•'), ('&#150;','–'), ('&#151;','—'), ('&#152;','?'), ('&#153;','™'), ('&#154;','s'), ('&#155;','›'), ('&#156;','?'), ('&#157;',''), ('&#158;','z'), ('&#159;','Y'), ('&#160;',''), ('&#161;','?'), ('&#162;','?'), ('&#163;','?'), ('&#164;','¤'), ('&#165;','?'), ('&#166;','¦'), ('&#167;','§'), ('&#168;','?'), ('&#169;','©'), ('&#170;','?'), ('&#171;','«'), ('&#172;','¬'), ('&#173;',''), ('&#174;','®'), ('&#175;','?'), ('&#176;','°'), ('&#177;','±'), ('&#178;','?'), ('&#179;','?'), ('&#180;','?'), ('&#181;','µ'), ('&#182;','¶'), ('&#183;','·'), ('&#184;','?'), ('&#185;','?'), ('&#186;','?'), ('&#187;','»'), ('&#188;','?'), ('&#189;','?'), ('&#190;','?'), ('&#191;','?'), ('&#192;','A'), ('&#193;','A'), ('&#194;','A'), ('&#195;','A'), ('&#196;','A'), ('&#197;','A'), ('&#198;','?'), ('&#199;','C'), ('&#200;','E'), ('&#201;','E'), ('&#202;','E'), ('&#203;','E'), ('&#204;','I'), ('&#205;','I'), ('&#206;','I'), ('&#207;','I'), ('&#208;','?'), ('&#209;','N'), ('&#210;','O'), ('&#211;','O'), ('&#212;','O'), ('&#213;','O'), ('&#214;','O'), ('&#215;','?'), ('&#216;','O'), ('&#217;','U'), ('&#218;','U'), ('&#219;','U'), ('&#220;','U'), ('&#221;','Y'), ('&#222;','?'), ('&#223;','?'), ('&#224;','a'), ('&#225;','a'), ('&#226;','a'), ('&#227;','a'), ('&#228;','a'), ('&#229;','a'), ('&#230;','?'), ('&#231;','c'), ('&#232;','e'), ('&#233;','e'), ('&#234;','e'), ('&#235;','e'), ('&#236;','i'), ('&#237;','i'), ('&#238;','i'), ('&#239;','i'), ('&#240;','?'), ('&#241;','n'), ('&#242;','o'), ('&#243;','o'), ('&#244;','o'), ('&#245;','o'), ('&#246;','o'), ('&#247;','?'), ('&#248;','o'), ('&#249;','u'), ('&#250;','u'), ('&#251;','u'), ('&#252;','u'), ('&#253;','y'), ('&#254;','?'), ('&#255;','y'), ('&laquo;','"'), ('&raquo;','"'), ('&nbsp;',' ')]
	for i in L:
		try:x=x.replace(i[0], i[1])
		except: pass
	try: x=uscode.decode(x)
	except: pass
	return x

def to_utf(s):
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
	else:
		try:s=s.encode('utf-8')
		except: pass
	return s

def lower_old(s):
	try:s=s.decode('utf-8')
	except: pass
	#try:s=s.decode('windows-1251')
	#except: pass
	try:s=s.lower()
	except: pass
	try:s=s.encode('utf-8')
	except: pass
	return s

def lower(t):
	t=t.lower()
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in range (65,90):
		t=t.replace(chr(i),chr(i+32))
	for i in RUS.keys():
		t=t.replace(i,RUS[i])
	return t

def mid(s, n):
	if sys.version_info.major > 2:
		s=s.center(n)
	else:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		s=s.center(n)
		try:s=s.encode('utf-8')
		except: pass
	return s

def mids(s, n):
	l="                                              "
	s=l[:n-len(s)]+s+l[:n-len(s)]
	return s

def FC(s, color="FFFFFF00"):
	s="[COLOR "+color+"]"+s+"[/COLOR]"
	return s

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "wb")
	fl.write(s)
	fl.close()

def deb_print(s):
	if __settings__.getSetting("DebMod")=='true': print (s)

def inputbox():
	skbd = xbmc.Keyboard()
	skbd.setHeading('Поиск:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return ""

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

#============================== основная часть ============================
def get_time():
	try:
		tm = xbmc.Player().getTime()
		if tm < 0 or tm == None: tm = 0
	except:
		tm = 0
	return 0

def GET(url,Referer = 'https://tvfeed.in', XML = False):
	deb_print (url)
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'KODI')#'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60'
		req.add_header('Accept', '*/*')
		req.add_header('Accept-Language', 'ru,en;q=0.9')
		req.add_header('Referer', Referer)
		if XML: req.add_header('X-Requested-With', 'XMLHttpRequest')
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
	except:
		deb_print ('ERR: недоступно')
		return ''


def get_params(params=''):
	param=[]
	if params=='': params=sys.argv[2]
	if len(params)>=2:
		deb_print (params)
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param



import sqlite3 as db
db_name = os.path.join( dbDir, "info.db" )
c = db.connect(database=db_name)
cu = c.cursor()
def add_to_db(n, item):
		deb_print ('TS add_to_db '+n)
		item=item.replace("'","XXCC").replace('"',"XXDD")
		err=0
		tor_id="n"+n.replace('-','')
		deb_print (tor_id)
		litm=str(len(item))
		try:
			cu.execute("CREATE TABLE "+tor_id+" (db_item VARCHAR("+litm+"), i VARCHAR(1));")
			c.commit()
			deb_print ('KP add_to_db CREATE TABLE '+tor_id)
		except: 
			err=1
			deb_print ("Ошибка БД"+ n)
		if err==0:
			cu.execute('INSERT INTO '+tor_id+' (db_item, i) VALUES ("'+item+'", "1");')
			c.commit()
			deb_print ('TS add_to_db INSERT INTO '+tor_id)
			#c.close()

def get_inf_db(n):
		deb_print ('TS get_inf_db '+n)
		tor_id="n"+n.replace('-','')
		cu.execute(str('SELECT db_item FROM '+tor_id+';'))
		c.commit()
		deb_print ('TS get_inf_db SELECT '+tor_id)
		Linfo = cu.fetchall()
		info=Linfo[0][0].replace("XXCC","'").replace("XXDD",'"')
		deb_print ('TS get_inf_db return_info OK')
		return info

def rem_inf_db(n):
		deb_print ('TS rem_inf_db '+n)
		tor_id="n"+n.replace('-','')
		try:
			cu.execute("DROP TABLE "+tor_id+";")
			c.commit()
			deb_print ('TS rem_inf_db DROP TABLE '+n)
		except: pass


def update_info(id):
	rem_inf_db(id)
	xbmc.executebuiltin('Container.Refresh')


def get_labels(info):
	Linf=['genre', 'year', 'rating', 'cast', 'director', 'plot', 'title', 'originaltitle', 'studio']
	Labels={}
	for inf in Linf:
		try:Labels[inf] = info[inf]
		except: pass
	try:Labels['duration'] = str(int(info['duration'])*60)
	except: pass
	return Labels


def AddItem(Title = "", mode = "", id='0', info={}, total=100, icon=icon):
			if info!={}:
				try:    cover = 'https://image.tmdb.org/t/p/w300'+info["cover"]
				except: cover = icon
				try:    fanart = 'https://image.tmdb.org/t/p/w1280'+info["fanart"]
				except: fanart = cover
				#if __settings__.getSetting("antizapret2")=='true':
				#	cover='http://127.0.0.1:8095/proxy/'+cover
				#	fanart='http://127.0.0.1:8095/proxy/'+fanart
				#el
				if __settings__.getSetting("antizapret3")=='true':
					cover=cover.replace('image.tmdb.org','image-tmdb-org.translate.goog')
					fanart=fanart.replace('image.tmdb.org','image-tmdb-org.translate.goog')
			else:
				cover = icon
				fanart = icon
				info={'id':id}
			
			
			
			if mode=="OpenTorrent" and __settings__.getSetting("DebMod")=='true':
					if 'magnet:' in id: cover = os.path.join( addon.getAddonInfo('path'), 'U.png')
					else:				cover = os.path.join( addon.getAddonInfo('path'), 'T.png')
			
			try:listitem = xbmcgui.ListItem(Title, iconImage=cover, thumbnailImage=cover)
			except:listitem = xbmcgui.ListItem(Title)
			listitem.setInfo(type = "Video", infoLabels = get_labels(info))
			try: listitem.setArt({ 'poster': cover, 'fanart' : fanart, 'thumb': cover, 'icon': cover})
			except: pass
			listitem.setProperty('fanart_image', fanart)
			
			purl = sys.argv[0] + '?mode='+mode+'&id='+str(id)+'&info='+repr(info)
			
			if mode=="OpenTorrent":
				infoLabels = get_labels(info)
				infoLabels["cover"]=cover
				infoLabels["fanart"]=fanart
				le=['','ace', 't2http', 'yatp', 'torrenter', 'elementum', 'xbmctorrent', 'ace_proxy', 'quasar', 'torrserver']
				tengine = le[int(__settings__.getSetting("TAMengine"))]
				purl='plugin://plugin.video.tam/?mode=open&url='+quote(id)+ '&info='+quote(repr(infoLabels))+ '&engine='+tengine#+ '&purl='+urllib.quote_plus(pu)
				sign = info['sign']
				season=info['season']
				sid=info['id']
				listitem.addContextMenuItems([('[B]Предпочитать[/B]', 'Container.Update("plugin://plugin.video.tvshow.tdw/?mode=SET&id='+str(sid)+ '&sign='+str(sign)+ '&season='+str(season)+'")'),])
			if mode=="Episodes" or mode=="Episodes2":
				try:Fav=eval(__settings__.getSetting("Favorites"))
				except: Fav=[]
				try:Chk=eval(__settings__.getSetting("Checker"))
				except: Chk=[]
				
				Context=[
					('[B]Похожие[/B]',          'Container.Update("plugin://plugin.video.tvshow.tdw/?mode=Similar&id='+str(id)+'")'),
					('[B]Персоны[/B]',          'Container.Update("plugin://plugin.video.tvshow.tdw/?mode=Persons&id='+str(id)+'")'),
					('[B]Отслеживать в ТС[/B]', 'Container.Update("plugin://plugin.video.tvshow.tdw/?mode=TC2&id='+str(id)+'")'),
					('[B]Сохранить сериал[/B]', 'Container.Update("plugin://plugin.video.tvshow.tdw/?mode=Save&id='+str(id)+'")'),
					]
				if id in Fav: 	Context.append(('[B]Удалить из избранного[/B]', 'Container.Update("plugin://plugin.video.tvshow.tdw/?mode=REM&id='+str(id)+'")'))
				else: 			Context.append(('[B]В избранное[/B]', 'Container.Update("plugin://plugin.video.tvshow.tdw/?mode=ADD&id='+str(id)+'")'))
				if id in Chk: 	Context.append(('[B]Не отслеживать[/B]', 'Container.Update("plugin://plugin.video.tvshow.tdw/?mode=REM_CK&id='+str(id)+'")'))
				else: 			Context.append(('[B]Отслеживать в TVShow[/B]', 'Container.Update("plugin://plugin.video.tvshow.tdw/?mode=ADD_CK&id='+str(id)+'")'))
				
				listitem.addContextMenuItems(Context)
			if mode=="Serials":
				listitem.addContextMenuItems([('[B]Обновить список сериалов[/B]', 'Container.Update("plugin://plugin.video.tvfeed/?mode=Update")')])
			if mode=="Play":
				listitem.setProperty('IsPlayable', 'true')
				#purl = sys.argv[0] + '?mode=Autoplay&id='+id
				xbmcplugin.addDirectoryItem(handle, purl, listitem, False, total)
			else:
				xbmcplugin.addDirectoryItem(handle, purl, listitem, True, total)

def AddEpisode(Title = "", mode = "", SID='', info={}, total=100):
			id=info['id']
			ep=info['episode']
			try:    cover =  'https://image.tmdb.org/t/p/w300'+info["cover"]
			except: cover =  ''
			try:    fanart = 'https://image.tmdb.org/t/p/w300'+info["thumb"]
			except: fanart = icon
			
			#if __settings__.getSetting("antizapret2")=='true':
			#		cover='http://127.0.0.1:8095/proxy/'+cover
			#		fanart='http://127.0.0.1:8095/proxy/'+fanart
			#el
			if __settings__.getSetting("antizapret3")=='true':
					cover=cover.replace('image.tmdb.org','image-tmdb-org.translate.goog')
					fanart=fanart.replace('image.tmdb.org','image-tmdb-org.translate.goog')

			if cover == '' : cover=fanart
			
			try: listitem = xbmcgui.ListItem(Title, iconImage=cover, thumbnailImage=cover)
			except: listitem = xbmcgui.ListItem(Title)
			listitem.setInfo(type = "Video", infoLabels = info)
			try: listitem.setArt({ 'poster': cover, 'fanart' : cover, 'thumb': cover, 'icon': cover})
			except: pass
			listitem.setProperty('fanart_image', fanart)
			purl = sys.argv[0] + '?mode='+mode+'&id='+str(SID)+'&ind='+str(ep)+'&info='+repr(info)
			#if url !="": purl = purl +'&url='+str(SID)
			
			try:type=info["type"]
			except:type=''
			#if __settings__.getSetting("Autoplay")=='true': 
			listitem.setProperty('IsPlayable', 'true')
			listitem.addContextMenuItems([
										('[B]Найти сезон[/B]', 'Container.Update("plugin://plugin.video.tvshow.tdw/?mode=Season&id='+str(SID)+'&info='+repr(info)+'")'),
										('[B]Найти эпизод[/B]', 'Container.Update("plugin://plugin.video.tvshow.tdw/?mode=Ep_list&id='+str(SID)+'&ind='+str(ep)+'&info='+repr(info)+'")'),
										('[B]Настройки ТАМ[/B]', 'RunPlugin("plugin://plugin.video.tvshow.tdw/?mode=Open_TAM_Settings")'),
										])
			xbmcplugin.addDirectoryItem(handle, purl, listitem, False, total)
			#else:
			#		purl = sys.argv[0] + '?mode=Season&id='+str(SID)+'&info='+repr(info)
			#		xbmcplugin.addDirectoryItem(handle, purl, listitem, True, total)

def get_info(ID):
	ID=str(ID)
	try:
			info=eval(xt(get_inf_db(ID)))
			deb_print ('KP get_info ОК')
			return info
	except:
			try:
				info = themoviedb.get_info(ID)
				deb_print(info)
			except: 
				return {"title": ID, "originaltitle":ID, "rating":0, "cover":icon, "type":'', "id":ID}
			try:
				deb_print("ADD: " + ID)
				add_to_db(ID, repr(info))
			except:
				deb_print ("ERR: " + ID)
			deb_print ('return info')
			return info

def mont2num(dt):
	L1=[' января ',' февраля ',' марта ',' апреля ',' мая ',' июня ',' июля ',' августа ',' сентября ',' октября ',' ноября ',' декабря ']
	L2=['.01.','.02.','.03.','.04.','.05.','.06.','.07.','.08.','.09.','.10.','.11.','.12.']
	for i in range (0,12):
		dt=dt.replace(L1[i], L2[i])
	return dt

#=============================  Menu  ==============================
def Root():
	if __settings__.getSetting("m1")=='true': AddItem("[B]Поиск[/B]", "Search")
	if __settings__.getSetting("m2")=='true': AddItem("[B]Навигатор[/B]", "Navigator")
	if __settings__.getSetting("m3")=='true': AddItem("Новинки", "New")
	if __settings__.getSetting("m4")=='true': AddItem("Популярные", "Popular")
	if __settings__.getSetting("m5")=='true': AddItem("Лучшие", "Top")
	if __settings__.getSetting("m6")=='true': AddItem("Жанры", "Genres")
	if __settings__.getSetting("m7")=='true': AddItem("Теги", "Tags")
	if __settings__.getSetting("m8")=='true': AddItem("Год", "Years")
	if __settings__.getSetting("m9")=='true': AddItem("В эфире", "On_air")
	if __settings__.getSetting("m10")=='true': AddItem("Популярное в эфире", "On_air2")
	if __settings__.getSetting("m11")=='true': AddItem("Подборки", "Collection")
	if __settings__.getSetting("m12")=='true': AddItem("Отслеживаемые", "Checker")
	if __settings__.getSetting("m13")=='true': AddItem("Избранное", "Favorites")
	__settings__.setSetting("LLL", '')
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

def Search():
	q=inputbox()
	if q=='': return
	L=themoviedb.search(q)
	for info in L:
		id = info['id']
		AddItem(info['title'], "Episodes", id, info, len(L))

def Serials():
	L=eval(get_inf_db('tvfeed'))
	n=0
	for id in L:
		n+=1
		#if n>30: return
		info=get_info(id)
		AddItem(info['title'], "Episodes", id, '', len(L))

def Similar(id):
	L=themoviedb.similar(id)
	for info in L:
		id = info['id']
		AddItem(info['title'], "Episodes", id, info, len(L))

def Genres():
	L=themoviedb.get_genre_list()
	AddItem('аниме', "Genre", 'anime')
	for info in L:
		#print ("'"+info['name']+"':'"+str(info['id'])+"'")
		AddItem(lower(info['name']), "Genre", info['id'], {}, len(L))

def Genre(gid):
	L=themoviedb.get_genre(gid)
	for info in L:
		id = info['id']
		AddItem(info['title'], "Episodes", id, info, len(L))

def Collection():
	L=themoviedb.collection_list()
	for info in L:
		deb_print (info)
		AddItem(info['title'], "Collect", info['id'])

def Collect(cid):
	L=themoviedb.collection(cid)
	for info in L:
		#if not (info['plot']=='' and info['title']==info['originaltitle']):
			id = info['id']
			AddItem(info['title'], "Episodes", id, info, len(L))

def On_air():
	L=themoviedb.on_the_air()
	try:Lf=eval(__settings__.getSetting("Favorites"))
	except:Lf=[]
	for info in L:
		id = info['id']
		if str(id) in Lf: AddItem('[B]'+info['title']+'[/B]', "Episodes", id, info, len(L))
	
	for info in L:
		id = info['id']
		if str(id) not in Lf: AddItem(info['title'], "Episodes", id, info, len(L))

def On_air2():
	L=themoviedb.on_the_air2()
	try:Lf=eval(__settings__.getSetting("Favorites"))
	except:Lf=[]
	for info in L:
		id = info['id']
		if str(id) in Lf: AddItem('[B]'+info['title']+'[/B]', "Episodes", id, info, len(L))
	
	for info in L:
		id = info['id']
		if str(id) not in Lf: AddItem(info['title'], "Episodes", id, info, len(L))

def New():
	L=themoviedb.new()
	for info in L:
		if not (info['plot']=='' and info['title']==info['originaltitle']):
			id = info['id']
			AddItem(info['title'], "Episodes", id, info, len(L))

def Top():
	L=themoviedb.top()
	for info in L:
		id = info['id']
		AddItem(info['title'], "Episodes", id, info, len(L))

def Popular():
	L=themoviedb.popular()
	for info in L:
		id = info['id']
		AddItem(info['title'], "Episodes", id, info, len(L))

def Years():
	L=range(1980, 2022)
	L.reverse()
	for i in L:
		AddItem(str(i), "Year", i)

def Year(y):
	L=themoviedb.year(y)
	for info in L:
		id = info['id']
		AddItem(info['title'], "Episodes", id, info, len(L))

def Tag(id):
	L=themoviedb.tag(id)
	for info in L:
		id = info['id']
		AddItem(info['title'], "Episodes", id, info, len(L))

def Tags():
	for i in themoviedb.tag_list:
		AddItem(i['name'], "Tag", i['id'])

def Persons(id):
	L=themoviedb.person_list(id)
	for i in L:
		AddItem(i['title'], "Person", i['id'], i)

def Person(id):
	L=themoviedb.person(id)
	for info in L:
		id = info['id']
		AddItem(info['title'], "Episodes", id, info, len(L))


def Episodes(id, ret=False):
	if __settings__.getSetting("TranslateEp")=='true':  trl = True
	else: 												trl = False
	Ls=themoviedb.seasons(id)
	Lr=[]
	for s_info in Ls:
		season=s_info['season']
		if season > 0:
			if ret==False: AddItem('[COLOR FF22FF22] '+str(season)+' сезон[/COLOR]', "Season", id, s_info, len(Ls))
			#else: Lr.append(s_info)
			Le=themoviedb.episodes(id, season, trl)
			s_info['episodes']=Le
			if ret==True: Lr.append(s_info)
			for info in Le:
					deb_print(info)
					title=str(info['season'])+'x'+str(info['episode'])+"  "+info['title']
					try:
						premiered = int(info['premiered'].replace('-',''))
						crdate = int(time.strftime('%Y%m%d'))
						if premiered>crdate: title = '[COLOR AA606060]'+title+'[/COLOR]'
					except: pass
					
					if ret==False: AddEpisode(title, "Play", id, info, len(Le))
	return Lr

def Episodes2(id, s):
	if __settings__.getSetting("TranslateEp")=='true':  trl = True
	else: 												trl = False
	Ls=themoviedb.seasons(id)
	Lr=[]
	for s_info in Ls:
		season=s_info['season']
		if season == s:
			Le=themoviedb.episodes(id, season, trl)
			for info in Le:
					deb_print(info)
					title=str(info['season'])+'x'+str(info['episode'])+"  "+info['title']
					try:
						premiered = int(info['premiered'].replace('-',''))
						crdate = int(time.strftime('%Y%m%d'))
						if premiered>crdate: title = '[COLOR FFFF2020]'+title+'[/COLOR]'
					except: pass
					
					AddEpisode(title, "Play", id, info, len(Le))

def Seasons(id):
	Ls=themoviedb.seasons(id)
	if len(Ls)==1: return Episodes(id)
	if len(Ls)==2: 
		if Ls[0]['season']==0: return Episodes(id)
	Lr=[]
	for s_info in Ls:
		season=s_info['season']
		if season > 0:
			AddItem('[COLOR FF22FF22] '+str(season)+' сезон[/COLOR]', "Episodes2", id, s_info, len(Ls))



def Season(id, info, additm=True):
	season=info['season']
	mod_st=int(__settings__.getSetting('Studio'))
	inf=themoviedb.get_info(id)
	sel=get_select(id, season)
	L=find_season(id, season)
	L2=[]
	Lu=[]
	pDialog = xbmcgui.DialogProgressBG()
	try:pDialog.create('Season '+str(season), 'Поиск ...')
	except: pass

	for n in range(7):
		if 0<n<5 and mod_st!=0:
			n_std = int(__settings__.getSetting('Studio'+str(n)))
			studio=L_studio[n_std]
		else:
			studio=''
		
		for i in L:
			pDialog.update(int(len(Lu)*100/len(L)), message=i['url'].replace('http://127.0.0.1:8095/proxy/',''))
			sign = get_sign(i)
			enable=False
			i_std=i['studio']
			if studio=='':
				if n==0:
					if sign == sel:	enable=True
					else: 			enable=False
				elif n==5:
					if i_std!='': 	enable=True
					else: 			enable=False
				else:				enable=True
			else:
				if i_std=='': i_std='?'
				if i_std == studio: enable=True
			
			if enable and i['url'] not in Lu:
				if 0<n<5:
					if '0' not in i['quality']: 
						if 'magnet:' in i['url']: 	q2 = get_label2(i['url'])#, force=True)
						else: 						q2 = get_label2(i['url'], force=True)
					else: q2='?'
					if '?' not in q2: 
						i['quality']=q2
						if filtr(i)==False: i['quality']=q2.replace('[COLOR F','[COLOR 4')
				
				if __settings__.getSetting("DebMod")=='true': 
					sep = str(get_episodes(i['title']))
					title=sep+' |'+str(n)+' |'+sign + i['quality']+" "+mid(i['size'],10)+" "+i['season']+" "+i['studio']+" [COLOR FFC0C0C0]"+rt(i['title'])+"[/COLOR]"#q2+" "+
				else: 
					try:
						c_ttl = i['title'].replace(inf['title'],'').replace(inf['originaltitle'],'').replace(i['studio'],'').replace('()','').replace('/','').replace('  ',' ').replace('  ',' ')
						title=i['quality']+" "+mids(i['season'], 8)+" "+mid(i['size'],10)+" "+mids(i['sids'], 6)+" [B]"+i['studio']+"[/B] | "+rt(c_ttl)#i['title']
					except:
						title='Error'
				if n==0:                title='[COLOR EFFF7711]'+title+'[/COLOR]'
				if 0<n<5 and mod_st!=0: title='[COLOR EF22FF22]'+title+'[/COLOR]'
				
				inf['sign'] = sign
				inf['season']= season
				inf['id']= id
				i['priority']= n
				i['sign'] = sign
				if additm: AddItem(title, "OpenTorrent", i['url'], inf)
				L2.append(i)
				Lu.append(i['url'])
				
				#if n<1:
				#	purl = sys.argv[0] + '?mode=Torrent_Directory&url='+quote(i['url'])+'&info='+repr(info)+'&name='+quote(i['title'])
				#	xbmc.executebuiltin('RunPlugin("'+purl+'")')
	pDialog.update(100, '')
	pDialog.close()
	
	return L2


#===================================================================

def Play(id, info, strm=False):
	
	pDialog = xbmcgui.DialogProgressBG()
	
	deb_print ('===PLAY===')
	s=info['season']
	sz=str(s)
	if len (sz)<2: sz='0'+sz
	deb_print (sz)
	
	e=info['episode']
	ep=str(e)
	if len (ep)<2: ep='0'+ep
	deb_print (ep)
	
	if __settings__.getSetting('Autoplay') == 'false': 
				purl='plugin://plugin.video.tvshow.tdw/?mode=Ep_list&id='+str(id)+'&ind='+str(e)+'&info='+repr(info)
				xbmc.executebuiltin('Container.Update("'+purl+'")')
				return False
	
	lpu=get_last_played(id, s)
	if lpu!='': 
		stream = find_stream(lpu, s, e)
		url=lpu
		tor_title = get_last_played_ttl(id, s)
	else: 
		stream = ''
		tor_title = ''
	
	try:pDialog.create('S'+sz+'E'+ep, 'Поиск серии ...')
	except: pass
	
	if stream == '':
		L=Season(id, info, False)
		Lt = []
		Ls = []
		for t in L:
			deb_print (t)
			xbmc.executebuiltin('RunPlugin("plugin://plugin.video.tvshow.tdw/?mode=Torrent_Directory&url='+quote(t['url'])+ '&name=' + quote(rt(t['title']))+'")')
			
			if t['priority']==0: Ls.append(t)
			if t['priority'] <4: Lt.append(t)
		
		
		
		
		ret = False
		if Lt==[]: 
			if __settings__.getSetting('Studio') == '3' or __settings__.getSetting('Studio') == '1': 
				pDialog.update(100, '')
				pDialog.close()
				purl='plugin://plugin.video.tvshow.tdw/?mode=Ep_list&id='+str(id)+'&ind='+str(e)+'&info='+repr(info)
				xbmc.executebuiltin('Container.Update("'+purl+'")')
				return False
		'''
			if __settings__.getSetting('Studio') == '1': 
				showMessage('TVShow', 'Нет нужной озвучки')
				pDialog.update(100, '')
				pDialog.close()
				return
			elif __settings__.getSetting('Studio') == '3': 
				dialog = xbmcgui.Dialog()
				ret = dialog.yesno('Нет предпочитаемой озвучки.', 'Искать с другим переводом?')
				if ret==False: 
					pDialog.update(100, '')
					pDialog.close()
					return
		'''
		n=0
		L3=[]
		L4=[]
		
		for t in L:
			ep_total = get_episodes(t['title'])
			if ep_total == 0 or ep_total >= e:
				if __settings__.getSetting('Studio') == '1': 
					if t not in Lt:
						showMessage('TVShow', 'Нет нужной озвучки')
						pDialog.update(100, '')
						pDialog.close()
						purl='plugin://plugin.video.tvshow.tdw/?mode=Ep_list&id='+str(id)+'&ind='+str(e)+'&info='+repr(info)
						xbmc.executebuiltin('Container.Update("'+purl+'")')
						return False
				
				'''
				if __settings__.getSetting('Studio') == '3':
					if t not in Lt and ret == False:
						dialog = xbmcgui.Dialog()
						ret = dialog.yesno('Нет предпочитаемой озвучки.', 'Искать с другим переводом?')
						if ret==False: 
							pDialog.update(100, '')
							pDialog.close()
							return
				'''
				
				if __settings__.getSetting('Studio') == '3': 
					if t not in Lt:
						pDialog.update(100, '')
						pDialog.close()
						purl='plugin://plugin.video.tvshow.tdw/?mode=Ep_list&id='+str(id)+'&ind='+str(e)+'&info='+repr(info)
						xbmc.executebuiltin('Container.Update("'+purl+'")')
						return False
				
				n+=1
				url=t['url']
				pDialog.update(int(n*100/len(L)), message=url.replace('http://127.0.0.1:8095/proxy/',''))
				tor_title=t['studio']+" | "+rt(t['title'])
				
				L2 = get_torrent_directory(url, t_title=rt(t['title']))
				if len(L2) >= e and '-' not in t['season']: L3.append(url)
				deb_print ('==== s'+sz+'e'+ep+' ====')
				for i in L2:
					L4.append(i)
					deb_print (i['label'].lower())
					#pDialog.update(int(n*100/len(L)), message=i['label'])
					#if 's'+sz in i['label'].lower() or 's'+str(s)+'e' in i['label'].lower():
					if 's'+sz in i['label'].lower() or s==1:
						if find_episode(e, i['label']):
							stream = i['file']
							sign = get_sign(t)
							if get_select(id, s) !=sign: set_select(id, s, sign)
							if get_last_played(id, s) !=sign: set_last_played(id, s, url, tor_title)
							deb_print (stream)
							deb_print ('==============')
						if stream !='': break
				
				if stream !='': break
	
	if stream =='' and s==1:
		for i in L4:
				if find_episode(e, i['label']): stream = i['file']
				if stream !='': break
	
	
	if stream =='' and __settings__.getSetting("index") == 'true' and L3!=[]:
		url = L3[0]
		L2 = get_torrent_directory(url)
		stream = L2[e-1]['file']
	
	if __settings__.getSetting("NoAD")=='true':
		try: AD = test_AD(tor_title)
		except: AD = False
		if AD: stream = stream + '&ad=1'
	
	deb_print ('STREAM:'+stream)
	pDialog.update(100, message=stream)
	pDialog.close()
	if stream =='': return
	
	tam_history(url, get_info(id))# в историю
	
	item = xbmcgui.ListItem(path=stream)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	
	if strm:
		ply = False
		for i in range(15):
				xbmc.sleep(1000)
				if xbmc.Player().isPlaying() and get_time()>0: 
					ply = True
					break
		
		if ply == False:
			purl='plugin://plugin.video.tvshow.tdw/?mode=Ep_list&id='+str(id)+'&ind='+str(e)+'&info='+repr(info)
			xbmc.executebuiltin('Container.Update("'+purl+'")')
			return False
	
	
	return True
	
	'''
	if __settings__.getSetting("NoAD")=='true':
		deb_print('==NoAD=1=')
		ADL=__settings__.getSetting("ADList").split(',')
		deb_print(tor_title)
		AD = test_AD(tor_title)
		if AD == False: return
		
		deb_print('==NoAD=2=')
		Player=xbmc.Player()
		for t in range(25):
			deb_print('==NoAD== '+str(t))
			xbmc.sleep(1000)
			if xbmc.Player().isPlaying():
				deb_print('==NoAD isPlaying==')
				break
		
		deb_print('==NoAD PlFile==')
		for t in range(25):
			xbmc.sleep(1000)
			try: PlFile=Player.getPlayingFile()
			except: PlFile=''
			try: PlTime=Player.getTime()
			except: PlTime=0
			deb_print('PlFile '+PlFile)
			if PlFile!='' and PlTime>0:
				xbmc.sleep(1000)
				deb_print('==NoAD seekTime==')
				Player.seekTime(35)
				break
	'''

def test_AD(tor_title):
		ADL=__settings__.getSetting("ADList").split(',')
		AD=False
		deb_print(tor_title)
		for ad in ADL:
			deb_print(ad)
			if ad.strip() in tor_title: AD=True
		return AD


def find_stream(url, s, e):
		sz=str(s)
		if len (sz)<2: sz='0'+sz
		stream = ''
		L2 = get_torrent_directory(url)
		for i in L2:
			if 's'+sz in i['label'].lower() or 's'+str(s)+'e' in i['label'].lower():
				if find_episode(e, i['label']):
					stream = i['file']
				if stream !='': break
		return stream

def Ep_list(id, info, fast=True):
	pDialog = xbmcgui.DialogProgressBG()
	
	deb_print ('===Ep_list===')
	s=info['season']
	sz=str(s)
	if len (sz)<2: sz='0'+sz
	deb_print (sz)
	
	e=info['episode']
	ep=str(e)
	if len (ep)<2: ep='0'+ep
	deb_print (ep)
	
	
	stream = ''
	L=Season(id, info, False)
	n=0
	deb_print ('==== s'+sz+'e'+ep+' ====')
	try:pDialog.create('S'+sz+'E'+ep, 'Поиск серии ...')
	except: pass
	
	Lt=[]
	Lm=[]
	for t in L:
		ep_total = get_episodes(t['title'])
		if ep_total == 0 or ep_total >= e:
			if 'magnet:' in t['url'] and t['priority']>4: 	Lm.append(t)
			else: 											Lt.append(t)
	
	nt=0
	for t in L:
		nt+=1
		if nt>0:
			if get_td(t['url'], 'fast')==None:
				xbmc.executebuiltin('RunPlugin("plugin://plugin.video.tvshow.tdw/?mode=Torrent_Directory&url='+quote(t['url'])+ '&name=' + quote(rt(t['title']))+'")')
				xbmc.sleep(100)
	
	if fast==False or len(Lt)<10: 
		Lt.extend(Lm)
	else: 
		for t in Lm:
			priority = t['priority']
			if priority <= 5: Lt.append(t)
	
	L3 = []
	Lh = []
	skp = 0
	for t in Lt:
			#try:
			n+=1
			url=t['url']
			#hash=get_torrent_hash(url)
			#if hash not in Lh:
			#Lh.append(hash)
			priority = t['priority']
			tor_label = t['quality']
			studio = t['studio']
			sign = t['sign']
			tdf = get_td(url, 'fast')
			if priority <= 5 or tdf!=None or fast == False or len(Lt)<6:
				#tor_title=t['studio']+" | "+rt(t['title'])
				pDialog.update(int(n*100/len(L)), message=url.replace('http://127.0.0.1:8095/proxy/',''))
				L2 = get_torrent_directory(url, t_title=rt(t['title']))
				total = len(L2)
				for i in L2:
					if str(total)+i['label'] not in L3:
						if 's'+sz in i['label'].lower() or s==1:
							if find_episode(e, i['label']):
								stream = i['file']
								
								deb_print (i['label'].lower())
								
								if '0' not in tor_label:
									item_label = get_label(i['label'])
									if '0' in item_label: 
										tor_label = item_label
										#i['label'] = item_label
										if filtr(i)==False: 
											tor_label=tor_label.replace('[COLOR F','[COLOR 4')
									
								if studio == '': studio = get_studio(i['label'])
								item_ttl = tor_label+" | "+i['label']
								if studio not in i['label']: item_ttl += " | "+studio
								if priority == 0:  item_ttl = FC(item_ttl ,   'FEFFFF88')
								elif priority < 5: item_ttl = FC(item_ttl ,   'FE88FF88')
								
								item = xbmcgui.ListItem(item_ttl)
								item.setInfo(type = "Video", infoLabels = {'title':i['label']})
								item.setProperty('IsPlayable', 'true')
								item.addContextMenuItems ([('[B]Предпочитать[/B]', 'Container.Update("plugin://plugin.video.tvshow.tdw/?mode=SET&id='+str(id)+ '&sign='+str(sign)+ '&season='+str(s)+'")'),
														  ('[B]Настройки ТАМ[/B]', 'RunPlugin("plugin://plugin.video.tvshow.tdw/?mode=Open_TAM_Settings")')])
								purl='plugin://plugin.video.tvshow.tdw/?mode=Play_item&id='+str(id)+ '&stream='+quote(stream)+ '&url='+quote(url)+ '&sign='+str(sign)+ '&season='+str(s)
								xbmcplugin.addDirectoryItem(handle, purl, item, False)#stream
								L3.append(str(total)+i['label'])
								if stream !='': break
				deb_print ('==============')
			else: 
				skp+=1
			#except:
			#	print('=== err item ===')
	
	deb_print ('STREAM:'+stream)
	pDialog.update(100, message=stream)
	pDialog.close()
	if fast and skp>0:
		purl = sys.argv[0] + '?mode=Ep_list2&id='+str(id)+'&info='+repr(info)
		item = xbmcgui.ListItem('[ еще > ]')
		item.setProperty('IsPlayable', 'true')
		xbmcplugin.addDirectoryItem(handle, purl, item, True)

def Play_item(stream, tor_url, ep_id, sign, season):
	tam_history(tor_url, get_info(ep_id))# в историю
	
	info=get_info(ep_id)
	if get_select(ep_id, season) !=sign: set_select(ep_id, season, sign)
	
	item = xbmcgui.ListItem(path=stream)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def Open_TAM_Settings():
	TAM_settings = xbmcaddon.Addon(id='plugin.video.tam')
	TAM_settings.openSettings()

def Ep_list_old(id, info):
	pDialog = xbmcgui.DialogProgressBG()
	
	deb_print ('===Ep_list===')
	s=info['season']
	sz=str(s)
	if len (sz)<2: sz='0'+sz
	deb_print (sz)
	
	e=info['episode']
	ep=str(e)
	if len (ep)<2: ep='0'+ep
	deb_print (ep)
	
	try:pDialog.create('S'+sz+'E'+ep, 'Поиск серии ...')
	except: pass
	
	stream = ''
	L=Season(id, info, False)
	n=0
	deb_print ('==== s'+sz+'e'+ep+' ====')
	
	Lt=[]
	Lm=[]
	for t in L:
		if 'magnet:' in t['url'] and t['priority']>4: 	Lm.append(t)
		else: 											Lt.append(t)
	Lt.extend(Lm)
	
	L3 = []
	Lh = []
	for t in Lt:
		#try:
			n+=1
			url=t['url']
			#hash=get_torrent_hash(url)
			#if hash not in Lh:
			#Lh.append(hash)
			priority = t['priority']
			tor_label = t['quality']
			studio = t['studio']
			sign = t['sign']
			#tor_title=t['studio']+" | "+rt(t['title'])
			pDialog.update(int(n*100/len(L)), message=url.replace('http://127.0.0.1:8095/proxy/',''))
			L2 = get_torrent_directory(url, t_title=rt(t['title']))
			total = len(L2)
			for i in L2:
				if str(total)+i['label'] not in L3:
					if 's'+sz in i['label'].lower() or s==1:
						if find_episode(e, i['label']):
							stream = i['file']
							
							deb_print (i['label'].lower())
							
							if '0' not in tor_label:
								item_label = get_label(i['label'])
								if '0' in item_label: tor_label = item_label
							if studio == '': studio = get_studio(i['label'])
							item_ttl = tor_label+" | "+i['label']
							if studio not in i['label']: item_ttl += " | "+studio
							if priority == 0:  item_ttl = FC(item_ttl ,   'FEFFFF88')
							elif priority < 5: item_ttl = FC(item_ttl ,   'FE88FF88')
							
							item = xbmcgui.ListItem(item_ttl)
							item.setInfo(type = "Video", infoLabels = {'title':i['label']})
							item.setProperty('IsPlayable', 'true')
							item.addContextMenuItems([('[B]Предпочитать[/B]', 'Container.Update("plugin://plugin.video.tvshow.tdw/?mode=SET&id='+str(id)+ '&sign='+str(sign)+ '&season='+str(s)+'")'),])
							xbmcplugin.addDirectoryItem(handle, stream, item, False)
							L3.append(str(total)+i['label'])
							if stream !='': break
			deb_print ('==============')
		#except:
		#	print('=== err item ===')
	
	deb_print ('STREAM:'+stream)
	pDialog.update(100, message=stream)
	pDialog.close()

def Play_tam(stream):
	item = xbmcgui.ListItem(path=stream)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def find_episode(e, t):
	t=t.replace('1080','').replace('720','').replace('480','').replace('360','').replace('240','')
	t=t.replace('Season ','S').replace('season ','S').replace('Episode ','E').replace('episode ','E')
	ep=str(e)
	if len (ep)<2: ep='0'+ep
	if 'e'+ep in t.lower():  return True
	if 'e.'+ep in t.lower(): return True
	
	if 'e.'+str(e)+' ' in t.lower(): return True
	if 'e'+str(e)+' '  in t.lower(): return True
	if 'e.'+str(e)+'.' in t.lower(): return True
	if 'e'+str(e)+'.'  in t.lower(): return True
	
	tmp=t.lower().replace('.',' ').replace('_',' ').replace('/',' ')
	for s in range(10):
		tmp=tmp.replace('s0'+str(s),' ')
	for s in range(10,99):
		tmp=tmp.replace('s'+str(s),' ')
	if ' '+ep+' ' in tmp: return True
	
	return False

def Save(id):
	info = get_info(id)
	info['cover'] = 'https://image.tmdb.org/t/p/w300'+info['cover']
	info['fanart'] = 'https://image.tmdb.org/t/p/w1280'+info['fanart']
	sel = xbmcgui.Dialog()
	Lu=Episodes(id, True)
	Lt=[]
	for i in Lu:
		Lt.append(str(i['season'])+' сезон')
	rs = sel.select("Сезон:", Lt)
	if rs<0: return
	
	s_info=Lu[rs]
	deb_print (s_info)
	
	season=s_info['season']
	Lt=[]
	Lu=[]
	L=find_season(id, season)
	for i2 in L:
		title=i2['quality']+" "+i2['season']+" "+i2['studio']
		img=''
		Lt.append(title)
		Lu.append(i2['url'])
		
	r = sel.select("Релизы:", Lt)
	if r>-1:
		url=Lu[r]
		ttl=Lt[r]
		AD=test_AD(ttl)
		if AD: info['AD']=1
		else:  info['AD']=0
		#uri='plugin://plugin.video.torrent.checker/?mode=save_episodes_api&url='+uquote(url)+'&name='+quote(info['originaltitle'])+ '&info=' + quote(repr(info))
		pu = sys.argv[0] + '?mode=Episodes&id='+str(id)+'&info='+repr(info)
		uri='plugin://plugin.video.tam/?mode=save_series&url='+quote(url)+'&name='+quote(info['originaltitle'])+ '&info=' + quote(repr(info))+'&purl='+quote(pu)
		xbmc.executebuiltin('RunPlugin("'+uri+'")')

def TC2(id):
	info = get_info(id)
	info['cover'] = 'https://image.tmdb.org/t/p/w300'+info['cover']
	info['fanart'] = 'https://image.tmdb.org/t/p/w1280'+info['fanart']
	sel = xbmcgui.Dialog()
	Lu=Episodes(id, True)
	s_info=Lu[-1]
	deb_print (s_info)
	season=s_info['season']
	sel_sign=get_select(id, season)
	
	Lt=[]
	Lu=[]
	L=find_season(id, season)
	for i2 in L:
		sign=get_sign(i2)
		title=i2['quality']+" "+i2['season']+" "+i2['studio']+" "+i2['size']
		if sign==sel_sign: title='[COLOR EFFF7711]'+title+'[/COLOR]'
		Lt.append(title)
		Lu.append(i2)
		
	r = sel.select("Релизы:", Lt)
	if r>-1:
		t_info=Lu[r]
		sign=get_sign(t_info)
		tvs_name = info['originaltitle']
		tvf_url = 'plugin://plugin.video.tvshow.tdw/?mode=TC&id='+str(id)+'&sign='+str(sign)+'&season='+str(season)+'&name='+quote(tvs_name)
		uri='plugin://plugin.video.torrent.checker/?mode=add&url='+quote(tvf_url)+'&name='+quote(tvs_name)+'&manual=0'
		xbmc.executebuiltin('RunPlugin("'+uri+'")')

def TC(id, sign, season, name):
	sz=str(season)
	if len (sz)<2: sz='0'+sz
	deb_print (sz)
	sys.path.append(os.path.join(xt("special://home/"),"addons","plugin.video.torrent.checker"))
	import updatetc
	LD=updatetc.file_list(name)
	L=find_season(id, season)
	L2=[]
	for t_info in L:
		n_sign=get_sign(t_info)
		if n_sign==sign: 
			L2.append(t_info)
	
	for t in L2:
		url = t['url']
		L3 = get_torrent_directory(url, t_title=rt(t['title']))
		for i in L3:
			stream = i['file']
			#print stream
			#print get_params(stream)
			#nm = i['label'].lower()+'.strm'
			for e in range(99):
				ep=str(e)
				if len (ep)<2: ep='0'+ep
				if find_episode(e, i['label']):
					nm = name+'.s'+sz+'e'+ep+'.strm'
					uri = unquote(get_params(stream)["url"])
					ind = int(get_params(stream)["ind"])
					if nm not in LD: updatetc.save_strm(name, nm, uri, ind)
					break


def get_torrent_directory(url, info={'history':False}, t_title=''):
	deb_print ('--get_torrent_directory--')
	if __settings__.getSetting("NoCache")=='false': 
		CL = get_td(url, ttl=t_title)
		if CL!=None: 
			deb_print ('ret ch')
			return CL
	
	try:
		info["cover"]  = 'https://image.tmdb.org/t/p/w300' +info["cover"]
		info["fanart"] = 'https://image.tmdb.org/t/p/w1280'+info["fanart"]
	except: pass
	
	Lext=['.avi', '.mkv', '.ts', '.mov', '.mp4', '.mpg', '.mpeg']
	le=['','ace', 't2http', 'yatp', 'torrenter', 'elementum', 'xbmctorrent', 'ace_proxy', 'quasar', 'torrserver', 'torrserver_tam']
	tengine = le[int(__settings__.getSetting("TAMengine"))] 
	purl='plugin://plugin.video.tam/?mode=open&url='+quote(url)+ '&engine='+tengine+ '&info='+quote(repr(info))
	response = eval(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Files.GetDirectory", "params": {"directory": "'+purl+'"},"id": 1}'))
	
	try:files=response["result"]["files"]
	except: files=[]
	Lr=[]
	for i in files:
		label=i['label'].lower()
		add = False
		for ext in Lext:
			if ext in label: add=True
		if add: Lr.append(i)
	
	add_td(url, Lr, ttl=t_title)
	return Lr

def get_tam_sid():
	purl='plugin://plugin.video.tam/?mode=get_sid'
	response = eval(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Files.GetDirectory", "params": {"directory": "'+purl+'"},"id": 1}'))
	deb_print (response)
	#return response["result"]["files"][0]['label']
	try:
		files=response["result"]["files"]
		sid=int(files[0]['label'])
	except: 
		sid=-2
	return sid

def get_torrent_hash(url):
	purl='plugin://plugin.video.tam/?mode=get_hash&url='+quote(url)
	response = eval(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Files.GetDirectory", "params": {"directory": "'+purl+'"},"id": 1}'))
	#print (response)
	#return response["result"]["files"][0]['label']
	try:
		files=response["result"]["files"]
		hash=files[0]['label']
	except: 
		hash=''
	return hash

def tam_history(url, info):
	deb_print ('===tam_history===')
	deb_print (info)
	try:    cover = 'https://image.tmdb.org/t/p/w300'+info["cover"]
	except: cover = icon
	try:    fanart = 'https://image.tmdb.org/t/p/w1280'+info["fanart"]
	except: fanart = cover
	if __settings__.getSetting("antizapret3")=='true':
					cover=cover.replace('image.tmdb.org','image-tmdb-org.translate.goog')
					fanart=fanart.replace('image.tmdb.org','image-tmdb-org.translate.goog')

	info["cover"]=cover
	info["fanart"]=fanart
	purl='plugin://plugin.video.tam/?mode=history&url='+quote(url)+ '&info='+quote(repr(info))
	xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Files.GetDirectory", "params": {"directory": "'+purl+'"},"id": 1}')


def find_season(id, S=1):
	deb_print('==find_season==')
	L=Quality(id, False)
	if L==[]: L=Quality(id, False, True)
	L2=[]
	try:L.sort()
	except: deb_print('ОШИБКА сортировки списка')
	for i in L:
		try:
			deb_print('----i---')
			deb_print(i['season'])
			if '-' in i['season']:
				#deb_print(' - in i')
				s1=int(i['season'].split('-')[0])
				s2=int(i['season'].split('-')[1])
				SL=range(s1,s2+1)
			else:
				#deb_print(' - not in i')
				try:    SL = [int(i['season']),]
				except: SL = []
			deb_print(SL)
			if S in SL:
				L2.append(i)
		except:
			deb_print('== ERR i ==')
	
	if len(L2)<5 and S==1:
		for i in L:
			if i['season']=='XX' and '[' in i['title']: L2.append(i)
	
	if L2==[] and S==1: L2=L
	
	return L2


def get_select(id, season):
	id = 'sig'+str(id)
	try: return eval(get_inf_db(id))[str(season)]
	except: return ''

def set_select(id, season, sign):
	lp_id = str(id)
	id = 'sig'+str(id)
	try: inf = eval(get_inf_db(id))
	except: inf = {}
	inf[str(season)]=sign
	rem_inf_db(id)
	add_to_db(id, repr(inf))
	set_last_played(lp_id, season, '')

def get_last_played(id, season):
	id = 'lp'+str(id)
	try: return eval(get_inf_db(id))[str(season)]
	except: return ''

def get_last_played_ttl(id, season):
	id = 'lp'+str(id)
	try: return eval(get_inf_db(id))[str(season)+'ttl']
	except: return ''

def set_last_played(id, season, url, ttl=''):
	id = 'lp'+str(id)
	try: inf = eval(get_inf_db(id))
	except: inf = {}
	inf[str(season)]=url
	inf[str(season)+'ttl']=ttl
	rem_inf_db(id)
	add_to_db(id, repr(inf))


def filtr(D):
	deb_print('======filtr=====')
	try:
		deb_print(D)
		
		Title = D['title']
		try:Title=Title+' '+D['quality']
		except:pass
		if sys.version_info.major < 3:
			try:Title=Title.encode('utf-8')
			except: Title=xt(Title)
		
		BL=['Трейлер', "Тизер", 'трейлер', "тизер", 'ТРЕЙЛЕР', "ТИЗЕР"]
		#if __settings__.getSetting("S_Qual") != "0":BL.extend([' TS','TeleSyn','TeleCin','TELECIN',' CAM',' CamRip','screen','Screen', 'звук из кинотеатра'])
		if __settings__.getSetting("BlackList") != "":
			for bli in __settings__.getSetting("BlackList").split(","):
				BL.append(bli.strip())
		WL1=[]
		WL2=[]
		if __settings__.getSetting("F_Qual")  != '0':
			if __settings__.getSetting("F_Qual1") == 'true': WL1.append("webrip")
			if __settings__.getSetting("F_Qual1") == 'true': WL1.append("web-dl")
			if __settings__.getSetting("F_Qual2") == 'true': WL1.append("bdrip")
			if __settings__.getSetting("F_Qual2") == 'true': WL1.append("hdrip")
			if __settings__.getSetting("F_Qual3") == 'true': WL1.append("tvrip")
			if __settings__.getSetting("F_Qual3") == 'true': WL1.append("hdtv")
			if __settings__.getSetting("F_Qual4") == 'true': WL1.append("blu-ray")
			if __settings__.getSetting("F_Qual4") == 'true': WL1.append("dvdrip")
		
		if __settings__.getSetting("S_Qual") != '0':
			if __settings__.getSetting("S_Qual1") == 'true': WL2.append("360p")
			if __settings__.getSetting("S_Qual2") == 'true': WL2.append("420p")
			if __settings__.getSetting("S_Qual3") == 'true': WL2.append("480p")
			if __settings__.getSetting("S_Qual4") == 'true': WL2.append("720p")
			if __settings__.getSetting("S_Qual5") == 'true': WL2.append("1080p")
			if __settings__.getSetting("S_Qual6") == 'true': WL2.append("2160p")
		
		#size1 = int(__settings__.getSetting("F_Size1"))
		#size2 = int(__settings__.getSetting("F_Size2"))
		#if size2 == 0: size2 = 999
		
		b=0
		q=0
		z=0
		deb_print (Title)
		
		for i in BL:
			if i in Title: 
					deb_print ('Попал в Черный список')
					return False
					#b=1
		#if b==0:
		for i in BL:
			if lower(Title).find(lower(i))>0:
					deb_print ('Попал в Черный список')
					return False
					#b=1
					#break
		
		if __settings__.getSetting("F_Qual") == "0": q=1
		else:
			for i in WL1:
				if i in Title.lower():
					q=1
					break
		
		if __settings__.getSetting("S_Qual") == "0": z=1
		else:
			for i in WL2:
				if i in Title.lower():
					z=1
					break
		'''
		if 'ГБ' in xt(D['size']) or 'GB' in xt(D['size']):
				szs=xt(D['size']).replace('ГБ','').replace('GB','').replace('|','').strip()
				sz=float(szs)
				if sz>size1 and sz<size2 : z=1
		else: z=0
		'''
		
		
		if b != 0: deb_print ('Попал в Черный список')
		if q == 0: deb_print ('Качество не соответствует')
		if z == 0: deb_print ('Размерешение не соответствует')
		
		deb_print ('========return filtr=======')
		if b == 0 and q > 0 and z > 0:
			#print ('Файл найден')
			return True
		else: 
			return False
	except:
		deb_print ('========except: filtr=======')
		return False

def year_in_title(L, t):
	if L==[]: return False
	for i in L:
		#print (i)
		if str(i) in t: return True
	if str(L[0]-1)in t: return True
	return False

def Quality(id, additm=True, rus=False):
	deb_print ('=====Quality=====')
	
	#try:lc = eval(__settings__.getSetting("LLL"))# --- Кеширование
	#except: lc = {'id':0}
	#try: lc_id = lc['id']
	#except: lc_id = 0
	#if lc_id == id and __settings__.getSetting("NoCache")=='false': 
	#	print ('=Cahe=')
	#	Ldata=lc['data']
	#	if Ldata!=[]: return Ldata             # ----------------
	
	info=themoviedb.get_info(id)
	
	if __settings__.getSetting("SYear")=='true': 
		try: years = themoviedb.get_years(id)
		except: years = []
	else: years = []
	
	if rus: 
		if info['originaltitle']==info['title']: return []
		info['originaltitle']=info['title']
	
	try: utm = float(__settings__.getSetting("start_uptime"))
	except: utm = 9999999999999
	
	L=[]
	if __settings__.getSetting("NoCache")=='true' or rus: L = sercher(info)
	elif utm-time.time()<20: 
		for n in range (10):
			t_ch =  get_ch(info)
			deb_print (t_ch)
			L  =  t_ch['list']
			tm =  t_ch['tm']
			if time.time()-tm < 3600: break
			if L == [] and tm == 0: xbmc.sleep(2000)
			else: break
	
	if L == [] and __settings__.getSetting("NoCache")=='false': L = sercher(info)
	
	F_Qual = __settings__.getSetting("F_Qual")
	S_Qual = __settings__.getSetting("S_Qual")
	SYear  = __settings__.getSetting("SYear")
	RuTitle = __settings__.getSetting("RuTitle")
	
	ru_title=utt(xt(info['title']))
	en_title=utt(info['originaltitle'])+' '
	year=str(info['year'])
	if len(year)>4: year=year[:4]
	
	L2=[]
	L3=[]
	Lz=[]
	
	deb_print('-----items: '+str(len(L)))
	for D in L:
		#flt = filtr(D)
		#if BlackList(D['title']):
			deb_print ('------ item -------')
			url = D['url']
			deb_print(url)
			if 'http' in url or 'magnet' in url:
				if sys.version_info.major > 2:
					title=utt(D['title'])
				else:
					try:    title=utt(D['title'].encode('utf-8'))
					except: title=utt(D['title'])
				
				tor_title=utt(title)#.replace('('+en_title+')', ' '+en_title+' ')
				
				deb_print (lower(tor_title))
				deb_print (lower(ru_title))
				deb_print (lower(en_title))
				
				if en_title in tor_title:
					deb_print ('en_title ok')
					if ru_title in tor_title or RuTitle =='false':
						deb_print ('ru_title ok')
						if year_in_title(years, tor_title) or SYear == 'false':
							
							#deb_print ('Название соответствует')
							#size = D['size']
							#if 'MB' in size and '.' in size: size=size[:size.find('.')]
							#size = size.replace('GB','').replace('MB','').strip()
							#if size not in Lz or __settings__.getSetting("CutSize") == 'false':
								#Lz.append(size)
								#Z=D['size']
								#if 'GB' in Z and Z.find('.') == 2: Z=Z[:3]+Z[4:]
								deb_print ('Название соответствует')
								season = get_season(tor_title)
								studio = get_studio(tor_title)
								label  = get_label (tor_title)
								
								if info['originaltitle']==info['title'] and season == 'XX': season = '01' # Односезонные русские
								
								if __settings__.getSetting("S_Q_ext") != '0':
									if '0' not in label: 
										sign   = get_sign(D)
										try:    sel  = get_select(id, int(season))
										except: sel  = 'err'
										deb_print (sign)
										deb_print (sel)
										if sign == sel: label2=get_label2(D['url'], True)
										else:			label2=get_label2(D['url'])
										if '?' not in label2: label  = label2
									
									if studio == '': studio=get_studio2(D['url'])
								
								D['quality'] = label
								D['studio']  = studio
								D['season']  = season
								
								flt = filtr(D)
								if flt: 
									D['quality']=label.replace('[COLOR F','[COLOR  F')
									L2.append(D)
								else: 
									D['quality']=label.replace('[COLOR F','[COLOR 4')
									L3.append(D)
								#title=xt(mid(Z, 10))+" | "+xt(mids(D['sids'], 6))+" | "+rt(title)
								#title=label+" "+season+" "+studio+" "+title
								#if additm: AddItem(title, "OpenTorrent", url, info)
						else: deb_print ('year wrong')
					else: deb_print ('ru_title wrong')
				else: deb_print ('en_title wrong')
			deb_print('---- end item----')
	if additm: 
		for D in L2:
			url = D['url']
			Z=D['size']
			if 'GB' in Z and Z.find('.') == 2: Z=Z[:3]+Z[4:]
			url = D['url']
			title=D['label']+" "+D['season']+" "+D['studio']+" "+xt(mid(Z, 10))+" | "+xt(mids(D['sids'], 6))+" | "+rt(utt(D['title']))
			AddItem(title, "OpenTorrent", url, info)
		for D in L3:
			url = D['url']
			Z=D['size']
			if 'GB' in Z and Z.find('.') == 2: Z=Z[:3]+Z[4:]
			url = D['url']
			title=D['label']+" "+D['season']+" "+D['studio']+" "+xt(mid(Z, 10))+" | "+xt(mids(D['sids'], 6))+" | "+rt(utt(D['title']))
			AddItem(title, "OpenTorrent", url, info)
		
	if S_Qual == '2': L2.extend(L3)
	#__settings__.setSetting("LLL", repr({'id':id, 'data':L2}))
	return L2

def sercher(info):
	deb_print('====sercher====')
	ch=get_ch(info)
	Lc=ch['list']
	#print (time.time()-ch['tm'])
	if __settings__.getSetting("NoCache")=='true': Lc=[]
	elif time.time()-ch['tm']<3600: return Lc
	
	__settings__.setSetting("start_uptime", str(time.time()))
	offlist=['core',]
	if __settings__.getSetting("Serv1")=='false':  offlist.append('rutor')
	if __settings__.getSetting("Serv2")=='false':  offlist.append('fasttor')
	if __settings__.getSetting("Serv3")=='false':  offlist.append('tragtorr')
	if __settings__.getSetting("Serv4")=='false':  offlist.append('bitru')
	if __settings__.getSetting("Serv5")=='false':  offlist.append('kpfr')
	if __settings__.getSetting("Serv6")=='false':  offlist.append('krasfs')
	if __settings__.getSetting("Serv7")=='false':  offlist.append('nnc')
	if __settings__.getSetting("Serv8")=='false':  offlist.append('lafa')
	if __settings__.getSetting("Serv9")=='false':  offlist.append('megapeer')
	if __settings__.getSetting("Serv11")=='false': offlist.append('findmagnet')
	if __settings__.getSetting("Serv12")=='false': offlist.append('kinozal')
	if __settings__.getSetting("Serv13")=='false': offlist.append('wriza')
	if __settings__.getSetting("Serv14")=='false': offlist.append('torlook')
	
	sys.path.append(os.path.join(addon.getAddonInfo('path'),"src"))
	ld=os.listdir(os.path.join(addon.getAddonInfo('path'),"src"))
	L=[]
	
	if __settings__.getSetting("Multimod")=='true': # -------------- многопоточный режим
		pDialog = xbmcgui.DialogProgressBG()
		pDialog.create(info['originaltitle'], '...')
		try: tr_count = int(__settings__.getSetting("TrCount"))+2
		except: tr_count = 4
		
		tid = time.time()
		update_Lt('reset', tid)
		total_threads=0
		xbmc.sleep(100)
		n=0
		for i in ld:
			n+=1
			
			off = True
			for sr in offlist:
				if sr in i: off = False
			
			if i[-3:]=='.py' and off: 
				pDialog.update(int(n*100/len(ld)), message=i[:-3])
				create_thread({'i': i, 'info':info, 'id':tid})
				total_threads+=1
				xbmc.sleep(100)
				deb_print ('total_threads '+str(total_threads))
				deb_print ('life_threads  '+str(total_threads- len(Lthread)))
				for t in range(20):
					if total_threads - len(Lthread) <= tr_count: break
					xbmc.sleep(100)
					deb_print ('= limit trad =')
					
		deb_print ('total_threads '+str(total_threads))
		
		try: tr_time = (int(__settings__.getSetting("TrTime"))+1)*5
		except: tr_time = 25
		
		for t in range(tr_time):
				pDialog.update(int(t*100/tr_time), message=str(len(Lthread))+' / '+str(total_threads))
				deb_print ('step '+str(t))
				deb_print (str(len(Lthread))+' to '+str(total_threads))
				if len(Lthread) == total_threads: break
				xbmc.sleep(1000)
		
		for Lst in Lthread:
				for st in Lst:
					L.append(st)
		
		pDialog.update(100, message='')
		pDialog.close()
		
		
	
	else: # ------------------------ однопоточный режим
		for i in ld:
			off = True
			for sr in offlist:
				if sr in i: off = False
			
			if i[-3:]=='.py' and off :#and 'core' not in i
				try:
					exec ("global skp; import "+i[:-3]+"; skp="+i[:-3]+".Tracker()")
					Lst = skp.Search(info)
				except: Lst=[]
				
				for st in Lst:
					L.append(st)
	
	
	Lr=[]
	Lh=[]
	for t in L:
		if BlackList(t['title']):
			deb_print (t['url'])
			hash = get_magnet_hash(t['url'])
			if hash == '': Lr.append(t)
			elif hash not in Lh:
					Lr.append(t)
					Lh.append(hash)
	
	add_ch(info, Lr)
	
	#for t in Lc:
	#	if t not in L: 
	#		hash = get_magnet_hash(t['url'])
	#		if hash == '': Lr.append(t)
	#		elif hash not in Lh:
	#				Lr.append(t)
	#				Lh.append(hash)
	
	deb_print ('=======return sercher========')
	return Lr


def utt(t):
	try: t=lower(rt(t).replace("«",'').replace("»",'').replace('"', '').replace("'", '').replace("`", '').replace(":", ' ').replace(")", ' ').replace("(", ' ').replace("ё", 'е'))
	except: pass
	return t

def BlackList(t):
	L=[' DLC', ' PC', 'Repack', ' PSP', ' MP3', ' FLAC']
	for i in L:
		if i in t: return False
	return True

def get_sign(i):
	#q=i['quality']
	#s=i['season']
	if 'magnet:' in i['url']: u='M'
	else:					  u='T'
	t=lower(i['title'])
	t=t.replace('360','lo').replace('400','md').replace('420','md').replace('480','md').replace('720','hi').replace('1080','hd').replace('2160','uhd')
	for n in range(9):
		t=t.replace(str(n),'')
	t=t.replace('   ',' ').replace('  ',' ').replace('  ',' ')
	t=t.replace('-','').replace(':','').replace('/','').replace('()','').replace('сезон','').replace('серия','').replace('|','')
	t=t.replace('   ',' ').replace('  ',' ').replace('  ',' ')
	t=t.replace('[x из ]','').replace('[х из ]','').replace('( из )','').replace('[ из ]','')
	t=t.replace('   ',' ').replace('  ',' ').replace('  ',' ')
	t=t.replace(' avc','')
	t=t.replace('webdlrip','web').replace('webrip','web').replace('webdl','web')
	
	sign=CRC32(t+u)
	deb_print(sign+' : '+u+' '+t)
	return sign

def get_season(t):
	s=['[s','s', 'x', 'х', 'сезон ', ' сезон', 'сезоны ', ' сезоны']
	L=[]
	for i in range(99):
		if i>9: si=str(i)
		else:   si='0'+str(i)
		L.append(s[0]+si)
		L.append(s[1]+si)
		L.append(si+s[2])
		L.append(si+s[3])
		L.append(s[4]+si)
		L.append(si+s[5])
		
	for i in range(10):
		L.append(str(i)+' сезоны')
		L.append('сезоны '+str(i))
		L.append(s[0]+str(i))
	
	for i in range(10):
		L.append(str(i)+' сезон')
		L.append('сезон '+str(i))
		L.append(s[0]+str(i))
		
	for i in range(10):
		si=str(i)
		L.append(s[0]+si)
		L.append(s[1]+si)
		L.append(si+s[2])
		L.append(si+s[3])
		L.append(s[4]+si)
		L.append(si+s[5])
	
	
	
	lt=lower(t)
	k=-1
	k2=-1
	se='XX'
	for se1 in L:
		if se1 in lt: 
			k=lt.find(se1)+len(se1)
			k2=lt.find(se1)-1
			for f in s:
				se1 = se1.replace(f,'')
			if len(se1)<2: se1='0'+se1
			se=se1
			break
	
	try: print (lt[k])
	except: k=-1
	try: print (lt[k2])
	except: k2=-1

	if k>0 :
		if lt[k]=='-':
			if lt[k+1]=='0': d=1
			else: d=0
			print ('----------------------')
			
			deb_print (lt[k+1+d:k+3])
			try:ne2=int(lt[k+1+d:k+3])
			except:ne2=-1
			deb_print (ne2)
			
			if ne2<0:
				print (lt[k+1])
				try:ne2=int(lt[k+1])
				except:ne2=-1
			
			if ne2>0:
				se2=str(ne2)
				if len(se2)<2: se2='0'+se2
				se = se1+'-'+se2
	
	elif k2>0:
		deb_print ('+++++++++++2+++++++++++')
		if lt[k2]=='-':
			if lt[k2-2]=='0': d=1
			else: d=0
			deb_print ('----------------------')
			
			deb_print (lt[k2-1-d:k2])
			try:ne2=int(lt[k2-1-d:k2])
			except:ne2=-1
			deb_print (ne2)
			
			if ne2<0:
				print (lt[k2-1])
				try:ne2=int(lt[k2-1])
				except:ne2=-1
			
			if ne2>0:
				se2=str(ne2)
				if len(se2)<2: se2='0'+se2
				se = se2+'-'+se1
	
	deb_print (se)
	deb_print ('=======')
	return se

def get_episodes(t):
	lt=lower(t)
	ep = 0
	if ' из ' in lt:
		if '-' in lt:
			try: ep = int(mfind(lt, '-', ' из ').replace('серии', '').replace('серий', '').replace('серия', ''))
			except: pass
			try: ep = int(mfind(lt, '-', 'серии'))
			except: pass

		if 'х' in lt:
			try: ep = int(mfind(lt, 'х', ' из ').replace('серии', '').replace('серий', ''))
			except: pass
		if 'x' in lt:
			try: ep = int(mfind(lt, 'x', ' из ').replace('серии', '').replace('серий', ''))
			except: pass
		if ':' in lt:
			try: ep = int(mfind(lt, ':', 'сери'))
			except: pass

	return ep


def get_label(text):
	text=lower(text)#.lower()
	#text=text.replace('.400.',' 420p ').replace('.420.',' 420p ').replace('.480.',' 480p ').replace('.1080.',' 1080p ').replace('.720.',' 720p ')
	#print text
	#if 'трейлер'  in text: return FC('[ Трейл.]',    'FF999999')
	#if 'telesyn'  in text: return FC('[    TS    ]', 'FFFF2222')
	#if 'telecin'  in text: return FC('[    TS    ]', 'FFFF2222')
	#if 'camrip'   in text: return FC('[    TS    ]', 'FFFF2222')
	#if ' ts'      in text: return FC('[    TS    ]', 'FFFF2222')
	#if 'dvdscr'   in text: return FC('[    Scr   ]', 'FFFF2222')
	#if ' 3d'      in text: return FC('[    3D    ]', 'FC45FF45')
	
	if '420'      in text: return FC('[  420p  ]',   'FEFF88FF')
	if '480'      in text: return FC('[  480p  ]',   'FEFF88FF')
	if '720'      in text: return FC('[  720p  ]',   'FBFFFF55')
	if '1080'     in text: return FC('[ 1080p ]',    'FAFF9535')
	if '2160'     in text: return FC('[ 2160p ]',    'FA99FF9F')
	if ' 4k'      in text: return FC('[ 2160p ]',    'FF5555FF')
	if '.avi'     in text: return FC('[  420p  ]',   'FFFF88FF')
	if 'dvdrip'   in text: return FC('[  480p  ]',   'FE88FFFF')
	if ' кпк'     in text: return FC('[  360p  ]',   'FFF8888F')
	if 'iphone'   in text: return FC('[  360p  ]',   'FFF8888F')
	if 'blu-ray'  in text: return FC('[  BRay  ]',   'FF5555FF')
	if 'bdremux'  in text: return FC('[    BD    ]', 'FF5555FF')
	if 'bdrip'    in text: return FC('[ BDRip ]',    'FE98FF98')
	if 'drip'     in text: return FC('[ BDRip ]',    'FE98FF98')
	if 'hdrip'    in text: return FC('[ HDRip ]',    'FE98FF98')
	if 'webrip'   in text: return FC('[  WEB   ]',   'FEFF88FF')
	if 'WEB'      in text: return FC('[  WEB   ]',   'FEFF88FF')
	if 'web-dl'   in text: return FC('[  WEB   ]',   'FEFF88FF')
	if 'hdtv'     in text: return FC('[ HDTV ]',     'FEFFFF88')
	if 'tvrip'    in text: return FC('[    TV    ]', 'FEFFFF88')
	if 'satrip'   in text: return FC('[    TV    ]', 'FEFFFF88')
	if 'dvb '     in text: return FC('[    TV    ]', 'FEFFFF88')
	if 'dvd5'     in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'xdvd'     in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'dvd-5'    in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'dvd-9'    in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'dvd9'     in text: return FC('[  DVD   ]',   'FE88FFFF')
	return FC('[   ????  ]', 'FFFFFFFF')

def get_label2(url, force=False):
	if ('magnet:' not in url and __settings__.getSetting("S_Q_ext") == '2') or force: L = get_torrent_directory(url)
	else: L = get_td(url, 'fast')
	if L==None: return FC('[   ????  ]', 'FFFFFFFF')
	for i in L:
		text = lower(i['label'])
		#text = text.replace('.400.',' 420p ').replace('.420.',' 420p ').replace('.480.',' 480p ').replace('.1080.',' 1080p ').replace('.720.',' 720p ')
		if '360'      in text: return FC('[  360p  ]',   'FFF8888F')
		if '400'      in text: return FC('[  420p  ]',   'FEFF88FF')
		if '420'      in text: return FC('[  420p  ]',   'FEFF88FF')
		if '480'      in text: return FC('[  480p  ]',   'FEFF88FF')
		if '720'      in text: return FC('[  720p  ]',   'FBFFFF55')
		if '1080'     in text: return FC('[ 1080p ]',    'FAFF9535')
		if '2160'     in text: return FC('[ 2160p ]',    'FA99FF9F')
		if '.avi'     in text: return FC('[  420p  ]',   'FFFF88FF')
		if '.mp4'     in text: return FC('[  360p  ]',   'FFF8888F')
	return FC('[   ????  ]', 'FFFFFFFF')


def get_title(t):
	n=999
	n1=t.find('/')
	n2=t.find('(')
	n3=t.find('[')
	if n1>0: n=n1
	if n2>0 and n2<n: n=n2
	if n3>0 and n3<n: n=n3
	ttl=t[:n].strip()
	deb_print ('ttl:'+ttl)
	if 'сезон' in ttl:
		for s in range(1,9):
			ss = str(s)+' сезон'
			if ss in ttl:
				n4=t.find(ss)
				ttl=ttl[:n4].strip()
				break
	
	return ttl

def get_studio(t):
	for i in L_studio:
		if lower(i) in lower(t):
			return i
	return ''

def get_studio2(url):
	if 'magnet:' not in url and __settings__.getSetting("S_Q_ext") == '2': L = get_torrent_directory(url)
	else: L = get_td(url, 'fast')
	if L==None: return ''
	for i in L:
		studio=get_studio(i['label'])
		if studio!='': return studio
	return ''

def SetViewMode(n):
	if n>0:
		xbmc.sleep(300)
		xbmc.executebuiltin("Container.SetViewMode(0)")
		#xbmc.sleep(10)
		for i in range(1,n):
			#xbmc.sleep(10)
			xbmc.executebuiltin("Container.NextViewMode")


def Favorites():
	try: La=eval(__settings__.getSetting("on_the_air"))#[]
	except: La=[]
	#try:
	#	Lad=themoviedb.on_the_air()
	#	for info in Lad:
	#		id = info['id']
	#		La.append(str(id))
	#except: pass
	
	try:L=eval(__settings__.getSetting("Favorites"))
	except:L=[]
	L.reverse()
	
	for id in L:
		if id in La:
			info = get_info(id)
			AddItem('[B]'+info['title']+'[/B]', "Episodes", id, info, len(L))
	
	for id in L:
		if id not in La:
			info = get_info(id)
			AddItem(info['title'], "Episodes", id, info, len(L))

def Checker():
	try:L=eval(__settings__.getSetting("Checker"))
	except:L=[]
	L.reverse()
	
	for id in L:
		info = get_info(id)
		AddItem(info['title'], "Episodes", id, info, len(L))
	
	#Checker_update()

def Checker_update():
	try:L=eval(__settings__.getSetting("Checker"))
	except:L=[]
	L.reverse()
	
	for id in L:
		info = get_info(id)
		originaltitle=info['originaltitle']
		try:
			cover='https://image.tmdb.org/t/p/w300'+info['cover']
			if __settings__.getSetting("antizapret3")=='true':
				cover=cover.replace('image.tmdb.org','image-tmdb-org.translate.goog')
		except: cover=''
		if '\\x8' in repr(originaltitle) or '\\x9' in repr(originaltitle): originaltitle=info['title']
		#print (repr(originaltitle))
		if __settings__.getSetting("SaveNFO")=='true': save_tvshow_nfo(originaltitle, info)
		Lep=Episodes(id, True)
		for s_info in Lep:
			season=s_info['season']
			Le=s_info['episodes']
			if __settings__.getSetting("SaveIMG")=='true' and len(cover)>0: save_img(cover, originaltitle, season)
			for e_info in Le:
					deb_print(info)
					title=str(e_info['season'])+'x'+str(e_info['episode'])+"  "+e_info['title']
					epd='S'+str(e_info['season'])+'.E'+str(e_info['episode'])
					try:
						#if True:
						premiered = int(e_info['premiered'].replace('-',''))
						crdate = int(time.strftime('%Y%m%d'))
						deb_print(premiered)
						deb_print(crdate)
						if premiered<crdate: 
							purl = 'plugin://plugin.video.tvshow.tdw/?mode=Play_strm&id='+id+'&ind='+str(e_info['episode'])+'&info='+repr(e_info)
							save_purl(originaltitle, epd, purl, e_info)
					except: pass
		
		if __settings__.getSetting("SavePURL")=='true': 
			purl = 'plugin://plugin.video.tvshow.tdw/?mode=Open_TVS&id='+id
			save_purl(originaltitle, 'S00.E00', purl, info={'title':'Открыть TVShow', 'season':0, 'episode':0 })
	
	xbmc.executebuiltin('UpdateLibrary("video", "", "false")')

def save_purl(name, epd, purl, info={}):
		deb_print(info)
		#epd='S00.E00'
		name=to_utf(name.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"").replace('>',"").replace('<',"").strip())
		epd=epd.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"").replace('>',"").replace('<',"").strip()
		#if isinstance(name, unicode): 
		#if isinstance(epd, unicode): epd=epd.encode('utf-8')
		try: title=to_utf(info['title'])
		except: title=epd
		
		try: plot=to_utf(info['plot'])
		except: plot=''
		#if isinstance(title, unicode): title=title.encode('utf-8')
		#if isinstance(plot, unicode): plot=plot.encode('utf-8')
		
		try:Directory= __settings__.getSetting("SaveDirectory2")
		except: Directory=os.path.join(addon.getAddonInfo('path'), 'strm')
		if Directory=="": Directory=os.path.join(addon.getAddonInfo('path'), 'strm')
		
		SaveDirectory = os.path.join(Directory, name)
		
		if os.path.isdir(fs_enc(SaveDirectory))==0: os.mkdir(fs_enc(SaveDirectory))
		
		strm_path = fs_enc(os.path.join(SaveDirectory, epd+'.strm'))
		if not os.path.isfile(strm_path):
			if sys.version_info.major > 2: 	fl = open(strm_path, "w", encoding='utf-8')
			else: 							fl = open(strm_path, "w")
			fl.write(purl)
			fl.close()
		
		try:fanart='https://image.tmdb.org/t/p/w300'+info['fanart']
		except:
			try: fanart='https://image.tmdb.org/t/p/w300'+info['thumb']
			except: fanart=''
		try: cover='https://image.tmdb.org/t/p/w300'+info['cover']
		except: cover=fanart
		
		if __settings__.getSetting("antizapret3")=='true':
				cover=cover.replace('image.tmdb.org','image-tmdb-org.translate.goog')
				fanart=fanart.replace('image.tmdb.org','image-tmdb-org.translate.goog')
		
		nfo="<episodedetails>"+chr(10)
		nfo+="	<title>"+title+"</title>"+chr(10)
		nfo+="	<season>"+str(info['season'])+"</season>"+chr(10)
		nfo+="	<episode>"+str(info['episode'])+"</episode>"+chr(10)
		nfo+="	<plot>"+plot+"</plot>"+chr(10)
		nfo+="	<fanart>"+fanart+"</fanart>"+chr(10)
		nfo+="	<thumb>"+fanart+"</thumb>"+chr(10)
		nfo+="</episodedetails>"+chr(10)
		
		nfo_path = fs_enc(os.path.join(SaveDirectory, epd+".nfo"))
		if not os.path.isfile(nfo_path):
			if sys.version_info.major > 2: 	fl = open(nfo_path, "w", encoding='utf-8')
			else: 							fl = open(nfo_path, "w")
			fl.write(nfo)
			fl.close()

def save_tvshow_nfo(name, info={}):
		name=to_utf(name.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"").replace('>',"").replace('<',"").strip())
		
		try:Directory= to_utf(__settings__.getSetting("SaveDirectory2"))
		except: Directory=""
		if Directory=="": Directory=to_utf(os.path.join(addon.getAddonInfo('path'), 'strm'))
		
		SaveDirectory = os.path.join(Directory, name)
		if os.path.isdir(fs_enc(SaveDirectory))==0: os.mkdir(fs_enc(SaveDirectory))
		
		title=name
		try:year=info['year']
		except:year=0
		try:plot=info['plot']
		except:plot=''
		try:cover='https://image.tmdb.org/t/p/w300'+info['cover']
		except:cover=''
		try:fanart='https://image.tmdb.org/t/p/w300'+info['fanart']
		except:fanart=''
		try:genre=info['genre']
		except:genre=''
		try:title=info['title']
		except:pass
		
		if __settings__.getSetting("antizapret3")=='true':
				cover=cover.replace('image.tmdb.org','image-tmdb-org.translate.goog')
				fanart=fanart.replace('image.tmdb.org','image-tmdb-org.translate.goog')
		
		nfo='<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>'+chr(10)
		nfo='<tvshow>'+chr(10)
		
		nfo+="	<title>"+title+"</title>"+chr(10)
		nfo+="	<showtitle>"+title+"</showtitle>"+chr(10)
		nfo+="	<premiered>"+str(year)+"</premiered>"+chr(10)
		nfo+="	<season>-1</season>"+chr(10)
		nfo+="	<genre>"+genre+"</genre>"+chr(10)
		nfo+="	<plot>"+plot+"</plot>"+chr(10)
		nfo+="	<fanart><thumb>"+fanart+"</thumb></fanart>"+chr(10)
		nfo+="	<thumb>"+cover+"</thumb>"+chr(10)
		nfo+="</tvshow>"+chr(10)
		
		nfo_path = fs_enc(os.path.join(SaveDirectory, "tvshow.nfo"))
		if not os.path.isfile(nfo_path):
			if sys.version_info.major > 2: 	fl = open(nfo_path, "w", encoding='utf-8')
			else: 							fl = open(nfo_path, "w")
			fl.write(nfo)
			fl.close()

def save_img(url, name, s):
		name=to_utf(name.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"").replace('>',"").replace('<',"").strip())
		ss = str(s)
		if len(ss)<2: ss='0'+ss
		try:Directory= to_utf(__settings__.getSetting("SaveDirectory2"))
		except: Directory=""
		if Directory=="": Directory=to_utf(os.path.join(addon.getAddonInfo('path'), 'strm'))
		
		SaveDirectory = os.path.join(Directory, name)
		if os.path.isdir(fs_enc(SaveDirectory))==0: os.mkdir(fs_enc(SaveDirectory))
		
		f_path = fs_enc(os.path.join(SaveDirectory, 'season'+ss+'-banner.jpg'))
		if not os.path.isfile(f_path):
			data = GET(url)
			try: fl = open(f_path, "wb")
			except: return
			fl.write(data)
			fl.close()
			#showMessage('Сохранено как', name)

def Upd_on_the_air():
	La=[]
	try:
		Lad=themoviedb.on_the_air()
		for info in Lad:
			id = info['id']
			La.append(str(id))
	except: pass
	try:
		Lad=themoviedb.on_the_air2()
		for info in Lad:
			id = info['id']
			La.append(str(id))
	except: pass
	if La!=[]: __settings__.setSetting("on_the_air",repr(La))


def add(id):
	try:L=eval(__settings__.getSetting("Favorites"))
	except:L=[]
	if id not in L: L.append(id)
	__settings__.setSetting("Favorites",repr(L))

def rem(id):
	try:L=eval(__settings__.getSetting("Favorites"))
	except:L=[]
	L2=[]
	for i in L:
		if i != id: L2.append(i)
	__settings__.setSetting("Favorites",repr(L2))

def add_checker(id):
	try:L=eval(__settings__.getSetting("Checker"))
	except:L=[]
	if id not in L: L.append(id)
	__settings__.setSetting("Checker",repr(L))
	Checker_update()

def rem_checker(id):
	try:L=eval(__settings__.getSetting("Checker"))
	except:L=[]
	L2=[]
	for i in L:
		if i != id: L2.append(i)
	__settings__.setSetting("Checker",repr(L2))



def Navigator():
	type   =__settings__.getSetting("type") 
	rating =__settings__.getSetting("rating") 
	year   =__settings__.getSetting("year")
	country=__settings__.getSetting("country").replace(' ','') 
	genre  =__settings__.getSetting("genre") 
	sort   =__settings__.getSetting("sort")
	
	
	AddItem("Жанр:               [COLOR FFFFFF00]" +genre+  "[/COLOR]",   "SelGenre")
	AddItem("Тег:                   [COLOR FFFFFF00]" +type+   "[/COLOR]",   "SelCat")
	AddItem("Год:                  [COLOR FFFFFF00]" +year+   "[/COLOR]",   "SelYear")
	AddItem("Страна:            [COLOR FFFFFF00]" +country+"[/COLOR]",   "SelCountry")
	AddItem("Рейтинг:         [COLOR FFFFFF00]" +rating+ "[/COLOR]",   "SelRating")
	AddItem("Порядок по:  [COLOR FFFFFF00]" +sort+   "[/COLOR]",   "SelSort")
	
	AddItem("[B][COLOR FF00FF00][ Искать ][/COLOR][/B]", "Filtr")

def Filtr():
	type   =__settings__.getSetting("type") 
	rating =__settings__.getSetting("rating") 
	year   =__settings__.getSetting("year")
	country=__settings__.getSetting("country") 
	genre  =__settings__.getSetting("genre") 
	sort   =__settings__.getSetting("sort")
	
	
	f_type   = tag_list[type]
	#f_rating = rating_list['rating']
	#f_year   = year_list['year']
	try:   f_country= countries_list[country]
	except:f_country=''
	try:   f_genre  = genre_list[genre]
	except:f_genre=''
	f_sort   = sort_list[sort]
	
	if year == '--': year = ''
	
	if f_country=='en' or f_country=='': vote_count = '20'
	else:				vote_count = '0'
	
	for p in range(5):
		param = {'without_genres':'16', 'include_null_first_air_dates':'false', 'vote_count.gte':vote_count, 'first_air_date_year':year, 'sort_by':f_sort,'vote_average.gte':rating,'page':str(p+1)}#'vote_count.gte':'900'language
		if f_country!='': param['with_original_language']=f_country
		if f_genre!='':   param['with_genres']=f_genre
		if f_type!='':    param['with_keywords']=f_type
		
		L=themoviedb.filtr(param)
		for info in L:
			id = info['id']
			AddItem(info['title'], "Episodes", id, info, len(L))
		if len(L)<20: break
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

try:    mode = unquote(get_params()["mode"])
except: mode = None
try:    url = unquote(get_params()["url"])
except: url = None
try:    stream = unquote(get_params()["stream"])
except: stream = None
try:    info = eval(unquote(get_params()["info"]))
except: info = {'history':False}
try:    id = str(get_params()["id"])
except: id = '0'
try:    sign = str(get_params()["sign"])
except: sign = ''
try:    season = int(get_params()["season"])
except: season = 0
try:    ind = int(get_params()["ind"])
except: ind = 0
try:    name = get_params()["name"]
except: name = 'Noname'

if mode == None:
	__settings__.setSetting(id="type",    value="--")
	__settings__.setSetting(id="rating",  value="6")
	__settings__.setSetting(id="year",    value="--")
	__settings__.setSetting(id="country", value="--")
	__settings__.setSetting(id="genre",   value="--")
	__settings__.setSetting(id="sort",    value="Популярности")
	Root()

if mode == "Season":
	Season(id, info)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	#xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewTorrent")))

if mode == "Search":
	Search()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Favorites":
	Favorites()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	Upd_on_the_air()

if mode == "Checker":
	Checker()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "ADD": add(id)
if mode == "REM": rem(id)
if mode == "ADD_CK": add_checker(id)
if mode == "REM_CK": rem_checker(id)
if mode == "SET": set_select(id, season, sign)
if mode == "Serials":
	Serials()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewSerial")))

if mode == "Genres":
	Genres()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Genre":
	Genre(id)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewSerial")))

if mode == "Similar":
	Similar(id)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewSerial")))

if mode == "Top":
	Top()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewSerial")))

if mode == "Popular":
	Popular()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewSerial")))


if mode == "On_air":
	On_air()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewSerial")))

if mode == "On_air2":
	On_air2()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewSerial")))

if mode == "New":
	New()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewSerial")))

if mode == "Years":
	Years()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Year":
	Year(id)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewSerial")))

if mode == "Tags":
	Tags()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Tag":
	Tag(id)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewSerial")))

if mode == "Persons":
	Persons(id)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Person":
	Person(id)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Collect":
	Collect(id)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewSerial")))

if mode == "Collection":
	Collection()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)


if mode == "Episodes":
	purl = sys.argv[0] + '?mode=sercher&id='+str(id)
	xbmc.executebuiltin('RunPlugin("'+purl+'")')
	
	if __settings__.getSetting("EpContent") == 'true': xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	if __settings__.getSetting("SList") == 'true': Episodes(id)
	else: Seasons(id)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	#xbmc.sleep(300)
	SetViewMode(int(__settings__.getSetting("ViewEpisode")))

if mode == "Torrent_Directory":
	get_torrent_directory(url, info, name)

if mode == "sercher":
	sercher(themoviedb.get_info(id))

if mode == "Episodes2":
	if __settings__.getSetting("EpContent") == 'true': xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	season=info['season']
	Episodes2(id, season)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	#xbmc.sleep(300)
	SetViewMode(int(__settings__.getSetting("ViewEpisode")))

if mode == "Quality":
	req=Quality(id)
	if req:
		xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
		xbmcplugin.endOfDirectory(handle)

#if mode == "Quality2":
#	Quality(url, id, False)
#	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
#	xbmcplugin.endOfDirectory(handle)

if mode == "Play":
	if Play(id, info):
		xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
		xbmcplugin.endOfDirectory(handle)

if mode == "Play_strm":
	sercher(themoviedb.get_info(id))
	if Play(id, info, True):
		xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
		xbmcplugin.endOfDirectory(handle)

if mode == "Play_item":
	Play_item(stream, url, id, sign, season)

if mode == "Ep_list":
	Ep_list(id, info)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewTorrent")))

if mode == "Ep_list2":
	Ep_list(id, info, False)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewTorrent")))

if mode == "Save": Save(id)

if mode == "Update": get_all_serials()

if mode == "update_info": update_info(id)

if mode == "TopLists":
	TopLists()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Save_strm":
	if __settings__.getSetting("NFO2")=='true': save_film_nfo(id)
	save_strm (url, 0, id)

if mode == "check":
	check()
if mode == "check2":
	Checker_update()
if mode == "Review":
	review(id)

if mode == "Autoplay":
	autoplay(id)

if mode == "TC":
	deb_print ('--- TC ---')
	TC(id, sign, season, name)

if mode == "TC2":
	TC2(id)
if mode == "Open_TAM_Settings":
	Open_TAM_Settings()
if mode == "Open_TVS":
	purl = 'plugin://plugin.video.tvshow.tdw/?mode=Episodes&id='+id
	xbmc.executebuiltin('Container.Update("'+purl+'")')

if mode == "Navigator":
	Navigator()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Filtr":
	Filtr()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "SelCat":
	sel = xbmcgui.Dialog()
	L=[]
	for i in tag_list.keys():
		L.append(i)
	L.sort()
	r = sel.select("Тег:", L)
	if r>-1:__settings__.setSetting(id="type", value=L[r])
	
if mode == "SelGenre":
	sel = xbmcgui.Dialog()
	L=[]
	for i in genre_list.keys():
		L.append(i)
	L.sort()
	r = sel.select("Жанр:", L)
	if r>-1:__settings__.setSetting(id="genre", value=L[r])
	
if mode == "SelCountry":
	sel = xbmcgui.Dialog()
	L=[]
	for i in countries_list.keys():
		L.append(i)
	L.sort()
	r = sel.select("Страна:", L)
	if r>-1:__settings__.setSetting(id="country", value=L[r])

if mode == "SelSort":
	sel = xbmcgui.Dialog()
	L=[]
	for i in sort_list.keys():
		L.append(i)
	r = sel.select("Порядок:", L)
	if r>-1:__settings__.setSetting(id="sort", value=L[r])

if mode == "SelYear":
	sel = xbmcgui.Dialog()
	L=years_list
	r = sel.select("Год:", L)
	if r>-1:__settings__.setSetting(id="year", value=years_list[r])

if mode == "SelRating":
	sel = xbmcgui.Dialog()
	L=['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']
	r = sel.select("Рейтинг:", L)
	if r>-1:__settings__.setSetting(id="rating", value=L[r])

#print tvfeed.GET_TOKEN()
#add_ch('id', {}, ['',])
#import s09_megapeer
c.close()
