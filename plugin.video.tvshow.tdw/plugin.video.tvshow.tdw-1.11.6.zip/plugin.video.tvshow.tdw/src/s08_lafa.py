#!/usr/bin/python
# -*- coding: utf-8 -*-

import string, xbmc, xbmcgui, xbmcplugin, urllib, cookielib, xbmcaddon
#-------------------------------
from core import *
icon = ""
siteUrl = 't.lafa.site'
httpSiteUrl = 'http://' + siteUrl

__settings__ = xbmcaddon.Addon(id='plugin.video.tvshow.tdw')
def encod(x):
	try:x=x.decode('Windows-1251')
	except:pass
	try:x=x.encode('utf-8')
	except:pass
	return x

def coder(x):
	x=x.decode('utf-8')
	x=x.encode('Windows-1251')
	return x

def clear(s):
	L=['<b>','</b>','</a>','</td>']
	for i in L:
		s=s.replace(i,'')
	s=s.replace(chr(10),'').replace(chr(13),'').replace('\t','').strip()
	return s

def Parser2(hp):
	#deb_print('======= parser2 ==========')
	sr_title = mfind(hp,'notop"><span itemprop="name">', '</td>').replace('</span>', '').replace('<br>', '')#ListItem"><span itemprop="name">
	#deb_print(sr_title)
	Lout=[]
	ss='class="expand-child"'
	es='width=36 height=36 src=/pic/document_save.svg></a>'
	Lid=[]
	L=findall(hp, ss,es)
	L2=[]
	#deb_print(len(L))
	for i in L:
		try:
					deb_print( '---------------------')
					#deb_print(i)
					url=httpSiteUrl+'/downloadt'+mfind(i, 'href="/downloadt', '">')
					deb_print(url)
					title=mfind(i, '<div style="float:left;">', '</')
					title=title[title.find('('):]
					if 'hild id' in title: title=title[:title.find('hild id')]
					deb_print(title)
					if '<td width="20%">' in i: sez=mfind(i, '<td width="20%">', '</')
					else: sez=''
					
					lng=mfind(i, 'dl_trad">', '</td>').replace('</span>', '').replace('<br>', '').replace('<i>', '').replace('</i>', '')
					
					sids = '?'#mfind(i, '<font color="green">&uarr; ', '<')
					deb_print(sids)
					size = mfind(mfind(i, 'data-sort-value', 'td>'), '>', '<')
					deb_print(size)
					quality = mfind(mfind(i, 'class="ttip"', 'span>'), '>', '<')
					
					#if __settings__.getSetting("antizapret") == "true": url = unlock(url)
					f_title = sr_title+' '+title+' '+sez+' '+lng
					f_title = f_title.replace('torrent', '').replace('<img src=/pic/rk.svg>', '')
					Lout.append({"sids":sids, "size":size, "title":f_title, "url":url, "quality": quality})
					#deb_print( Lout
		except:
					#deb_print( '=================================='
					#deb_print( i
					deb_print('err')
	return Lout

def Parser1(hp, info):
	deb_print('--parser--')
	Lout=[]
	ss='<tr><td>'
	es='</td></tr>'
	Lid=[]
	L=findall(hp, ss,es)
	L2=[]
	deb_print(len(L))
	for i in L:
		url = httpSiteUrl+mfind(i, '<a href="', '">')
		deb_print(url)
		#title = mfind(i, 'htm">', '<')
		#if info['title'] in title: 
		L2.append(url)
	return L2



def Storr(info):
	#deb_print('---LAFA---')
	Lout=[]
	text=lower(info['title'])
	
	url='http://t.lafa.site/ajax.php?action=quicksearch&keyword='+quote(text)
	#deb_print(url)
	#post='search='+urllib.quote_plus(text)+'&cat=3&search_in=0'
	
	http=GET(url)#,'http://torrent.by', post)
	#deb_print(http)
	L2=Parser1(http, info)
	Lout=[]
	for i in L2:
		#deb_print(i)
		r=encod(GET(i))
		Lout.extend(Parser2(r))
	
	
	return Lout



class Tracker:
	def __init__(self):
		pass

	def Search(self, info):
		Lout=Storr(info)
		return Lout

#Storr({'title': 'terminator'})