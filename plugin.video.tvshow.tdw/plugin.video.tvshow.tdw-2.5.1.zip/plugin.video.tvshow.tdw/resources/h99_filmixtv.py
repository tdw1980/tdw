#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys, json, time

prov = 'rezka'
serv = 'http://77.238.239.103:12133/lite/'
D_UA='|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 OPR/77.0.4054.203'

if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2


def b2s(s):
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def test_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False

def CRC32(buf):
		import binascii
		if sys.version_info.major > 2: buf = (binascii.crc32(buf.encode('utf-8')) & 0xFFFFFFFF)
		else: buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		r=str("%08X" % buf)
		return r

def add_ch(id, D):
	try:
		import settings
		settings.set(prov+'_ch_'+id, {'ch':D, 'tm': time.time()})
	except: pass


def get_ch(id):
	try:
		import settings
		Dch  = settings.get(prov+'_ch_'+id)
		D  = Dch['ch']
		tm = Dch['tm']
		if (time.time()-tm<3600*3): return D
		else: return None
	except:
		return None

def unlock(url):
	try:
		import xbmcaddon
		tam_settings = xbmcaddon.Addon(id='plugin.video.tam')
		tam_port = int(tam_settings.getSetting("serv_port"))
	except:
		tam_port = 8095
	url='http://127.0.0.1:'+str(tam_port)+'/proxy/'+url
	return url


def findall(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	if e=='': r2=r
	else: r2=r[:r.find(e)]
	return r2


def GET2(target, referer='', post=None):
		import requests
		s = requests.session()
		r=s.get(target, timeout=(0.6, 4), verify=False).text
		return r


def GET(target, referer='', post=None):
	urllib2.install_opener(urllib2.build_opener())
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return b2s(http)
	except:
		return GET2(target)

def is_libreelec():
	try:
		if os.path.isfile('/etc/os-release'):
			f = open('/etc/os-release', 'r')
			str = f.read()
			f.close()
			if "LibreELEC" in str and "Generic" in str: return True
	except: pass
	return False

def rt(s):
	if sys.version_info.major > 2: return s
	try:s=s.decode('utf-8')
	except: pass
	if not is_libreelec():
		try:s=s.decode('windows-1251')
		except: pass
	try:s=s.encode('utf-8')
	except: pass
	return s

def filtr(s=''):
	L=['[UA]', 'UKR', ' Ukr', 'Укра', 'укра', u'Укра', u'укра']
	try:
		for i in L:
			if i in rt(s): return False
			if i in s: return False
	except: pass
	return True


def get_movie(info={}):
	Lr=[]
	try:
		en_title = quote(info['originaltitle'])
		ru_title = quote(info['title'])
		year = str(info['year'])
		kp_id = info['id']
		url=serv+prov+'?serial=0&kinopoisk_id='+kp_id+'&original_title='+en_title+'&title='+ru_title+'&year='+year#&kinopoisk_id=5457899&title=Дикий%20робот&original_language=en&source=tmdb&clarification=0'
	except:
		url=serv+prov+'?id=1184918&imdb_id=tt29623480&kinopoisk_id=5457899&title=Дикий%20робот&original_title=The%20Wild%20Robot&serial=0&original_language=en&year=2024&source=tmdb&clarification=0'
	
	h=GET(url)
	L=findall(h,"data-json='{","}'><div class")
	for i in L:
		try:
			j=i.replace("data-json='","")+"}"
			#print (j)
			if filtr(j):
				D=json.loads(j)
				t=D['translate'].replace('4K','').replace('SDR','').replace(',','').replace('  ',' ').replace('  ',' ').replace('[ ]','')
				if filtr(t):
					try:
						Lq=D['quality']
						for q in Lq.keys():
							stream = Lq[q]
							#print (t+' '+q)
							if '360' not in q: Lr.append ({"sids":'0',"size":'0', "title": '[ '+prov+' ] '+t+' '+q, "url":stream})
					except:
						stream = D['url']
						ttl = D['title']
						if t not in ttl: ttl=ttl+' '+t
						Lr.append ({"sids":'0',"size":'0', "title": '[ '+prov+' ] '+ttl, "url":stream})
		except: pass
	return Lr

#print (get_movie())
def get_kp_id(imdb_id):
	url='https://api.manhan.one/externalids?serial=1&imdb_id='+imdb_id
	j=GET(url)
	D=json.loads(j)
	kp_id=D['kinopoisk_id']
	return kp_id

def get_serial_off(info={}):
	Lr=[]
	try:
		en_title = quote(info['originaltitle'])
		ru_title = quote(info['title'])
		year = str(info['year'])
		kp_id = str(info['id'])
		url='https://api.manhan.one/late/'+prov+'?serial=1&kinopoisk_id='+kp_id+'&original_title='+en_title+'&title='+ru_title+'&year='+year#&kinopoisk_id=5457899&title=Дикий%20робот&original_language=en&source=tmdb&clarification=0'
		#print (url)
	except:
		url='https://api.manhan.one/late/'+prov+'?title=%D0%98%D0%B7%D0%B2%D0%BD%D0%B5&original_title=FROM&serial=1&original_language=en&year=2022&kinopoisk_id=4476885'
		#url='http://212.34.154.180:9441/lite/'+prov+'?id=94605&imdb_id=tt11126994&kinopoisk_id=4445150&title=Аркейн&original_title=Arcane&serial=1&original_language=en&year=2021&source=tmdb&clarification=0'
	h=GET(url)
	Ls=findall(h,"data-json='{","}'><div class")
	for si in Ls:
		try:
			j=si.replace("data-json='","")+"}"
			print (j)
			D=json.loads(j)
			S=mfind(j,'&s=','"')
			if len(S)==1:S='0'+S
			tl_url=D['url']
			tlh=GET(tl_url)
			q=mfind(tlh,'"quality":{"','":"')
			Lt=findall(tlh,"data-json='{","</div><div")
			for ti in Lt:
				#jt=ti.replace("data-json='","").replace("}'>", ',"trl":"')+'"}'
				jt=mfind(ti,"data-json='","}'>")+'}'
				#print (jt)
				if '"method":"link"' in jt and filtr(jt):
					#print (jt)
					Dt=json.loads(jt)
					link=Dt['url']
					t= unquote(mfind(link,'&t=','')).replace('+',' ')#Dt['trl'].replace('4K','').replace('SDR','').replace(',','').replace('  ',' ').replace('  ',' ').replace('[ ]','').replace('</div>','')
					#print (link)
					Lr.append ({"sids":'0',"size":'0', "title": '[ '+prov+' ] s'+S+' '+t+' '+q, "url":"manhan_"+prov+"_season:"+link})
		except: pass
	return Lr

def get_serial(info={}):
	Lr=[]
	try:
		en_title = quote(info['originaltitle'])
		ru_title = quote(info['title'])
		year = str(info['year'])
		imdb_id = str(info['imdb_id'])
		kp_id = get_kp_id(imdb_id)
		url=serv+prov+'?serial=1&imdb_id='+imdb_id+'&original_title='+en_title+'&title='+ru_title+'&year='+year+'&kinopoisk_id='+kp_id#&title=Дикий%20робот&original_language=en&source=tmdb&clarification=0'
		
	except:
		year = '2022'
		url=serv+prov+'?title=%D0%98%D0%B7%D0%B2%D0%BD%D0%B5&original_title=FROM&serial=1&original_language=en&year=2022&kinopoisk_id=4476885'
		#url='http://212.34.154.180:9441/lite/'+prov+'?id=94605&imdb_id=tt11126994&kinopoisk_id=4445150&title=Аркейн&original_title=Arcane&serial=1&original_language=en&year=2021&source=tmdb&clarification=0'
	print (url)
	h=GET(url)
	if 'season selector focused' in h: 
		url = json.loads(mfind(h,"data-json='","}'")+'}')['url']
		h=GET(url)
	Ls=findall(h,"data-json='{","}'><div class")
	#bi = Ls[0]
	#for ss in range(2,9):
	#	Ls.append(bi.replace('&s=1','&s='+str(ss)))
	for si in Ls:
		try:
			j=si.replace("data-json='","")+"}"
			if '&s=' in j:
				S=mfind(j,'&s=','"')
				if len(S)==1:S='0'+S
			else:
				S='0'
			#print (j)
			#'{"method":"link","url":"http://77.238.239.103:12133/lite/filmix?postid=6079\u0026title=%d0%94%d0%b5%d0%ba%d1%81%d1%82%d0%b5%d1%80\u0026original_title=Dexter","similar":true,"year":2006,"details":"","img":"/proxyimg:210:0/6596813b39c0f022f1a662aba19ce515.jpg"}'
			D=json.loads(j)
			tl_url=D['url']
			
			tlh=GET(tl_url)
			if '"method":' not in tlh: break
			
			q='hd'#mfind(tlh,'"quality":{"','":"')
			
			Lt=findall(tlh,"data-json='{","</div><div")
			for ti in Lt:
				#print (ti)
				t= unquote(mfind(ti,">",'')).replace('+',' ').replace('4K','').replace('SDR','').replace(',','').replace('  ',' ').replace('  ',' ').replace('[ ]','').replace('</div>','')
				jt=mfind(ti,"data-json='","}'>")+'}'
				#print (jt)
				if '"method":"link"' in jt and 'UKR' not in jt and ' Ukr' not in jt and 'Украин' not in jt :
					#print (jt)
					Dt=json.loads(jt)
					link=Dt['url']
					if 'Украин' not in t and 'UKR' not in t and ' Ukr' not in t :
						#print ({"translate":t, "season":S, "quality":q, "title": '[ '+prov+' ] s'+S+' '+t+' '+q, "url":link})
						#Lr.append ({"sids":'0',"size":'0', "title": '[ '+prov+' ] s'+S+' '+t+' '+q, "url":"manhan_"+prov+"_season:"+link})
						Lr.append ({"translate":t, "season":S, "quality":q, "title": '[ '+prov+' ] s'+S+' '+t+' '+q, "url":link})
		except: pass
	return Lr

#print(get_serial())

def get_episodes(url):
	Lr=[]
	h=GET(url.replace('manhan_'+prov+'_season:',''))
	#print (h)
	Le=findall(h,'{"method":"play"',"}'><div class")
	for ei in Le:
		j=ei.replace("data-json='","")+"}"
		print (j)
		if '"method":"play"' in j :
			D=json.loads(j)
			method = D['method']
			if method == 'play':
				stream=D['url']
				qse=stream[stream.rfind('/')+1:stream.rfind('.')]
				print (qse)
				
				ttl=D['title']#+' [COLOR 00ffffff]'++'[/COLOR]'
				e=mfind(ttl,' (',' ')
				#Lr.append ({"sids":'0',"size":'0', "title": ttl, "url":stream})#'['+qse+'] '+
				Lr.append ({"sids":'0',"ep":e, "title": ttl, "url":stream})
	return Lr

get_episodes('http://77.238.239.103:12133/lite/rezka/serial?rjson=False&title=Извне&original_title=FROM&href=https%3a%2f%2fhdrezka.me%2fseries%2fdrama%2f46417-izvne-2022-latest.html&id=46417&t=549&s=1')

def get_serial_episodes(info={}):
	id=str(info['id'])
	Dc=get_ch(id)
	#if Dc!=None: return Dc

	L2=[]
	D={}
	L=get_serial(info)
	for si in L:
		t = si['translate']
		q = si['quality']
		s = int(si['season'])
		url = si['url']
		L2=get_episodes(url)
		if s not in D.keys(): D[s]={}
		for i in L2:
			try:
				stream = i['url']
				e=int(i['ep'])
				if e not in D[s].keys(): D[s][e]=[]
				print ({'translate':t,'quality':q, 'url':stream})
				D[s][e].append({'translate':t,'quality':q, 'url':stream})
			except: pass
	
	#if D!={}: add_ch(id, D)
	return D
#print (get_serial_episodes())

class Tracker:
	def Search(self, info):
		id=info['id']
		Dc=get_ch(id)
		if Dc!=None: return Dc
		#print (info)
		Lout = []
		#if info['type']=='': Lout = get_movie(info)
		#else:                
		Lout = get_serial(info)
		
		if Lout != []: add_ch(id, Lout)
		return Lout

		
	def Episodes(self, url):
		id=CRC32(url)
		Dc=get_ch(id)
		if Dc!=None: return Dc
		
		Lout = []
		Lout = get_episodes(url)
		
		if Lout != []: add_ch(id, Lout)
		return Lout
