#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys, time
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
#-------------------------------


icon = ""
siteUrl = 'fileek.com'
httpSiteUrl = 'http://' + siteUrl
addon = xbmcaddon.Addon(id='plugin.video.KinoPoisk.ru')
#__settings__ = xbmcaddon.Addon(id='plugin.video.KinoPoisk.ru')

__settings__ = xbmcaddon.Addon(id='plugin.video.tvshow.tdw')
#def unlock(url):
#	url='http://127.0.0.1:8095/proxy/'+url
#	return url


if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2


def b2s(s):
	if test_torrent(s)==False: return s
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def test_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False


def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "wb")
	fl.write(s)
	fl.close()


def GET(target, referer='http://fileek.com', post=None):
	#print (target)
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return b2s(http)
	except:
		return ''

def upd(info, p):
	text=info['originaltitle']
	search=text.replace(' ','+')
	#url= 'http://fileek.com/search/?q='+search+'&ft%5B%5D=cinema&page='+p
	url= 'http://fileek.com/search/?q='+search+'&fs%5B%5D=2&fs%5B%5D=3&fs%5B%5D=4&fs%5B%5D=5&ft%5B%5D=cinema&fc%5B%5D=&page='+p#+'&f_yf='+year1+'&f_yt='+year2+''
	
	http = GET(url)
	if http == None:
		print ('Сервер не отвечает')
		return None
	else:
		return http

def Parser(http, info):
	Lout=[]
	title=info['title']
	
	
	hp=http[http.find('id="files_list"'):]
	ss='<div id="item_'
	es='>Загрузить<'
	Lid=[]
	L=mfindal(hp, ss,es)
	L2=[]
	for i in L:
		#if title in i and (year1 in i or year2 in i):
			if 'download-btn' in i:
				id = mfind(i,'checkLink(',', &quot;')
				if id not in Lid:
					Lid.append(id)
					torrent=get_torrent(id)
					size=mfind(i, '<div class="size">', '</div>')
					title=mfind(i, 'href="#">', '</a></div>')
					seed='0'
					Lout.append({"sids":seed, "size":size, "title":xt(title),"url":torrent, "quality": ""})
	return Lout

def get_torrent(id):
	url = 'http://fileek.com/index.php?r=download/ajaxlinkcheck&id='+id+'&action=%2Fsearch&ismagnet=0'
	link=eval(GET(url).replace("\\/", "/"))['link']
	return link

def get_sz(url):
	http=GET(url)
	L=[25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1]
	for i in L:
		if 'season-'+str(i) in http: return i
	return 0

def Storr(info):
	Lout=[]
	#text=info['originaltitle']
	p = 1
	http=upd(info, str(p))
	Lout.extend(Parser(http, info))
	if 'href="#">2<' in http:
		p = 2
		http=upd(info, str(p))
		Lout.extend(Parser(http, info))
	if 'href="#">3<' in http:
		p = 3
		http=upd(info, str(p))
		Lout.extend(Parser(http, info))
	return Lout



class Tracker:
	def Search(self, info):
		Lout=Storr(info)
		return Lout