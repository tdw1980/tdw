# -*- coding: utf-8 -*-
# *  Copyright (C) 2020 TDW

import time, os, sys, settings
api_key='ef17a1e0c9df7d0c6a926a0c94627e93'
api_url='https://api.themoviedb.org/3'
api_lang='ru-RU'
#prx='https://proxy-nossl.antizapret.prostovpn.org:29976'
#proxy_support = urllib2.ProxyHandler({"http" : prx, "https" : prx})
#opener = urllib2.build_opener(proxy_support)
antizapret = False


if sys.version_info.major > 2:  # Python 3 or later
	import urllib.request
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote_plus as unquote
	import urllib2


def b2s(s):
	if err_torrent(s)==False: return s
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		if not is_libreelec():
			try:s=s.decode('windows-1251')
			except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def err_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False

def is_libreelec():
	try:
		if os.path.isfile('/etc/os-release'):
			f = open('/etc/os-release', 'r')
			str = f.read()
			f.close()
			if "LibreELEC" in str and "Generic" in str: return True
	except: pass
	return False

from threading import Thread
class MyThread(Thread):
	def __init__(self, param):
		Thread.__init__(self)
		self.param = param
	
	def run(self):
		url=self.param['url']
		UPD_CH(url)

def create_thread(param):
		my_thread = MyThread(param)
		my_thread.start()

def JSON(j):
	null = None
	false = False
	true = True
	r = eval(j.replace('\\/','/'))
	return r

def GET(url, Referer = ''):
	data=GET_2(url, Referer = '')
	if len(data)>0: return data
	time.sleep(1000)
	data=GET_2(url, Referer = '')
	if len(data)>0: return data
	time.sleep(1000)
	data=GET_2(url, Referer = '')
	if len(data)>0: return data

def GET_2(url, Referer = ''):
	D=get_ch(url)
	ch = D['data']
	if time.time()-D['tm']<3600*24 and ch!='': 
		if time.time()-D['tm']>3600*3: create_thread({'url':url})
		return ch
	try:
		t_out = 5
		if api_url in url and antizapret: 
			#url='http://127.0.0.1:8095/proxy/'+url #opener = urllib2.build_opener(proxy_support)
			#https://api-themoviedb-org.translate.goog/3/tv/95403/season/1?api_key=ef17a1e0c9df7d0c6a926a0c94627e93&language=ru-RU
			url=url.replace('api.themoviedb.org','api-themoviedb-org.translate.goog')
			t_out = 10
		
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36 OPR/72.0.3815.400')
		response = urllib2.urlopen(req, timeout = t_out)
		data=b2s(response.read())
		response.close()
		if data==None: data==''
		if len(data)>0: 
			add_ch(data, url)
			return data
		else:
			return ch
	except: 
		if ch!='': return ch
		else: return ''

def UPD_CH(url, Referer = ''):
	try:
		t_out = 5
		if api_url in url and antizapret: 
			url=url.replace('api.themoviedb.org','api-themoviedb-org.translate.goog')
			t_out = 15
		
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36 OPR/72.0.3815.400')
		response = urllib2.urlopen(req, timeout = t_out)
		data=b2s(response.read())
		response.close()
		if data==None: data==''
		if len(data)>0: add_ch(data, url)
	except: pass


def deb_print(t):
	try: print (t)
	except: print (repr(t))

def CRC32(buf):
		import binascii
		if sys.version_info.major > 2: buf = (binascii.crc32(buf.encode('utf-8')) & 0xFFFFFFFF)
		else: buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		r=str("%08X" % buf)
		return r

def add_ch(data, url):
	url=url.replace('api-themoviedb-org.translate.goog','api.themoviedb.org')
	#print ('add_ch')
	try:
		SID = 'get_'+str(CRC32(url))
		#print (SID)
		D={}
		D['data'] = data
		D['tm']=time.time()
		settings.set(SID, repr(D))
	except: pass

def get_ch(url):
	url=url.replace('api-themoviedb-org.translate.goog','api.themoviedb.org')
	#print ('get_ch')
	try:
		SID = 'get_'+str(CRC32(url))
		#print (SID)
		D  = eval(settings.get(SID))
		data = D['data']
		#print (data)
		tm = D['tm']
		return {'tm':tm, 'data':data}
	except:
		return {'tm':0, 'data':''}

def add_tr(data, url):
	try:
		import kinodb
		kinodb.save_translate(url, data)
	except: pass
	try:
		SID = 'tt_'+str(CRC32(url))
		settings.set(SID, repr(data))
	except: pass

def get_tr(url):
	try:
		SID = 'tt_'+str(CRC32(url))
		data = eval(settings.get(SID))
		return data
	except: pass
	try:
		import kinodb
		data  = kinodb.get_translate(url)
		if data !='':
			SID = 'tt_'+str(CRC32(url))
			settings.set(SID, repr(data))
		return data
	except:
		return ''


def translate(t):
	try:
		if t=='': return ''
		if 'Episode' in t: return ''
		if len(t)< 5: return ''
		tt = get_ch(t)['data']
		if tt !='': 
			return tt
		else:
			tt = get_tr(t)
			if tt !='': 
				add_ch(tt, t)
				return tt
		
		try: tm=float(eval(settings.get('tm_trl_err')))
		except: tm=0
		if time.time()-tm < 3600*6  and tm > 100: 
			#print tm
			deb_print('translate timeout :'+str(3600*6-(time.time()-tm)))
			return ''
		
		url = 'https://api.mymemory.translated.net/get?langpair=en|ru&q='+urllib.quote_plus(t[:250])
		deb_print(url)
		h=GET(url)
		deb_print(h)
		null = None
		false = False
		true = True
		json = eval(h)
		if json['quotaFinished']!=False: return ''
		tt = eval('u"'+json['responseData']['translatedText']+'"')
		tt = tt.replace('\\/', '/')
		if tt !='': 
			add_ch(tt, t)
			add_tr(tt, t)
		deb_print('translate OK')
		return tt
	except:
		settings.set('tm_trl_err', repr(time.time()))
		return ''

#=============== API ==================
#sort_by=
#popularity.desc/.asc
#vote_average.desc/.asc
#first_air_date.desc/.asc

#with_genres=18
#include_null_first_air_dates=false
#first_air_date_year=2000
#vote_count.gte=50
#vote_average.gte=6
def discover(param):
	head = api_url+'/discover/tv?api_key='+api_key+'&language='+api_lang
	tail = ''
	for key in param.keys():
		tail = tail+'&'+key+'='+param[key]
	url = head + tail
	
	j=GET(url)
	D=JSON(j)
	return D

def search(q):
	q=quote(q)
	url = api_url+'/search/tv?api_key='+api_key+'&query='+q+'&language='+api_lang
	j=GET(url)
	L=JSON(j)['results']
	LL=[]
	for i in L:
		LL.append(kodi_info(i))
	return LL


def seasons(id):
	url = api_url+'/tv/'+str(id)+'?api_key='+api_key+'&language='+api_lang
	#deb_print(url)
	j=GET(url)
	#deb_print(j)
	L=JSON(j)['seasons']
	Ls=[]
	try:total = L[-1]['season_number']
	except:total = 0
	for i in L:
		Ls.append({'season':i['season_number'], 'title':i['name'], 'plot':i['overview'], 'cover':i['poster_path'], 'id':i['id'], 'year': i['air_date'], 'total':total})
	return Ls

def episodes(id, sn, tr=False):
	url = api_url+'/tv/'+str(id)+'/season/'+str(sn)+'?api_key='+api_key+'&language='+api_lang
	deb_print(url)
	j=GET(url)
	deb_print(j)
	L=JSON(j)['episodes']
	Le=[]
	d_en = {}
	if tr == True:
		try:
			#if L[0]['overview']=='': 
				deb_print('= overview_en =>')
				d_en = overview_en(id, sn)
		except: pass
	for i in L:
		info = kodi_info(i)
		if 'title' not in info.keys(): 
			title = 'Эпизод '+str(info['episode'])
			info['title'] = title
		
		if 'Эпизод ' in info['title']:
			try:tr_title = translate(d_en['t'+str(info['episode'])])
			except: tr_title = ''
			if tr_title!='': info['title'] = tr_title
		
		if i['overview']=='':
			try: info['plot']=translate(d_en[info['episode']])#+' [COLOR 80808080][translated][/COLOR]'
			except: pass
		Le.append(info)
	return Le

def overview_en(id, sn):
	url = api_url+'/tv/'+str(id)+'/season/'+str(sn)+'?api_key='+api_key+'&language=en-EN'
	#deb_print(url)
	j=GET(url)
	#deb_print(j)
	L=JSON(j)['episodes']
	d_en={}
	
	n_ow=0
	n_tt=0
	for info in L:
		if n_ow<2:
			ep = info['episode_number']
			en_ow = info['overview']
			deb_print(en_ow)
			#ow = translate(en_ow)
			d_en[ep]=en_ow
		
		if n_tt<2:
			en_title = info['name']
			deb_print(en_title)
			#title = translate(en_title)
			d_en['t'+str(ep)]=en_title
		
		#if  ow == '': n_ow+=1
		#if title=='': n_tt+=1
		
	return d_en


def get_info(id):
	url = api_url+'/tv/'+str(id)+'?api_key='+api_key+'&language='+api_lang
	#deb_print(url)
	j=GET(url)
	#deb_print(j)
	D=JSON(j)
	return kodi_info(D)
#====================================
def kodi_info(mdb_info):
	print ('======kodi_info======')
	#deb_print(mdb_info)
	key_dict = {'title':'name', 'originaltitle': 'original_name', 'rating': 'vote_average', 'plot': 'overview', 'cover': 'poster_path', 'fanart': 'backdrop_path', 'year': 'first_air_date', 'episode':'episode_number', 'season':'season_number', 'thumb':'still_path', 'premiered':'air_date', 'id':'id'}
	info={}
	for key in key_dict.keys():
		try: info[key]=mdb_info[key_dict[key]]
		except: pass
	
	Dg={10759:'Боевик',16:'Мультфильм',35:'Комедия',80:'Криминал',99:'Документальный',18:'Драма',10751:'Семейный',10762:'Детский',9648:'Детектив',10763:'Новости',10764:'Реалити-шоу',10765:'Фантастика / Фэнтези',10766:'Мыльная опера',10767:'Ток-шоу',10768:'Война',37:'Вестерн'}
	
	if 'genre_ids' in mdb_info.keys():
		genre = []
		Lgi = mdb_info['genre_ids']
		for gi in Lgi:
			if gi in Dg.keys(): genre.append(Dg[gi])
		if genre != []: info['genre']=genre
	
	if 'origin_country' in mdb_info.keys():
		country = mdb_info['origin_country']
		info['country']=country
		info['studio']=country
		if 'JP' in country or 'TH' in country or 'KR' in country:
			id = mdb_info['id']
			alt_title = get_alt_title(id)
			try:alt_title=alt_title.encode('utf-8')
			except: pass
			if info['originaltitle'] == info['title']: info['title']=b2s(alt_title)
			info['originaltitle']=b2s(alt_title)
	
	if 'season' not in mdb_info.keys():
		if 'origin_country' in mdb_info.keys():
			country = mdb_info['origin_country']
			if 'RU' not in country:
				ms_info = {}
				if info['originaltitle'] == info['title']:
					#print 'Title'
					ms_info = get_alt_info(info['originaltitle'], info['year'])
					if ms_info !={}:
						if ms_info['title'] !='':
							info['title'] = ms_info['title']
							#print 'set Title: '+info['title'] 
				if 'plot' not in info.keys(): plot = ''
				else: plot = info['plot'] 
				
				if len(plot) < 3:
					#print 'Plot'
					#if ms_info =={}: ms_info = get_alt_info(info['originaltitle'], info['year'])
					if ms_info !={}: 
						info['plot'] = ms_info['plot']
						#print 'set plot: '+info['plot']
					
	deb_print ('=====>=======')
	return info


def get_years(id):
	url = api_url+'/tv/'+str(id)+'?api_key='+api_key
	j=GET(url)
	D=JSON(j)
	fad=int(D['first_air_date'][:4])
	lad=int(D['last_air_date'][:4])
	return range(fad,lad+1)


def get_alt_info(en_title, year):
	#return {}
	info = get_ms_info(en_title)
	#if info != {}: 
	return info
	#if str(year) > 4: year = str(year)[:4]
	#info = get_kp_info(en_title, year)
	#return info

def get_ms_info(t):
	try:
		import myshows
		L=myshows.search(t)
		#deb_print(L)
		if L==[]: return {}
		info = L[0]
		#deb_print(info)
		#deb_print(t.lower())
		#deb_print(info['title'].lower())
		if t.lower() == info['title'].lower():
			deb_print('title OK')
			ruTitle=info['ruTitle'].encode('utf-8')
			deb_print(ruTitle)
			description=info['description'].encode('utf-8').replace('<p>','').replace('</p>','')
			if '\\u' in description: description=eval("u'"+description+"'").encode('utf-8')
			#deb_print(description)
			return {'title': ruTitle, 'plot': description}
		else: return {}
	except:
		return {}

import kpdb
def get_kp_info(en_title, year):
	try:
		#print ('get_KP_info')
		#print (en_title, year)
		kp_id_s = kpdb.search_id(en_title, year)
		if kp_id_s !='': 
			info = get_kpdb_info(kp_id_s)
			if info != {}: 
				#print (info['title'])
				return {'title': info['title'], 'plot': info['plot']}
			else: return {}
		else: return {}
	except:
		return {}

def get_kpdb_info(kp_id):
	import kpdb
	try: info = kpdb.get_info(kp_id)
	except: info = {}
	return info

def get_en_title(id):
	url = api_url+'/tv/'+str(id)+'?api_key='+api_key
	try:
		j=GET(url)
		D=JSON(j)
		return D['name']
	except:
		return ''

def get_alt_title(id):
	try:
		import msdb
		return msdb.get_inf_db('alt'+str(id))
	except: pass
	alt_title = ''
	url = api_url+'/tv/'+str(id)+'/alternative_titles?api_key='+api_key
	j=GET(url)
	try: L=JSON(j)['results']
	except: L=[]
	for i in L:
		if i['iso_3166_1'] == 'JP': 
			alt_title = i['title']
			try: msdb.add_to_db('alt'+str(id), alt_title)
			except: pass
			return alt_title
	
	en_title=get_en_title(id)
	try: msdb.add_to_db('alt'+str(id), en_title)
	except: pass
	
	return en_title

def get_genre_list():
	url = api_url+'/genre/tv/list?api_key='+api_key+'&language='+api_lang
	j=GET(url)
	L=JSON(j)['genres']
	return L

def get_genre(id):
	LL=[]
	for p in range(5):
		if id == 'anime': param = {'include_null_first_air_dates':'false', 'sort_by':'vote_average.desc', 'vote_count.gte':'30','vote_average.gte':'4','with_genres':'16','with_original_language':'ja','page':str(p+1)}
		else:
			param = {'include_null_first_air_dates':'false', 'sort_by':'vote_average.desc', 'vote_count.gte':'150', 'vote_average.gte':'4', 'with_genres':str(id),'page':str(p+1)}
			if str(id) != '16': param['without_genres']='16'
			else:               param['without_keywords']='210024, 233'
		L=discover(param)['results']
		for i in L:
			LL.append(kodi_info(i))
	return LL

def on_the_air2():
	LL=[]
	for p in range(3):
		param = {'include_null_first_air_dates':'false', 'sort_by':'vote_count.desc', 'air_date.gte':'2022-06-01', 'vote_average.gte':'6', 'page':str(p+1)}#'air_date.lte':'2022-07-08', 'with_status':'2', 'vote_count.gte':'150'
		L=discover(param)['results']
		for i in L:
			LL.append(kodi_info(i))
	return LL


def similar(id):
	url = api_url+'/tv/'+id+'/similar?api_key='+api_key+'&language='+api_lang
	j=GET(url)
	L=JSON(j)['results']
	LL=[]
	for i in L:
		LL.append(kodi_info(i))
	return LL

def new():
	param = {'include_null_first_air_dates':'false', 'sort_by':'first_air_date.desc', 'vote_count.gte':'10','vote_average.gte':'5'}
	L=discover(param)['results']
	LL=[]
	for i in L:
		LL.append(kodi_info(i))
	return LL

def top():
	LL=[]
	for p in range(10):
		param = {'include_null_first_air_dates':'false', 'sort_by':'vote_count.desc', 'vote_count.gte':'900','vote_average.gte':'6','without_genres':'16','page':str(p+1)}#vote_average.desc
		L=discover(param)['results']#
		for i in L:
			LL.append(kodi_info(i))
	return LL


def top_mult():
	LL=[]
	for p in range(5):
		param = {'include_null_first_air_dates':'false', 'sort_by':'popularity.desc', 'vote_count.gte':'100','vote_average.gte':'5','with_genres':'16','include_adult':'false','page':str(p+1)}
		L=discover(param)['results']
		for i in L:
			LL.append(kodi_info(i))
	return LL

def popular():
	LL=[]
	for p in range(5):
		param = {'include_null_first_air_dates':'false', 'sort_by':'popularity.desc', 'vote_count.gte':'80','vote_average.gte':'5','page':str(p+1)}
		L=discover(param)['results']
		for i in L:
			LL.append(kodi_info(i))
	return LL


def on_the_air():
	LL=[]
	for p in range(5):
		url = api_url+'/tv/on_the_air?api_key='+api_key+'&language='+api_lang+'&page='+str(p+1)
		j=GET(url)
		L=JSON(j)['results']
		for i in L:
			if 'genre_ids' in i.keys(): genre_ids=i['genre_ids']
			else: genre_ids = []
			if 10767 not in genre_ids and 10764 not in genre_ids:
				LL.append(kodi_info(i))
	return LL


def country(c):
	param = {'include_null_first_air_dates':'false', 'sort_by':'popularity.desc', 'vote_count.gte':'3','vote_average.gte':'4', 'with_original_language':c}
	L=discover(param)['results']
	LL=[]
	for i in L:
		LL.append(kodi_info(i))
	return LL

def tag(id):
	param = {'include_null_first_air_dates':'false', 'sort_by':'popularity.desc', 'vote_count.gte':'3','vote_average.gte':'4', 'with_keywords':str(id)}
	L=discover(param)['results']
	LL=[]
	for i in L:
		LL.append(kodi_info(i))
	
	if len(LL)>19:
		param = {'include_null_first_air_dates':'false', 'sort_by':'popularity.desc', 'vote_count.gte':'3','vote_average.gte':'4', 'with_keywords':str(id), 'page':'2'}
		L=discover(param)['results']
		for i in L:
			LL.append(kodi_info(i))
	
	return LL



def year(y):
	LL=[]
	for p in range(5):
		param = {'sort_by':'popularity.desc', 'vote_count.gte':'3','vote_average.gte':'4', 'first_air_date_year':y,'page':str(p+1)}#'include_null_first_air_dates':'false', 
		L=discover(param)['results']
		for i in L:
			LL.append(kodi_info(i))
	return LL

def person(id):
	url = api_url+'/person/'+id+'/tv_credits?api_key='+api_key+'&language='+api_lang
	j=GET(url)
	L=JSON(j)['cast']
	LL=[]
	for i in L:
		LL.append(kodi_info(i))
	return LL

def person_list(id):
	url = api_url+'/tv/'+str(id)+'/credits?api_key='+api_key+'&language='+api_lang
	j=GET(url)
	L=JSON(j)['cast']
	LL=[]
	for i in L:
		LL.append({'id':i['id'],'title':i['name'],'cover':i['profile_path']})
	return LL

def collection_list():
	L=[
	{'id':'1', 'title': 'Anime', 'param' :{'include_null_first_air_dates':'false', 'sort_by':'vote_average.desc', 'vote_count.gte':'30','vote_average.gte':'4','with_genres':'16','with_original_language':'ja'}},
	{'id':'2', 'title': 'Американские мультфильмы', 'param' :{'include_null_first_air_dates':'false', 'sort_by':'vote_average.desc', 'vote_count.gte':'30','vote_average.gte':'4','with_genres':'16','with_original_language':'en'}},
	{'id':'3', 'title': 'Русские мультфильмы', 'param' :{'include_null_first_air_dates':'false', 'sort_by':'popularity.desc','with_genres':'16',   'with_original_language':'ru'}},
	{'id':'4', 'title': 'Русские сериалы', 'param'     :{'include_null_first_air_dates':'false', 'sort_by':'popularity.desc','without_genres':'16','with_original_language':'ru'}},
	{'id':'5', 'title': 'Немецкие сериалы', 'param'    :{'include_null_first_air_dates':'false', 'sort_by':'popularity.desc','without_genres':'16','with_original_language':'de'}},
	{'id':'6', 'title': 'Испанские сериалы', 'param'   :{'include_null_first_air_dates':'false', 'sort_by':'popularity.desc','without_genres':'16','with_original_language':'es'}},
	{'id':'7', 'title': 'Турецкие сериалы', 'param'    :{'include_null_first_air_dates':'false', 'sort_by':'popularity.desc','without_genres':'16','with_original_language':'tr'}},
	{'id':'8', 'title': 'Французские сериалы', 'param' :{'include_null_first_air_dates':'false', 'sort_by':'popularity.desc','without_genres':'16','with_original_language':'fr'}},
	{'id':'9', 'title': 'Итальянские сериалы', 'param' :{'include_null_first_air_dates':'false', 'sort_by':'popularity.desc','without_genres':'16','with_original_language':'it'}},
	{'id':'10', 'title': 'Шведские сериалы', 'param'    :{'include_null_first_air_dates':'false', 'sort_by':'popularity.desc','without_genres':'16','with_original_language':'sv'}},
	]
	return L

def collection(id):
	Lc=collection_list()
	param={}
	LL=[]
	for c in Lc:
		if str(c['id'])==str(id): param=c['param']
	
	for p in range(5):
		param['page']=str(p+1)
		L=discover(param)['results']
		for i in L:
				LL.append(kodi_info(i))
	return LL

tag_list=[
	{"name": "18й век","id": 160279},
	{"name": "19-й век","id": 207928},
	{"name": "40-е","id": 207883},
	{"name": "80-е","id": 208289},
	{"name": "альтернативная история","id": 212049},
	{"name": "андройд","id": 803},
	{"name": "атомная станция","id": 4368},
	{"name": "аутизм","id": 1646},
	{"name": "ботан","id": 5801},
	{"name": "вампир","id": 3133},
	{"name": "ведьма","id": 616},
	{"name": "вторая жизнь","id": 10440},
	{"name": "вторая мировая война","id": 1956},
	{"name": "выживание","id": 10349},
	{"name": "выживший","id": 5385},
	{"name": "высшая школа","id": 6270},
	{"name": "гик","id": 5800},
	{"name": "госпиталь","id": 11612},
	{"name": "дикий запад","id": 155573},
	{"name": "дракон","id": 12554},
	{"name": "дружба","id": 6054},
	{"name": "друзья","id": 9713},
	{"name": "дьявол","id": 14999},
	{"name": "заговор","id": 10410},
	{"name": "зомби","id": 12377},
	{"name": "идеальное преступление","id": 584},
	{"name": "искусственный интеллект","id": 310},
	{"name": "история","id": 9682},
	{"name": "коп","id": 8015},
	{"name": "королевство","id": 4152},
	{"name": "король","id": 13084},
	{"name": "космическая опера","id": 161176},
	{"name": "космический вестерн","id": 11606},
	{"name": "криминал","id": 15009},
	{"name": "любовный треугольник","id": 128},
	{"name": "магия","id": 2343},
	{"name": "маленький городок","id": 1415},
	{"name": "мафия","id": 10391},
	{"name": "медицина","id": 1279},
	{"name": "мир фентези","id": 170362},
	{"name": "монстр","id": 1299},
	{"name": "наркотики","id": 14964},
	{"name": "наука","id": 156810},
	{"name": "НЛО","id": 9738},
	{"name": "оборотень","id": 12564},
	{"name": "основано на книге","id": 818},
	{"name": "основано на комиксе","id": 9717},
	{"name": "основано на фильме","id": 165317},
	{"name": "охотник за головами","id": 801},
	{"name": "параллельный мир","id": 33465},
	{"name": "петля времени","id": 10854},
	{"name": "пещера","id": 1964},
	{"name": "постапокалипсис","id": 4458},
	{"name": "правительственный заговор","id": 181635},
	{"name": "пропавший ребенок","id": 156948},
	{"name": "пропавший человек","id": 156091},
	{"name": "психологический триллер","id": 12565},
	{"name": "путешествие во времени","id": 4379},
	{"name": "расследование","id": 5340},
	{"name": "ремейк","id": 9714},
	{"name": "робот","id": 14544},
	{"name": "ролевая игра","id": 10196},
	{"name": "романтика","id": 9840},
	{"name": "сверхестественное","id": 6152},
	{"name": "священник","id": 10093},
	{"name": "секретное общество","id": 2908},
	{"name": "семейный кризис","id": 217316},
	{"name": "силовое поле","id": 205740},
	{"name": "ситком","id": 193171},
	{"name": "скорость","id": 3428},
	{"name": "супергерой","id": 9715},
	{"name": "сюрреализм","id": 9887},
	{"name": "тайна","id": 10092},
	{"name": "телекинез","id": 5086},
	{"name": "тематический парк","id": 158340},
	{"name": "убийство","id": 627},
	{"name": "ученый","id": 14760},
	{"name": "ФБР","id": 1812},
	{"name": "феномен","id": 200725},
	{"name": "флешбек","id": 9856},
	{"name": "хакер","id": 2157},
	{"name": "хоррор","id": 8087},
	{"name": "чужой/инопланетянин","id": 9951},
	{"name": "школа","id": 10873},
	{"name": "шотландия","id": 388},
	{"name": "шпион","id": 470},
	{"name": "эксперимент","id": 1706},
]

#id=new()[1]['id']
#print get_info(65930)
#time.sleep(10)