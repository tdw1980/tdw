# -*- coding: utf-8 -*-
import sys, os
from ftplib import FTP
temp_dir = "d:\\"

if sys.version_info.major > 2:  # Python 3 or later
	import urllib.request
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote_plus as unquote
	import urllib2


def b2s(s):
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		if not is_libreelec():
			try:s=s.decode('windows-1251')
			except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s


def ru(x):return unicode(x,'utf8', 'ignore')


def GET(url, Referer = ''):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36 OPR/72.0.3815.400')
	response = urllib2.urlopen(req, timeout = 3)
	data=b2s(response.read())
	response.close()
	return data

'''
def getURL(url,Referer = 'http://emulations.ru/'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link
'''

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		#sn=http[s:]
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def CRC32(buf):
		import binascii
		buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		return str("%08X" % buf)

def save_inf(s):
	p = os.path.join(ru(temp_dir),"temp.txt")
	f = open(p, "w")
	f.write(s)
	f.close()
	return p

def obj_inf(s):
	try:
		from StringIO import StringIO # for Python 2
	except:
		from io import BytesIO as StringIO# for Python 3
	buf = StringIO(s)
	return buf

def upload(ftp, path, ftp_path):
	with open(path, 'rb') as fobj:
		ftp.storbinary('STOR ' + ftp_path, fobj, 1024)

def upload_obj(ftp, fobj, ftp_path):
		ftp.storbinary('STOR ' + ftp_path, fobj, 1024)

def get_path(id):
	pref='0'*(6-len(id))
	id=pref+id
	#print len(id[:-4])
	if len(id[:-4])==3:s1=chr(int(id[:-5])+87)+id[-5:-4]
	else:s1=id[:-4]
	s=[s1,id[-4:-2],id[-2:]]
	#print s
	return s


def get_translate(q):
	id=CRC32(q)
	#id = 'CFD22E90'
	HUP=get_host('request')
	HOST=HUP['HOST']
	
	url='http://'+HOST+'/translate/'+id[:1]+'/'+id[1:2]+'/'+id[2:]+'.txt'
	try:translate=GET(url)
	except: translate=''
	return translate
	'''
		try: 
			#print ('http://roms.my1.ru/translate/'+id[:1]+'/'+id[1:2]+'/'+id[2:]+'.txt')
			tr = GET('http://roms.my1.ru/translate/'+id[:1]+'/'+id[1:2]+'/'+id[2:]+'.txt')
			#print (tr)
			translate=eval(tr)
			if translate!='': save_translate(q, translate)
		except: translate=''
	'''

def save_translate(q, r):
	print ('ADD translate: '+q[:10])
	try: r=r.encode('utf-8')
	except: pass
	#print (r)
	HUP=get_host('translate')
	HOST=HUP['HOST']
	USER=HUP['USER']
	PASS=HUP['PASS']
	ftp = FTP(HOST)
	ftp.login(USER, PASS)
	
	id=CRC32(q)
	#print (id)
	try:
		ftp.mkd('/translate/'+id[0])
	except: pass
	try:
		ftp.mkd('/translate/'+id[0]+'/'+id[1])
	except: pass
	#path = save_inf(r)
	obj = obj_inf(r)
	#upload(ftp, path, '/translate/'+id[0]+'/'+id[1]+'/'+id[2:]+'.txt')
	upload_obj(ftp, obj, '/translate/'+id[0]+'/'+id[1]+'/'+id[2:]+'.txt')
	ftp.quit()


def add(info):
	return add_compression_info(info)

def update(info):
	return add_compression_info(info)

def get_info(id):
	return get_compression_info(id)

def get_host(id):
	return {'HOST':'td-soft.narod.ru','USER':'otd-soft','PASS':'19111980'}

def new_translate(t):
		url = 'https://api.mymemory.translated.net/get?langpair=en|ru&q='+urllib.quote_plus(t[:250])
		h=GET(url)
		null = None
		false = False
		true = True
		json = eval(h)
		if json['quotaFinished']!=False: return ''
		tt = eval('u"'+json['responseData']['translatedText']+'"')
		tt = tt.replace('\\/', '/')
		return tt

#save_translate('q90ksdfфываvl fgjd', 'rПРолщ"рло лл')
#print (get_translate('Sarian'))