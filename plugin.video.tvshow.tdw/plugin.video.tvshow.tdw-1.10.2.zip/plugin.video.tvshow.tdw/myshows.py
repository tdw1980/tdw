# -*- coding: utf-8 -*-
# *  Copyright (C) 2020 TDW

import urllib2, urllib, time, os, settings

api_url='https://api.myshows.me'

def JSON(j):
	null = None
	false = False
	true = True
	return eval(j.replace('\\/','/').replace(':"\u',':u"\u'))

def GET(url, Referer = ''):
	D=get_ch(url)
	if time.time()-D['tm']<3600*240 and D['data']!='': return D['data']
	try:
		req = urllib2.Request(url)
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		add_ch(link, url)
		return link
	except: 
		if D['data']!='': return D['data']

def deb_print(t):
	print t

def CRC32(buf):
		import binascii
		buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		return str("%08X" % buf)

def add_ch(data, url):
	try:
		SID = 'get_'+str(CRC32(url))
		D={}
		D['data'] = data
		D['tm']=time.time()
		settings.set(SID, repr(D))
	except: pass

def get_ch(url):
	try:
		SID = 'get_'+str(CRC32(url))
		D  = eval(settings.get(SID))
		data = D['data']
		tm = D['tm']
		return {'tm':tm, 'data':data}
	except:
		return {'tm':0, 'data':''}



def search(q):
	q=urllib.quote_plus(q.lower().replace('the ', ''))
	url = api_url+'/shows/search/?q='+q
	j=GET(url)
	try:    L=JSON(j).items()
	except: L=JSON(j)
	LL=[]
	for i in L:
		#print i
		LL.append(i[1])
	return LL

#print search("The Queen's Gambit")