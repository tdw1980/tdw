# -*- coding: utf-8 -*-
import os, sys
try:
	import xbmcaddon, xbmc, xbmcvfs
	try:    db_dir = os.path.join(xbmc.translatePath("special://masterprofile/"),"addon_data","plugin.video.tvshow.tdw")
	except: db_dir = os.path.join(xbmcvfs.translatePath("special://masterprofile/"),"addon_data","plugin.video.tvshow.tdw")
except:
	db_dir = os.path.join(os.getcwd(), "settings" )

def set(key, val):
	#try:
	fp=os.path.join(db_dir, key)
	if sys.version_info.major > 2: 
		fl = open(fp, "wb")
		fl.write(repr(val).encode())
	else: 
		fl = open(fp, "w")
		fl.write(repr(val))
	fl.close()
	return 'ok'
	#except:
	#	return 'error set '+key

def get(key):
	try:
		fp=os.path.join(db_dir, key)
		fl = open(fp, "r")
		t=fl.read()
		fl.close()
		if sys.version_info.major > 2: val=eval(t.decode())
		else: val=eval(t)
		return val
	except:
		val=default(key)
		if val!='': set(key, val)
		return val

def default(key):
	try:
		D={
		'ip':			'127.0.0.1',
		}
		if key in D.keys(): return D[key]
		return ''
	except:
		return ''

#print set('KEY', 'VALUE')
#print get('KEY')
