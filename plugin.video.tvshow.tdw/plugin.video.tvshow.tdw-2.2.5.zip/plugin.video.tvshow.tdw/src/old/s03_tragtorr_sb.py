#!/usr/bin/python
# -*- coding: utf-8 -*-

#import string, xbmc, xbmcgui, xbmcplugin, urllib, cookielib, xbmcaddon
import json
#-------------------------------
from core import *
icon = ""
domen = 'http://tragtorr.in'
deb = False
deb = True
#__settings__ = xbmcaddon.Addon(id='plugin.video.tvshow.tdw')
def encod(x):
	try:x=x.decode('Windows-1251')
	except:pass
	try:x=x.encode('utf-8')
	except:pass
	return x

def coder(x):
	x=x.decode('utf-8')
	x=x.encode('Windows-1251')
	return x

def deb_print(t):
	if deb: print(t)

def clear(s):
	L=['<b>','</b>','</a>','</td>']
	for i in L:
		s=s.replace(i,'')
	s=s.replace(chr(10),'').replace(chr(13),'').replace('\t','').strip()
	return s

def filtr(t):
	L=['[MP3]','[GOG]','lossless','FLAC',' MP3','[NSZ]','[TR24]','[Wine]','[amd64]','[PC]',' Repack ','RePack',' PC ','DLC','Portable','/Multi ','[MacOS]']#,'','','','',''
	for i in L:
		if i in t: return False
	return True

def get_tor_url(url):
	redir=GET(url, domen).replace(chr(10),'').replace(chr(13),'').replace('\t','').strip()
	url2=domen+'/'+redir
	return url2

def Parser2(L):
	deb_print('======= parser2 ==========')
	Lout=[]
	tm = time.time()
	for i in L:
		try:
					deb_print( '---------------------')
					#deb_print(i)
					title=encod(i['title'].strip())
					if filtr(title):
						deb_print(title)
						url=get_tor_url(domen+'/'+i['torr'])
						#deb_print(url)
						
						sids = i['do']
						#deb_print(sids)
						size = i['size'].replace(' ','').replace('&nbsp;','')
						#deb_print(size)
						
						Lout.append({"sids":sids, "size":size, "title":title, "url":url, "quality": ''})
						if time.time()-tm>5: return Lout
		except:
					deb_print('==================================')
					deb_print('err')
	return Lout

def Parser1(hp, info):
	deb_print('--parser--')
	Lout=[]
	ss='<tr><td>'
	es='</td></tr>'
	Lid=[]
	L=findall(hp, ss,es)
	L2=[]
	deb_print(len(L))
	for i in L:
		url = httpSiteUrl+mfind(i, '<a href="', '">')
		deb_print(url)
		#title = mfind(i, 'htm">', '<')
		#if info['title'] in title: 
		L2.append(url)
	return L2



def Storr(info, tr='gt'):
	deb_print('---TRAGTORR---'+tr)
	Lout=[]
	text=lower(info['originaltitle'])
	
	url=domen+'/pars/'+tr+'/action.php'
	post='search='+quote(text)
	ref = domen+'/?search='+quote(text)
	deb_print(url)
	deb_print(ref)
	http=GET(url, ref, post)
	deb_print(http)
	deb_print(json.loads(http))
	
	try: L=json.loads(http)
	except: L=[]
	try: Lout=Parser2(L)
	except: Lout=[]
	deb_print(len(Lout))
	return Lout



class Tracker:
	def __init__(self):
		pass

	def Search(self, info):
		L=[]
		Ltrc = ['bl','rk','plt','ut','rt','gt','sb','bt']#,'pt','pe'
		t = Ltrc[6]
		L=Storr(info, t)
		return L

#Ltrc = ['gt','bl','rk','plt','ut','rt','bt']#,'pt','pe','sb',
#Storr({'originaltitle': 'terminator'}, Ltrc[2])
#t=Tracker()
#print(len(t.Search({'originaltitle': 'Breaking Bad'})))
#time.sleep(10)
