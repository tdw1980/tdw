import json, time
from websocket import create_connection
nws_id = '6stttgdcsgxsqgtzwgrnzducvgw0zdo8'

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	if e=='': r2=r
	else: r2=r[:r.find(e)]
	return r2

def send2(serv):
	ws = create_connection(serv)
	result =  ws.recv()
	print ('> ', result)
	
	msg = {"method":"RchRegistry","args":[{"version":154,"host":"prisma.ws","rchtype":"web","apkVersion":0,"player":"inner","account_email":"","unic_id":"swra4jne","profile_id":"","token":""}]}
	data = json.dumps(msg)
	ws.send(data)
	
	result =  ws.recv()
	print ('> ', result)
	time.sleep(25)
	print ('< ws.close')
	ws.close()

def loop2(serv):
	import xbmc
	ws = create_connection(serv)
	result =  ws.recv()
	print ('> ', result)
	
	msg = {"method":"RchRegistry","args":[{"version":154,"host":"prisma.ws","rchtype":"web","apkVersion":0,"player":"inner","account_email":"","unic_id":"swra4jne","profile_id":"","token":""}]}
	data = json.dumps(msg)
	ws.send(data)
	result =  ws.recv()
	print ('> ', result)
	
	time.sleep(25)
	while xbmc.Player().isPlaying():
		ws.send('ping')
		time.sleep(50)
		print ('< ping')
		
	print ('< ws.close')
	ws.close()

def get_serv(url):
	serv = "wss://"+mfind(url,'//','/')+"/nws?id="+nws_id
	return serv

from threading import Thread
class MyThread3(Thread):
	def __init__(self, param):
		Thread.__init__(self)
		self.param = param
	
	def run(self):
		exec(self.param)

def run_string(param):
		my_thread = MyThread3(param)
		my_thread.start()

def send(url):
	serv=get_serv(url)
	run_string("send2('"+serv+"')")

def loop(url):
	if 'manhan' in url or '.bwa.' in url or 'maxvol' in url:
		serv=get_serv(url)
		run_string("loop2('"+serv+"')")
	elif ':12133' in url: 
		return
	else: 
		send(url)

#send("wss://api.manhan.one/nws?id=6stttgdcsgxsqgtzwgrnzducvgw0zdo8")
#send('wss://rc.bwa.ad/nws?id=vpatus9dtk3mnbgugq0rx9lkpjsnoave&ver=1')
