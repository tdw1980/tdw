import sys, os
import xbmcgui, xbmc

if __name__ == '__main__':
	fn = sys.listitem.getVideoInfoTag().getFilenameAndPath()
	#message = " '{}'".format(fn)
	#xbmcgui.Dialog().notification("Hello context items!", message)
	if '.strm' in fn.lower():
		try:
			if os.path.isfile(fn):
				f = open(fn, 'r')
				s = f.read()
				f.close()
				purl=s.replace('Play_strm','Ep_list')
				#xbmcgui.Dialog().notification("Hello context items!", purl)
				xbmc.executebuiltin('Container.Update("'+purl+'")')
		except: pass
