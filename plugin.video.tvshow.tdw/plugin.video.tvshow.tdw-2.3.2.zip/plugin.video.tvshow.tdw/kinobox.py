#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys, json

siteUrl = 'api.loadbox.ws'
httpSiteUrl = 'http://' + siteUrl

if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2


def b2s(s):
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def test_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False


def unlock(url):
	url='http://127.0.0.1:8095/proxy/'+url
	return url


def findall(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def GET(target, referer='', post=None):
	urllib2.install_opener(urllib2.build_opener())
	#if __settings__.getSetting("antizapret") == "true": target = unlock(target)
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return b2s(http)
	except:
		print ('GET err')

#seasons:[{"season":1,"blocked":false,"episodes":[{"episode":"1","id":653525,"videoKey":1046833,"dash":"https://hye1eaipby4w.takedwn.ws/01_24/25/16/JRPNIMD7/1046833.mpd","hls":"https://hye1eaipby4w.takedwn.ws/01_25_24/01/25/09/Y476KPDJ/3TACOUSW.mp4/master.m3u8","audio":{"names":["Рус. Оригинальный"],"order":[0]},"cc":[{"url":"https://hye1eaipby4w.takedwn.ws/01_25_24/01/25/08/UWGWNO76/GC7WRVKR.vtt","name":"Рус. SDH - 1"},{"url":"https://hye1eaipby4w.takedwn.ws/01_25_24/01/25/08/35E2GWG4/M6XG74OC.vtt","name":"Рус. полные - 2"}],"duration":3163,"title":"Иные (1 сезон) - 1 серия","download":"","sections":[],"poster":"https://img.imgilall.me/movies/video/6/5/3/5/2/5/0/0/0/0/800x450_653525.jpg?t=1706191458","preview":{"src":"https://img.zcvh.net/1046833/desktop/thumb-${spriteNum}.webp"}},{"episode":"2","id":653537,"videoKey":1047035,"dash":"https://hye1eaipby4w.takedwn.ws/01_24/25/15/OWRPJFAA/1047035.mpd","hls":"https://hye1eaipby4w.takedwn.ws/01_25_24/01/25/13/7KN7HEMY/ZH4QRRHW.mp4/master.m3u8","audio":{"names":["Рус. Оригинальный","delete"],"order":[0,1]},"cc":[{"url":"https://hye1eaipby4w.takedwn.ws/01_25_24/01/25/10/ZSWJBU3D/AIFFM3WH.vtt","name":"Рус. полные - 1"}],"duration":3221,"title":"Иные (1 сезон) - 2 

def get_list(url):
	L2=[]
	hp=GET(url)
	if 'seasons:[' in hp:
		j = '['+mfind(hp, 'seasons:[', '}}]}]')+'}}]}]'
		false=False
		true=True
		null = None
		L=eval(j)
		for s in L:
			season = s['season']
			episodes = s['episodes']
			for e in episodes:
				episode = e['episode']
				ep_url = e['hls']
				ep_title = e['title']
				L2.append ({"sids":'0',"size":'0', "title":ep_title,"url":ep_url})
	else:
		curl = mfind(hp, 'hls: "', '"')
		trl  = mfind(hp, '"names":["', '"]').replace('","',', ').replace('delete','').replace(', ,',',')
		ttl  = mfind(hp, '<title>', '<')
		L2.append ({"sids":'0',"size":'0', "title": ttl+' ('+trl+')', "url":curl})
	return L2


def get_VIDEOCDN(url):
	Lq=['[360p]','[480p]','[720p]','[1080p]']
	hp=GET(url)
	#print ('ok')
	Dtr={}
	try:
		ttr = mfind(hp, '<div class="translations">', '<div id="player"')
		#print (ttr)
		Ltr = findall(ttr,'<option value="', '</option>')
		for trl in Ltr:
			trl=trl.replace('<option value="','').replace('>','').replace('\t','').replace('   ',' ').replace('selected="selected"','').replace('\n ','')
			#print (trl)
			Dtr[trl.split('"')[0]]=trl.split('"')[1].strip()
	except: pass
	j = mfind(hp, '<input type="hidden" id="ury" value=', "'>")[1:]
	Dr = json.loads(j)
	#print (Dr.keys())
	L=[]
	D={}
	
	for k in Dr.keys():
		try: translate = Dtr[k]
		except: translate = k
		Ln=Dr[k]
		for n in Ln:
			Ls=n['folder']
			s=n['id']
			if s not in D.keys(): D[s]={}
			for i in Ls:
				#try: e = int(i['id'])
				#except: 
				e = int(i['id'].split('_')[1])
				if e not in D[s].keys(): D[s][e]=[]
				Lfile = i['file'].split(',')
				for f in Lfile:
					for q in Lq:
						if q in f: 
							D[s][e].append({'translate':translate,'quality':q, 'url':f.replace(q,'http:')})
							#print ([s,e,q,translate])
	#print (D)
	return D


def get_frames(url):
	L2=[]
	hp=GET(url)
	L = json.loads(hp)['data']
	return L

def Search(id):
		Dout={}
		url='https://w5.kpfr.wiki/kinobox/index.php?imdb='+id
		try:L=get_frames(url)
		except: L=[]
		for i in L:
			if i["type"]=='VIDEOCDN': 
				try:Dout = get_VIDEOCDN(i["iframeUrl"])
				except: pass
		return Dout

#print(get_frames('https://w5.kpfr.wiki/kinobox/index.php?imdb=tt2543312'))
#list_VIDEOCDN('https://91165.svetacdn.in/YmLIdpHnHNuq/tv-series/542')