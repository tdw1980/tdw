#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,urllib2,re,sys,os,random
import xbmcplugin,xbmcgui,xbmcaddon
import time

pluginhandle = int(sys.argv[1])
__settings__ = xbmcaddon.Addon(id='plugin.audio.hqradio.ru')
addon=xbmcaddon.Addon('plugin.audio.hqradio.ru')
thumb = os.path.join( __settings__.getAddonInfo('path'), 'icon.png')
Clist=['files', 'songs', 'artists', 'albums', 'movies', 'tvshows', 'episodes', 'musicvideos', 'addons']
vn=int(__settings__.getSetting("CL"))
xbmcplugin.setContent(int(sys.argv[1]), Clist[vn])

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def showMessage(heading, message, times = 3000):
	heading = heading.encode('utf-8')
	message = message.encode('utf-8')
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, thumb))


def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param



def getURL(url,Referer = 'https://hqradio.ru'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		#sn=http[s:]
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L


def Root(url="http://radiopotok.ru/radiostations/"):
	title="[COLOR F050F050][B]РАДИОСТАНЦИИ[/B][/COLOR]"
	uri = sys.argv[0] + '?mode=Category'
	item = xbmcgui.ListItem(title, iconImage = thumb, thumbnailImage = thumb)
	xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
	
	title="[COLOR F050F050][B]ИЗБРАННОЕ[/B][/COLOR]"
	uri = sys.argv[0] + '?mode=Favorites'
	item = xbmcgui.ListItem(title, iconImage = thumb, thumbnailImage = thumb)
	xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)

	xbmcplugin.endOfDirectory(pluginhandle)


def PlayStation(url,name,img):# отключил. играет по прямой ссылке
	if '.m3u' in url:
		http = getURL(url)
		L=http.splitlines()
		u=[]
		for i in L:
			if i[:4]=="http" or i[:4]=="rtmp": u.append(i)
		url=u[0]
	item = xbmcgui.ListItem(name, iconImage = img, thumbnailImage = img)
	item.setInfo(type="Music", infoLabels={"Title": name})
	#xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	xbmc.Player().play(url, item)

def add(url, name, img):
	try:L=eval(__settings__.getSetting("Favorites"))
	except:L=[]
	st=(url, name, img)
	if st not in L:L.append(st)
	__settings__.setSetting("Favorites",repr(L))


def rem(url):
	try:L=eval(__settings__.getSetting("Favorites"))
	except:L=[]
	L2=[]
	for i in L:
		if i[0] != url: L2.append(i)
	__settings__.setSetting("Favorites",repr(L2))


def Favorites():
	try:L=eval(__settings__.getSetting("Favorites"))
	except:L=[]
	if len(L)==0 and __settings__.getSetting("FP")=="1":
		title="[COLOR F050F050][B]ПОИСК[/B][/COLOR]"
		uri = sys.argv[0] + '?mode=Category'
		item = xbmcgui.ListItem(title, iconImage = thumb, thumbnailImage = thumb)
		xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)

	for i in L:
			url = i[0]
			title=i[1]
			img = i[2]
			
			item = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
			item.setInfo(type="Music", infoLabels={"Title": title})
			
			urc1 = sys.argv[0] + '?mode=rem'
			urc1 += '&url='  + urllib.quote_plus(url)
			urc1 += '&name='  + urllib.quote_plus(title)

			urc2 = sys.argv[0] + '?mode=export'
			urc2 += '&url='  + urllib.quote_plus(url)
			urc2 += '&name='  + urllib.quote_plus(title)

			item.addContextMenuItems([('[COLOR F050F050] Удалить [/COLOR]', 'Container.Update("plugin://plugin.audio.hqradio.ru/'+urc1+'")'),('[COLOR F050F050] Поиск станций [/COLOR]', 'Container.Update("plugin://plugin.audio.hqradio.ru/?mode=Category")'),('[COLOR F050F050] Сохранить избранное в m3u [/COLOR]', 'Container.Update("plugin://plugin.audio.hqradio.ru/?mode=export")')])
			xbmcplugin.addDirectoryItem(pluginhandle, url, item, False)
	xbmcplugin.endOfDirectory(pluginhandle)


def Export():
	try:L=eval(__settings__.getSetting("Favorites"))
	except: return
	
	fl = open(os.path.join( addon.getAddonInfo('path'),"hqradio.m3u"), "w")
	fl.write('#EXTM3U\n')
	for i in L:
		url = i[0]
		title=i[1]
		fl.write('#EXTINF:-1, '+title+'\n')
		fl.write(url+"\n")
	fl.close()

st_key={'radiotunes':'rt', 'rockradio':'rr', 'classicalradio':'cr', 'jazzradio':'jr', 'di':'di', 'digitallyimported':'di'}
g_add={'radiotunes':'', 'rockradio':' rock', 'classicalradio':' classical', 'jazzradio':' jazz', 'di':' digitall', 'digitallyimported':'di'}

def Category():
		GenreList=[]
		url="https://hqradio.ru/data/config.min.json?v=v3.18.0"
		json = eval(getURL(url).replace('\\/', '/'))
		L=json.keys()
		for st in L:
				#try:
					j=json[st]
					sid = st_key[j['key']]
					filters = j['filters']
					for flt in filters.keys():
						f = filters[flt]
						title = f['title']+g_add[j['key']]
						GenreList.append({'title': title, 'filter': f['channels'], 'station':sid})

		title="[COLOR F050F050][B]ВСЕ СТАНЦИИ[/B][/COLOR]"
		uri = sys.argv[0] + '?mode=stations'
		uri += '&url='  + urllib.quote_plus("0")
		item = xbmcgui.ListItem(title, iconImage = thumb, thumbnailImage = thumb)
		xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)

		for i in GenreList:
			title=i['title']
			uri = sys.argv[0] + '?mode=dir'
			uri += '&sf='  + urllib.quote_plus(repr(i['station']))
			uri += '&cf='  + urllib.quote_plus(repr(i['filter']))
			uri += '&name='  + urllib.quote_plus(title)
			item = xbmcgui.ListItem(title, iconImage = thumb, thumbnailImage = thumb)
			xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
		#xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
		xbmcplugin.addSortMethod(pluginhandle, xbmcplugin.SORT_METHOD_LABEL)
		xbmcplugin.endOfDirectory(pluginhandle)

def Stations(sf='', cf=[]):
	#print url
	url="https://hqradio.ru/data/config.min.json?v=v3.18.0"
	json = eval(getURL(url).replace('\\/', '/'))
	L=json.keys()
	for st in L:
			#try:
				j=json[st]
				sid = st_key[j['key']]
				s_title = j['title']
				
				if sf=='' or sf == sid:
					channels = j['channels']
					L2= channels.keys()
					L2.sort()
					for c in L2:
						cn    = channels[c]
						id    = cn['id']
						key   = cn['key']
						if cf==[] or id in cf:
							title = cn['title'].replace("\\u00e1", 'a').replace("\\u00e9", 'e')
							img   = 'http:'+cn['image']
							if sid == 'rr' or sid == 'jr': bitrate='256'
							else:          bitrate='320'
							url   = 'http://hot.friezy.ru/?radio='+sid+'&station='+key+'&bitrate='+bitrate#320
							
							item = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
							item.setInfo(type="Music", infoLabels={"Title": title, 'album':s_title})
							
							urc1 = sys.argv[0] + '?mode=add'
							urc1 += '&url='  + urllib.quote_plus(url)
							urc1 += '&name='  + urllib.quote_plus(title)
							urc1 += '&img='  + urllib.quote_plus(img)
							
							item.addContextMenuItems([('[COLOR F050F050] Добавить в избранное [/COLOR]', 'Container.Update("plugin://plugin.audio.hqradio.ru/'+urc1+'")'),('[COLOR F050F050] Избранное [/COLOR]', 'Container.Update("plugin://plugin.audio.hqradio.ru/?mode=Favorites")')])
							
							if title!="":xbmcplugin.addDirectoryItem(pluginhandle, url, item, False, 300)
			#except:
				#print "err: " +i
	xbmcplugin.endOfDirectory(pluginhandle)

def all(d=""):
	if d=="0": d=""
	for n in range(0,9):
		url="http://radiopotok.ru/radiostations/page-"+d+str(n+1)+".html"
		print url
		Stations(url)
		
	if d=="": d="1"
	else: d=str(int(d)+1)
	
	title="[COLOR F050F050][B]"+d+" Далее >[/B][/COLOR]"
	uri = sys.argv[0] + '?mode=all'
	uri += '&url='  + urllib.quote_plus(d)
	item = xbmcgui.ListItem(title, iconImage = thumb, thumbnailImage = thumb)
	xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
	
	xbmcplugin.endOfDirectory(pluginhandle)



params = get_params()
url  =	''
mode =	"Root"
name =	''
img =	' '
sf=''
cf=[]

try: cf = eval(urllib.unquote_plus(params["cf"]))
except: pass
try: sf = eval(urllib.unquote_plus(params["sf"]))
except: pass
try: url = urllib.unquote_plus(params["url"])
except: pass
try: mode = urllib.unquote_plus(params["mode"])
except: pass
try: name = urllib.unquote_plus(params["name"])
except: pass
try: img = urllib.unquote_plus(params["img"])
except: pass
try: filtr = eval(urllib.unquote_plus(params["filtr"]))
except: filtr = []

if   mode == "Root":
	if __settings__.getSetting("FP")=="1" and url=="":Favorites()
	else:Root(url)
elif mode == 'PlayStation':	PlayStation(url,name,img)
elif mode == 'add':			add(url,name,img)
elif mode == 'rem':			rem(url)
elif mode == 'Favorites':	Favorites()
elif mode == 'Category':	Category()
elif mode == 'stations':	Stations()
elif mode == 'dir':			Stations(sf, cf)
elif mode == 'export':		Export()