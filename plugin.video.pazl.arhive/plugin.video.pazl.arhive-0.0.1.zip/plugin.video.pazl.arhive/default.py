# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, urllib, sys, urllib2, time
#nt=time.time()
PLUGIN_NAME   = 'plugin.video.pazl.arhive'
handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.pazl.arhive')
__settings__ = xbmcaddon.Addon(id='plugin.video.pazl.arhive')

siteUrl = 'viks.tv'
httpSiteUrl = 'http://' + siteUrl

Pdir = addon.getAddonInfo('path')
icon = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'icon.png'))
fanart = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'fanart.png'))
Logo = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'logo'))
UserDir = xbmc.translatePath(os.path.join(xbmc.translatePath("special://masterprofile/"),"addon_data","plugin.video.pazl.arhive"))

xbmcplugin.setContent(int(sys.argv[1]), 'movies')

#sys.path.append(os.path.join(addon.getAddonInfo('path'),"serv"))
#ld=os.listdir(os.path.join(addon.getAddonInfo('path'),"serv"))
#Lserv=[]
#for i in ld:
#	if i[-3:]=='.py': Lserv.append(i[:-3])

#Lserv=['p01_peers', 'p02_onelike', 'p03_1ttv', 'p04_asplaylist']

sys.path.append(os.path.join(addon.getAddonInfo('path'),"arh"))
ld=os.listdir(os.path.join(addon.getAddonInfo('path'),"arh"))
Larh=[]
for i in ld:
	if i[-3:]=='.py': Larh.append(i[:-3])


#from xid import *
#from DefGR import *
#Ldf=eval(__settings__.getSetting("Groups"))
def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def fs_enc(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode('utf-8').encode(sys_enc)

def fs_dec(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode(sys_enc).encode('utf-8')

def lower(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in range (65,90):
		t=t.replace(chr(i),chr(i+32))
	for i in RUS.keys():
		t=t.replace(i,RUS[i])
	return t


def getURL(url,Referer = 'http://viks.tv/'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def GETimg(target, nmi):
	#lfimg=os.listdir(Logo)
	if nmi =='':
		#print target
		return target
	LogoDir=__settings__.getSetting("logodir")
	if LogoDir=="":LogoDir=Logo
	path1 = fs_enc(os.path.join(LogoDir,nmi+'.png'))
	path2 = fs_enc(os.path.join(Logo,nmi+'.png'))
	try:
		try:
			sz=os.path.getsize(path1)
			path=path1
		except:
			try:
				sz=os.path.getsize(path2)
				path=path2
			except:
				sz=0
				path=path2
		
		if sz > 0:
			return path
		else:
			if __settings__.getSetting("dllogo")=='false': return target
			
			pDialog = xbmcgui.DialogProgressBG()
			pDialog.create('Пазл ТВ', 'Загрузка логотипа: '+ nmi)
			req = urllib2.Request(url = target, data = None)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			fl = open(path, "wb")
			fl.write(resp.read())
			fl.close()
			pDialog.close()
			return path
	except:
			print "err:  "+target
			return target


def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		#sn=http[s:]
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "w")
	fl.write(s)
	fl.close()

def inputbox(t):
	skbd = xbmc.Keyboard(t, 'Название:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return t

Player=xbmc.Player()


def play_ace2(url):
	s=url.find('getstream?id=')
	if s<0: return ""
	PID=url[s+13:]
	print PID
	
	tsserv.start()
	tsserv.push('HELLOBG version=3')
	#command='HELLOBG version=3'
	#sock.send(command + '\r\n')
	n=0
	while not tsserv.version:
			print tsserv.version
			n+=1
			xbmc.sleep(200)
			if n>50: return "X HELLOBG"
	import hashlib
	sha1 = hashlib.sha1()
	pkey = tsserv.pkey
	sha1.update(tsserv.key + pkey)
	key = sha1.hexdigest()
	pk = pkey.split('-')[0]
	ready_key = 'READY key=%s-%s' % (pk, key)
	tsserv.push(ready_key)
	#sock.send(ready_key + '\r\n')

	n=0
	while not tsserv.auth_ok:
			n+=1
			xbmc.sleep(200)
			if n>50: return "X READY"
	#PID=url
	tsserv.push('START PID '+PID+' 0')
	while not tsserv.state == 2:
			n+=1
			xbmc.sleep(200)
			if n>50: return "X START"
	return tsserv.content_url

def ACE2_end():
	try:
		tsserv.push('SHUTDOWN')
		sock.shutdown(socket.SHUT_RDWR)
		sock.close()
	except:
		pass

def play_archive(urls, name ,cover, ref=True):
	#print urls
	Player.stop()
	pDialog = xbmcgui.DialogProgressBG()
	try:pDialog.create('Пазл ТВ', 'Поиск потоков ...')
	except: pass
	Lpurl=[]
	for url in urls:
		#Lcurl=get_stream(url)
		try: Lcurl=get_archive(url)
		except:Lcurl=[]
		#print Lcurl
		try:Lpurl.extend(Lcurl)
		except:Lcurl=[]
	
	Lpurl2=[]
	Lm3u8 =[]
	Lrtmp =[]
	Lp2p  =[]
	Lourl =[]
	Ltmp=[]
	
	for i in Lpurl:
		if '.m3u8' in i and i not in Lm3u8:  Lm3u8.append(i)
		elif 'rtmp' in i and i not in Lrtmp: Lrtmp.append(i)
		elif '/ace/' in i and i not in Lp2p: Lp2p.append(i)
		elif i not in Ltmp:                  Lourl.append(i)
		Ltmp.extend(Lp2p)
		Ltmp.extend(Lm3u8)
		Ltmp.extend(Lrtmp)
		Ltmp.extend(Lourl)
	
	if __settings__.getSetting("ace_start")=='true' and len(Lp2p)>0: ASE_start()
	
	if __settings__.getSetting("p2p_start")=='true':
			Lpurl2.extend(Lp2p)
			Lpurl2.extend(Lm3u8)
			Lpurl2.extend(Lrtmp)
			Lpurl2.extend(Lourl)
	else:
			Lpurl2.extend(Lm3u8)
			Lpurl2.extend(Lourl)
			Lpurl2.extend(Lp2p)
			Lpurl2.extend(Lrtmp)
	
	if Lpurl2==[]:
		pDialog.close()
		showMessage('Пазл ТВ', 'Канал недоступен')
		return ""
		
	else:
		playlist = xbmc.PlayList (xbmc.PLAYLIST_VIDEO)
		playlist.clear()
		
		n=1
		if len(Lpurl2)>1:n=3
		
		for j in range (0,n): # несколько копий в плейлист
			k=0
			for purl in Lpurl2:
				k+=1
				if __settings__.getSetting("split")=='true':name2=unmark(name)#.replace(" #1","")
				else:name2=colormark(name)#.replace(" #1","[COLOR 40FFFFFF] #1[/COLOR]")
				item = xbmcgui.ListItem(name2+" [ "+str(k)+"/"+str(len(Lpurl2))+" ]", path=purl, thumbnailImage=cover, iconImage=cover)
				playlist.add(url=purl, listitem=item)
		
		for j in range (0,5):
			purl2=os.path.join(addon.getAddonInfo('path'),"2.mp4")
			item = xbmcgui.ListItem(" > ", path=purl2, thumbnailImage=cover, iconImage=cover)
			playlist.add(url=purl2, listitem=item)
		
		
		pDialog.close()
		
		Player.play(playlist)
		xbmc.sleep(1000)
		xbmcplugin.endOfDirectory(handle)



Lmrk=[]
for i in range (0,100):
		Lmrk.append(str(i))
Lmrk.reverse()

def unmark(nm):
	for i in Lmrk:
		nm=nm.replace(" #"+str(i),"")
	return nm

def uni_mark(nm):
	for i in Lmrk:
		nm=lower(nm.replace(" #"+str(i),""))
	return nm

def colormark(nm):
	for i in Lmrk:
		nm=nm.replace(" #"+str(i),"[COLOR 40FFFFFF] #"+str(i)+"[/COLOR]")
	return nm

def get_ttv(url):
		http=getURL(url)
		#print http
		ss1='this.loadPlayer("'
		ss2='this.loadTorrent("'
		es='",{autoplay: true})'
		srv=__settings__.getSetting("p2p_serv")
		prt=__settings__.getSetting("p2p_port")
		
		try:
			if ss1 in http:
				CID=mfindal(http,ss1,es)[0][len(ss1):]
				lnk='http://'+srv+':'+prt+'/ace/getstream?id='+CID
				if len(CID)<30:lnk=''
				return lnk
			elif ss2 in http:
				AL=mfindal(http,ss2,es)[0][len(ss2):]
				lnk='http://'+srv+':'+prt+'/ace/getstream?url='+AL
				if len(AL)<30:lnk=''
				return lnk
			else: return ""
		except:
			return ""



def get_archive(url):
	for i in Larh:
		ids=i[4:].replace('_','-')
		#print ids
		if ids in url:
			print ids
			exec ("import "+i+"; serv="+i+".ARH()")
			return serv.Streams(url)
	return []


def upd_archive_db(i):
	exec ("import "+i+"; serv="+i+".ARH()")
	return serv.name2id()


def get_all_archive():
	pDialog = xbmcgui.DialogProgressBG()
	L=[]
	for i in Larh:
		serv_id=str(int(i[1:3]))
		if __settings__.getSetting("arh"+serv_id+"")=='true' :
			try: exec ("import aid"+serv_id+"; Ds=aid"+serv_id+".n2id")
			except:Ds={}
			if Ds=={}: 
				pDialog.create('Пазл ТВ', 'Обновление архива #'+serv_id+' ...')
				Ds=upd_archive_db(i)
				pDialog.close()
		else: Ds={}
		if Ds !={}:
			Ds['srv_id']=i
			L.append(Ds)
	return L



def add_item (name, mode="", path = Pdir, ind="0", cover=None, funart=None):
	if __settings__.getSetting("fanart")=='true':funart=cover
	else: funart=fanart
	if __settings__.getSetting("icons")!='true':cover=icon

	listitem = xbmcgui.ListItem(name, iconImage=cover)
	listitem.setProperty('fanart_image', funart)
	uri = sys.argv[0] + '?mode='+mode
	uri += '&url='  + urllib.quote_plus(repr(path))
	uri += '&name='  + urllib.quote_plus(xt(ind))
	uri += '&ind='  + urllib.quote_plus(str(ind))
	if cover!=None:uri += '&cover='  + urllib.quote_plus(cover)
	#if funart!=None and funart!="":uri += '&funart='  + urllib.quote_plus(funart)
	
	if mode=="play":
		if __settings__.getSetting("epgon")=='true':
				id = get_idx(ind)
				cepg=get_cepg(id,'xmltv').replace('&quot;','"').replace('&apos;',"'")
				if cepg !="":
					dict={"plot":cepg}
					try:listitem.setInfo(type = "Video", infoLabels = dict)
					except: pass

		fld=False
		#fld=True
		
		ContextCmd=[
			('[COLOR FF55FF55][B]ГРУППА[/B][/COLOR]', 'Container.Update("plugin://plugin.video.pazl.arhive/?mode=select_gr")'),
			('[COLOR FF55FF55][B]+ Добавить в группу[/B][/COLOR]', 'Container.Update("plugin://plugin.video.pazl.arhive/?mode=add&name='+urllib.quote_plus(ind)+'")'),
			('[COLOR FFFF5555][B]- Удалить из группы[/B][/COLOR]', 'Container.Update("plugin://plugin.video.pazl.arhive/?mode=rem&name='+urllib.quote_plus(ind)+'")'),
			('[COLOR FF55FF55][B]<> Переместить канал[/B][/COLOR]', 'Container.Update("plugin://plugin.video.pazl.arhive/?mode=set_num&name='+urllib.quote_plus(ind)+'")'),
		('[COLOR FFFFFF55][B]* Обновить каналы[/B][/COLOR]', 'Container.Update("plugin://plugin.video.pazl.arhive/?mode=update")'),
			('[COLOR FFFFFF55][B]* Обновить программу[/B][/COLOR]', 'Container.Update("plugin://plugin.video.pazl.arhive/?mode=updateepg")'),
			('[COLOR FF55FF55][B]ПЕРЕДАЧИ[/B][/COLOR]', 'Container.Update("plugin://plugin.video.pazl.arhive/?mode=tvgide")')]
		if test_rec(ind): ContextCmd.append(('[COLOR FF55FF55][B]АРХИВ[/B][/COLOR]', 'Container.Update("plugin://plugin.video.pazl.arhive/?mode=archive&name='+urllib.quote_plus(ind)+'")'))
			
		#if __settings__.getSetting("grincm")=='true':listitem.addContextMenuItems(ContextGr, replaceItems=True)
		#else:										listitem.addContextMenuItems(ContextCmd, replaceItems=True)
	
	elif mode=="play2" or mode=="select_date":
		fld=False
	else: 
		fld=True
		'''
		listitem.addContextMenuItems([
			('[COLOR FF55FF55][B]+ Создать группу[/B][/COLOR]', 'Container.Update("plugin://plugin.video.pazl.arhive/?mode=addgr")'),
			('[COLOR FFFF5555][B]- Удалить группу[/B][/COLOR]', 'Container.Update("plugin://plugin.video.pazl.arhive/?mode=remgr")'),
			('[COLOR FFFFFF55][B]* Обновить каналы[/B][/COLOR]', 'Container.Update("plugin://plugin.video.pazl.arhive/?mode=update")'),
			('[COLOR FFFFFF55][B]* Обновить программу[/B][/COLOR]', 'Container.Update("plugin://plugin.video.pazl.arhive/?mode=updateepg")'),
			('[COLOR FFFFFF55][B]Управление каналами[/B][/COLOR]', 'Container.Update("plugin://plugin.video.pazl.arhive/?mode=grman")'),
			('[COLOR FFFFFF55][B]Архивные каналы[/B][/COLOR]', 'Container.Update("plugin://plugin.video.pazl.arhive/?mode=cnl_archive")'),])
		'''
	xbmcplugin.addDirectoryItem(handle, uri, listitem, fld)#, ind)cnl_archive


def cnl_archive():
	La=get_all_archive()
	Lc=[]
	for n2id in La:
		for name in n2id.keys():
			uname=uni_mark(name)
			if uname not in Lc:
				add_item (name, 'archive', '', name)
				Lc.append(uname)
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(handle)


def archive(name):#, sd='0'
	try:sd=__settings__.getSetting("Sel_sday")
	except: sd='0'
	if sd=="":sd='0'
	La=get_all_archive()
	ssec=int(sd)*24*60*60
	t=time.localtime(time.time() - ssec)
	add_item ('[COLOR FF10FF10][B]'+time.strftime('%d.%m.%Y',t)+" - "+unmark(name)+"[/B][/COLOR]", "select_date", 'url', '0' )
	da={}
	Lm=[]
	for n2id in La:
		serv_id=n2id['srv_id']
		#try: 
		exec ("import "+serv_id+"; arh="+serv_id+".ARH()")
		#n2id=arh.name2id()
		for key in n2id.keys():
			if uni_mark(key)==uni_mark(name): name=key
			
		try:aid=n2id[name]
		except: aid=""
		#from aid3 import *
		#n2id
		if aid!="":
			L=arh.Archive(aid, t)
			for i in L:
				#url=i['url']
				#title=i['title']
				st=i['time']
				#add_item (st+" - "+title, "play2", [url,], 'archive' )
				try: 
					i2=da[st]
					urls=i2['url']
					url=i['url']
					urls.append(url)
					i2['url']=urls
					da[st]=i2
				except: 
					url=i['url']
					i['url']=[url,]
					da[st]=i
	for d in da.keys():
			urls=da[d]['url']
			title=da[d]['title']
			st=da[d]['time']
			add_item (st+" - "+title, "play2", urls, 'archive' )
			
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(handle)


def select_date():
		L=[]
		for i in range (0,10):
			ssec=i*24*60*60
			t=time.localtime(time.time() - ssec)
			st=time.strftime('%d.%m.%Y',t)
			L.append(st)
		sel = xbmcgui.Dialog()
		r = sel.select("Дата:", L)
		__settings__.setSetting("Sel_sday",str(r))
		xbmc.executebuiltin("Container.Refresh")


def get_allurls(xid, L):
	L3=[]
	for j in L:
		name = j['title']
		id=get_idx(name)
		if id == xid and id !="":
			L3.append(j['url'])
	return L3

def ASE_start():
	srv=__settings__.getSetting("p2p_serv")
	prt=__settings__.getSetting("p2p_port")
	lnk='http://'+srv+':'+prt+'/webui/api/service?method=get_version&format=jsonp&callback=mycallback'#getstream?id='+CID
	try:
		http=getURL(lnk)
		return False
	except:
		#showMessage('Пазл ТВ', 'Запуск Ace Stream')
		pDialog.create('Пазл ТВ', 'Запуск Ace Stream ...')
		pDialog.update(0, message='Запуск Ace Stream ...')
		start_linux()
		start_windows()
		for i in range (0,10):
			pDialog.update(i*10, message='Запуск Ace Stream ...')
			xbmc.sleep(1500)
			try:
				http=getURL(lnk)
				pDialog.close()
				return True
			except: pass
		pDialog.close()
		return False

def start_linux():
        import subprocess
        try:
            subprocess.Popen(['acestreamengine', '--client-console'])
        except:
            try:
                subprocess.Popen('acestreamengine-client-console')
            except: 
                try:
                    xbmc.executebuiltin('XBMC.StartAndroidActivity("org.acestream.media")')
                    xbmc.sleep(2000)
                    xbmc.executebuiltin('XBMC.StartAndroidActivity("org.xbmc.kodi")')
                except:
                    return False
        return True
    
def start_windows():
        try:
            import _winreg
            try:
                t = _winreg.OpenKey(_winreg.HKEY_CURRENT_USER, r'Software\AceStream')
            except:
                t = _winreg.OpenKey(_winreg.HKEY_CURRENT_USER, r'Software\TorrentStream')
            path = _winreg.QueryValueEx(t, r'EnginePath')[0]
            os.startfile(path)
            return True
        except:
            return False


def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

params = get_params()

try:mode = urllib.unquote_plus(params["mode"])
except:mode =""
try:name = urllib.unquote_plus(params["name"])
except:name =""
try:url = eval(urllib.unquote_plus(params["url"]))
except:url =[]
try:cover = urllib.unquote_plus(params["cover"])
except:cover =""
try:ind = urllib.unquote_plus(params["ind"])
except:ind ="0"
pDialog = xbmcgui.DialogProgressBG()

if mode==""         : cnl_archive()#root

if mode=="play2"    : play_archive(url, name, cover)

if mode=="archive"   :  archive(name)#, ind
if mode=="select_date": select_date()

if mode=="cnl_archive": cnl_archive()


