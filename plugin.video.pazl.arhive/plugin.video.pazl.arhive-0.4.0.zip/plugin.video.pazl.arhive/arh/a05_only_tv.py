#!/usr/bin/python
# -*- coding: utf-8 -*-

import string, xbmc, xbmcgui, xbmcplugin, xbmcaddon
import os, cookielib, urllib, urllib2, time
addon = xbmcaddon.Addon(id='plugin.video.pazl.arhive')
__settings__ = xbmcaddon.Addon(id='plugin.video.pazl.arhive')
#-----------------------------------------

icon = ""
serv_id = '5'
siteUrl = 'only-tv.org'
httpSiteUrl = 'http://' + siteUrl
sid_file = os.path.join(xbmc.translatePath('special://temp/'), siteUrl+'.sid')

cj = cookielib.FileCookieJar(sid_file) 
hr  = urllib2.HTTPCookieProcessor(cj) 
opener = urllib2.build_opener(hr) 
urllib2.install_opener(opener) 

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def unmark(nm):
	for i in range (0,20):
		nm=nm.replace(" #"+str(i),"")
	return nm

def lower(s):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.lower().encode('utf-8')
	return s


def get_HTML(url, post = None, ref = None, get_redirect = False):
    import urlparse
    if url.find('http')<0 :
        if CT=="0": url='http:'+url
        else: url='https:'+url
    #url="http://translate.googleusercontent.com/translate_c?u="+url
    request = urllib2.Request(url, post)

    host = urlparse.urlsplit(url).hostname
    if ref==None:
        try:
           ref='http://'+host
        except:
            ref='localhost'

    request.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
    request.add_header('Host',   host)
    request.add_header('Accept', 'text/html, application/xhtml+xml, */*')
    request.add_header('Accept-Language', 'ru-RU')
    request.add_header('Referer',             ref)
    request.add_header('Content-Type','application/x-www-form-urlencoded')

    try:
        f = urllib2.urlopen(request)
    except IOError, e:
        if hasattr(e, 'reason'):
           print('We failed to reach a server.')
        elif hasattr(e, 'code'):
           print('The server couldn\'t fulfill the request.')
        return 'We failed to reach a server.'

    if get_redirect == True:
        html = f.geturl()
    else:
        html = f.read()

    return html

def Login():
	url1 = 'http://torrent-tv.ru/auth.php'
	login = __settings__.getSetting("ttv_login")
	passw = __settings__.getSetting("ttv_password")
	if login == '' or passw == '': return False
	
	values = {
				'email'     : login,
				'password'  : passw,
				'remember'    : 'on',
				'enter'    : 'Войти'
		}
	post = urllib.urlencode(values)
	html = get_HTML(url1, post, 'http://torrent-tv.ru/')
	return True

def getURL(url, Referer = httpSiteUrl):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L


def save_aid(ns, d):
		fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'aid'+ns+'.py'))
		fl = open(fp, "w")
		fl.write('# -*- coding: utf-8 -*-\n')
		fl.write('n2id=')
		fl.write(repr(d))
		fl.close()

def get_tv(url):
		#print url
		i=getURL(url)
		ss="var stream_url = '"#"value='src="
		es="';"#"&ar="
		tvpl = i[i.find(ss)+len(ss):i.find(es)]
		return tvpl

class ARH:
	def __init__(self):
		pass
		#self.name2id()

	def Streams(self, url):
		try:
			strm=get_tv(url)
			#print strm
			if len(strm)<10: return []
			else:return [strm,]
		except:
			return []

	def Archive(self, id, t):
		dt=str(time.mktime(t))#.strftime('-%d-%m-%Y',t).replace('-0','-')[1:]
		url='http://only-tv.org/modules/mod_tv-archive-channel/archive-chanel.php?time='+dt+'&id='+id#12-7-2016
		http=getURL(url)
		ss='<span class="archive_time">'
		es='<div class="clear"></div>'
		L=mfindal(http,ss,es)
		LL=[]
		for i in L:
			if 'href=' in i:
			#try:
				i=i.replace(chr(10),"").replace(chr(13),"").replace('<span class="archive_time">', '')
				#print i
				ss='">'
				es='</a></span>'
				tm=mfindal(i,ss,es)[0][len(ss):].strip()
				#print tm
				
				ss='">'
				es='</a></p>'
				title=i[i.rfind('">')+2:i.rfind('</a>')]
				#print title
				
				ss='href="'
				es='">'
				uri='http://only-tv.org'+mfindal(i,ss,es)[0][len(ss):]
				#print uri
				
				LL.append({'url':uri, 'title':title, 'time':tm})
			#except: pass
		return LL

	def name2id(self):
		url='http://only-tv.org/archive-tv.html'
		http=getURL(url)
		ss='align: center;"><a '
		es='width="105" height="105"'
		L=mfindal(http,ss,es)
		d={}
		for i in L:
			#try:
				tv = i[i.find('href="/')+7:i.find('.html">')]
				curl='http://only-tv.org/'+tv+'.html'
				chp=getURL(curl)
				tmp = chp[chp.find("var id = '")+10:]
				idc = tmp[:tmp.find("';")]
				nmc = i[i.find('alt="')+5:i.find('" title')].replace('Архив канала ', '').replace('Архив ', '').replace('канала', 'канал').replace('Нового', 'Новый').strip()#+29 lower()
				#print i
				d[nmc] = idc
			#except: pass
		save_aid(serv_id, d)
		return d