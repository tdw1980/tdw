# -*- coding: utf-8 -*-
import sys, os, urllib, urllib2

def getURL(url, Referer = 'http://emulations.ru/'):
	req = urllib2.Request(url)
#	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
#	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
#	req.add_header('Accept-Language', 'ru,en;q=0.9')
#	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def get_path(id):
	pref='0'*(6-len(id))
	id=pref+id
	if len(id[:-4])==3:s1=chr(int(id[:-5])+87)+id[-5:-4]
	else:s1=id[:-4]
	s=[s1,id[-4:-2],id[-2:]]
	return s

def get_info(id):
	c=get_path(id)
	url='http://td-soft.narod.ru/kinodb/'+c[0]+'/'+c[1]+'.info'
	#hp=getURL(url)
	f=urllib.urlopen(url)
	hp=f.read()
	cinfo=eval(hp)
	info=cinfo[id]
	return info