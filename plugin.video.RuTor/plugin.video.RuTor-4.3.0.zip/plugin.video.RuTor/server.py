# coding: utf-8
# Module: server
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys
import xbmc, xbmcgui, xbmcaddon
__settings__ = xbmcaddon.Addon(id='plugin.video.RuTor')

print('----- Rutor serv started -----')
start_trigger = False
xbmc.sleep(12000)
monitor = xbmc.Monitor()

while not monitor.abortRequested():
		xbmc.executebuiltin('RunPlugin("plugin://plugin.video.RuTor/?mode=Check")')
		monitor.waitForAbort(6*60*60)

print('----- Rutor serv started stopped -----')

