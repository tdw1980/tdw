# -*- coding: utf-8 -*-
import sys, os, urllib

if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2

#try:
#	import ssl
#	context = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
#	opener = urllib2.build_opener(urllib2.HTTPSHandler(context=context))
#	urllib2.install_opener(opener)
#except: pass

def b2s(s):
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def GET(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	response = urllib2.urlopen(req, timeout=5)
	link=response.read()
	response.close()
	return b2s(link)

def get_path_old(id):
	pref='0'*(6-len(id))
	id=pref+id
	if len(id[:-4])==3:s1=chr(int(id[:-5])+87)+id[-5:-4]
	else:s1=id[:-4]
	s=[s1,id[-4:-2],id[-2:]]
	return s

def get_info_old(id):
	c=get_path_old(id)
	url='http://td-soft.narod.ru/kinodb/'+c[0]+'/'+c[1]+'.info'
	#hp=getURL(url)
	f=urllib.urlopen(url)
	hp=f.read()
	cinfo=eval(hp)
	info=cinfo[id]
	return info

def get_path(id):
	pref='xxx'
	id=pref+id
	s=[id[-2:],id[-4:-2]]
	return s

def get_info(id):
	c=get_path(id)
	url='http://td-soft.narod.ru/db/'+c[0]+'/'+c[1]+'.info'
	cinfo=eval(GET(url))
	info=cinfo[id]
	return info

#get_info('4449144')