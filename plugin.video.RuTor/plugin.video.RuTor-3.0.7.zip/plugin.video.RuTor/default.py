#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib, urllib2, sys, os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import rutor

handle = int(sys.argv[1])
PLUGIN_NAME   = 'RuTor'

addon = xbmcaddon.Addon(id='plugin.video.RuTor')
__settings__ = xbmcaddon.Addon(id='plugin.video.RuTor')

icon = os.path.join(addon.getAddonInfo('path'), 'icon.png')
thumb = os.path.join( addon.getAddonInfo('path'), "icon.png" )
fanart = os.path.join( addon.getAddonInfo('path'), "fanart.jpg" )
LstDir = os.path.join( addon.getAddonInfo('path'), "playlists" )

siteUrl = __settings__.getSetting('Url')
if siteUrl == "": siteUrl = 'open-tor.org'
httpSiteUrl = 'http://' + siteUrl

xbmcplugin.setContent(int(sys.argv[1]), 'movies')


# - ====================================== antizapret ====================================================
import time, cookielib
sid_file = os.path.join(xbmc.translatePath('special://temp/'), 'vpn.sid')
cj = cookielib.FileCookieJar(sid_file) 
hr  = urllib2.HTTPCookieProcessor(cj) 

def GETvpn():
	import httplib
	conn = httplib.HTTPConnection("antizapret.prostovpn.org")
	conn.request("GET", "/proxy.pac", headers={"User-Agent": 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)'})
	r1 = conn.getresponse()
	data = r1.read()
	conn.close()
	return data

def proxy_update():
	#try:
		print 'proxy_update'
		#url='https://antizapret.prostovpn.org/proxy.pac'
		pac=GETvpn()#url)
		prx=pac[pac.find('PROXY ')+6:pac.find('; DIRECT')]
		__settings__.setSetting("proxy_serv", prx)
		__settings__.setSetting("proxy_time", str(time.time()))
	#except: 
	#	print 'except get proxy'

if __settings__.getSetting("antizapret") == "true":
	#try:
		try:pt=float(__settings__.getSetting("proxy_time"))
		except:pt=0
		print pt
		if time.time()-pt > 36000: proxy_update()
		prx=__settings__.getSetting("proxy_serv")
		print prx
		if prx.find('http')<0 : prx="http://"+prx
		proxy_support = urllib2.ProxyHandler({"http" : prx})
		opener = urllib2.build_opener(proxy_support, hr)
	#except:
	#	print 'except set proxy'
	#	opener = urllib2.build_opener(hr) 
		urllib2.install_opener(opener)

def convert(url):
	import base64
	sign=base64.b64encode(url)
	redir='http://www.proxy.zee18.info/index.php?q='+urllib.quote_plus(sign)
	return redir
	
#if __settings__.getSetting("antizapret") == "true": url=convert(url)
# - ==========================================================================================

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)
def fs_enc(path):
	path=xbmc.translatePath(path)
	sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
	try:path2=path.decode('utf-8')
	except: pass
	try:path2=path2.encode(sys_enc)
	except: 
		try: path2=path2.encode(sys_enc)
		except: path2=path
	return path2

def mid(s, n):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.center(n)
	try:s=s.encode('utf-8')
	except: pass
	return s

def mids(s, n):
	l="                                              "
	s=l[:n-len(s)]+s+l[:n-len(s)]
	return s

def lower(s):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.lower().encode('utf-8')
	return s

def save_strm(url, ind=0, id='0'):
		info = eval(get_inf_db(id))
		SaveDirectory = __settings__.getSetting("SaveDirectory")
		if SaveDirectory=="":SaveDirectory=LstDir
		name = info['originaltitle'].replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"")+" ("+str(info['year'])+")"
		
		uri = sys.argv[0] + '?mode=Play2'
		uri = uri+ '&url='+urllib.quote_plus(url)
		uri = uri+ '&num='+str(ind)
		uri = uri+ '&id='+str(id)
		
		fl = open(os.path.join(fs_enc(SaveDirectory),fs_enc(name+".strm")), "w")
		fl.write(uri)
		fl.close()
		
		if __settings__.getSetting("NFO")=='true': save_film_nfo(id)
		xbmc.executebuiltin('UpdateLibrary("video", "", "false")')

def save_film_nfo(id):
		info = eval(get_inf_db(id))
		title=info['title']
		fanart=info['fanart']
		cover=info['cover']
		year=info['year']
		fanarts=[fanart,cover]
		
		try:plot=info['plot']
		except:plot=''
		try:rating=info['rating']
		except:rating=0
		try:originaltitle=info['originaltitle']
		except:originaltitle=title
		
		try:duration=info["duration"]
		except:duration=''
		try:genre=info["genre"].replace(', ', '</genre><genre>')
		except:genre=''
		try:studio=info["studio"]
		except:studio=''
		
		try: director=info["director"]
		except: director=''
		try:cast=info["cast"]
		except:cast=[]
		try: actors=info["actors"]
		except: actors={}
		
		name = info['originaltitle'].replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"")+" ("+str(info['year'])+")"
		#cn=name.find(" (")
		
		SaveDirectory = __settings__.getSetting("SaveDirectory")
		if SaveDirectory=="":SaveDirectory=LstDir
		
		nfo='<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>'+chr(10)
		nfo+='<movie>'+chr(10)
		
		nfo+="	<title>"+title+"</title>"+chr(10)
		nfo+="	<originaltitle>"+originaltitle+"</originaltitle>"+chr(10)
		nfo+="	<genre>"+genre+"</genre>"+chr(10)
		nfo+="	<studio>"+studio+"</studio>"+chr(10)
		nfo+="	<director>"+director+"</director>"+chr(10)
		nfo+="	<year>"+str(year)+"</year>"+chr(10)
		nfo+="	<plot>"+plot+"</plot>"+chr(10)
		nfo+='	<rating>'+str(rating)+'</rating>'+chr(10)
		nfo+='	<runtime>'+duration+' min.</runtime>'+chr(10)
		
		nfo+="	<fanart>"+chr(10)
		for fan in fanarts:
			nfo+="		<thumb>"+fan+"</thumb>"+chr(10)
		nfo+="		<thumb>"+cover+"</thumb>"+chr(10)
		nfo+="	</fanart>"+chr(10)
		
		nfo+="	<thumb>"+cover+"</thumb>"+chr(10)
		
		for actor in cast:
			nfo+="	<actor>"+chr(10)
			nfo+="		<name>"+actor+"</name>"+chr(10)
			nfo+="	</actor>"+chr(10)
		
		nfo+="</movie>"+chr(10)
		
		fl = open(os.path.join(fs_enc(SaveDirectory),fs_enc(name+".nfo")), "w")
		fl.write(nfo)
		fl.close()




def GETtorr(target):
	try:
			req = urllib2.Request(url = target)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			return resp.read()
	except Exception, e:
			print 'HTTP ERROR ' + str(e)
			return None

def Open(url):
	if 'http' not in url: url=httpSiteUrl+url
	torrent_data = GETtorr(url)
	#print torrent_data
	if torrent_data != None:
		import bencode
		torrent = bencode.bdecode(torrent_data)
		cover = icon#get_info(id)['cover']
		try:
			L = torrent['info']['files']
			ind=0
			for i in L:
				name=ru(i['path'][-1])
				#size=i['length']
				listitem = xbmcgui.ListItem(name, iconImage=cover, thumbnailImage=cover)
				listitem.setProperty('IsPlayable', 'true')
				uri = sys.argv[0]+'?mode=Play&num='+str(ind)+'&url='+urllib.quote_plus(url)
				xbmcplugin.addDirectoryItem(handle, uri, listitem)
				ind+=1
		except:
				ind=0
				name=torrent['info']['name']
				listitem = xbmcgui.ListItem(name, iconImage=cover, thumbnailImage=cover)
				listitem.setProperty('IsPlayable', 'true')
				#listitem.addContextMenuItems([('[B]Сохранить фильм(STRM)[/B]', 'Container.Update("plugin://plugin.video.torrentino.me/?mode=Save_strm&id='+id+'&url='+urllib.quote_plus(url)+'")'),])
				uri =sys.argv[0]+'?mode=Play&num='+str(ind)+'&url='+urllib.quote_plus(url)
				xbmcplugin.addDirectoryItem(handle, uri, listitem)

	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)


def get_item_name(url, ind):
	torrent_data = GETtorr(url)
	if torrent_data != None:
		import bencode
		torrent = bencode.bdecode(torrent_data)
		try:
			L = torrent['info']['files']
			name=L[ind]['path'][-1]
		except:
			name=torrent['info']['name']
		return name
	else:
		return ' '

def play(url, ind=0, id='0'):
		if __settings__.getSetting("antizapret") == "true": url=convert(url)
		
		if 'http' not in url: url=httpSiteUrl+url
		#print url
		engine=__settings__.getSetting("Engine")
		if engine=="0": play_ace (url, ind)
		if engine=="1": play_t2h (url, ind, __settings__.getSetting("DownloadDirectory"))
		if engine=="2": play_yatp(url, ind)
		if engine=="3": play_torrenter(url, ind)
		if engine=="4": play_elementum(url, ind)

def play_ace(torr_link, ind=0):
	try:
		title=get_item_name(torr_link, ind)
		from TSCore import TSengine as tsengine
		TSplayer=tsengine()
		out=TSplayer.load_torrent(torr_link,'TORRENT')
		#print out
		if out=='Ok': TSplayer.play_url_ind(int(ind),title, icon, icon, True)
		TSplayer.end()
		return out
	except: 
		return '0'

def play_t2h(uri, file_id=0, DDir=""):
	try:
		sys.path.append(os.path.join(xbmc.translatePath("special://home/"),"addons","script.module.torrent2http","lib"))
		from torrent2http import State, Engine, MediaType
		progressBar = xbmcgui.DialogProgress()
		from contextlib import closing
		if DDir=="": DDir=os.path.join(xbmc.translatePath("special://home/"),"userdata")
		progressBar.create('Torrent2Http', 'Запуск')
		# XBMC addon handle
		# handle = ...
		# Playable list item
		# listitem = ...
		# We can know file_id of needed video file on this step, if no, we'll try to detect one.
		# file_id = None
		# Flag will set to True when engine is ready to resolve URL to XBMC
		ready = False
		# Set pre-buffer size to 15Mb. This is a size of file that need to be downloaded before we resolve URL to XMBC 
		pre_buffer_bytes = 15*1024*1024
		
		engine = Engine(uri, download_path=DDir, enable_dht=True, dht_routers=["router.bittorrent.com:6881","router.utorrent.com:6881"], user_agent = 'uTorrent/2200(24683)')
		with closing(engine):
			# Start engine and instruct torrent2http to begin download first file, 
			# so it can start searching and connecting to peers  
			engine.start(file_id)
			progressBar.update(0, 'Torrent2Http', 'Загрузка торрента', "")
			while not xbmc.abortRequested and not ready:
				xbmc.sleep(500)
				status = engine.status()
				# Check if there is loading torrent error and raise exception 
				engine.check_torrent_error(status)
				# Trying to detect file_id
				if file_id is None:
					# Get torrent files list, filtered by video file type only
					files = engine.list(media_types=[MediaType.VIDEO])
					# If torrent metadata is not loaded yet then continue
					if files is None:
						continue
					# Torrent has no video files
					if not files:
						break
						progressBar.close()
					# Select first matching file                    
					file_id = files[0].index
					file_status = files[0]
				else:
					# If we've got file_id already, get file status
					file_status = engine.file_status(file_id)
					# If torrent metadata is not loaded yet then continue
					if not file_status:
						continue
				if status.state == State.DOWNLOADING:
					# Wait until minimum pre_buffer_bytes downloaded before we resolve URL to XBMC
					if file_status.download >= pre_buffer_bytes:
						ready = True
						break
					#print file_status
					#downloadedSize = status.total_download / 1024 / 1024
					getDownloadRate = status.download_rate / 1024 * 8
					#getUploadRate = status.upload_rate / 1024 * 8
					getSeeds = status.num_seeds
					
					progressBar.update(100*file_status.download/pre_buffer_bytes, xt('Предварительная буферизация: '+str(file_status.download/1024/1024)+" MB"), "Сиды: "+str(getSeeds), "Скорость: "+str(getDownloadRate)[:4]+' Mbit/s')#
					
				elif status.state in [State.FINISHED, State.SEEDING]:
					#progressBar.update(0, 'T2Http', 'We have already downloaded file', "")
					# We have already downloaded file
					ready = True
					break
				
				if progressBar.iscanceled():
					progressBar.update(0)
					progressBar.close()
					break
				# Here you can update pre-buffer progress dialog, for example.
				# Note that State.CHECKING also need waiting until fully finished, so it better to use resume_file option
				# for engine to avoid CHECKING state if possible.
				# ...
			progressBar.update(0)
			progressBar.close()
			if ready:
				# Resolve URL to XBMC
				item = xbmcgui.ListItem(path=file_status.url)
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
				xbmc.sleep(3000)
				xbmc.sleep(3000)
				# Wait until playing finished or abort requested
				while not xbmc.abortRequested and xbmc.Player().isPlaying():
					xbmc.sleep(500)
	except: pass




def play_yatp(url, ind):
	purl ="plugin://plugin.video.yatp/?action=play&torrent="+ urllib.quote_plus(url)+"&file_index="+str(ind)
	item = xbmcgui.ListItem(path=purl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def play_torrenter(url, ind):
	purl ="plugin://plugin.video.torrenter/?action=playSTRM&url="+ urllib.quote_plus(url)+"&file_index="+str(ind)
	item = xbmcgui.ListItem(path=purl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def play_elementum(url, ind):
	purl ="plugin://plugin.video.elementum/play?uri="+ urllib.quote_plus(url)+"&index="+str(ind)
	item = xbmcgui.ListItem(path=purl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


#============================================

def construct_request(params):
	return '%s?%s' % (sys.argv[0], urllib.urlencode(params))

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def GET(target, referer='', post=None):
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		showMessage('HTTP ERROR', e, 5000)

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def showMessage(heading, message, times = 50000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, thumb))

def inputbox():
	skbd = xbmc.Keyboard()
	skbd.setHeading('Поиск:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return ""


def AddItem(Title = "", mode = "", id='0', url='', inf={}, total=100):
			if id !='0':
				try:    info=get_info(inf)
				except: info={}
				try:    cover = info["cover"]
				except: cover = icon
				try:    fanart = info["fanart"]
				except: fanart = ''
				try:    type=info["type"]
				except: type=''
			else:
				cover = icon
				fanart = ''
				info={'id':id}
				type=''
			
			listitem = xbmcgui.ListItem(Title, iconImage=cover, thumbnailImage=cover)
			listitem.setInfo(type = "Video", infoLabels = info)
			try: listitem.setArt({ 'poster': cover, 'fanart' : fanart, 'thumb': cover, 'icon': cover})
			except: pass
			listitem.setProperty('fanart_image', fanart)
			
			purl = sys.argv[0] + '?mode='+mode+'&id='+id+'&info='+urllib.quote_plus(repr(info))
			if url !="": purl = purl +'&url='+urllib.quote_plus(url)
			
			#if mode=="Play": 
			#	listitem.addContextMenuItems([('[B]Сохранить фильм(STRM)[/B]', 'Container.Update("plugin://plugin.video.RuTor/?mode=save_strm&id='+id+'&url='+urllib.quote_plus(url)+'")'),])
			if mode=="Open":
				if type != '': listitem.addContextMenuItems([('[B]Сохранить сериал[/B]', 'Container.Update("plugin://plugin.video.torrent.checker/?mode=save_episodes_api&url='+urllib.quote_plus(url)+'&name='+urllib.quote_plus(info['originaltitle'])+ '&info=' + urllib.quote_plus(repr(info))+'")'),('[B]Отслеживать сериал[/B]', 'Container.Update("plugin://plugin.video.torrent.checker/?mode=add&url='+urllib.quote_plus(url)+'&name='+urllib.quote_plus(info['originaltitle'])+'")')])
				else: listitem.addContextMenuItems([('[B]Сохранить фильм(STRM)[/B]', 'Container.Update("plugin://plugin.video.RuTor/?mode=Save_strm&id='+id+'&url='+urllib.quote_plus(url)+'")'),])
			xbmcplugin.addDirectoryItem(handle, purl, listitem, True, total)

def Root():
	if __settings__.getSetting("sort") == '0': s = '2'
	if __settings__.getSetting("sort") == '1': s = '0'
	if __settings__.getSetting("sort") == '2': s = '4'
	
	AddItem("[B][COLOR FF00FF00][ ПОИСК ][/COLOR][/B]", "Search")
	if __settings__.getSetting("HistoryON") == 'true': AddItem("[B][COLOR FF00FF00][ ИСТОРИЯ ][/COLOR][/B]", "History")
	AddItem("[Иностранные фильмы]", "List", '0', httpSiteUrl+'/browse/0/1/0/'+s)
	AddItem("[Русские фильмы]", 	"List", '0', httpSiteUrl+'/browse/0/5/0/'+s)
	AddItem("[Сериалы]", 			"List", '0', httpSiteUrl+'/browse/0/4/0/'+s)
	AddItem("[Мультфильмы]", 		"List", '0', httpSiteUrl+'/browse/0/7/0/'+s)
	AddItem("[Аниме]", 				"List", '0', httpSiteUrl+'/browse/0/10/0/'+s)
	AddItem("[Научно-Популярное]", 	"List", '0', httpSiteUrl+'/browse/0/12/0/'+s)
	AddItem("[Телепередачи]", 		"List", '0', httpSiteUrl+'/browse/0/6/0/'+s)
	AddItem("[Спорт]", 				"List", '0', httpSiteUrl+'/browse/0/13/0/'+s)
	AddItem("[Юмор]", 				"List", '0', httpSiteUrl+'/browse/0/15/0/'+s)
	AddItem("[COLOR 44999999]Donate: http://paypal.me/tdw1980[/COLOR]", "Donate")
	
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

def List(url):
	L=rutor.get_list(url)
	Lid=[]
	dubl=0
	for i in L:
		if '/browse/0/4/0/' in url: i['type']='show'
		Title=get_title(i)#i['fulltitle']#i['title']#+' ('+i['year']+')'
		db_id = rutor.get_db_id(i)
		if db_id not in Lid and filtr(i['fulltitle']):
			#print Title+':'+db_id
			Lid.append(db_id)
			AddItem(Title, 'Torrents', db_id, i['id'], i, len(L)-dubl)
		else:
			dubl+=1
	next=get_next_url(url)
	AddItem('Далее >', 'List', '0', next)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

def Search(t=''):
	if t=='': t=inputbox()
	if t!='':
		if __settings__.getSetting("HistoryON") == 'true': add_history(t)
		Lid=[]
		L=rutor.serch(t)
		for i in L:
			Title=i['title']#+' ('+i['year']+')'
			db_id = rutor.get_db_id(i)
			if db_id not in Lid and filtr(i['fulltitle']):
				Lid.append(db_id)
				AddItem(Title, 'Torrents', db_id, i['id'], i, len(L))
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	

def Torrents(info):
	L=rutor.torrents(info)
	for i in L:
		try:
			ft=i['fulltitle']
			label=get_label(ft)
			seeds=mids(i['seeds'], 6)
			size=mids(i['size'], 8)
			
			Title=label+" "+seeds+" | "+size+" | "+ft
			db_id = rutor.get_db_id(i)
			curl=httpSiteUrl+'/download/'+i['id']
			AddItem(Title, 'Open', db_id, curl, info, len(L))
		except: pass
	
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode()

def get_next_url(url):
	n1=url[url.find('/browse/')+8:]
	#print n1
	n=str(int(n1[:n1.find('/')])+1)
	t=n1[n1.find('/'):]
	h=url[:url.find('/browse/')+8]
	return h+n+t

def get_info(inf):
	db_id = rutor.get_db_id(inf)
	try: 
		info = eval(get_inf_db(db_id))
		try: info['type'] = inf['type']
		except: pass
		return info
	except:
		info = rutor.get_info(inf)
		try: info['type'] = inf['type']
		except: pass
		add_to_db(db_id, repr(info))
		return info

def get_title(i):
	r=i['title']
	e=i['originaltitle']
	if __settings__.getSetting("Title Mode") == '0':
		if r == e: title = r
		else: title = r+' / '+e
	if __settings__.getSetting("Title Mode") == '1': 
		title = r
	if __settings__.getSetting("Title Mode") == '2': 
		try: rat = i['seeds']
		except: rat = '--'
		rat = mids(rat, 6)
		title = '['+rat+'] '+r
	return title

import sqlite3 as db
db_name = os.path.join( addon.getAddonInfo('path'), "info.db" )
c = db.connect(database=db_name)
cu = c.cursor()

def add_to_db(n, item):
		item=item.replace("'","XXCC").replace('"',"XXDD")
		err=0
		tor_id="n"+n
		litm=str(len(item))
		try:
			cu.execute("CREATE TABLE "+tor_id+" (db_item VARCHAR("+litm+"), i VARCHAR(1));")
			c.commit()
		except: 
			err=1
			print "Ошибка БД"+ n
		if err==0:
			cu.execute('INSERT INTO '+tor_id+' (db_item, i) VALUES ("'+item+'", "1");')
			c.commit()

def get_inf_db(n):
		tor_id="n"+n
		cu.execute(str('SELECT db_item FROM '+tor_id+';'))
		c.commit()
		Linfo = cu.fetchall()
		info=Linfo[0][0].replace("XXCC","'").replace("XXDD",'"')
		return info

def rem_inf_db(n):
		tor_id="n"+n
		try:
			cu.execute("DROP TABLE "+tor_id+";")
			c.commit()
		except: pass

def get_label(text):
	text=lower(text)#.lower()
	#print text
	if 'трейлер'  in text: return FC('[ Трейл.]',    'FF999999')
	if ' кпк'     in text: return FC('[   КПК  ]',   'FFF8888F')
	if 'telesyn'  in text: return FC('[    TS    ]', 'FFFF2222')
	if 'telecin'  in text: return FC('[    TS    ]', 'FFFF2222')
	if 'camrip'   in text: return FC('[    TS    ]', 'FFFF2222')
	if ' ts'      in text: return FC('[    TS    ]', 'FFFF2222')
	if 'dvdscr'   in text: return FC('[    Scr   ]', 'FFFF2222')
	if ' 3d'      in text: return FC('[    3D    ]', 'FC45FF45')
	if '720'      in text: return FC('[  720p  ]',   'FBFFFF55')
	if '1080'     in text: return FC('[ 1080p ]',    'FAFF9535')
	if '2160'     in text: return FC('[ 2160p ]',    'FAF990FF')
	if 'blu-ray'  in text: return FC('[  BRay  ]',   'FF5555FF')
	if 'bdremux'  in text: return FC('[    BD    ]', 'FF5555FF')
	if ' 4k'      in text: return FC('[    4K    ]', 'FF5555FF')
	if 'bdrip'    in text: return FC('[ BDRip ]',    'FE98FF98')
	if 'drip'     in text: return FC('[ BDRip ]',    'FE98FF98')
	if 'hdrip'    in text: return FC('[ HDRip ]',    'FE98FF98')
	if 'webrip'   in text: return FC('[  WEB   ]',   'FEFF88FF')
	if 'WEB'      in text: return FC('[  WEB   ]',   'FEFF88FF')
	if 'web-dl'   in text: return FC('[  WEB   ]',   'FEFF88FF')
	if 'hdtv'     in text: return FC('[ HDTV ]',     'FEFFFF88')
	if 'tvrip'    in text: return FC('[    TV    ]', 'FEFFFF88')
	if 'satrip'   in text: return FC('[    TV    ]', 'FEFFFF88')
	if 'dvb '     in text: return FC('[    TV    ]', 'FEFFFF88')
	if 'dvdrip'   in text: return FC('[DVDRip]',     'FE88FFFF')
	if 'dvd5'     in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'xdvd'     in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'dvd-5'    in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'dvd-9'    in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'dvd9'     in text: return FC('[  DVD   ]',   'FE88FFFF')
	return FC('[   ????  ]', 'FFFFFFFF')

def FC(s, color="FFFFFF00"):
	s="[COLOR "+color+"]"+s+"[/COLOR]"
	return s

def debug(s):
	fl = open(os.path.join( ru(LstDir),"test.txt"), "w")
	fl.write(s)
	fl.close()





def US(text):
	Search(text)

def filtr(title):
	f=True
	Tresh = ["Repack"," PC ","XBOX","RePack","FB2","TXT","DOC"," MP3"," JPG"," PNG"," SCR"]
	for i in Tresh:
		if i in title: f=False
	
	if __settings__.getSetting("Hide Scr") == 'true':
		Scr = ["CAMRip", ") TS", ") TC", ") ТС", "CamRip", " DVDScr"]
		for i in Scr:
			if i in title: f=False
	
	if __settings__.getSetting("EnabledFiltr") == 'true':
		Flt = __settings__.getSetting("Filtr").split(',')
		for i in Flt:
			if i.strip() in title: f=False
	
	return f

def SetViewMode():
	n = int(__settings__.getSetting("ListView"))
	if n>0:
		xbmc.executebuiltin("Container.SetViewMode(0)")
		for i in range(1,n):
			xbmc.executebuiltin("Container.NextViewMode")

def History():
	try:L=eval(__settings__.getSetting("History"))
	except: L=[]
	for i in L:
		AddItem(i, 'HSearch', '0', i)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

def add_history(t):
	try:L=eval(__settings__.getSetting("History"))
	except: L=[]
	if t not in L:
		NL=[]
		NL.append(t)
		NL.extend(L[:15])
		__settings__.setSetting("History", repr(NL))

try:
	from kodidb import*
except: pass

def chek_in():
	try:
		argv2=sys.argv[2]
		
		if xbmc.getInfoLabel('ListItem.FileName') == '': 
			if '.strm' in argv2: 
				FileName = argv2[argv2.find('title=')+6:argv2.find('.strm')+5].replace('+',' ')
			else: 
				id = argv2[argv2.find('&id=')+4:]
				info = eval(get_inf_db(id))
				FileName = info['originaltitle'].replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"")+" ("+str(info['year'])+")"+".strm"
		else:   FileName = xbmc.getInfoLabel('ListItem.FileName')
		
		if xbmc.getInfoLabel('ListItem.Path') == '':     Path = __settings__.getSetting("SaveDirectory")
		else:                                            Path = xbmc.getInfoLabel('ListItem.Path')
		try: 
			FileName = FileName.decode('utf-8')
			Path = Path.decode('utf-8')
		except: pass
		k_db = KodiDB(FileName, Path, sys.argv[0] + sys.argv[2])
		k_db.PlayerPreProccessing()
		return k_db
	except: 
		return None


def chek_out(k_db):
	k_db.PlayerPostProccessing()
	xbmc.sleep(300)
	xbmc.executebuiltin('Container.Refresh')
	xbmc.sleep(200)
	if not xbmc.getCondVisibility('Library.IsScanningVideo'):
		xbmc.executebuiltin('UpdateLibrary("video", "", "false")')



params = get_params()
mode     = ''
url      = ''
title    = ''
ref      = ''
img      = ''
id       = '0'
sort     = '2'
text     = '0'
info  = {}

try:	mode  = urllib.unquote_plus(params["mode"])
except:	pass
try:	url  = urllib.unquote_plus(params["url"])
except:	pass
try:	title  = urllib.unquote_plus(params["title"])
except:	pass
try:	img  = urllib.unquote_plus(params["img"])
except:	pass
try:	num  = int(urllib.unquote_plus(params["num"]))
except:	pass
try:	id  = urllib.unquote_plus(params["id"])
except:	pass
try:	text  = urllib.unquote_plus(params["text"])
except:	pass
try:	info  = eval(urllib.unquote_plus(params["info"]))
except:	pass


if mode == '': 			Root()
if mode == 'List': 		List(url)
if mode == 'Search':	Search()
if mode == 'HSearch':	Search(url)
if mode == 'History':	History()
if mode == 'Torrents':	Torrents(info)
if mode == 'Open':		Open(url)
if mode == "Play":		play(url, num)
if mode == "Save_strm":	save_strm (url, 0, id)
if mode == 'US':		US(text)
if mode == "Play2":
	progressBar = xbmcgui.DialogProgress()
	progressBar.create('Rutor', 'Запуск сохраненного файла')
	cancel=False
	for i in range (0,5):
		progressBar.update(20*i, '', '[B]Нажмите "Отмена" для выбора качества[/B]')
		xbmc.sleep(600)
		if progressBar.iscanceled():
					progressBar.update(0)
					cancel=True
					break
	progressBar.close()
	if cancel:
		tid=url[url.rfind('/')+1:]
		inf = repr({'id':tid})
		xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.RuTor/?mode=Torrents&info='+inf+'", return)')
		xbmc.executebuiltin("Container.Refresh()")
	else: 
		k_db=chek_in()
		play(url, num, id)
		if k_db != None: chek_out(k_db)


c.close()
































