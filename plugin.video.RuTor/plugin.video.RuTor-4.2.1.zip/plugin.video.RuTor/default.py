#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys, os, time
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import rutor
import ssl

if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2

handle = int(sys.argv[1])
PLUGIN_NAME   = 'RuTor'

addon = xbmcaddon.Addon(id='plugin.video.RuTor')
__settings__ = xbmcaddon.Addon(id='plugin.video.RuTor')

icon = os.path.join(addon.getAddonInfo('path'), 'icon.png')
thumb = os.path.join( addon.getAddonInfo('path'), "icon.png" )
fanart = os.path.join( addon.getAddonInfo('path'), "fanart.jpg" )
LstDir = os.path.join( addon.getAddonInfo('path'), "playlists" )

siteUrl = __settings__.getSetting('Url')
if siteUrl == "": siteUrl = 'rutor.is'
httpSiteUrl = 'http://' + siteUrl

xbmcplugin.setContent(int(sys.argv[1]), 'movies')

# - ====================================== antizapret ====================================================
try: proxy_id = int(__settings__.getSetting("proxy_id"))
except: proxy_id = 0

if __settings__.getSetting("antiblock") == "1":
	prx='http://proxy-nossl.antizapret.prostovpn.org:29976'
	proxy_support = urllib2.ProxyHandler({"http" : prx, "https" : prx})
	opener = urllib2.build_opener(proxy_support)
	urllib2.install_opener(opener)

if __settings__.getSetting("antiblock") == "2":
	prx=__settings__.getSetting('proxy')
	if 'http' not in prx: prx='http://'+prx
	proxy_support = urllib2.ProxyHandler({"http" : prx, "https": prx})
	opener = urllib2.build_opener(proxy_support)
	urllib2.install_opener(opener)

if __settings__.getSetting("antiblock") == "3":
	try:
		import xbmcaddon
		tam_settings = xbmcaddon.Addon(id='plugin.video.tam')
		tam_port = int(tam_settings.getSetting("serv_port"))
	except:
		tam_port = 8095
	prx='http://127.0.0.1:'+str(tam_port)
	proxy_support = urllib2.ProxyHandler({"http" : prx, "https": prx})
	opener = urllib2.build_opener(proxy_support)
	urllib2.install_opener(opener)

if __settings__.getSetting("antiblock") == "4":
	prx='http://193.124.130.96:8095'
	proxy_support = urllib2.ProxyHandler({"http" : prx, "https": prx})
	opener = urllib2.build_opener(proxy_support)
	urllib2.install_opener(opener)

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es,s)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):
	try: r = xbmc.translatePath(x)
	except: r = xbmcvfs.translatePath(x)
	return r

def mid(s, n):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.center(n)
	try:s=s.encode('utf-8')
	except: pass
	return s

def mids(s, n):
	l="                                              "
	s=l[:n-len(s)]+s+l[:n-len(s)]
	return s

def lower(s):
	if sys.version_info.major > 2: return s.lower()
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.lower().encode('utf-8')
	return s

def info_to_utf(inf):
	if sys.version_info.major > 2: 
		info = eval(inf.replace("\\x", "\\\\x").replace("\\r", "\\\\r").replace("\\n", "\\\\n").replace("\\\\xa0", " "))
		for key in info.keys():
			try: info[key]=eval("b'"+info[key]+"'").decode()
			except: pass
	else:
		info = eval(inf)
	return info

def construct_request(params):
	return '%s?%s' % (sys.argv[0], urllib.urlencode(params))

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def GET(target, referer='', post=None):
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36 OPR/52.0.2871.64')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except:
		showMessage('HTTP ERROR', e, 5000)
		return ''

def GET2(url, Referer = '', XML = False):
	try:
		opener = urllib2.build_opener() 
		urllib2.install_opener(opener)
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
		req.add_header('Accept', '*/*')
		req.add_header('Accept-Language', 'ru,en;q=0.9')
		req.add_header('Referer', Referer)
		if XML: req.add_header('X-Requested-With', 'XMLHttpRequest')
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
	except:
		#print 'ERR: недоступно'
		return ''

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def showMessage(heading, message, times = 50000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, thumb))

def inputbox():
	skbd = xbmc.Keyboard()
	skbd.setHeading('Поиск:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return ""


def AddItem(Title = "", mode = "", id='0', url='', inf={}, total=100):
			if id !='0':
				if mode == "Open": 
					info=inf
				else:
					try:    info=get_info(inf)
					except: info={}
				try:    cover = info["cover"]
				except: cover = icon
				try:    fanart = info["fanart"]
				except: fanart = cover
				try:    type=info["type"]
				except: type=''
			else:
				cover = icon
				fanart = ''
				info={'id':id}
				type=''
			#print cover
			#print (info)
			try: listitem = xbmcgui.ListItem(Title, iconImage=cover, thumbnailImage=cover)
			except: listitem = xbmcgui.ListItem(Title)
			if mode!="Open":listitem.setInfo(type = "Video", infoLabels = info)
			try: listitem.setArt({ 'poster': cover, 'fanart' : fanart, 'thumb': cover, 'icon': cover})
			except: pass
			try:listitem.setProperty('fanart_image', fanart)
			except: pass
			purl = sys.argv[0] + '?mode='+mode+'&id='+id+'&info='+quote(repr(info))
			if url !="": purl = purl +'&url='+quote(url)
			
			
			if mode=="Open":
				#if __settings__.getSetting("Engine")=="0": 
				#if __settings__.getSetting("antiblock") != "0": url=convert(url)
				try:pu='plugin://plugin.video.RuTor/?mode=HSearch&url='+info['title']
				except:pu=''
				purl='plugin://plugin.video.tam/?mode=open&url='+quote(url)+ '&info='+quote(repr(info))+ '&purl='+quote(pu)
				
				try:type=info["type"]
				except:type=''
				
				try:
					if type != '': listitem.addContextMenuItems([('[B]Сохранить сериал[/B]', 'Container.Update("plugin://plugin.video.tam/?mode=save_series&url='+quote(url)+'&purl='+quote(pu)+'&name='+quote(info['originaltitle'])+ '&info=' + quote(repr(info))+'")'),('[B]Отслеживать сериал[/B]', 'Container.Update("plugin://plugin.video.torrent.checker/?mode=add&url='+quote(url)+'&name='+quote(info['originaltitle'])+'")')])
					else: listitem.addContextMenuItems([('[B]Сохранить фильм(STRM)[/B]', 'Container.Update("plugin://plugin.video.tam/?mode=save_movie&purl='+quote(pu)+'&url='+quote(url)+ '&info=' + quote(repr(info))+'")'),('[B]Настройки ТАМ[/B]', 'Container.Update("plugin://plugin.video.tam/?mode=settings")')])
				except:
					pass
					'''
					else:
						if type != '': listitem.addContextMenuItems([('[B]Сохранить сериал[/B]', 'Container.Update("plugin://plugin.video.torrent.checker/?mode=save_episodes_api&url='+quote(url)+'&name='+quote(info['originaltitle'])+ '&info=' + quote(repr(info))+'")'),('[B]Отслеживать сериал[/B]', 'Container.Update("plugin://plugin.video.torrent.checker/?mode=add&url='+quote(url)+'&name='+quote(info['originaltitle'])+'")')])
						else: 
							if __settings__.getSetting("magnet")=='true': url=inf['magnet']
							listitem.addContextMenuItems([('[B]Сохранить фильм(STRM)[/B]', 'Container.Update("plugin://plugin.video.RuTor/?mode=Save_strm&id='+id+'&url='+quote(url)+'")'),])
					'''
			if mode=="Torrents":
				listitem.addContextMenuItems([('[B]Обновить описание[/B]', 'Container.Update("plugin://plugin.video.RuTor/?mode=UpdateInfo&id='+id+'&url='+quote(url)+'")'),])
			xbmcplugin.addDirectoryItem(handle, purl, listitem, True, total)

def Root():
	if __settings__.getSetting("sort") == '0': s = '2'
	if __settings__.getSetting("sort") == '1': s = '0'
	if __settings__.getSetting("sort") == '2': s = '4'
	
	AddItem("[B][COLOR FF00FF00][ ПОИСК ][/COLOR][/B]", "Search")
	if __settings__.getSetting("HistoryON") == 'true': AddItem("[B][COLOR FF00FF00][ ИСТОРИЯ ][/COLOR][/B]", "History")
	AddItem("Иностранные фильмы", 	"List", '0', httpSiteUrl+'/browse/0/1/0/'+s)
	AddItem("Русские фильмы", 		"List", '0', httpSiteUrl+'/browse/0/5/0/'+s)
	AddItem("Иностранные сериалы",	"List", '0', httpSiteUrl+'/browse/0/4/0/'+s)
	AddItem("Русские сериалы", 		"List", '0', httpSiteUrl+'/browse/0/16/0/'+s)
	AddItem("Мультфильмы", 			"List", '0', httpSiteUrl+'/browse/0/7/0/'+s)
	AddItem("Аниме", 				"List", '0', httpSiteUrl+'/browse/0/10/0/'+s)
	AddItem("Научно-Популярное", 	"List", '0', httpSiteUrl+'/browse/0/12/0/'+s)
	AddItem("Телепередачи", 		"List", '0', httpSiteUrl+'/browse/0/6/0/'+s)
	AddItem("Спорт", 				"List", '0', httpSiteUrl+'/browse/0/13/0/'+s)
	AddItem("Юмор", 				"List", '0', httpSiteUrl+'/browse/0/15/0/'+s)
	#AddItem("[COLOR 44999999]Donate: http://paypal.me/tdw1980[/COLOR]", "Donate")
	
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

def List(url, pb=True):
	if pb:
		if __settings__.getSetting("Progress") == 'false': pb=False
	
	if pb:
		pDialog = xbmcgui.DialogProgressBG()
		try: pDialog.create('Загрузка:', '')
		except: pass
	try:
		L=rutor.get_list(url)
		Lid=[]
		dubl=0
		for i in L:
			if pb:
				try:pDialog.update(int(len(Lid)+dubl/len(L)*100), 'Загрузка:', i['title'])
				except: pass
			if '/browse/0/4/0/' in url: i['type']='show'
			Title=get_title(i)#i['fulltitle']#i['title']#+' ('+i['year']+')'
			db_id = rutor.get_db_id(i)
			if db_id not in Lid and filtr(i['fulltitle']):
				#print (Title+':'+db_id)
				Lid.append(db_id)
				AddItem(Title, 'Torrents', db_id, i['id'], i, len(L)-dubl)
			else:
				dubl+=1
		next=get_next_url(url)
		AddItem('Далее >', 'List', '0', next)
	except: pass
	try:pDialog.close()
	except: pass
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

def Check(n=0):
	try: n=int(__settings__.getSetting("ch_n"))
	except: n=0
	if n>9: n=0
	if __settings__.getSetting("sort") == '0': s = '2'
	if __settings__.getSetting("sort") == '1': s = '0'
	if __settings__.getSetting("sort") == '2': s = '4'
	CL=['1','4','5','6','7','10','12','13','15','16']
	c=CL[n]
	url=httpSiteUrl+'/browse/0/'+c+'/0/'+s
	__settings__.setSetting("ch_n", str(n+1))
	try:
		L=rutor.get_list(url)
		Lid=[]
		for i in L:
			if '/browse/0/4/0/' in url: i['type']='show'
			db_id = rutor.get_db_id(i)
			if db_id not in Lid and filtr(i['fulltitle']):
				Lid.append(db_id)
				try:    info=get_info(i)
				except: info={}
	except: pass

def Search(t=''):
	if t=='': t=inputbox()
	if t!='':
		if __settings__.getSetting("HistoryON") == 'true': add_history(t)
		Lid=[]
		L=rutor.serch(t)
		for i in L:
			Title=i['title']#+' ('+i['year']+')'
			db_id = rutor.get_db_id(i)
			if db_id not in Lid and filtr(i['fulltitle']):
				Lid.append(db_id)
				AddItem(Title, 'Torrents', db_id, i['id'], i, len(L))
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

def Torrents(info):
	L=rutor.torrents(info)
	for i in L:
		try:
			ft=i['fulltitle']
			label=get_label(ft)
			seeds=mids(i['seeds'], 6)
			size=mids(i['size'], 8)
			
			Title=label+" "+seeds+" | "+size+" | "+ft
			db_id = rutor.get_db_id(i)
			#print (Title+':'+db_id)
			curl=httpSiteUrl+'/download/'+i['id']
			info['magnet']=i['magnet']
			AddItem(Title, 'Open', db_id, curl, info, len(L))
		except: pass
	
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode()

def get_next_url(url):
	n1=url[url.find('/browse/')+8:]
	##print n1
	n=str(int(n1[:n1.find('/')])+1)
	t=n1[n1.find('/'):]
	h=url[:url.find('/browse/')+8]
	return h+n+t

def get_info(inf):
	db_id = rutor.get_db_id(inf)
	
	try: 
		info = info_to_utf(get_inf_db(db_id))
		try: info['type'] = inf['type']
		except: pass
		try: info['id'] = inf['id']
		except: pass
		return info
	except:
		info = rutor.get_info(inf)
		try: info['type'] = inf['type']
		except: pass
		add_to_db(db_id, repr(info))
		return info


def get_title(i):
	r=i['title']
	e=i['originaltitle']
	if __settings__.getSetting("Title Mode") == '0':
		if r == e: title = r
		else: title = r+' / '+e
	if __settings__.getSetting("Title Mode") == '1': 
		title = r
	if __settings__.getSetting("Title Mode") == '3': 
		title = r +" [COLOR 33FFFFFF]("+str(i['year'])+")[/COLOR]"
	if __settings__.getSetting("Title Mode") == '2': 
		try: rat = i['seeds']
		except: rat = '--'
		rat = mids(rat, 6)
		title = '['+rat+'] '+r
	return title

import sqlite3 as db
db_name = os.path.join( addon.getAddonInfo('path'), "info.db" )
c = db.connect(database=db_name)
cu = c.cursor()

def add_to_db(n, item):
		item=item.replace("'","XXCC").replace('"',"XXDD")
		err=0
		tor_id="n"+n
		litm=str(len(item))
		try:
			cu.execute("CREATE TABLE "+tor_id+" (db_item VARCHAR("+litm+"), i VARCHAR(1));")
			c.commit()
		except: 
			err=1
		if err==0:
			cu.execute('INSERT INTO '+tor_id+' (db_item, i) VALUES ("'+item+'", "1");')
			c.commit()

def get_inf_db(n):
		tor_id="n"+n
		cu.execute(str('SELECT db_item FROM '+tor_id+';'))
		c.commit()
		Linfo = cu.fetchall()
		info=Linfo[0][0].replace("XXCC","'").replace("XXDD",'"')
		return info

def rem_inf_db(n):
		tor_id="n"+n
		try:
			cu.execute("DROP TABLE "+tor_id+";")
			c.commit()
		except: pass

def update_info(id):
	rem_inf_db(id)
	xbmc.sleep(300)
	xbmc.executebuiltin('Container.Refresh')

def get_label(text):
	text=lower(text)#.lower()
	#print text
	if 'трейлер'  in text: return FC('[ Трейл.]',    'FF999999')
	if ' кпк'     in text: return FC('[   КПК  ]',   'FFF8888F')
	if 'telesyn'  in text: return FC('[    TS    ]', 'FFFF2222')
	if 'telecin'  in text: return FC('[    TS    ]', 'FFFF2222')
	if 'camrip'   in text: return FC('[    TS    ]', 'FFFF2222')
	if ' ts'      in text: return FC('[    TS    ]', 'FFFF2222')
	if 'dvdscr'   in text: return FC('[    Scr   ]', 'FFFF2222')
	if ' 3d'      in text: return FC('[    3D    ]', 'FC45FF45')
	if '720'      in text: return FC('[  720p  ]',   'FBFFFF55')
	if '1080'     in text: return FC('[ 1080p ]',    'FAFF9535')
	if '2160'     in text: return FC('[ 2160p ]',    'FAF990FF')
	if 'blu-ray'  in text: return FC('[  BRay  ]',   'FF5555FF')
	if 'bdremux'  in text: return FC('[    BD    ]', 'FF5555FF')
	if ' 4k'      in text: return FC('[    4K    ]', 'FF5555FF')
	if 'bdrip'    in text: return FC('[ BDRip ]',    'FE98FF98')
	if 'drip'     in text: return FC('[ BDRip ]',    'FE98FF98')
	if 'hdrip'    in text: return FC('[ HDRip ]',    'FE98FF98')
	if 'webrip'   in text: return FC('[  WEB   ]',   'FEFF88FF')
	if 'WEB'      in text: return FC('[  WEB   ]',   'FEFF88FF')
	if 'web-dl'   in text: return FC('[  WEB   ]',   'FEFF88FF')
	if 'hdtv'     in text: return FC('[ HDTV ]',     'FEFFFF88')
	if 'tvrip'    in text: return FC('[    TV    ]', 'FEFFFF88')
	if 'satrip'   in text: return FC('[    TV    ]', 'FEFFFF88')
	if 'dvb '     in text: return FC('[    TV    ]', 'FEFFFF88')
	if 'dvdrip'   in text: return FC('[DVDRip]',     'FE88FFFF')
	if 'dvd5'     in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'xdvd'     in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'dvd-5'    in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'dvd-9'    in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'dvd9'     in text: return FC('[  DVD   ]',   'FE88FFFF')
	return FC('[   ????  ]', 'FFFFFFFF')

def FC(s, color="FFFFFF00"):
	s="[COLOR "+color+"]"+s+"[/COLOR]"
	return s

def debug(s):
	fl = open(os.path.join( ru(LstDir),"test.txt"), "w")
	fl.write(s)
	fl.close()

def US(text):
	Search(text)

def filtr(title):
	f=True
	Tresh = ["Repack"," PC ","XBOX","RePack","FB2","TXT","DOC"," MP3"," JPG"," PNG"," SCR"]
	for i in Tresh:
		if i in title: f=False
	
	if __settings__.getSetting("Hide Scr") == 'true':
		Scr = ["CAMRip", ") TS", ") TC", ") ТС", "CamRip", " DVDScr"]
		for i in Scr:
			if i in title: f=False
	
	if __settings__.getSetting("EnabledFiltr") == 'true':
		Flt = __settings__.getSetting("Filtr").split(',')
		for i in Flt:
			if i.strip() in title: f=False
	
	return f

def SetViewMode():
	n = int(__settings__.getSetting("ListView"))
	if n>0:
		xbmc.executebuiltin("Container.SetViewMode(0)")
		for i in range(1,n):
			xbmc.executebuiltin("Container.NextViewMode")

def History():
	try:L=eval(__settings__.getSetting("History"))
	except: L=[]
	for i in L:
		AddItem(i, 'HSearch', '0', i)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

def add_history(t):
	try:L=eval(__settings__.getSetting("History"))
	except: L=[]
	if t not in L:
		NL=[]
		NL.append(t)
		NL.extend(L[:15])
		__settings__.setSetting("History", repr(NL))


params = get_params()
mode     = ''
url      = ''
title    = ''
ref      = ''
img      = ''
id       = '0'
sort     = '2'
text     = '0'
num      = 0
info  = {}

try:	mode  = unquote(params["mode"])
except:	pass
try:	url  = unquote(params["url"])
except:	pass
try:	title  = unquote(params["title"])
except:	pass
try:	img  = unquote(params["img"])
except:	pass
try:	num  = int(unquote(params["num"]))
except:	pass
try:	id  = unquote(params["id"])
except:	pass
try:	text  = unquote(params["text"])
except:	pass
try:	info  = eval(unquote(params["info"]))
except:	pass


if mode == '': 			Root()
if mode == 'List': 		List(url)
if mode == 'Search':	Search()
if mode == 'HSearch':	Search(url)
if mode == 'History':	History()
if mode == 'Torrents':	Torrents(info)
if mode == 'Open':		Open(url)
if mode == "Play":		play(url, num)
if mode == "Save_strm":	save_strm (url, 0, id)
if mode == "UpdateInfo":update_info(id)
if mode == "GetInfo":	get_info(info)
if mode == 'US':		US(text)
if mode == "Check": Check()
c.close()
































