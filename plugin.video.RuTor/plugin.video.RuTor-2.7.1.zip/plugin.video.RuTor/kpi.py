# -*- coding: utf-8 -*-
import urllib2

def GET(target, referer='', post=None):
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		print e

def get_path(id):
	pref='0'*(6-len(id))
	id=pref+id
	if len(id[:-4])==3:s1=chr(int(id[:-5])+87)+id[-5:-4]
	else:s1=id[:-4]
	s=[s1,id[-4:-2],id[-2:]]
	return s

def info(id):
	try:
		c=get_path(id)
		url='http://td-soft.narod.ru/kinodb/'+c[0]+'/'+c[1]+'/'+c[2]+'.nfo'
		info=eval(GET(url))
		return info
	except:
		return {}