#!/usr/bin/python
# -*- coding: utf-8 -*-
# - ====================================== antizapret ====================================================
#import xbmc, xbmcaddon
import time, cookielib, urllib, urllib2, os, sys
#__settings__ = xbmcaddon.Addon(id='plugin.video.KinoPoisk.ru')
#sid_file = os.path.join(xbmc.translatePath('special://temp/'), 'vpn.sid')
#cj = cookielib.FileCookieJar(sid_file) 
#hr  = urllib2.HTTPCookieProcessor(cj)

proxy_list=[
	'http://www.pitchoo.net/zob_/index.php?q=', #France: 
	'http://thely.fr/proxy/?q=',                #France: 
	'http://xawos.ovh/index.php?q=',            #France: 
	'http://prx.afkcz.eu/prx/index.php?q=',     #чехия: 
	'https://derzeko.de/Proxy/index.php?q=',    #германия: 
	'https://dev.chamoun.fr/proxy/index.php?q=', #France: 
	'http://www.proxy.zee18.info/index.php?q=', #Англия
]

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es,s)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def GET_HTML(url):
	req = urllib2.Request(url)
	#req.add_header('Referer', referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


def convert(url, id=0):
	import base64
	sign=base64.b64encode(url)
	redir=proxy_list[id]+urllib.quote_plus(sign)
	return redir

def decoder(hp, id=0):
	import base64
	L=mfindal(hp, proxy_list[id], '"')
	for i in L:
		try:
			#print i
			url=base64.b64decode(i.replace(proxy_list[id],'').replace('%3D','='))
			#print url
			hp=hp.replace(i, url)
		except:
			pass
			print i
	#print hp
	return hp
	
def GET(url):
	url2=convert(url)
	print url2
	hp=GET_HTML(url2)
	return decoder(hp)

#print GET('http://rutor.is')