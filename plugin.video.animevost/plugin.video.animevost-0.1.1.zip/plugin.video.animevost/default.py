# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, urllib, sys, urllib2

PLUGIN_NAME   = 'Animevost.org'
handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.animevost')
__settings__ = xbmcaddon.Addon(id='plugin.video.animevost')

Pdir = addon.getAddonInfo('path')
icon = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'icon.png'))
xbmcplugin.setContent(int(sys.argv[1]), 'movies')


zhanr={
	"Боевые искусства":"http://animevost.org/zhanr/boyevyye-iskusstva/",
	"Война":"http://animevost.org/zhanr/voyna/",
	"Драма":"http://animevost.org/zhanr/drama/",
	"Детектив":"http://animevost.org/zhanr/detektiv/",
	"История":"http://animevost.org/zhanr/istoriya/",
	"Комедия":"http://animevost.org/zhanr/komediya/",
	"Меха":"http://animevost.org/zhanr/mekha/",
	"Мистика":"http://animevost.org/zhanr/mistika/",
	"Махо-сёдзё":"http://animevost.org/zhanr/makho-sedze/",
	"Музыкальный":"http://animevost.org/zhanr/muzykalnyy/",
	"Повседневность":"http://animevost.org/zhanr/povsednevnost/",
	"Приключения":"http://animevost.org/zhanr/priklyucheniya/",
	"Пародия":"http://animevost.org/zhanr/parodiya/",
	"Романтика":"http://animevost.org/zhanr/romantika/",
	"Сёнэн":"http://animevost.org/zhanr/senen/",
	"Сёдзё":"http://animevost.org/zhanr/sedze/",
	"Спорт":"http://animevost.org/zhanr/sport/",
	"Сказка":"http://animevost.org/zhanr/skazka/",
	"Сёдзё-ай":"http://animevost.org/zhanr/sedze-ay/",
	"Сёнэн-ай":"http://animevost.org/zhanr/senen-ay/",
	"Самураи":"http://animevost.org/zhanr/samurai/",
	"Триллер":"http://animevost.org/zhanr/triller/",
	"Ужасы":"http://animevost.org/zhanr/uzhasy/",
	"Фантастика":"http://animevost.org/zhanr/fantastika/",
	"Фэнтези":"http://animevost.org/zhanr/fentezi/",
	"Школа":"http://animevost.org/zhanr/shkola/",
	"Этти":"http://animevost.org/zhanr/etti/",
}

tip={
	"ТВ":"http://animevost.org/tip/tv/",
	"ТВ-спэшл":"http://animevost.org/tip/tv-speshl/",
	"OVA":"http://animevost.org/tip/ova/",
	"ONA":"http://animevost.org/tip/ona/",
	"Полнометражный фильм":"http://animevost.org/tip/polnometrazhnyy-film/",
	"Короткометражный фильм":"http://animevost.org/tip/korotnometrazhnyy-film/",
}

god={
	"1971":"http://animevost.org/god/1971/",
	"1977":"http://animevost.org/god/1977/",
	"1980":"http://animevost.org/god/1980/",
	"1984":"http://animevost.org/god/1984/",
	"1991":"http://animevost.org/god/1991/",
	"1992":"http://animevost.org/god/1992/",
	"1993":"http://animevost.org/god/1993/",
	"1994":"http://animevost.org/god/1994/",
	"1995":"http://animevost.org/god/1995/",
	"1996":"http://animevost.org/god/1996/",
	"1997":"http://animevost.org/god/1997/",
	"1998":"http://animevost.org/god/1998/",
	"1999":"http://animevost.org/god/1999/",
	"2000":"http://animevost.org/god/2000/",
	"2001":"http://animevost.org/god/2001/",
	"2002":"http://animevost.org/god/2002/",
	"2003":"http://animevost.org/god/2003/",
	"2004":"http://animevost.org/god/2004/",
	"2005":"http://animevost.org/god/2005/",
	"2006":"http://animevost.org/god/2006/",
	"2007":"http://animevost.org/god/2007/",
	"2008":"http://animevost.org/god/2008/",
	"2009":"http://animevost.org/god/2009/",
	"2010":"http://animevost.org/god/2010/",
	"2011":"http://animevost.org/god/2011/",
	"2012":"http://animevost.org/god/2012/",
	"2013":"http://animevost.org/god/2013/",
	"2014":"http://animevost.org/god/2014/",
	"2015":"http://animevost.org/god/2015/",
	"2016":"http://animevost.org/god/2016/",
	"2017":"http://animevost.org/god/2017/",
}


def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)
def rt(x):#('&#39;','’'), ('&#145;','‘')
	L=[('&quot;','"'),('&amp;',"&"),('&#133;','…'),('&#38;','&'),('&#34;','"'), ('&#39;','"'), ('&#145;','"'), ('&#146;','"'), ('&#147;','“'), ('&#148;','”'), ('&#149;','•'), ('&#150;','–'), ('&#151;','—'), ('&#152;','?'), ('&#153;','™'), ('&#154;','s'), ('&#155;','›'), ('&#156;','?'), ('&#157;',''), ('&#158;','z'), ('&#159;','Y'), ('&#160;',''), ('&#161;','?'), ('&#162;','?'), ('&#163;','?'), ('&#164;','¤'), ('&#165;','?'), ('&#166;','¦'), ('&#167;','§'), ('&#168;','?'), ('&#169;','©'), ('&#170;','?'), ('&#171;','«'), ('&#172;','¬'), ('&#173;',''), ('&#174;','®'), ('&#175;','?'), ('&#176;','°'), ('&#177;','±'), ('&#178;','?'), ('&#179;','?'), ('&#180;','?'), ('&#181;','µ'), ('&#182;','¶'), ('&#183;','·'), ('&#184;','?'), ('&#185;','?'), ('&#186;','?'), ('&#187;','»'), ('&#188;','?'), ('&#189;','?'), ('&#190;','?'), ('&#191;','?'), ('&#192;','A'), ('&#193;','A'), ('&#194;','A'), ('&#195;','A'), ('&#196;','A'), ('&#197;','A'), ('&#198;','?'), ('&#199;','C'), ('&#200;','E'), ('&#201;','E'), ('&#202;','E'), ('&#203;','E'), ('&#204;','I'), ('&#205;','I'), ('&#206;','I'), ('&#207;','I'), ('&#208;','?'), ('&#209;','N'), ('&#210;','O'), ('&#211;','O'), ('&#212;','O'), ('&#213;','O'), ('&#214;','O'), ('&#215;','?'), ('&#216;','O'), ('&#217;','U'), ('&#218;','U'), ('&#219;','U'), ('&#220;','U'), ('&#221;','Y'), ('&#222;','?'), ('&#223;','?'), ('&#224;','a'), ('&#225;','a'), ('&#226;','a'), ('&#227;','a'), ('&#228;','a'), ('&#229;','a'), ('&#230;','?'), ('&#231;','c'), ('&#232;','e'), ('&#233;','e'), ('&#234;','e'), ('&#235;','e'), ('&#236;','i'), ('&#237;','i'), ('&#238;','i'), ('&#239;','i'), ('&#240;','?'), ('&#241;','n'), ('&#242;','o'), ('&#243;','o'), ('&#244;','o'), ('&#245;','o'), ('&#246;','o'), ('&#247;','?'), ('&#248;','o'), ('&#249;','u'), ('&#250;','u'), ('&#251;','u'), ('&#252;','u'), ('&#253;','y'), ('&#254;','?'), ('&#255;','y'), ('&laquo;','"'), ('&raquo;','"'), ('&nbsp;',' ')]
	for i in L:
		x=x.replace(i[0], i[1])
	return x

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		#sn=http[s:]
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def inputbox(t=''):
	skbd = xbmc.Keyboard(t, 'Название:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return t


def play(url, id=0):
	print url
	engine=__settings__.getSetting("Engine")
	if engine=="0":
		play_ace(url, id)
		
	if engine=="1":
		item = xbmcgui.ListItem()#path=url
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
		tthp.play(url, handle, id, __settings__.getSetting("DownloadDirectory"))
		
	if engine=="2":
		purl ="plugin://plugin.video.yatp/?action=play&torrent="+ urllib.quote_plus(url)+"&file_index="+str(id)
		item = xbmcgui.ListItem()#path=purl
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
		xbmc.Player().play(purl)


def add_item (name, mode="", path = Pdir, ind="0", cover=icon, funart=None, info={}):
	#print name
	#print path
	if   path.find("720p")>0: qual="[COLOR FFA900EF][ 720p ] [/COLOR]"
	elif path.find("480p")>0: qual="[COLOR FFFF0090][ 480p ] [/COLOR]"
	elif path.find("400p")>0: qual="[COLOR FF70F020][ 400p ] [/COLOR]"
	elif path.find("1080p")>0:qual="[COLOR FF50FF50][1080p] [/COLOR]"
	else: qual=''#"[ ???? ] "
	if funart==None: funart=cover
	if cover==None:	listitem = xbmcgui.ListItem(qual+"[B]"+name+"[/B]")
	else:			listitem = xbmcgui.ListItem(qual+"[B]"+name+"[/B]", iconImage=cover)
	listitem.setInfo(type = "Video", infoLabels = info)
	listitem.setProperty('fanart_image', funart)
	uri = sys.argv[0] + '?mode='+mode
	uri += '&url='  + urllib.quote_plus(path.encode('utf-8'))
	uri += '&name='  + urllib.quote_plus(xt(name))
	uri += '&ind='  + urllib.quote_plus(ind)
	if cover!=None:uri += '&cover='  + urllib.quote_plus(cover)
	if funart!=None and funart!="":uri += '&funart='  + urllib.quote_plus(funart)
	
	if mode=="play": 
		fld=False
		uri=path
	else: fld=True

	xbmcplugin.addDirectoryItem(handle, uri, listitem, fld)



def POST(target, post=None, referer='http://tvfeed.in'):
	#print target
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		req.add_header('X-Requested-With', 'XMLHttpRequest')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		print e
		return ''


def getURL(url,Referer = 'http://coldfilm.ru/'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


def pars(url):
	r=getURL(url)
	L=mfindal(r, '<div class="shortstory">', '<span><strong>')
	L2=[]
	for k in L:
		curl=''
		cover=''
		title=''
		originaltitle=''
		year=''
		genre=''
		type=''
		total=''
		rating=''
		plot=''
		for i in k.splitlines():
			if '>Смотреть<' in i: 		curl=mfind(i, '<a href="', '">')
			if 'imgRadius' in i: 		cover=mfind(i, 'src="', '" alt=')
			if 'imgRadius' in i: 		title=rt(mfind(i, 'title="', ' / '))
			if 'imgRadius' in i: 		originaltitle=mfind(mfind(i, 'title="', '"'), ' / ','/>')
			if 'Год выхода:' in i: 		year=mfind(i, '</strong>', '</p>')
			if 'Жанр:' in i: 			genre=mfind(i, '</strong>', '</p>')
			if 'Тип:' in i: 			type=mfind(i, '</strong>', '</p>')
			if 'Количество серий:' in i: total=mfind(i, '</strong>', '</p>')
			if 'current-rating' in i: 	rating=int(mfind(i, ';">', '</li>'))/20
			if 'Описание:' in i: 		plot=mfind(i, '</strong>', '<br />')
		info={
			'url':curl,
			'cover':cover,
			'title':title,
			'originaltitle':originaltitle,
			'year':year,
			'genre':genre,
			'type':type,
			'total':total,
			'rating':rating,
			'plot':plot
			}
		L2.append(info)
	return L2

def pars2(r):
	L=mfindal(r, '<div class="shortstory">', '<span><strong>')
	L2=[]
	for k in L:
		curl=''
		cover=''
		title=''
		originaltitle=''
		year=''
		genre=''
		type=''
		total=''
		rating=''
		plot=''
		for i in k.splitlines():
			if '>Смотреть<' in i: 		curl=mfind(i, '<a href="', '">')
			if 'imgRadius' in i: 		cover=mfind(i, 'src="', '" alt=')
			if 'imgRadius' in i: 		title=rt(mfind(i, 'title="', ' / '))
			if 'imgRadius' in i: 		originaltitle=mfind(mfind(i, 'title="', '"'), ' / ','/>')
			if 'Год выхода:' in i: 		year=mfind(i, '</strong>', '</p>')
			if 'Жанр:' in i: 			genre=mfind(i, '</strong>', '</p>')
			if 'Тип:' in i: 			type=mfind(i, '</strong>', '</p>')
			if 'Количество серий:' in i: total=mfind(i, '</strong>', '</p>')
			if 'current-rating' in i: 	rating=int(mfind(i, ';">', '</li>'))/20
			if 'Описание:' in i: 		plot=mfind(i, '</strong>', '<br />')
		info={
			'url':curl,
			'cover':cover,
			'title':title,
			'originaltitle':originaltitle,
			'year':year,
			'genre':genre,
			'type':type,
			'total':total,
			'rating':rating,
			'plot':plot
			}
		L2.append(info)
	return L2

def epd_lst(url):
	j=getURL(url)
	dict=eval('{'+mfind(j,'var data = {', '}')+'}')
	L=dict.keys()
	L.sort()
	for i in L:
		add_item (i, 'play', 'http://mp4.aniland.org/'+dict[i]+'.mp4', '0', 'http://media.aniland.org/img/'+dict[i]+'.jpg')
	xbmcplugin.endOfDirectory(handle)

def root():
	add_item ('Поиск', 'serch')
	add_item ('Онгоинги', 'ongoing')
	add_item ('Жанр', 'genres')
	add_item ('Тип', 'types')
	add_item ('Год', 'years')
	xbmcplugin.endOfDirectory(handle)

def list(url):
	L=pars(url)
	for i in L:
		name  = i['title']
		url   = i['url']
		cover = i['cover']
		add_item (name, 'epd_lst', url, '0',cover, info=i)

def ongoing():
	for i in range(1,10):
		list('http://animevost.org/ongoing/page/'+str(i)+'/')
	xbmcplugin.endOfDirectory(handle)

def genres():
	L=zhanr.keys()
	L.sort()
	for i in L:
		add_item (i, 'genre', zhanr[i])
	xbmcplugin.endOfDirectory(handle)

def genre(url):
	for i in range(1,11):
		list(url+'page/'+str(i)+'/')
	xbmcplugin.endOfDirectory(handle)


def types():
	L=tip.keys()
	L.sort()
	for i in L:
		add_item (i, 'type', tip[i])
	xbmcplugin.endOfDirectory(handle)

def type(url):
	for i in range(1,11):
		list(url+'page/'+str(i)+'/')
	xbmcplugin.endOfDirectory(handle)

def years():
	L=god.keys()
	L.sort()
	for i in L:
		add_item (i, 'year', god[i])
	xbmcplugin.endOfDirectory(handle)

def year(url):
	list(url)
	xbmcplugin.endOfDirectory(handle)

def serch():
	s=urllib.quote_plus(inputbox())#%D1%81%D0%B0%D0%BA%D1%83%D1%80%D0%B0
	for p in range(1,11):
		post='do=search&subaction=search&search_start='+str(p)+'&story='+s+'&x=0&y=0'#+'&result_from=21'
		r = POST('http://animevost.org/index.php?do=search', post)
		L=pars2(r)
		for i in L:
			add_item (i['title'], 'epd_lst', i['url'], '0', i['cover'], info=i)
	xbmcplugin.endOfDirectory(handle)


def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

params = get_params()

try:mode = urllib.unquote_plus(params["mode"])
except:mode =""
try:name = urllib.unquote_plus(params["name"])
except:name =""
try:url = urllib.unquote_plus(params["url"])
except:url =""
try:ind = urllib.unquote_plus(params["ind"])
except:ind ="0"


if mode==""         : root()

if mode=="ongoing"  : ongoing()
if mode=="genres"   : genres()
if mode=="genre"    : genre(url)
if mode=="types"    : types()
if mode=="type"     : type(url)
if mode=="years"    : years()
if mode=="year"     : year(url)
if mode=="serch"    : serch()
	
if mode=="epd_lst"  : epd_lst(url)
if mode=="play"     : play(url, int(ind))

