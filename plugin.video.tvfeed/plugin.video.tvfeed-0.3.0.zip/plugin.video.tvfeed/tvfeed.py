# -*- coding: utf-8 -*-
import xbmc, urllib2

def rt(x):#('&#39;','’'), ('&#145;','‘')
	L=[('&amp;',"&"),('&#133;','…'),('&#38;','&'),('&#34;','"'), ('&#39;','"'), ('&#145;','"'), ('&#146;','"'), ('&#147;','“'), ('&#148;','”'), ('&#149;','•'), ('&#150;','–'), ('&#151;','—'), ('&#152;','?'), ('&#153;','™'), ('&#154;','s'), ('&#155;','›'), ('&#156;','?'), ('&#157;',''), ('&#158;','z'), ('&#159;','Y'), ('&#160;',''), ('&#161;','?'), ('&#162;','?'), ('&#163;','?'), ('&#164;','¤'), ('&#165;','?'), ('&#166;','¦'), ('&#167;','§'), ('&#168;','?'), ('&#169;','©'), ('&#170;','?'), ('&#171;','«'), ('&#172;','¬'), ('&#173;',''), ('&#174;','®'), ('&#175;','?'), ('&#176;','°'), ('&#177;','±'), ('&#178;','?'), ('&#179;','?'), ('&#180;','?'), ('&#181;','µ'), ('&#182;','¶'), ('&#183;','·'), ('&#184;','?'), ('&#185;','?'), ('&#186;','?'), ('&#187;','»'), ('&#188;','?'), ('&#189;','?'), ('&#190;','?'), ('&#191;','?'), ('&#192;','A'), ('&#193;','A'), ('&#194;','A'), ('&#195;','A'), ('&#196;','A'), ('&#197;','A'), ('&#198;','?'), ('&#199;','C'), ('&#200;','E'), ('&#201;','E'), ('&#202;','E'), ('&#203;','E'), ('&#204;','I'), ('&#205;','I'), ('&#206;','I'), ('&#207;','I'), ('&#208;','?'), ('&#209;','N'), ('&#210;','O'), ('&#211;','O'), ('&#212;','O'), ('&#213;','O'), ('&#214;','O'), ('&#215;','?'), ('&#216;','O'), ('&#217;','U'), ('&#218;','U'), ('&#219;','U'), ('&#220;','U'), ('&#221;','Y'), ('&#222;','?'), ('&#223;','?'), ('&#224;','a'), ('&#225;','a'), ('&#226;','a'), ('&#227;','a'), ('&#228;','a'), ('&#229;','a'), ('&#230;','?'), ('&#231;','c'), ('&#232;','e'), ('&#233;','e'), ('&#234;','e'), ('&#235;','e'), ('&#236;','i'), ('&#237;','i'), ('&#238;','i'), ('&#239;','i'), ('&#240;','?'), ('&#241;','n'), ('&#242;','o'), ('&#243;','o'), ('&#244;','o'), ('&#245;','o'), ('&#246;','o'), ('&#247;','?'), ('&#248;','o'), ('&#249;','u'), ('&#250;','u'), ('&#251;','u'), ('&#252;','u'), ('&#253;','y'), ('&#254;','?'), ('&#255;','y'), ('&laquo;','"'), ('&raquo;','"'), ('&nbsp;',' '), ('&mdash;','-'), ('&quot;','"')]
	for i in L:
		x=x.replace(i[0], i[1])
	return x

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def POST(target, post=None, referer='http://tvfeed.in'):
	#print target
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		req.add_header('X-Requested-With', 'XMLHttpRequest')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		print e
		return ''

def GET(url,Referer = 'https://tvfeed.in', XML = False):
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
		req.add_header('Accept', '*/*')
		req.add_header('Accept-Language', 'ru,en;q=0.9')
		req.add_header('Referer', Referer)
		if XML: req.add_header('X-Requested-With', 'XMLHttpRequest')
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
	except:
		print 'ERR: недоступно'
		#import requests
		#s = requests.session()
		#r=s.get(url).text
		#rd=r.encode('windows-1251')
		#return rd

def get_info(url):
	#print '-=-=-= get_info =-=-=-'
	#print url
	hp=rt(GET(url))
	
	cover='https://tvfeed.in'+mfind(mfind(hp,'<div class="col-def bleft pad20">','</div>'), '<img src="','" alt=')
	fanart='https://tvfeed.in'+mfind(mfind(hp,'<div class="page-bg">','</div>'), '<img src="','" alt=')
	#print cover
	#print fanart
	
	if '/serial/' in url: type='serial'
	else: type='film'
	
	s='<div class="col-auto serial_info hpad50">'
	e='<div id="remember-block" class="container'
	t=mfind(hp,s,e)
	
	title=mfind(t,'<h1 itemprop="name" class="f32">','</h1>')
	originaltitle=mfind(t,'<h3 itemprop="alternativeHeadline">','</h3>')
	plot=mfind(t,'<div class="about" itemprop="about">','</p>')
	plot=plot.replace('\n','').replace('\t','').replace('<p>','').strip()
	year=mfind(t,'года" >','</a>')
	duration=mfind(t,'additional thin">','</div>')
	duration=duration.replace('\n','').replace('\t','').strip()
	try:rating=float(mfind(t,'<meta itemprop="ratingValue" content="','"/>'))
	except:rating=0
	countrys=mfindal(t,'title="Сериалы страны ','" itemprop=')
	country=''
	for c in countrys:
		c=c.replace('title="Сериалы страны ','')
		if len(c) >1: country+=c+" / "
	country=country[:-3]
	
	
	#print title
	#print originaltitle
	#print year
	#print duration
	#print country
	
	genres=mfindal(t,'title="Сериалы в жанре ','" itemprop="genre">')
	genre=''
	for g in genres:
		g=g.replace('title="Сериалы в жанре ','')
		genre+=g+" / "
	genre=genre[:-3]
	
	#print genre
	
	actors2=mfindal(t,'<a href="/actor','"actor" itemscope')
	actors=[]
	cast=[]
	for a in actors2:
		actor=mfind(a, 'title="', '" itemprop')
		a_url=mfind(a, 'href="', '" class')
		cast.append(actor)
		actors.append({'name':actor,'url':a_url})
	
	#print actors
	
	info = {"title": title,
			"originaltitle": originaltitle,
			"year": year, 
			"duration": duration,
			"genre": genre,
			"cast": cast,
			"actors": actors,
			"rating": rating,
			"cover": cover,
			"fanart": fanart,
			"plot": plot,
			"type": type,
			"url": url
			}
	
	return info

#get_info('https://tvfeed.in/serial/prizrachnye-vojny/')

def get_list(url):
	hp=GET(url)
	n='<div class="ajax_container container'
	if n in hp: hp=hp[hp.find(n):]
	L=mfindal(hp,'<div class="row','<div class="genre h60')
	LL=[]
	for i in L:
		if 'newest.jpg' not in i:
			url=mfind(i,'href="','" title')
			img='https://tvfeed.in'+mfind(i,'<img src="','" alt="')
			title=mfind(i,'" alt="','" itemprop=')
			print title+" > "+url
			print img
			LL.append(url)
	return LL

#get_list('https://tvfeed.in/serial/newest/')

def search(t):
	url='https://tvfeed.in/ajax_search/'
	#%D1%82%D0%B5%D1%80%D0%BC%D0%B8%D1%82
	post='q='+t#+'&csrfmiddlewaretoken=h5UPzxDGdojKoH9DTaBwFMYe4PKltMy0'
	json=POST(url, post)
	return json


def get_top(top='tvfeed'):
	url='https://tvfeed.in/serial/popular/'+top+'/'
	hp=GET(url)
	L=mfindal(hp,'<h4>','</h4>')
	LL=[]
	for i in L:
			url=mfind(i,'href="','" title')
			LL.append(url)
	return LL


def get_genres_list():
	url='https://tvfeed.in/genre/'
	hp=GET(url)
	L=mfindal(hp,'<div class="col-18 spad','</h4>')
	LL=[]
	for i in L:
			i+='</h4>'
			url=mfind(i,'href="','">')
			img=mfind(i,'src="','" alt=')
			title=mfind(i,'<h4>','</h4>')
			LL.append({'url':url, 'title':title, 'cover':img})
	return LL

def get_collection():
	url='https://tvfeed.in/collection/'
	hp=GET(url)
	L=mfindal(hp,'<div class=" row','</h4>')
	LL=[]
	for i in L:
			i+='</h4>'
			url=mfind(i,'href="','">')
			img=mfind(i,'src="','" alt=')
			title=mfind(i,'<h4>','</h4>')
			if 'Гибли' not in title: LL.append({'url':url, 'title':title, 'cover':img})
	return LL


def get_seasons(url):
	hp=GET(url)
	L=mfindal(hp,'<div class="row5 spad','<h4 itemprop="name')
	LL=[]
	for i in L:
		url=mfind(i,'href="','" class')
		img='https://tvfeed.in'+mfind(i,'<img src="','" alt="')
		title=mfind(i,'title="',' сериала ')
		print title+" > "+url
		print img
		LL.append(url)
	return LL

#get_seasons('https://tvfeed.in/serial/igra-prestolov/')

def get_episodes(url):
	hp=GET(url)
	
	L=mfindal(hp,'<div class="series past hide"','\n        </div>\n        \n    </div>\n</div>\n')#'</p>\n        </div>'
	LL=[]
	for i in L:
		#i=i+'</p>'
		curl=mfind(i, '<a href="', '" title=')
		title=rt(mfind(i, 'itemprop="url">', '</a>'))
		epd=mfind(i, '<div class="episode">', '</div>')
		episode=epd[epd.find('x')+1:]
		season=epd[:epd.find('x')]
		if '<p>' in i: plot=rt(mfind(i,'<p>','</p>'))
		else:          plot=''
		date=mfind(i,'<div class="date">',', ')
		date=date.replace('\n','').replace('\t','').strip()
		try:
			year=date[6:8]
			if int(year)>30:year='19'+year
			else:year='20'+year
			aired=date[:2]+'-'+date[3:5]+'-'+year
		except:
			aired=''
		print aired
		if 'no-series-image' in i: img='https://tvfeed.in/img/no-series-image.jpg'
		else: img='https://'+mfind(i,'https://','.jpg')+'.jpg'
		
		#if 'class="translate"' in i: translate_id=mfind(i, 'translate" data="', '" title=')
		#else:                        translate_id=''
		#if translate_id!='' : plot=translate(translate_id) # Отключен автоперевод описаний
			
		print epd+' - '+title
		print curl
		print date
		print img
		print plot
		if curl!='':LL.append({'url':curl, 'title':title, 'aired':aired, 'episode':episode, 'season':season, 'cover':img, 'plot':plot})
	
	# Расмписание будущих серий
	Lf=mfindal(hp,'<div class="series future hide"','\n        </div>\n        \n    </div>\n</div>\n')
	for i in Lf:
		curl=mfind(i, '<a href="', '" title=')
		title=rt(mfind(i, 'itemprop="url">', '</a>'))
		epd=mfind(i, '<div class="episode">', '</div>')
		episode=epd[epd.find('x')+1:]
		season=epd[:epd.find('x')]
		if '<p>' in i: plot=rt(mfind(i,'<p>','</p>'))
		else:          plot=''
		date=mfind(i,'<div class="date">',', ')
		date=date.replace('\n','').replace('\t','').strip()
		try:
			year=date[6:8]
			if int(year)>30:year='19'+year
			else:year='20'+year
			aired=date[:2]+'-'+date[3:5]+'-'+year
		except:
			aired=''
		print aired
		if 'no-series-image' in i: img='https://tvfeed.in/img/no-series-image.jpg'
		else: img='https://'+mfind(i,'https://','.jpg')+'.jpg'
		
		#if 'class="translate"' in i: translate_id=mfind(i, 'translate" data="', '" title=')
		#else:                        translate_id=''
		#if translate_id!='' : plot=translate(translate_id) # Отключен автоперевод описаний
			
		print epd+' - '+title
		print curl
		print date
		print img
		print plot
		if curl!='':LL.append({'url':curl, 'title':'[COLOR FFFF2222]'+title+'[/COLOR]', 'aired':aired, 'episode':episode, 'season':season, 'cover':img, 'plot':plot})
		
	return LL


#get_episodes('https://tvfeed.in/serial/utinye-istorii-2017/series/')

def translate(id):
	url='https://tvfeed.in/translate/'
	post='q='+id+'&lang=en-ru'
	tr=POST(url, post)[3:-4]
	return tr

def get_quality(url):
	hp=GET(url)
	L=mfindal(hp,'<figure>','<meta itemprop="name"')
	LL=[]
	for i in L:
		if 'container quality' in i:
			url=mfind(i,'<a href="','" title="')
			studio=rt(mfind(i,'в озвучке ',' смотреть онлайн'))
			img=mfind(i,'<img src="','" alt="')
			L2=mfindal(i,'tcenter active">','</div>')
			Lq=[]
			for q in L2:
				if 'SD' in q: Lq.append('[SD]')
				if 'HD' in q: Lq.append('[HD]')
				
			print url
			print studio
			print img
			print Lq
			LL.append({'url':url, 'title':studio, 'quality':Lq, 'cover':img})
	return LL


#get_quality('https://tvfeed.in/serial/vo-vse-tyazhkie/s1/e5/')


def get_stream(url, ep):
	ep=str(ep)
	if len (ep)<2: ep='0'+ep
	ace=GET(url, XML = True)
	srv='127.0.0.1'#__settings__.getSetting("p2p_serv")
	prt='6878'#__settings__.getSetting("p2p_port")
	CID=ace.replace('acestream://','')
	lnk='http://'+srv+':'+prt+'/ace/getstream?id='+CID+"&.mp4"
	lnk2='http://'+srv+':'+prt+'/ace/getstream?id='+CID+"&format=json"
#	json=GET(lnk2)
#	print json
	m3u=GET(lnk2)
	L= m3u.splitlines()
	n=0
	for e in L:
		n+=1
		if '#EXTINF' in e and 'e'+ep in e.lower(): return L[n]
	
	return ''


#lnk=get_stream('https://tvfeed.in/season/135/external/?q=sd', 3)
#xbmc.Player().play(lnk)

