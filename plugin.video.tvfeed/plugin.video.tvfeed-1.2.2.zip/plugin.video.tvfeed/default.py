#!/usr/bin/python
# -*- coding: utf-8 -*-

# *  Copyright (C) 2016 TDW

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, urllib, urllib2, time, codecs, httplib
import tvfeed

PLUGIN_NAME   = 'tvfeed'
siteUrl = 'tvfeed.in'
httpSiteUrl = 'https://' + siteUrl
handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.tvfeed')
__settings__ = xbmcaddon.Addon(id='plugin.video.tvfeed')
xbmcplugin.setContent(int(sys.argv[1]), 'movies')

icon  = os.path.join( addon.getAddonInfo('path'), 'icon.png')
dbDir = __settings__.getSetting("DBDirectory")
if dbDir =='': dbDir = addon.getAddonInfo('path')
LstDir = addon.getAddonInfo('path')

try:Fav=eval(__settings__.getSetting("Favorites"))
except: Fav=[]


#======================== стандартные функции ==========================
def fs_enc(path):
	sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
	return path.decode('utf-8').encode(sys_enc)

def fs_dec(path):
	sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
	return path.decode(sys_enc).encode('utf-8')

def fs(s):return s.decode('windows-1251').encode('utf-8')
def win(s):return s.decode('utf-8').encode('windows-1251')
def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def lower(s):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.lower().encode('utf-8')
	return s

def inputbox():
	skbd = xbmc.Keyboard()
	skbd.setHeading('Поиск:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return ""

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

#============================== основная часть ============================

def GET(url,Referer = 'https://tvfeed.in', XML = False):
	print url
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'KODI')#'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60'
		req.add_header('Accept', '*/*')
		req.add_header('Accept-Language', 'ru,en;q=0.9')
		req.add_header('Referer', Referer)
		if XML: req.add_header('X-Requested-With', 'XMLHttpRequest')
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
	except:
		print 'ERR: недоступно'
		return ''


def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		print params
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param



import sqlite3 as db
db_name = os.path.join( dbDir, "info.db" )
c = db.connect(database=db_name)
cu = c.cursor()
def add_to_db(n, item):
		item=item.replace("'","XXCC").replace('"',"XXDD")
		err=0
		tor_id="n"+n.replace('-','')
		print tor_id
		litm=str(len(item))
		try:
			cu.execute("CREATE TABLE "+tor_id+" (db_item VARCHAR("+litm+"), i VARCHAR(1));")
			c.commit()
		except: 
			err=1
			print "Ошибка БД"+ n
		if err==0:
			cu.execute('INSERT INTO '+tor_id+' (db_item, i) VALUES ("'+item+'", "1");')
			c.commit()
			#c.close()

def get_inf_db(n):
		tor_id="n"+n.replace('-','')
		cu.execute(str('SELECT db_item FROM '+tor_id+';'))
		c.commit()
		Linfo = cu.fetchall()
		info=Linfo[0][0].replace("XXCC","'").replace("XXDD",'"')
		return info

def rem_inf_db(n):
		tor_id="n"+n.replace('-','')
		try:
			cu.execute("DROP TABLE "+tor_id+";")
			c.commit()
		except: pass


def update_info(id):
	rem_inf_db(id)
	xbmc.executebuiltin('Container.Refresh')


def get_labels(info):
	Linf=['genre', 'year', 'rating', 'cast', 'director', 'plot', 'title', 'originaltitle', 'studio']
	Labels={}
	for inf in Linf:
		try:Labels[inf] = info[inf]
		except: pass
	try:Labels['duration'] = str(int(info['duration'])*60)
	except: pass
	return Labels


def AddItem(Title = "", mode = "", id='0', url='', total=100, icon=icon):
			if id !='0' and mode!="Play" and mode!="Genre" and 'Далее >' not in Title:
				try:    info=get_info(id)
				except: info={}
				try:    cover = info["cover"]
				except: cover = icon
				try:    fanart = info["fanart"]
				except: fanart = icon
				try:    blocked = info["blocked"]
				except: blocked = False
			else:
				cover = icon
				fanart = icon
				info={'id':id}
				blocked = False
			
			#if blocked: Title = '[COLOR FFFF5555]'+Title+'[/COLOR]'
			listitem = xbmcgui.ListItem(Title, iconImage=cover, thumbnailImage=cover)
			listitem.setInfo(type = "Video", infoLabels = get_labels(info))
			try: listitem.setArt({ 'poster': cover, 'fanart' : fanart, 'thumb': cover, 'icon': cover})
			except: pass
			listitem.setProperty('fanart_image', fanart)
			
			purl = sys.argv[0] + '?mode='+mode+'&id='+str(id)
			if url !="": purl = purl +'&url='+str(url)
			
			try:type=info["type"]
			except:type=''
			if mode=="Episodes":
				if id in Fav:	listitem.addContextMenuItems([
					('[B]Сохранить сериал[/B]', 'Container.Update("plugin://plugin.video.tvfeed/?mode=Save&id='+str(id)+'")'),
					('[B]Отслеживать в ТС[/B]', 'Container.Update("plugin://plugin.video.tvfeed/?mode=TC2&id='+str(id)+'")'),
					('[B]Удалить из избранного[/B]', 'Container.Update("plugin://plugin.video.tvfeed/?mode=REM&id='+str(id)+'")'),
					('[B]Обновить описание[/B]', 'Container.Update("plugin://plugin.video.tvfeed/?mode=update_info&id='+str(id)+'")')
					])
				else: 			listitem.addContextMenuItems([
					('[B]Сохранить сериал[/B]', 'Container.Update("plugin://plugin.video.tvfeed/?mode=Save&id='+str(id)+'")'),
					('[B]Отслеживать в ТС[/B]', 'Container.Update("plugin://plugin.video.tvfeed/?mode=TC2&id='+str(id)+'")'),
					('[B]В избранное[/B]', 'Container.Update("plugin://plugin.video.tvfeed/?mode=ADD&id='+str(id)+'")'),
					('[B]Обновить описание[/B]', 'Container.Update("plugin://plugin.video.tvfeed/?mode=update_info&id='+str(id)+'")')
					])
			if mode=="Serials":
				listitem.addContextMenuItems([('[B]Обновить список сериалов[/B]', 'Container.Update("plugin://plugin.video.tvfeed/?mode=Update")')])
			if mode=="Play":
				listitem.setProperty('IsPlayable', 'true')
				#purl = sys.argv[0] + '?mode=Autoplay&id='+id
				xbmcplugin.addDirectoryItem(handle, purl, listitem, False, total)
			else:
				xbmcplugin.addDirectoryItem(handle, purl, listitem, True, total)

def AddEpisode(Title = "", mode = "", info={}, SID='', total=100):
			id=info['id']
			ep=info['episode']
			try:    cover = info["cover"]
			except: cover = ''
			if cover == '' or 'no-series-image' in cover or 'tvmazecdn' in cover: #                          tvmazecdn ВРЕМЕННО ОТКЛЮЧЕНО !!!
				cover=get_info(id)['fanart']
				
			fanart = cover
			
			listitem = xbmcgui.ListItem(Title, iconImage=cover, thumbnailImage=cover)
			listitem.setInfo(type = "Video", infoLabels = info)
			try: listitem.setArt({ 'poster': cover, 'fanart' : cover, 'thumb': cover, 'icon': cover})
			except: pass
			listitem.setProperty('fanart_image', fanart)
			purl = sys.argv[0] + '?mode='+mode+'&id='+str(ep)
			if url !="": purl = purl +'&url='+str(SID)
			
			try:type=info["type"]
			except:type=''
			if __settings__.getSetting("Autoplay")=='true': 
					listitem.setProperty('IsPlayable', 'true')
					listitem.addContextMenuItems([('[B]Выбрать качество[/B]', 'Container.Update("plugin://plugin.video.tvfeed/?mode=Quality2&id='+str(ep)+'&url='+str(SID)+'")'),])
					xbmcplugin.addDirectoryItem(handle, purl, listitem, False, total)
			else:
					xbmcplugin.addDirectoryItem(handle, purl, listitem, True, total)


def get_info(ID):
	ID=str(ID)
	try:
			info=eval(xt(get_inf_db(ID)))
			return info
	except:
			try:    info = tvfeed.get_info(ID)
			except: return {"title": ID, "originaltitle":ID, "rating":0, "cover":icon, "type":'', "id":ID}
			try:    add_to_db(ID, repr(info))
			except: print "ERR: " + ID
			return info

def mont2num(dt):
	L1=[' января ',' февраля ',' марта ',' апреля ',' мая ',' июня ',' июля ',' августа ',' сентября ',' октября ',' ноября ',' декабря ']
	L2=['.01.','.02.','.03.','.04.','.05.','.06.','.07.','.08.','.09.','.10.','.11.','.12.']
	for i in range (0,12):
		dt=dt.replace(L1[i], L2[i])
	return dt

#==============  Menu  ====================
def Root():
	#get_all_serials()
	AddItem("Поиск", "Search")
	AddItem("Все сериалы", "Serials")
	AddItem("Популярные", "Popular")
	AddItem("Новинки", "New")
	AddItem("Жанры", "Genres")
	AddItem("Подборки", "Collection")
	AddItem("Избранное", "Favorites")
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	__settings__.setSetting("Favorites",repr(tvfeed.get_fav()))

def Search():
	q=inputbox()
	if q=='': return
	L=tvfeed.search(q)
	for id in L:
		info=get_info(id)
		AddItem(info['title'], "Episodes", id, '', len(L))


def get_all_serials():
	LL=[]
	for i in range(1,40):
		print i
		L=tvfeed.get_serial(i)
		if L==[]: break
		
		for id in L:
			LL.append(id)
			#print id
			#info=get_info(id)
	
	item=repr(LL)
	rem_inf_db('tvfeed')
	add_to_db('tvfeed', item)

def Serials():
	L=eval(get_inf_db('tvfeed'))
	try:upd_pos=int(__settings__.getSetting("upd_pos"))
	except: upd_pos=0
	for p in range(10):
		up = upd_pos+p
		if up>=len(L): 
			up=0
			break
		id = L[up]
		rem_inf_db(str(id))
	__settings__.setSetting("upd_pos", str(up+1))
	n=0
	for id in L:
		n+=1
		#if n>30: return
		try:
			info=get_info(id)
			AddItem(info['title'], "Episodes", id, '', len(L))
		except: pass

def Genres():
	L=tvfeed.get_genre_list()
	for info in L:
		print info
		AddItem(info['name'], "Genre", info['id'],1, len(L))

def Genre(gid, p=1):
		p=int(p)
		L=tvfeed.get_genre(gid, p)
		for id in L:
			info=get_info(id)
			AddItem(info['title'], "Episodes", id, '', len(L))
		if len(L)==30: AddItem("[B]Далее >[/B]", "Genre", gid, p+1)

def Collection():
	L=tvfeed.get_collection_list()
	for info in L:
		print info
		AddItem(info['title'], "Collect", '0', info['id'], len(L), info['cover'])

def Collect(id):
	L=tvfeed.get_collection(id)
	for id in L:
		info=get_info(id)
		AddItem(info['title'], "Episodes", id, '', len(L))

def New():
	Ls=eval(get_inf_db('tvfeed'))
	upd=False
	
	L=tvfeed.get_serial(page=1, order='default')
	for id in L:
		if id not in Ls:
			Ls.append(id)
			upd=True
		info=get_info(id)
		AddItem(info['title'], "Episodes", id, '', len(L))
	
	if upd:
		item=repr(Ls)
		rem_inf_db('tvfeed')
		add_to_db('tvfeed', item)


def Top():
	L=tvfeed.get_serial(page=1, order='tvfeed')
	for id in L:
		info=get_info(id)
		AddItem(info['title'], "Episodes", id, '', len(L))

def Episodes(id, ret=False):
	tvm_id = get_info(id)['tvmaze']
	Ls=tvfeed.get_season_list(id)
	Le = tvfeed.get_episodes(tvm_id)
	Lr=[]
	for s in Ls:
		SID = s['id']
		season=str(s['num'])
		if ret==False: AddItem('[COLOR FF22FF22] '+season+' сезон[/COLOR]', "Quality2", SID, SID, len(Le))
		else: Lr.append({'s':season, 'SID':SID})
		for i in Le:
			if str(i['season']) == season:
				i['id']=id
				title=str(i['season'])+'x'+str(i['episode'])+"  "+i['title']
				if ret==False: AddEpisode(title, "Quality", i, SID, len(Le))
	return Lr

def Quality(SID, ep, ap=True):
	LS = ['LostFilm','NewStudio','Кураж-Бамбей','Amedia','Кубик в Кубе','AlexFilm','NovaFilm','Jasker','Good People','Profix Media','OMSKBIRD','Baibak','Sunshine']
	#if __settings__.getSetting("Quality")=='0': u_quality = 'hd'
	#if __settings__.getSetting("Quality")=='1': u_quality = 'sd'
	u_studio1  = LS[int(__settings__.getSetting("Studio1"))]
	u_studio2  = LS[int(__settings__.getSetting("Studio2"))]
	u_studio3  = LS[int(__settings__.getSetting("Studio3"))]
	u_studio4  = LS[int(__settings__.getSetting("Studio4"))]
	Ls1 = []
	Ls2 = []
	Ls3 = []
	Ls4 = []
	Ld  = []
	L=tvfeed.get_voice(SID)
	for info in L:
		img=info['cover']
		PID =info['id']
		AddItem(info['title'], "Play", ep, PID, len(L), img)
		Ld.append(PID)
		if u_studio1 in info['title']: Ls1.append(PID)
		if u_studio2 in info['title']: Ls2.append(PID)
		if u_studio3 in info['title']: Ls3.append(PID)
		if u_studio4 in info['title']: Ls4.append(PID)
	
	if __settings__.getSetting("Autoplay")=='true' and ap:
		#print Ld
		pt=False
		if Ls1 != []: 				pt=Play(Ls1[0], ep, '', False)
		if Ls2 != [] and pt==False: pt=Play(Ls2[0], ep, '', False)
		if Ls3 != [] and pt==False: pt=Play(Ls3[0], ep, '', False)
		if Ls4 != [] and pt==False: pt=Play(Ls4[0], ep, '', False)
		if pt==False: 				   Play(Ld[0],  ep, '', False)
		if Ls1 != [] or Ls2 != [] or Ls3 != []: return False
		else: return True
	else:
		return True

def Save(id):
	sel = xbmcgui.Dialog()
	Lu=Episodes(id, True)
	Lt=[]
	for i in Lu:
		Lt.append(i['s']+' сезон')
	rs = sel.select("Сезон:", Lt)
	
	SID=Lu[rs]['SID']
	info=get_info(id)
	Lt=[]
	Lu=[]
	L=tvfeed.get_voice(SID)
	for info2 in L:
			Lt.append(info2['title'])
			Lu.append(info2['id'])
	r = sel.select("Перевод:", Lt)
	if r>-1:
		PID=Lu[r]
		if __settings__.getSetting("Quality")=='0': quality = 'hd'
		elif __settings__.getSetting("Quality")=='1': quality = 'sd'
		CID=tvfeed.GET_CID(PID, quality)
		if CID=='' or CID=='blocked': 
			showMessage('Контент недоступен.','Подробнее в личном кабинете.')
			return
		if 'acestream://' not in CID: CID='acestream://'+CID
		uri='plugin://plugin.video.torrent.checker/?mode=save_episodes_api&url='+urllib.quote_plus(CID)+'&name='+urllib.quote_plus(info['originaltitle'])+ '&info=' + urllib.quote_plus(repr(info))
		print uri
		xbmc.executebuiltin('RunPlugin("'+uri+'")')
		#xbmc.executebuiltin('Container.Update("'+uri+'")')

def TC2(id):
	#import base64
	info=get_info(id)
	tvs_name = info['originaltitle']
	
	sel = xbmcgui.Dialog()
	Lu=Episodes(id, True)
	Lt=[]
	for i in Lu:
		Lt.append(i['s']+' сезон')
	rs = sel.select("Сезон:", Lt)
	
	SID=Lu[rs]['SID']
	
	Lt=[]
	Lu=[]
	L=tvfeed.get_voice(SID)
	for info2 in L:
			Lt.append(info2['title'])
			Lu.append(info2['id'])
	r = sel.select("Перевод:", Lt)
	if r>-1:
		PID=Lu[r]
		tvf_url = 'plugin://plugin.video.tvfeed/?mode=TC&name='+tvs_name+'&id='+str(PID)
		uri='plugin://plugin.video.torrent.checker/?mode=add&url='+urllib.quote_plus(tvf_url)+'&name='+tvs_name+'&manual=0'
		xbmc.executebuiltin('RunPlugin("'+uri+'")')
		#xbmc.executebuiltin('Container.Update("'+uri+'")')

def TC(PID, name):
	if __settings__.getSetting("Quality")=='0': quality = 'hd'
	elif __settings__.getSetting("Quality")=='1': quality = 'sd'
	#import base64
	#link = base64.b64decode(link+'=')
	sys.path.append(os.path.join(xbmc.translatePath("special://home/"),"addons","plugin.video.torrent.checker"))
	import updatetc
	LD=updatetc.file_list(name)
	Ls=tvfeed.get_streams(PID, quality)
	for i in Ls:
		nm = i['title']+'.strm'
		uri = i['url']
		ind = i['ind']
		if nm not in LD:
			#print nm
			updatetc.save_strm(name, nm, uri, ind)
			#updatetc.save_nfo(name, nm.replace('.strm',''),'0' , e, {'title':xt(title), 'cover':cover})


def get_ace_status():
	stat_url=__settings__.getSetting("stat_url")
	j=eval(GET(stat_url).replace('null','"null"'))["response"]
	if j=={}:
		return '{}'
	else:
		status=j['status'] #if status=='dl': 
		try:
			progress=j['total_progress']
			if progress > 99: return 'Загрузка завершена'
			
			download=j['downloaded']
			seeds=j['peers']
			speed=j['speed_down']
			return "Загружено "+str(download/1024/1024)+" MB ("+str(progress)+" %) \nСиды: "+str(seeds)+" \nСкорость: "+str(speed)+' Kbit/s'
		except:
			return 'err'

class pPlayer(xbmc.Player):
	def __init__(self):
		self.tsserv = None
		self.active = True
		self.started = False
		self.ended = False
		self.paused = False
		self.buffering = False
		xbmc.Player.__init__(self)
		width, height = pPlayer.get_skin_resolution()
		w = width
		h = int(0.14 * height)
		x = 0
		y = (height - h) / 2
		self._ov_window = xbmcgui.Window(12005)
		self._ov_label = xbmcgui.ControlLabel(x, y, w, h, '', alignment=6)
		self._ov_background = xbmcgui.ControlImage(x, y, w, h, fs_dec(pPlayer.get_ov_image()))
		self._ov_background.setColorDiffuse('0xD0000000')
		self.ov_visible = False
		#self.onPlayBackStarted()


	def onPlayBackPaused(self):
		self.ov_show()


	def onPlayBackStarted(self):
		if __settings__.getSetting("NoAD")=='true': xbmc.Player().seekTime(35)
		self.ov_hide()
		if not xbmc.Player().isPlaying(): xbmc.sleep(2000)
		status = ''
		while xbmc.Player().isPlaying():
			if self.ov_visible == True:
				try: status = get_ace_status()
				except: pass
				self.ov_update(status)
			xbmc.sleep(800)


	def onPlayBackResumed(self):
		self.ov_hide()
		
	def onPlayBackStopped(self):
		self.ov_hide()
	
	def __del__(self):
		self.ov_hide()

	@staticmethod
	def get_ov_image():
		import base64
		ov_image = fs_enc(os.path.join(addon.getAddonInfo('path'), 'bg.png'))
		if not os.path.isfile(ov_image):
			fl = open(ov_image, 'wb')
			fl.write(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII='))
			fl.close()
		return ov_image

	@staticmethod
	def get_skin_resolution():
		import xml.etree.ElementTree as Et
		skin_path = fs_enc(xbmc.translatePath('special://skin/'))
		tree = Et.parse(os.path.join(skin_path, 'addon.xml'))
		res = tree.findall('./extension/res')[0]
		return int(res.attrib['width']), int(res.attrib['height'])

	def ov_show(self):
		if not self.ov_visible:
			self._ov_window.addControls([self._ov_background, self._ov_label])
			self.ov_visible = True

	def ov_hide(self):
		if self.ov_visible:
			self._ov_window.removeControls([self._ov_background, self._ov_label])
			self.ov_visible = False

	def ov_update(self, txt=" "):
		if self.ov_visible:
			self._ov_label.setLabel(txt)

Player=pPlayer()

def Play(PID, ep, id='', lst=True):
	
	progressBar = xbmcgui.DialogProgress()
	progressBar.create('ACE Stream', 'Запуск')
	ASE_start()
	
	if __settings__.getSetting("Quality")=='0': u_quality = 'hd'
	if __settings__.getSetting("Quality")=='1': u_quality = 'sd'
	as_url=tvfeed.get_stream(PID, ep, lst, u_quality)
	
	print as_url
	if as_url!='':
		false = False
		true  = True
		json=eval(GET(as_url).replace('null','"null"'))["response"]
		progressBar.update(0, 'ACE Stream', 'Контент найден', "")
		stat_url=json["stat_url"]
		stop_url=json["command_url"]+'?method=stop'
		url=json["playback_url"]
		
		__settings__.setSetting("stat_url", stat_url)
		progressBar.update(0, 'ACE Stream', 'Подключение', "")
		while not xbmc.abortRequested:
			xbmc.sleep(500)
			j=eval(GET(stat_url).replace('null','"null"'))["response"]
			print j
			if j=={}:
				pass
				progressBar.update(0, 'ACE Stream', 'Ожидание', "")
			else:
				try:status=j['status']
				except:status='err'
				if status=='dl': break
				try:
					download=j['downloaded']
					progress=j['total_progress']
					seeds=j['peers']
					speed=j['speed_down']
					progressBar.update(progress*10, xt('Предварительная буферизация: '+str(download/1024/1024)+" MB"), "Сиды: "+str(seeds), "Скорость: "+str(speed)+' Kbit/s')
				except: pass
			if progressBar.iscanceled():
				progressBar.update(0)
				progressBar.close()
				GET(stop_url)
				return
		
		progressBar.update(0)
		if __settings__.getSetting("NoAD")=='true':
			progressBar.update(0, '', 'Пропуск рекламы', "")
			xbmc.sleep(1500)
		progressBar.close()

		item = xbmcgui.ListItem(path=url)
		xbmc.sleep(1000)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
		
		for i in range(30):
			xbmc.sleep(1000)
			if xbmc.Player().isPlaying(): break
		
		while not xbmc.abortRequested and xbmc.Player().isPlaying():
						xbmc.sleep(500)
		GET(stop_url)
		return True
	else:
		progressBar.update(0)
		progressBar.close()
		if lst: showMessage('TVFeed','Поток не найден')
		return False

def get_id(url):
	return mfind(url,'serial/','/')



def SetViewMode(n):
	xbmc.sleep(500)
	if n>0:
		xbmc.executebuiltin("Container.SetViewMode(0)")
		for i in range(1,n):
			xbmc.executebuiltin("Container.NextViewMode")


def ASE_start():
	srv=__settings__.getSetting("p2p_serv")#'127.0.0.1'
	prt=__settings__.getSetting("p2p_port")#'6878'
	lnk='http://'+srv+':'+prt+'/webui/api/service?method=get_version&format=jsonp&callback=mycallback'#getstream?id='+CID
	pDialog = xbmcgui.DialogProgressBG()
	resp=GET(lnk)
	if resp != '':
		return False
	else:
		#showMessage('Пазл ТВ', 'Запуск Ace Stream')
		pDialog.create('TVFeed', 'Запуск Ace Stream ...')
		pDialog.update(0, message='Запуск Ace Stream ...')
		start_linux()
		start_windows()
		for i in range (0,10):
			pDialog.update(i*10, message='Запуск Ace Stream ...')
			xbmc.sleep(1500)
			resp=GET(lnk)
			if resp != '':
				pDialog.close()
				return True
		pDialog.close()
		return False

def start_linux():
        import subprocess
        try:
            subprocess.Popen(['acestreamengine', '--client-console'])
        except:
            try:
                subprocess.Popen('acestreamengine-client-console')
            except: 
                try:
                    xbmc.executebuiltin('XBMC.StartAndroidActivity("org.acestream.media")')
                    xbmc.sleep(2000)
                    xbmc.executebuiltin('XBMC.StartAndroidActivity("org.xbmc.kodi")')
                except:
                    return False
        return True
    
def start_windows():
        try:
            import _winreg
            try:
                t = _winreg.OpenKey(_winreg.HKEY_CURRENT_USER, r'Software\AceStream')
            except:
                t = _winreg.OpenKey(_winreg.HKEY_CURRENT_USER, r'Software\TorrentStream')
            path = _winreg.QueryValueEx(t, r'EnginePath')[0]
            os.startfile(path)
            return True
        except:
            return False



def Favorites():
	global Fav
	L=tvfeed.get_fav()
	for id in L:
		info = get_info(id)
		AddItem(info['title'], "Episodes", id, '', len(L))
	Fav=L
	__settings__.setSetting("Favorites",repr(L))


def add(id):
	L=tvfeed.get_fav()
	if id not in L:
		tvfeed.set_fav(id)
		L.append(id)
		__settings__.setSetting("Favorites",repr(L))

def rem(id):
	#if id in L:
	tvfeed.set_fav(id)
	L=tvfeed.get_fav()
	__settings__.setSetting("Favorites",repr(L))

def region():
	noblock=__settings__.getSetting("noblock")
	noblock2=__settings__.getSetting("noblock2")
	if noblock!=noblock2:
		if noblock=='true': status = tvfeed.changeblock('no')
		else: 			    status = tvfeed.changeblock('yes')
		if status == True: noblock = 'false'
		elif status == False: noblock = 'true'
		else: return
		__settings__.setSetting("noblock2", noblock)
		__settings__.setSetting("noblock", noblock)


try:    mode = urllib.unquote_plus(get_params()["mode"])
except: mode = None
try:    url = urllib.unquote_plus(get_params()["url"])
except: url = None
try:    info = eval(urllib.unquote_plus(get_params()["info"]))
except: info = {}
try:    id = str(get_params()["id"])
except: id = '0'
try:    ind = int(get_params()["ind"])
except: ind = 0
try:    name = get_params()["name"]
except: name = 'Noname'

if mode == None:
	region()
	Root()

if mode == "NEW_TOKEN": 
	print "=NEW_TOKEN="
	TOKEN=tvfeed.NEW_TOKEN()
	if TOKEN != '': showMessage('TVFeed', 'Ключ создан.', 3000)

if mode == "RESET_TOKEN": 
	__settings__.setSetting("TOKEN", '')
	__settings__.setSetting("T_NAME", '')


if mode == "Search":
	Search()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Favorites":
	Favorites()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "ADD": add(id)
if mode == "REM": rem(id)

if mode == "Serials":
	Serials()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewSerial")))

if mode == "Genres":
	Genres()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Genre":
	Genre(id, url)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewSerial")))

if mode == "Popular":
	Top()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	#xbmc.sleep(300)
	SetViewMode(int(__settings__.getSetting("ViewSerial")))

if mode == "New":
	New()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewSerial")))

if mode == "Collect":
	Collect(url)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewSerial")))

if mode == "Collection":
	Collection()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)


if mode == "Episodes":
	xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	Episodes(id)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
	SetViewMode(int(__settings__.getSetting("ViewEpisode")))

if mode == "Quality":
	req=Quality(url, id)
	if req:
		xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
		xbmcplugin.endOfDirectory(handle)

if mode == "Quality2":
	Quality(url, id, False)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Play":
	Play(url, id)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Save": Save(id)

if mode == "Update": get_all_serials()


if mode == "update_info":
	update_info(id)


if mode == "Save_strm":
	if __settings__.getSetting("NFO2")=='true': save_film_nfo(id)
	save_strm (url, 0, id)

if mode == "check":
	check()

if mode == "Review":
	review(id)

if mode == "Autoplay":
	autoplay(id)

if mode == "TC":
	print '--- TC ---'
	TC(id, name)

if mode == "TC2":
	TC2(id)

c.close()