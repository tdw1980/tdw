# -*- coding: utf-8 -*-
import xbmc, urllib2, xbmcaddon, uscode, os, time
__settings__ = xbmcaddon.Addon(id='plugin.video.tvfeed')
icon  = os.path.join(__settings__.getAddonInfo('path'), 'icon.png')

siteUrl = 'tvfeed.in'
httpSiteUrl = 'https://' + siteUrl


def rt(x):#('&#39;','’'), ('&#145;','‘')
	L=[('&amp;',"&"),('&#133;','…'),('&#38;','&'),('&#34;','"'), ('&#39;','"'), ('&#145;','"'), ('&#146;','"'), ('&#147;','“'), ('&#148;','”'), ('&#149;','•'), ('&#150;','–'), ('&#151;','—'), ('&#152;','?'), ('&#153;','™'), ('&#154;','s'), ('&#155;','›'), ('&#156;','?'), ('&#157;',''), ('&#158;','z'), ('&#159;','Y'), ('&#160;',''), ('&#161;','?'), ('&#162;','?'), ('&#163;','?'), ('&#164;','¤'), ('&#165;','?'), ('&#166;','¦'), ('&#167;','§'), ('&#168;','?'), ('&#169;','©'), ('&#170;','?'), ('&#171;','«'), ('&#172;','¬'), ('&#173;',''), ('&#174;','®'), ('&#175;','?'), ('&#176;','°'), ('&#177;','±'), ('&#178;','?'), ('&#179;','?'), ('&#180;','?'), ('&#181;','µ'), ('&#182;','¶'), ('&#183;','·'), ('&#184;','?'), ('&#185;','?'), ('&#186;','?'), ('&#187;','»'), ('&#188;','?'), ('&#189;','?'), ('&#190;','?'), ('&#191;','?'), ('&#192;','A'), ('&#193;','A'), ('&#194;','A'), ('&#195;','A'), ('&#196;','A'), ('&#197;','A'), ('&#198;','?'), ('&#199;','C'), ('&#200;','E'), ('&#201;','E'), ('&#202;','E'), ('&#203;','E'), ('&#204;','I'), ('&#205;','I'), ('&#206;','I'), ('&#207;','I'), ('&#208;','?'), ('&#209;','N'), ('&#210;','O'), ('&#211;','O'), ('&#212;','O'), ('&#213;','O'), ('&#214;','O'), ('&#215;','?'), ('&#216;','O'), ('&#217;','U'), ('&#218;','U'), ('&#219;','U'), ('&#220;','U'), ('&#221;','Y'), ('&#222;','?'), ('&#223;','?'), ('&#224;','a'), ('&#225;','a'), ('&#226;','a'), ('&#227;','a'), ('&#228;','a'), ('&#229;','a'), ('&#230;','?'), ('&#231;','c'), ('&#232;','e'), ('&#233;','e'), ('&#234;','e'), ('&#235;','e'), ('&#236;','i'), ('&#237;','i'), ('&#238;','i'), ('&#239;','i'), ('&#240;','?'), ('&#241;','n'), ('&#242;','o'), ('&#243;','o'), ('&#244;','o'), ('&#245;','o'), ('&#246;','o'), ('&#247;','?'), ('&#248;','o'), ('&#249;','u'), ('&#250;','u'), ('&#251;','u'), ('&#252;','u'), ('&#253;','y'), ('&#254;','?'), ('&#255;','y'), ('&laquo;','"'), ('&raquo;','"'), ('&nbsp;',' '), ('&mdash;','-'), ('&quot;','"')]
	for i in L:
		x=x.replace(i[0], i[1])
	x=uscode.decode(x)
	return x

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def showMessage(heading, message, times = 5000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def POST(target, post=None, referer='http://tvfeed.in', AUTH = False):
	if AUTH: auth = authorization()
	else: auth = ''
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'KODI')
		req.add_header('platform', 'kodi-tvfeed')
		if auth!='': req.add_header('Authorization', 'Basic '+auth)
		#req.add_header('X-Requested-With', 'XMLHttpRequest')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		print e
		return ''



def GET(url,Referer = 'https://tvfeed.in', XML = False, AUTH = False):
	if AUTH: auth = authorization()
	else: auth = ''
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'KODI')
		req.add_header('Accept', '*/*')
		req.add_header('Accept-Language', 'ru,en;q=0.9')
		req.add_header('platform', 'kodi-tvfeed')
		req.add_header('Referer', Referer)
		if auth!='': req.add_header('Authorization', 'Basic '+auth)
		if XML: req.add_header('X-Requested-With', 'XMLHttpRequest')
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
	except Exception, e:
		print e
		return ''

def JSON(j):
	null = None
	false = False
	true = True
	try: r=eval(j)
	except: r=''
	if 'detail' in j: 
		try:showMessage('Ошибка', r['detail'])
		except: pass
	return r



def get_top(top='tvfeed'):
	return get_serial(page=1, order='popularity', rev=0)



def translate(id):
	url='https://tvfeed.in/translate/'
	post='q='+id+'&lang=en-ru'
	tr=POST(url, post)[3:-4]
	return tr


def get_streams(PID, quality='hd'):
	ace=GET_CID(PID, quality)
	if ace=='' or ace=='blocked': return []
	srv=__settings__.getSetting("p2p_serv")#'127.0.0.1'
	prt=__settings__.getSetting("p2p_port")#'6878'
	CID=ace.replace('acestream://','')
	if CID=='' or CID=='blocked': 
			showMessage('Контент недоступен.','Подробнее в личном кабинете.')
			return []
	
	lnk='http://'+srv+':'+prt+'/ace/getstream?id='+CID+"&.mp4"
	lnk2='http://'+srv+':'+prt+'/ace/getstream?id='+CID+"&format=json"
	m3u=GET(lnk2)
	L= m3u.splitlines()
	Lt=[]
	Lu=[]
	for e in L:
		if '#EXTINF' in e: Lt.append(e.replace('#EXTINF:-1,',''))
		if 'http:'   in e: Lu.append(e)
	n=0
	LL=[]
	for k in Lt:
		LL.append ({'title':Lt[n], 'url':'acestream://'+CID, 'ind': n})
		n+=1
	return LL

def get_stream(PID, ep, lst=True, quality='hd'):
	ep=str(ep)
	if len (ep)<2: ep='0'+ep
	ace=GET_CID(PID, quality)
	if ace=='': return ''
	elif ace=='blocked': 
		showMessage('Контент недоступен.','Подробнее в личном кабинете.')
		return ''
	print ace
	srv=__settings__.getSetting("p2p_serv")#'127.0.0.1'
	prt=__settings__.getSetting("p2p_port")#'6878'
	CID=ace.replace('acestream://','')
	lnk='http://'+srv+':'+prt+'/ace/getstream?id='+CID+"&.mp4"
	lnk2='http://'+srv+':'+prt+'/ace/getstream?id='+CID+"&format=json"
	m3u=GET(lnk2)
	print m3u
	if 'missing content descriptor' in m3u: return ''
	if '#EXTINF' not in m3u: 
		if int(ep)<2: return lnk2
		else: return ''
	L= m3u.splitlines()
	n=0
	Lt=[]
	Lu=[]
	for e in L:
		n+=1
		if '#EXTINF' in e and 'e'+ep in e.lower(): return L[n]
		
		if '#EXTINF' in e: Lt.append(e.replace('#EXTINF:-1,',''))
		if 'http:' in e: Lu.append(e)
	if __settings__.getSetting("index") == 'true' and len(Lu) >= int(ep): return Lu[int(ep)-1]
	if lst:
		import xbmcgui
		sel = xbmcgui.Dialog()
		r = sel.select("Серия:", Lt)
		if r>-1: return Lu[r]
		else: return ''
	else:
		return ''


#======== API =========

def authorization():
	log=__settings__.getSetting("log")
	pas=__settings__.getSetting("pas")
	
	if log=='' or pas=='': 
		showMessage('ТРЕБУЕТСЯ АВТОРИЗАЦИЯ.','Проверьте логин и пароль.')
		return ''
	import base64
	logpas = log+':'+pas
	sign=base64.b64encode(logpas)
	return sign

def NEW_TOKEN():
	print '=== GET_TOKEN ==='
	
	url = httpSiteUrl+'/api/getlimit/'
	j = GET(url, AUTH = True)
	#print j
	D = JSON(j)
	try:
		remain = D['remain']
		limit = D['limit']
	except:
		showMessage('ОШИБКА ПОЛУЧЕНИЯ КЛЮЧА','Проверьте логин и пароль', 10000)
		#__settings__.setSetting("T_NAME", 'ОШИБКА ПОЛУЧЕНИЯ КЛЮЧА')
		return ''
	if remain<1: 
		#__settings__.setSetting("T_NAME", 'ПРЕВЫШЕН ЛИМИТ КЛЮЧЕЙ')
		showMessage('НЕТ СВОБОДНЫХ КЛЮЧЕЙ','Освободите ключ в личном\n кабинете на http://tvfeed.in', 10000)
		print '!!! TOKEN LIMIT !!!'
		return ''
	
	url = httpSiteUrl+'/api/gettoken/?name=KODI_'+time.strftime('%d-%m-%Y', time.localtime())
	j = GET(url, AUTH = True)
	D = JSON(j)
	TOKEN = D['token']
	T_NAME = eval('u"'+D['name']+'"')+ " "
	__settings__.setSetting("TOKEN", TOKEN)
	__settings__.setSetting("T_NAME", T_NAME)
	return TOKEN


def GET_TOKEN():
	try:    TOKEN = __settings__.getSetting("TOKEN")
	except: TOKEN = ''
	try:    T_NAME = __settings__.getSetting("T_NAME")
	except: T_NAME = ''
	if TOKEN != '' and T_NAME != '': return TOKEN
	else: 
		showMessage('Создайте ключ','В настройках плагина', 10000)
		xbmc.executebuiltin("Addon.OpenSettings(plugin.video.tvfeed)")
	return ''

def search(q):
	import urllib
	LL=[]
	token = GET_TOKEN()
	url = httpSiteUrl+'/api/search/?q='+urllib.quote_plus(q)+'&token='+token
	j = GET(url)
	L = JSON(j)
	for i in L:
		LL.append(i['id'])
	return LL

def get_serial(page=1, order='default', rev=1):
	LL=[]
	token = GET_TOKEN()
	if token == '': return []
	url = httpSiteUrl+'/api/serial/?size=30&reverse='+str(rev)+'&page='+str(page)+'&order='+order+'&token='+token
	j = GET(url)
	L = JSON(j)
	for i in L:
		id = i['id']
		LL.append(id)
	return LL

def get_collection_list():
	LL=[]
	token = GET_TOKEN()
	if token == '': return []
	url = httpSiteUrl+'/api/collection/?token='+token
	#print url
	j=GET(url)
	L=JSON(j)
	for i in L:
		LL.append({'id':i['id'], 'cover':i['get_background_webp'], 'title': i['name']})
	return LL

def get_collection(id):
	LL=[]
	token = GET_TOKEN()
	if token == '': return []
	url = httpSiteUrl+'/api/collection/'+str(id)+'/?token='+token
	#print url
	j=GET(url)
	L=JSON(j)['serial_list']
	
	for i in L:
		id = i['id']
		LL.append(id)
	return LL

def get_genre_list():
	token = GET_TOKEN()
	if token == '': return []
	url = httpSiteUrl+'/api/genre/?token='+token
	#print url
	j=GET(url)
	L=JSON(j)
	return L

def get_genre(id, page=1):
	LL=[]
	token = GET_TOKEN()
	if token == '': return []
	url = httpSiteUrl+'/api/genre/'+str(id)+'/?size=30&order=tvfeed&reverse=1&page='+str(page)+'&token='+token
	print url
	j=GET(url)
	try:L=JSON(j)['serial_list']
	except: return []
	for i in L:
		id = i['id']
		LL.append(id)
	return LL


def get_season_list(id):
	token = GET_TOKEN()
	if token == '': return []
	url = httpSiteUrl+'/api/serial/'+str(id)+'/?token='+token
	#print url
	j=GET(url)
	try:L=JSON(j)['season_list']
	except: return []
	return L

def get_episodes(id):
	LL=[]
	url='http://api.tvmaze.com/shows/'+str(id)+'/episodes'
	j=GET(url)
	L=JSON(j)
	if L=='': return []
	for i in L:
		try:cover = i['image']['medium']
		except: cover = ''
		season   = i['season']
		episode  = i['number']
		airdate  = i['airdate']
		title    = i['name']
		try:plot = i['summary'].replace('<p>','').replace('</p>','')
		except: plot = ''
		LL.append({'cover':cover,'title':title,'season':season,'episode':episode,'plot':plot,'date':airdate})
	return LL

def get_voice(id):
	LL=[]
	token = GET_TOKEN()
	if token == '': return []
	url = httpSiteUrl+'/api/season/'+str(id)+'/?token='+token
	j = GET(url)
	try:L = JSON(j)['player_list']
	except: L=[]
	for i in L:
		title = i['voice']['name']+" "+ i['voice_add']
		LL.append({'id':i['id'], 'title': title, 'cover':i['voice']['get_poster_webp']})
	return LL

def GET_CID(id, quality='hd'):
	LL=[]
	
	token = GET_TOKEN()
	if token == '': return ''
	url = httpSiteUrl+'/api/player/'+str(id)+'/?token='+token
	j = GET(url)
	D = JSON(j)
	if D=='': return ''
	try:	count_sd = int(D['count_series_sd'])
	except: count_sd = 0
	try:	count_hd = int(D['count_series_hd'])
	except: count_hd = 0
	if count_hd == 0 and count_sd == 0: return ''
	if quality=='hd' and count_hd == 0 and count_sd != 0: quality='sd'
	if quality=='sd' and count_sd == 0 and count_hd != 0: quality='hd'
	
	if quality=='hd': return D['code_hd']
	elif quality=='sd': return D['code_sd']


def get_info(id):
	print '-=-=-= get_info =-=-=-'
	token = GET_TOKEN()
	if token == '': return ''
	url = httpSiteUrl+'/api/serial/'+str(id)+'/?token='+token
	#print url
	j=GET(url)
	#print j
	D=JSON(j)
	if D == '': return ''
	type         = 'serial'
	title        =D['name_ru']
	originaltitle=D['name_orig']
	plot         =D['about'].replace('<p>','').replace('</p>','')
	year         =D['year']
	cover        =D['get_poster_webp']
	fanart       =D['get_background_webp']
	tvmaze       =D['tvmaze']
	try:rating   =D['tvfeed']
	except:rating=0
	is_blocked   =D['is_blocked']
	
	countrys =D['country_list']
	country=''
	for c in countrys:
		country+=c['name']+" / "
	country=country[:-3]
	
	genres=D['genre_list']
	genre=''
	for g in genres:
		genre+=g['name']+" / "
	genre=genre[:-3]
	
	info = {"title": rt(title),
			"originaltitle": rt(originaltitle),
			"year": year, 
			"genre": genre,
			"cover": cover,
			"fanart": fanart,
			"plot": rt(plot),
			"type": type,
			"id": str(id),
			"tvmaze":str(tvmaze),
			"rating":rating,
			"blocked":is_blocked
			}
	
	return info


def changeblock(blocked='yes'):
	token = GET_TOKEN()
	url = httpSiteUrl+'/api/changeblock/'
	post= '{"token":"'+token+'", "blocked":"'+blocked+'"}'
	j = POST(url, post, AUTH=True)
	#print j
	if 'is_blocked' in j:
		status=JSON(j)['is_blocked']
		return status
	else:
		return ''

def get_fav():
	LL=[]
	token = GET_TOKEN()
	if token == '': return []
	url = httpSiteUrl+'/api/serial/fav/?token='+token
	j = GET(url)
	print j
	L = JSON(j)
	#print L
	for i in L:
		id = i['id']
		LL.append(id)
	return LL

def set_fav(id):
	token = GET_TOKEN()
	if token == '': return
	post= '{"token":"'+token+'"}'
	url = httpSiteUrl+'/api/serial/'+str(id)+'/fav/'
	j = POST(url, post, AUTH=True)
	print j
	try:msg=JSON(j)['is_like']
	except: return
	print msg
	if msg==True: showMessage('Избранное', 'Добавлено')
	if msg==False: showMessage('Избранное', 'Удалено')