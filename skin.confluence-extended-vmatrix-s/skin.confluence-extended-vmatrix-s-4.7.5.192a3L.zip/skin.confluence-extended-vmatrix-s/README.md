# Confluence Extended Shortcuts is the modernized skin for KODI.
