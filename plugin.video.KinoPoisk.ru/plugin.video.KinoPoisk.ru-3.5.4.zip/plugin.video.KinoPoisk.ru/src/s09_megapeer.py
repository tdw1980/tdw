#!/usr/bin/python
# -*- coding: utf-8 -*-

import urllib, urllib2, time
#import os
#import Cookie

import string, xbmc, xbmcgui, xbmcplugin, urllib, cookielib, xbmcaddon
#-------------------------------


icon = ""
siteUrl = 'megapeer.ru'
httpSiteUrl = 'http://' + siteUrl
#addon = xbmcaddon.Addon(id='plugin.video.KinoPoisk.ru')
#__settings__ = xbmcaddon.Addon(id='plugin.video.KinoPoisk.ru')


__settings__ = xbmcaddon.Addon(id='plugin.video.KinoPoisk.ru')
def unlock(url):
	url='http://127.0.0.1:8095/proxy/'+url
	return url

'''
if __settings__.getSetting("antizapret") == "true":
	try:
		import azpt
		opener = azpt.get_opener()
		urllib2.install_opener(opener)
		print 'antizapret ok'
	except:
		print 'except set proxy'
'''


def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def encod(x):
	try:x=x.decode('Windows-1251')
	except:pass
	try:x=x.encode('utf-8')
	except:pass
	return x


def coder(x):
	x=x.decode('utf-8')
	x=x.encode('Windows-1251')
	return x

def lower(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in range (65,90):
		t=t.replace(chr(i),chr(i+32))
	for i in RUS.keys():
		t=t.replace(i,RUS[i])
	return t


def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "wb")
	fl.write(s)
	fl.close()


def GET(target, referer='http://torrent.by', post=None):
		if __settings__.getSetting("antizapret") == "true": target = unlock(target)
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36 OPR/50.0.2762.67')
		req.add_header('Content-Type', 'application/x-www-form-urlencoded')
		req.add_header('Referer', referer)
		req.add_header('Origin', referer)
		#req.add_header('Content-Type', 'application/x-www-form-urlencoded')
		#req.add_header('Content-Type', 'application/x-www-form-urlencoded')
		
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http#encod()

def clear(s):
	L=['<b>','</b>','</a>','</td>']
	for i in L:
		s=s.replace(i,'')
	s=s.replace(chr(10),'').replace(chr(13),'').replace('\t','').strip()
	return s

def Parser(hp):
	print 'parser'
	Lout=[]
	ss='class="tCenter hl-tr"'
	es='class="med">'
	Lid=[]
	L=mfindal(hp, ss,es)
	L2=[]
	#print len(L)
	for i in L:
		#try:
					#print '---------------------'
					#print i
					url=mfind(i, 'tr-dl dl-stub" href="', '">')
					if 'http' not in url: url = httpSiteUrl+'/'+url
					#print url
					title=mfind(i, 'hl-tags bold" href="', '</a>').replace('<span class="brackets-pair">', '').replace('</span>', '')
					title=title[title.find('">')+2:]
					#print title
					sids = '?'
					#print sids
					
					size = mfind(i, 'gr-button tr-dl dl-stub', '<').replace(chr(10), '').replace(chr(13), '').strip()
					size = size[size.find('">')+2:]
					if 'MB' in size: 					size = size[:size.find('.')]+'MB'
					elif len(size)-size.find('.')>4: 	size = size[:size.find('.')+3]+'GB'
						
					#print size
					if __settings__.getSetting("antizapret") == "true": url = unlock(url)
					Lout.append({"sids":sids, "size":size, "title":title, "url":url, "quality": ""})
					#print Lout
		#except:
					#print '=================================='
					#print i
		#			print 'err'
	return Lout


def Storr(info):
	Lout=[]
	text=coder(info['originaltitle'])
	url=httpSiteUrl+'/browse.php?search='+urllib.quote_plus(text)
	http=encod(GET(url,httpSiteUrl))
	Lout=Parser(http)
	return Lout



class Tracker:
	def __init__(self):
		pass

	def Search(self, info):
		Lout=Storr(info)
		return Lout

#Storr('info')