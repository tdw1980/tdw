#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys, json

siteUrl = 'lordserial44.top'
httpSiteUrl = 'http://' + siteUrl

if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2


def b2s(s):
	if test_torrent(s)==False: return s
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def test_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False


def unlock(url):
	url='http://127.0.0.1:8095/proxy/'+url
	return url

Dc={
"sources":"'sources'",
"hlsUrl":"'hlsUrl'",
"dashUrl":"'dashUrl'",
"mpeg2kUrl":"'mpeg2kUrl'",
"mpeg4kUrl":"'mpeg4kUrl'",
"mpegHighUrl":"'mpegHighUrl'",
"mpegFullHdUrl":"'mpegFullHdUrl'",
"mpegMediumUrl":"'mpegMediumUrl'",
"mpegLowUrl":"'mpegLowUrl'",
"mpegLowestUrl":"'mpegLowestUrl'",
"mpegTinyUrl":"'mpegTinyUrl'",
"title":"'title'",
"thumbUrl":"'thumbUrl'",
"unitedVideoId":"'unitedVideoId'",
"duration":"'duration'",
"name":"'name'",
"season":"'season'",
"episode":"'episode'",
"Number('":"'",
"'),":"',",
"\\u0026":"&",
"\\/":"/",
}

def toJSON(s):
	for i in Dc.keys():
		s=s.replace(i,Dc[i])
	s=s.replace('\n','').replace('\t','').replace('     ',' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return s


def findall(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def deliveryv(url):
	h=GET(url)
	for a in h.splitlines():
		if '-a' in a and '"ru"' in a: return mfind(a.replace('-a1','-v1-a1'),'URI="','"')
	return url

def GET(target, referer='', post=None):
	urllib2.install_opener(urllib2.build_opener())
	#if __settings__.getSetting("antizapret") == "true": target = unlock(target)
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		if referer!='': req.add_header('referer', referer)
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return b2s(http)
	except:
		import requests
		s = requests.session()
		r=s.get(target, timeout=(0.5, 3), verify=False).text
		return r
		print ('GET err')

def GET2(target, referer='', post=None):
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		req.add_header('x-requested-with', 'XMLHttpRequest')
		req.add_header('referer', 'https://gencit.info/lat/836?season=10&episode=13&voice=79')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return b2s(http)


def get_list(url):
	L2=[]
	hp=GET(url)
	if 'seasons:[' in hp:
		j = '['+mfind(hp, 'seasons:[', '}}]}]')+'}}]}]'
		false=False
		true=True
		null = None
		L=eval(j)
		for s in L:
			season = s['season']
			episodes = s['episodes']
			for e in episodes:
				episode = e['episode']
				ep_url = e['hls']
				ep_title = e['title']
				if 'ab.legitcode.ws' in ep_url: ep_url=deliveryv(ep_url)
				L2.append ({"sids":'0',"size":'0', "title":'[ loadbox ] '+ep_title,"url":ep_url})
	else:
		curl = mfind(hp, 'hls: "', '"')
		trl  = mfind(hp, '"names":["', '"]').replace('","',', ').replace('delete','').replace(', ,',',')
		ttl  = mfind(hp, '<title>', '<')
		L2.append ({"sids":'0',"size":'0', "title": '[ tobaco ] '+ttl+' ('+trl+')', "url":curl})
	return L2

def get_list1(url):
	hp=GET(url)
	#print (hp)
	L1=findall(hp,'<div class="th-item"','<span class="fa fa-play"></span>')
	L=[]
	for i in L1:
		link=mfind(i,'href="','"')
		title=mfind(i,'itemprop="position">','<')
		print (link)
		hp2=GET(link)
		link2=mfind(hp2,'<span data-player="','"')
		if 'http' not in link2: link2='http:'+link2
		print (link2)
		L2=get_list2(link2)
		#try: 
		#except: 
		#	L2=[]
		#	print('err videohub')
		L.extend(L2)
	return L

def get_list2(link2):
		L2=[]
		hp3=GET(link2,link2)
		js=json.loads(mfind(hp3,'data-end-skip2="">','<'))
		print (js)
		L=eval(js)
		for j in L:
			#print (j)
			try:    ttl=j['name']+"_s"+j['season']+"e"+j['episode']
			except: ttl=j['name']
			curl=j['sources']['hlsUrl']
			print(ttl)
			L2.append ({"sids":'0',"size":'0', "title": '[ videohub ] '+ttl, "url":curl})
		return L2


class Tracker:
	def Search(self, info):
		id=info['title']
		url=httpSiteUrl+'/?do=search&subaction=search&story='+quote(id)
		Lout=get_list1(url)
		return Lout

#print(GET('https://gencit.info/player/responce.php?id=836&season=10&episode=14&voice=79&uniqueid=255605','https://gencit.info/player/responce.php?id=836&season=10&episode=14&voice=79&uniqueid=255605'))
#print(get_list2('https://player.cdnvideohub.com/svplayer?partner=29&kid=749562'))
print(get_list1('https://lordserials.fan/index.php?do=search&subaction=search&story=терминатор'))