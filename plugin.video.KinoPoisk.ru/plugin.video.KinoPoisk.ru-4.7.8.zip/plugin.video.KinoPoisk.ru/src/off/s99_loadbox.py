#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys

siteUrl = 'api.loadbox.ws'
siteUrl = 'www.loadbox.ws'
httpSiteUrl = 'http://' + siteUrl

if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2


def b2s(s):
	if test_torrent(s)==False: return s
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def test_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False


def unlock(url):
	url='http://127.0.0.1:8095/proxy/'+url
	return url


def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def deliveryv(url):
	h=GET(url)
	for a in h.splitlines():
		if '-a' in a and '"ru"' in a: return mfind(a.replace('-a1','-v1-a1'),'URI="','"')
	return url

def GET(target, referer='', post=None):
	urllib2.install_opener(urllib2.build_opener())
	#if __settings__.getSetting("antizapret") == "true": target = unlock(target)
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return b2s(http)
	except:
		print ('GET err')

#seasons:[{"season":1,"blocked":false,"episodes":[{"episode":"1","id":653525,"videoKey":1046833,"dash":"https://hye1eaipby4w.takedwn.ws/01_24/25/16/JRPNIMD7/1046833.mpd","hls":"https://hye1eaipby4w.takedwn.ws/01_25_24/01/25/09/Y476KPDJ/3TACOUSW.mp4/master.m3u8","audio":{"names":["Рус. Оригинальный"],"order":[0]},"cc":[{"url":"https://hye1eaipby4w.takedwn.ws/01_25_24/01/25/08/UWGWNO76/GC7WRVKR.vtt","name":"Рус. SDH - 1"},{"url":"https://hye1eaipby4w.takedwn.ws/01_25_24/01/25/08/35E2GWG4/M6XG74OC.vtt","name":"Рус. полные - 2"}],"duration":3163,"title":"Иные (1 сезон) - 1 серия","download":"","sections":[],"poster":"https://img.imgilall.me/movies/video/6/5/3/5/2/5/0/0/0/0/800x450_653525.jpg?t=1706191458","preview":{"src":"https://img.zcvh.net/1046833/desktop/thumb-${spriteNum}.webp"}},{"episode":"2","id":653537,"videoKey":1047035,"dash":"https://hye1eaipby4w.takedwn.ws/01_24/25/15/OWRPJFAA/1047035.mpd","hls":"https://hye1eaipby4w.takedwn.ws/01_25_24/01/25/13/7KN7HEMY/ZH4QRRHW.mp4/master.m3u8","audio":{"names":["Рус. Оригинальный","delete"],"order":[0,1]},"cc":[{"url":"https://hye1eaipby4w.takedwn.ws/01_25_24/01/25/10/ZSWJBU3D/AIFFM3WH.vtt","name":"Рус. полные - 1"}],"duration":3221,"title":"Иные (1 сезон) - 2 серия","download":"","sections":[],"poster":"https://img.imgilall.me/movies/video/6/5/3/5/3/7/0/0/0/0/800x450_653537.jpg?t=1706188817","preview":{"src":"https://img.zcvh.net/1047035/desktop/thumb-${spriteNum}.webp"}},{"episode":"3","id":656109,"videoKey":1049506,"dash":"https://hye1eaipby4w.takedwn.ws/02_24/01/14/AD4L7EAH/1049506.mpd","hls":"https://hye1eaipby4w.takedwn.ws/02_01_24/02/01/08/ZO2YZ5XK/O34BOVVN.mp4/master.m3u8","audio":{"names":["Рус. Оригинальный"],"order":[0]},"cc":[{"url":"https://hye1eaipby4w.takedwn.ws/02_01_24/02/01/08/OOXE62O4/WWBN7UGY.vtt","name":"Рус. SDH - 1"},{"url":"https://hye1eaipby4w.takedwn.ws/02_01_24/02/01/08/DCMOEIKV/5GY72AS2.vtt","name":"Рус. полные - 2"}],"duration":3030,"title":"Иные (1 сезон) - 3 серия","download":"","sections":[],"poster":"https://img.imgilall.me/movies/video/6/5/6/1/0/9/0/0/0/0/800x450_656109.jpg?t=1706790213","preview":{"src":"https://img.zcvh.net/1049506/desktop/thumb-${spriteNum}.webp"}},{"episode":"4","id":658012,"videoKey":1051477,"dash":"https://hye1eaipby4w.takedwn.ws/02_24/08/13/WW4YJY5I/1051477.mpd","hls":"https://hye1eaipby4w.takedwn.ws/02_08_24/02/08/09/F246ZXDA/XB273FWK.mp4/master.m3u8","audio":{"names":["Рус. Оригинальный"],"order":[0]},"cc":[{"url":"https://hye1eaipby4w.takedwn.ws/02_08_24/02/08/08/CDYIC3PY/4V6LBO2B.vtt","name":"Рус. SDH - 1"},{"url":"https://hye1eaipby4w.takedwn.ws/02_08_24/02/08/08/VDMLXAAT/UTQNDDCU.vtt","name":"Рус. полные - 2"}],"duration":3226,"title":"Иные (1 сезон) - 4 серия","download":"","sections":[],"poster":"https://img.imgilall.me/movies/video/6/5/8/0/1/2/0/0/0/0/800x450_658012.jpg?t=1707390328","preview":{"src":"https://img.zcvh.net/1051477/desktop/thumb-${spriteNum}.webp"}},{"episode":"5","id":660403,"videoKey":1054018,"dash":"https://hye1eaipby4w.takedwn.ws/02_24/15/13/BGKUILHS/1054018.mpd","hls":"https://hye1eaipby4w.takedwn.ws/02_15_24/02/15/09/2KZAGSEU/4CFX3ND5.mp4/master.m3u8","audio":{"names":["Рус. Оригинальный","delete"],"order":[0,1]},"cc":[{"url":"https://hye1eaipby4w.takedwn.ws/02_15_24/02/15/09/ACR6FORL/KA7D4GOB.vtt","name":"Рус. SDH - 1"},{"url":"https://hye1eaipby4w.takedwn.ws/02_15_24/02/15/09/R6EHC547/Z4VQZ6TE.vtt","name":"Рус. полные - 2"}],"duration":3063,"title":"Иные (1 сезон) - 5 серия","download":"","sections":[],"poster":"https://img.imgilall.me/movies/video/6/6/0/4/0/3/0/0/0/0/800x450_660403.jpg?t=1708580529","preview":{"src":"https://img.zcvh.net/1054018/desktop/thumb-${spriteNum}.webp"}},{"episode":"6","id":663032,"videoKey":1057247,"dash":"https://hye1eaipby4w.takedwn.ws/02_24/22/15/OBA6Q432/1057247.mpd","hls":"https://hye1eaipby4w.takedwn.ws/02_22_24/02/22/10/AZBM4Z2E/62KMT2CX.mp4/master.m3u8","audio":{"names":["Рус. Оригинальный"],"order":[0]},"cc":[{"url":"https://hye1eaipby4w.takedwn.ws/02_22_24/02/22/07/EC2KAUYT/FZ7M6ZWZ.vtt","name":"Рус. SDH - 1"},{"url":"https://hye1eaipby4w.takedwn.ws/02_22_24/02/22/07/6CGNNO3J/OIZZNSM3.vtt","name":"Рус. полные - 2"}],"duration":3168,"title":"Иные (1 сезон) - 6 серия","download":"","sections":[],"poster":"https://img.imgilall.me/movies/video/6/6/3/0/3/2/0/0/0/0/800x450_663032.jpg?t=1708608943","preview":{"src":"https://img.zcvh.net/1057247/desktop/thumb-${spriteNum}.webp"}}]}]

def get_list(url):
	L2=[]
	hp=GET(url)
	if 'seasons:[' in hp:
		j = '['+mfind(hp, 'seasons:[', '}}]}]')+'}}]}]'
		false=False
		true=True
		null = None
		L=eval(j)
		for s in L:
			season = s['season']
			episodes = s['episodes']
			for e in episodes:
				episode = e['episode']
				ep_url = e['hls']
				ep_title = e['title']
				if 'ab.deliveryv.ws' in ep_url: ep_url=deliveryv(ep_url)
				L2.append ({"sids":'0',"size":'0', "title":'[ loadbox ] '+ep_title,"url":ep_url})
	else:
		curl = mfind(hp, 'hls: "', '"')
		trl  = mfind(hp, '"names":["', '"]').replace('","',', ').replace('delete','').replace(', ,',',')
		ttl  = mfind(hp, '<title>', '<')
		L2.append ({"sids":'0',"size":'0', "title": '[ loadbox ] '+ttl+' ('+trl+')', "url":curl})
	return L2


class Tracker:
	def Search(self, info):
		id=info['id']
		url=httpSiteUrl+'/embed/kp/'+id
		Lout=get_list(url)
		return Lout

#print(get_list('http://api.loadbox.ws/embed/kp/5368058'))