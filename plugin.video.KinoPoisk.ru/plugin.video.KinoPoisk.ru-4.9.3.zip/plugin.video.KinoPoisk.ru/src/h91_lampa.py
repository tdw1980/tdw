#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys, json, time
Lprov = ["vibix", "videodb","vdbmovies","kinotochka","filmix","filmixtv","collaps","hdvb","veoveo","aniliberty","animevost","animedia","animebesst","anilibria","animelib","animego"]#,"kinobase","rutubemovie","rezka","kinopub","lumex","fxapi","redheadsound","rhsprem","kodik","remux","kinoukr","rc/filmix","rc/fxapi","rc/rhs","vcdn","videocdn","mirage","alloha"

prov = Lprov[1]#"kinotochka", "vdbmovies", "collaps", "hdvb", "filmix", "filmixtv" ,"veoveo"
serv = 'http://77.238.239.103:12133/lite/'
D_UA='|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 OPR/77.0.4054.203'

if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2


def b2s(s):
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def is_libreelec():
	try:
		if os.path.isfile('/etc/os-release'):
			f = open('/etc/os-release', 'r')
			str = f.read()
			f.close()
			if "LibreELEC" in str and "Generic" in str: return True
	except: pass
	return False

def rt(s):
	if sys.version_info.major > 2: return s
	try:s=s.decode('utf-8')
	except: pass
	if not is_libreelec():
		try:s=s.decode('windows-1251')
		except: pass
	try:s=s.encode('utf-8')
	except: pass
	return s

def test_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False

def CRC32(buf):
		import binascii
		if sys.version_info.major > 2: buf = (binascii.crc32(buf.encode('utf-8')) & 0xFFFFFFFF)
		else: buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		r=str("%08X" % buf)
		return r



Lthread=[]
LtID=''
def update_Lt(d, id):
	global Lthread, LtID
	if d == 'reset':
		Lthread=[]
		LtID = id
	elif LtID == id:
		Lthread.append(d)

from threading import Thread
class MyThread(Thread):
	def __init__(self, param):
		Thread.__init__(self)
		self.param = param
	
	def run(self):
		info=self.param['info']
		id=self.param['id']
		pr=self.param['pr']
		fn=self.param['fn']
		try:
			#exec ("global skp; import "+i[:-3]+"; skp="+i[:-3]+".Tracker()")
			#L = skp.Search(self.param['info'])
			if fn=='movie': L=get_movie_prov(info, pr)
			elif fn=='serial': L=get_serial_prov(info, pr)
			elif fn=='episodes': 
				L=[{'list':get_episodes(info['url']), 'info':info}]
		except: 
			L=[]
		update_Lt(L, self.param['id'])

def create_thread(param):
		my_thread = MyThread(param)
		my_thread.start()


def RUN(fn, info):
		L=[]
		tid = time.time()
		update_Lt('reset', tid)
		total_threads=0
		time.sleep(0.1)
		n=0
		for pr in Lprov:
				create_thread({'fn': fn, 'info':info, 'pr':pr, 'id':tid})
				total_threads+=1
				time.sleep(0.2)
		
		tr_time = 15
		for t in range(tr_time):
				if len(Lthread) == total_threads: break
				time.sleep(1)
		
		for Lst in Lthread:
				L.extend(Lst)
		return L

def EPD(Ls, info):
		L=[]
		tid = time.time()
		update_Lt('reset', tid)
		total_threads=0
		time.sleep(0.1)
		n=0
		for si in Ls:
				
				pr = si['pr']
				t = si['translate']
				q = si['quality']
				s = int(si['season'])
				url = si['url']
				
				create_thread({'fn': 'episodes', 'info':si, 'pr':pr, 'id':tid})
				total_threads+=1
				time.sleep(0.1)
		
		tr_time = 25
		for t in range(tr_time):
				if len(Lthread) == total_threads: break
				time.sleep(1)
		
		for Lst in Lthread:
				L.extend(Lst)
		return L

def add_ch(id, D):
	try:
		import settings
		settings.set(prov+'_ch_'+id, {'ch':D, 'tm': time.time()})
	except: pass


def get_ch(id):
	try:
		import settings
		Dch  = settings.get(prov+'_ch_'+id)
		D  = Dch['ch']
		tm = Dch['tm']
		if (time.time()-tm<3600*3): return D
		else: return None
	except:
		return None

def unlock(url):
	try:
		import xbmcaddon
		tam_settings = xbmcaddon.Addon(id='plugin.video.tam')
		tam_port = int(tam_settings.getSetting("serv_port"))
	except:
		tam_port = 8095
	url='http://127.0.0.1:'+str(tam_port)+'/proxy/'+url
	return url


def findall(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	if e=='': r2=r
	else: r2=r[:r.find(e)]
	return r2


def GET2(target, referer='', post=None):
		import requests
		s = requests.session()
		r=s.get(target, timeout=(0.6, 4), verify=False).text
		return r


def GET(target, referer='', post=None):
	print (target)
	urllib2.install_opener(urllib2.build_opener())
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return b2s(http)
	except:
		return GET2(target)

def is_libreelec():
	try:
		if os.path.isfile('/etc/os-release'):
			f = open('/etc/os-release', 'r')
			str = f.read()
			f.close()
			if "LibreELEC" in str and "Generic" in str: return True
	except: pass
	return False

def rt(s):
	if sys.version_info.major > 2: return s
	try:s=s.decode('utf-8')
	except: pass
	if not is_libreelec():
		try:s=s.decode('windows-1251')
		except: pass
	try:s=s.encode('utf-8')
	except: pass
	return s

def filtr(s=''):
	L=['[Ukr','[UA]', 'UKR', ' Ukr', 'Укра', 'укра', u'Укра', u'укра', 'English', '(EN)','(ENG)', '(UK)','[ENG]']
	try:
		for i in L:
			if i in rt(s): return False
			if i in s: return False
	except: pass
	return True


def get_movie_prov(info={}, pr=prov):
	Lr=[]
	try:
		en_title = quote(info['originaltitle'])
		ru_title = quote(info['title'])
		year = str(info['year'])
		if '-' in year: year=year.split('-')[0]
		kp_id = info['id']
		url=serv+pr+'?serial=0&kinopoisk_id='+kp_id+'&original_title='+en_title+'&title='+ru_title+'&year='+year+'&rjson=True'#&kinopoisk_id=5457899&title=Дикий%20робот&original_language=en&source=tmdb&clarification=0'
	except:
		url=serv+pr+'?id=1184918&imdb_id=tt29623480&kinopoisk_id=5457899&title=Дикий%20робот&original_title=The%20Wild%20Robot&serial=0&original_language=en&year=2024&source=tmdb&clarification=0&rjson=True'
		url=serv+pr+'?imdb_id=tt0088247&kinopoisk_id=507&title=%D0%A2%D0%B5%D1%80%D0%BC%D0%B8%D0%BD%D0%B0%D1%82%D0%BE%D1%80&original_title=The%20Terminator&serial=0&year=1984&rjson=True'
	
	j=GET(url)
	try: D=json.loads(j)
	except: return []
	type = D['type']
	if type == 'movie':
		L=D['data']
		for i in L:
			method = i['method']
			if method == 'play':
				try:
					t=rt(i['translate'])
					if filtr(t):
						try: q = rt(i['maxquality'])
						except: q = ''
						ttl = rt(i['title'])
						if t not in ttl: ttl=ttl+' ('+t+')'
						try:
							stream = i['url']
							if q=='' and 'quality' in i.keys(): 
								q=list(i['quality'].keys())[0]
							Lr.append ({'pr':pr, "sids":'0',"size":'0', "title": '[ '+pr+' ] '+ttl+' '+q, "url":stream})
						except:
							Lq=i['quality']
							for q in Lq.keys():
								stream = Lq[q]
								if '360' not in q: Lr.append ({'pr':pr, "sids":'0',"size":'0', "title": '[ '+pr+' ] '+ttl+' '+q, "url":stream})
				except: pass
	return Lr

def get_movie(info={}):
	try: imdb_id = str(info['imdb_id'])
	except: imdb_id =''
	try: kp_id = str(info['id'])
	except: kp_id = ''
	
	if imdb_id =='': 
		imdb_id = get_imdb_id(kp_id)
		info['imdb_id'] = imdb_id
	if kp_id =='':   
		kp_id = get_kp_id(imdb_id)
		info['id'] = kp_id
	
	'''
	L=[]
	for pr in Lprov:
		Lr=get_movie_prov(info, pr)
		#except: Lr=[]
		print(Lr)
		L.extend(Lr)
	'''
	
	L=RUN('movie', info)
	
	return L

def get_kp_id(imdb_id):
	try:
		url='https://api.manhan.one/externalids?serial=1&imdb_id='+imdb_id
		j=GET(url)
		D=json.loads(j)
		kp_id=D['kinopoisk_id']
		return kp_id
	except:
		return ''

def get_imdb_id(kp_id):
	try:
		url='https://api.manhan.one/externalids?serial=1&kinopoisk_id='+kp_id
		j=GET(url)
		D=json.loads(j)
		imdb_id=D['imdb_id']
		return imdb_id
	except:
		return ''

def select_similar(L, info):
	print ('select_similar')
	en_title = info['originaltitle']#'Wednesday'#
	ru_title = info['title']#'Уэнздей'#
	try: 
		year1 = int(info['year'])#2022#
		year2 = year1+1
	except: 
		year1 = 0
		year2 = 0
	n=0
	for i in L:
		print (i)
		title = rt(i['title'])
		sm_url = i['url']
		year = i['year']
		if '&rjson=True' not in sm_url: sm_url=sm_url+'&rjson=True'
		if ru_title in title: n+=1
		if en_title in title: n+=1
		if year == year1: n+=1
		if year == year2: n+=1
		print (n)
		if n>1: return sm_url
	print (n)
	return ''


def get_serial_prov(info={},pr=prov):
	Lr=[]
	try:
		en_title = quote(info['originaltitle'])
		ru_title = quote(info['title'])
		year = str(info['year'])
		if '-' in year: year=year.split('-')[0]
			
		try:imdb_id = str(info['imdb_id'])
		except: imdb_id =''
		try: kp_id = str(info['id'])
		except: kp_id = ''
		
		if imdb_id =='': imdb_id = get_imdb_id(kp_id)
		if kp_id =='':   kp_id = get_kp_id(imdb_id)
		
		url=serv+pr+'?serial=1&imdb_id='+imdb_id+'&original_title='+en_title+'&title='+ru_title+'&year='+year+'&kinopoisk_id='+kp_id+'&rjson=True'#&title=Дикий%20робот&original_language=en&source=tmdb&clarification=0'
	except:
		year = '2025'
		url=serv+pr+'?title=%D0%98%D0%B7%D0%B2%D0%BD%D0%B5&original_title=FROM&serial=1&original_language=en&year=2022&kinopoisk_id=4476885&rjson=True'
		#url=serv+pr+'?serial=1&imdb_id=tt13443470&original_title=Wednesday&title=Уэнздей&year=2022&kinopoisk_id=4365427&rjson=True'
		url='http://77.238.239.103:12133/lite/aniliberty?imdb_id=tt17069148&kinopoisk_id=4870795&title=Дни%20Сакамото&original_title=SAKAMOTO%20DAYS&serial=1&year=2025&rjson=True'
		url='http://77.238.239.103:12133/lite/aniliberty?rjson=True&title=Ванпанчмен&releases=8335'
	#print (url)
	j=GET(url)
	try: D=json.loads(j)
	except: return []
	type = D['type']
	
	if type == 'similar':
		Lsm = D['data']
		url = select_similar(Lsm, info)
		if url !='': 
			jsm=GET(url)
			D=json.loads(j)
			type = D['type']
		else: return []
	
	if type == 'season':
		Ls=D['data']
		try: q = rt(D['maxquality'])#.encode('utf-8')
		except: q = ''
		for si in Ls:
			#try:
			method = si['method']
			if method == 'link':
				s=si['id']
				S=str(s)
				if len(S)==1: S='0'+S
				s_url = si['url']
				if '&rjson=True' not in s_url: s_url=s_url+'&rjson=True'
				
				jt=GET(s_url)
				Dt=json.loads(jt)
				type2 = Dt['type']
				if type2 == 'episode':
					if 'voice' in Dt.keys():
						Lt=Dt['voice']
						for ti in Lt:
							method2 = ti['method']
							if method == 'link':
								t = rt(ti['name'])#.encode('utf-8')
								t_url = ti['url']
								if '&rjson=True' not in t_url: t_url=t_url+'&rjson=True'
								if filtr(t):
									#Lr.append ({"sids":'0',"size":'0', "title": '[ '+prov+' ] s'+S+' '+t+' '+q, "url":"lampa_"+prov+"_season:"+link})
									t_url = "lampa_season:"+t_url
									Lr.append ({'pr':pr, "sids":'0',"size":'0', "translate":t, "season":s, "quality":q, "title": '[ '+pr+' ] s'+S+' '+t+' '+q, "url":t_url})
					else:
						t = ''
						t_url = s_url
						t_url = "lampa_season:"+t_url
						Lr.append ({'pr':pr, "sids":'0',"size":'0',"translate":t, "season":s, "quality":q, "title": '[ '+pr+' ] s'+S+' '+t+' '+q, "url":t_url})
			#except: pass
	elif type == 'episode':
		if 'voice' not in D.keys():
						i = D['data'][0]
						s = i['s']
						S = str(s)
						if len(S)==1: S='0'+S
						try: q = rt(D['quality'].keys()[0])
						except: q = ''
						t = pr
						t_url = url
						t_url = "lampa_season:"+t_url
						Lr.append ({'pr':pr, "sids":'0',"size":'0',"translate":t, "season":s, "quality":q, "title": '[ '+pr+' ] s'+S+' '+t+' '+q, "url":t_url})
			
	return Lr

#print(get_serial_prov('','aniliberty'))

def get_serial(info={}):
	
	try: imdb_id = str(info['imdb_id'])
	except: imdb_id =''
	try: kp_id = str(info['id'])
	except: kp_id = ''
	
	if imdb_id =='': 
		imdb_id = get_imdb_id(kp_id)
		info['imdb_id'] = imdb_id
	if kp_id =='':   
		kp_id = get_kp_id(imdb_id)
		info['id'] = kp_id
	'''
	L=[]
	for pr in Lprov:
		try: Lr=get_serial_prov(info, pr)
		except: Lr=[]
		L.extend(Lr)
	'''
	L=RUN('serial', info)
	
	return L

#for pr in Lprov:
#	try: print (pr+'    -\t'+str(len(get_serial({}, pr))))
#	except: print (pr+'    -\t ERR')


def get_episodes(t_url):
	Lr=[]
	t_url=t_url.replace('lampa_season:','')#'+prov+'_
	je=GET(t_url)
	
	De=json.loads(je)
	try: type = De['type']
	except: type = 'error'
	if type == 'episode':
		Le=De['data']
		for ei in Le:
			method = ei['method']
			if method == 'play' or method == 'call':
				e = ei['e']
				ttl = rt(ei['title'])#.encode('utf-8')
				if 'url' in ei.keys(): 
					if method == 'play': stream = ei['url']
					if method == 'call': stream = ei['stream']
					if 'quality' in ei.keys(): 
						q=list(ei['quality'].keys())[0]
						Lr.append ({"sids":'0',"ep":e, "title": ttl, "url":stream, 'quality':q})
					else:
						Lr.append ({"sids":'0',"ep":e, "title": ttl, "url":stream})
					
				elif 'quality' in ei.keys(): 
					quality = ei['quality']
					for q in quality.keys():
						stream=quality[q]
						Lr.append ({"sids":'0',"ep":e, "title": ttl, "url":stream, 'quality':q})
						#print ({"sids":'0',"ep":e, "title": ttl, "url":stream, "quality":q})
	return Lr

#get_episodes('http://77.238.239.103:12133/lite/aniliberty?rjson=True&title=Ванпанчмен&releases=8335&rjson=True')

def get_serial_episodes(info={}):
	id=str(info['id'])
	Dc=get_ch(id)
	if Dc!=None: return Dc

	L2=[]
	D={}
	L=get_serial(info)
	for si in L:
		pr = si['pr']
		t = si['translate']
		q = si['quality']
		s = int(si['season'])
		url = si['url']
		L2=get_episodes(url)
		#L2=RUN('episodes', {'url':url})
		if s not in D.keys(): D[s]={}
		for i in L2:
			try:
				if 'quality' in i.keys(): q = i['quality']
				stream = i['url']
				e=int(i['ep'])
				if e not in D[s].keys(): D[s][e]=[]
				#print ({'translate':t,'quality':q, 'url':stream})
				D[s][e].append({'translate':'[ '+pr+' ] '+t,'quality':q, 'url':stream})
			except: pass
	
	if D!={}: add_ch(id, D)
	return D


def get_serial_episodes_old(info={}):
	id=str(info['id'])
	Dc=get_ch(id)
	if Dc!=None: return Dc

	L2=[]
	D={}
	
	Ld=EPD(get_serial(info), info)
	for d in Ld:
		
		si = d['info']
		
		pr = si['pr']
		t = si['translate']
		q = si['quality']
		s = int(si['season'])
		#url = si['url']
		L2 = d['list']
		#L2=get_episodes(url)
		
		if s not in D.keys(): D[s]={}
		for i in L2:
			try:
				if 'quality' in i.keys(): q = i['quality']
				stream = i['url']
				e=int(i['ep'])
				if e not in D[s].keys(): D[s][e]=[]
				#print ({'translate':t,'quality':q, 'url':stream})
				D[s][e].append({'translate':'[ '+pr+' ] '+t,'quality':q, 'url':stream})
			except: pass
	
	if D!={}: add_ch(id, D)
	return D


#print (get_serial_episodes())

class Tracker:
	def Search(self, info):
		id=info['id']
		Dc=get_ch(id)
		if Dc!=None: return Dc
		#print (info)
		Lout = []
		if info['type']=='': Lout = get_movie(info)
		else:                Lout = get_serial(info)
		
		if Lout != []: add_ch(id, Lout)
		return Lout

		
	def Episodes(self, url):
		id=CRC32(url)
		Dc=get_ch(id)
		if Dc!=None: return Dc
		
		Lout = []
		Lout = get_episodes(url)
		
		if Lout != []: add_ch(id, Lout)
		return Lout

