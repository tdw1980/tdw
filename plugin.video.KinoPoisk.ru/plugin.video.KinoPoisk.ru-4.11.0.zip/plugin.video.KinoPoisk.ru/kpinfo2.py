# -*- coding: utf-8 -*-
import json
import requests
import sys
import time
import random

CITY_ID = 1
COUNTRY_ID = 2
null = None
false = False
true = True

UAL=[
'"Android Tablet client (T40 PRO_ROW; Android 11; api30), ru.kinopoisk/6.112.1 (31733)"',
'"Android (Mi13; Android 12; api30), ru.kinopoisk/6.112.1 (31733)"',
'"Android client (HWT Neo; Android 11; api30), ru.kinopoisk/6.112.1 (31733)"',
]

random.shuffle(UAL)
print (UAL[0])

headers={
'accept': 'application/json',
'user-agent': UAL[0],
'content-type': 'application/json; charset=utf-8',
'accept-encoding':'gzip',
'x-yandex-appinfo': 'eyJ2ZXJzaW9uIjoiNi4xMTIuMSJ9',
'service-id': '76',
'countryid': str(COUNTRY_ID),
'cityid': str(CITY_ID),
'x-preferred-language': 'ru'
}

def kp_get_info_by_id(kp_id):
    qdata = {'operationName': 'MovieDetails', 'variables': {'movieId': kp_id, 'countryId': COUNTRY_ID, 'cityId': CITY_ID, 'sequelsAndPrequelsLimit': 10, 'relatedMoviesLimit': 10, 'actorsLimit': 12, 'trailersLimit': 10, 'creatorsPerGroupLimit': 12, 'imagesPerGroupLimit': 10, 'factsLimit': 10, 'bloopersLimit': 10, 'criticReviewsLimit': 10, 'userReviewsLimit': 10, 'userRecommendationMoviesLimit': 10, 'postsLimit': 10, 'premieresLimit': 10, 'isAppendUserData': False, 'isInternationalUserData': False, 'movieListsLimit': 9, 'streamsLimit': 10, 'sequelsAndPrequelsRelationsOrder': ['AFTER', 'BEFORE'], 'relatedMoviesRelationsOrder': ['REMAKE', 'VERSION', 'SPOOFS', 'SPOOFED', 'SPIN_OFF', 'SPUN_OFF_FROM', 'REFERENCES', 'REFERENCES_IN', 'EDITED_FROM', 'EDITED_INTO', 'ALTERNATE_LANGUAGE'], 'friendsVotesLimit': 10, 'isTariffSubscriptionActive': True, 'mediaBillingTarget': 'kp-mobile-sdk-android-mooviecard', 'checkSilentInvoiceAvailability': True, 'isInternational': False, 'skipTrailers': False}, 'query': 'query MovieDetails($movieId: Long!, $countryId: Long!, $cityId: Int!, $sequelsAndPrequelsLimit: Int!, $relatedMoviesLimit: Int!, $actorsLimit: Int!, $trailersLimit: Int!, $creatorsPerGroupLimit: Int!, $imagesPerGroupLimit: Int!, $factsLimit: Int!, $bloopersLimit: Int!, $criticReviewsLimit: Int!, $userReviewsLimit: Int!, $userRecommendationMoviesLimit: Int!, $postsLimit: Int!, $premieresLimit: Int!, $isAppendUserData: Boolean!, $isInternationalUserData: Boolean!, $movieListsLimit: Int!, $streamsLimit: Int!, $sequelsAndPrequelsRelationsOrder: [RelatedMovieType!]!, $relatedMoviesRelationsOrder: [RelatedMovieType!]!, $friendsVotesLimit: Int!, $isTariffSubscriptionActive: Boolean!, $mediaBillingTarget: String!, $checkSilentInvoiceAvailability: Boolean!, $isInternational: Boolean!, $skipTrailers: Boolean!) { movie(id: $movieId) { __typename id contentId url userData @include(if: $isAppendUserData) { __typename ... movieFullUserDataFragment } editorAnnotation gallery { __typename posters { __typename ... moviePostersFragment kpVertical: vertical(override: DISABLED) @skip(if: $isInternational) { __typename ... imageFragment } } covers { __typename square { __typename ... imageFragment } horizontal { __typename ... imageFragment } } logos { __typename rightholderForPoster { __typename ... imageFragment } rightholderForCover(filter: {formFactor: S, theme: LIGHT}) { __typename image { __typename ... imageFragment } } } } ... movieLogoFragment rating @skip(if: $isInternational) { __typename ... fullRatingFragment } title { __typename ... titleFragment } ... movieDetailsImagesFragment @skip(if: $isInternational) viewOption { __typename ... viewOptionDetailedFragment } releaseOptions { __typename ... movieReleaseOptionsFragment } ... movieDetailsCreatorsFragment @skip(if: $isInternational) countries { __typename ... countryFragment } ...movieDetailsDurationFragment genres { __typename ... genreFragment } restriction { __typename ... restrictionFragment } distribution @skip(if: $isInternational) { __typename ... distributionFragment } kpSynopsis: synopsis(override: DISABLED) @skip(if: $isInternational) ottSynopsis: synopsis(override: OTT_WHEN_EXISTS) shortDescription isTicketsAvailableByKpCityId(kpCityId: $cityId) @skip(if: $isInternational) ... movieDetailsActorsFragment ... movieDetailsWatchabilityFragment @skip(if: $isInternational) mainTrailer @skip(if: $skipTrailers) { __typename ... trailerFragment } trailers(limit: $trailersLimit, orderBy: IS_MAIN_MAKE_DATE_DESC) @skip(if: $skipTrailers) { __typename total items { __typename ... trailerFragment } } facts: trivias(type: FACT, limit: $factsLimit) @skip(if: $isInternational) { __typename total items { __typename ... triviaFragment } } bloopers: trivias(type: BLOOPER, limit: $bloopersLimit) @skip(if: $isInternational) { __typename total items { __typename ... triviaFragment } } ... movieTopsFragment ... movieDetailsSequelsAndPrequelsFragment @skip(if: $isInternational) ... movieDetailsRelatedMoviesFragment @skip(if: $isInternational) ... movieOttFragment ... movieOttTrailersFragment ... movieYearsFragment ... on VideoInterface @skip(if: $isInternational) { kpYear: productionYear(override: DISABLED) } ... movieEpisodesFragment posts: post(mainOnly: true, limit: $postsLimit) @skip(if: $isInternational) { __typename total items { __typename ... postFragment } } ... reviewsFragment @skip(if: $isInternational) ... movieDetailsAwardsFragment @skip(if: $isInternational) dvdSales @skip(if: $isInternational) { __typename totalAmount { __typename ... moneyAmountFragment } } boxOffice @skip(if: $isInternational) { __typename budget { __typename ... moneyAmountFragment } marketing { __typename ... moneyAmountFragment } rusBox { __typename ... moneyAmountFragment } usaBox { __typename ... moneyAmountFragment } worldBox { __typename ... moneyAmountFragment } } userRecommendations(limit: $userRecommendationMoviesLimit) @skip(if: $isInternational) { __typename total items { __typename movie { __typename ... movieSummaryFragment } } } movieLists(limit: $movieListsLimit) @skip(if: $isInternational) { __typename total items { __typename ... movieListRelationFragment } } } } fragment movieLogoFragment on Movie { __typename gallery { __typename logos { __typename horizontal { __typename ... imageFragment origSize { __typename width height } } } } } fragment movieDetailsImagesFragment on Movie { __typename gallery { __typename filteredImagesTotal: images(types: [STILL, SHOOTING, POSTER], offset: 0, limit: 0) { __typename total } filteredImagesStill: images(types: [STILL], offset: 0, limit: $imagesPerGroupLimit) { __typename ... movieImageCollectionFragment } filteredImagesShooting: images(types: [SHOOTING], offset: 0, limit: $imagesPerGroupLimit) { __typename ... movieImageCollectionFragment } filteredImagesPosters: images(types: [POSTER], offset: 0, limit: $imagesPerGroupLimit) { __typename ... movieImageCollectionFragment } } } fragment movieDetailsCreatorsFragment on Movie { __typename directors: members(role: [DIRECTOR], offset: 0, limit: $creatorsPerGroupLimit) { __typename ... membersListFragment } producers: members(role: [PRODUCER], offset: 0, limit: $creatorsPerGroupLimit) { __typename ... membersListFragment } writers: members(role: [WRITER], offset: 0, limit: $creatorsPerGroupLimit) { __typename ... membersListFragment } operators: members(role: [OPERATOR], offset: 0, limit: $creatorsPerGroupLimit) { __typename ... membersListFragment } composers: members(role: [COMPOSER], offset: 0, limit: $creatorsPerGroupLimit) { __typename ... membersListFragment } artists: members(role: [ART], offset: 0, limit: $creatorsPerGroupLimit) { __typename ... membersListFragment } editors: members(role: [EDITOR], offset: 0, limit: $creatorsPerGroupLimit) { __typename ... membersListFragment } others: members(role: [CAMEO, COSTUMER, DECORATOR, DESIGN, TRANSLATOR, VOICEOVER, VOICE_DIRECTOR], offset: 0, limit: $creatorsPerGroupLimit) { __typename ... membersListFragment } } fragment movieDetailsDurationFragment on Movie { __typename ... on Film { duration: duration } ... on TvSeries { duration: seriesDuration } ... on MiniSeries { duration: seriesDuration } ... on Video { duration: duration } ... on TvShow { duration: seriesDuration } } fragment movieDetailsActorsFragment on Movie { __typename actors: members(role: [ACTOR, CAMEO, GROUP_CAMEO, VOICEOVER, UNCREDITED, GROUP_UNCREDITED], limit: $actorsLimit, orderBy: BY_ROLE_POSITION_BY_CREW_PRIORITY) { __typename total items { __typename ... movieCrewMemberSummaryFragment } } } fragment movieDetailsWatchabilityFragment on Movie { __typename watchability { __typename total } } fragment movieTopsFragment on Movie { __typename top10 ... on Film @skip(if: $isInternational) { top250 } ... on TvSeries @skip(if: $isInternational) { top250 } ... on MiniSeries @skip(if: $isInternational) { top250 } ... on TvShow @skip(if: $isInternational) { top250 } } fragment movieDetailsSequelsAndPrequelsFragment on Movie { __typename sequelsAndPrequels: relatedMovies(orderBy: PREMIERE_DATE_ASC, offset: 0, limit: $sequelsAndPrequelsLimit, type: $sequelsAndPrequelsRelationsOrder) { __typename total items { __typename movie { __typename ... movieSummaryFragment } } } } fragment movieDetailsRelatedMoviesFragment on Movie { __typename related: relatedMovies(orderBy: TYPE_POSITION__MOVIE_ID_ASC, offset: 0, limit: $relatedMoviesLimit, type: $relatedMoviesRelationsOrder) { __typename total items { __typename relationType movie { __typename ... movieSummaryFragment } } } } fragment movieOttFragment on Movie { __typename ott { __typename preview { __typename ...previewFeatureFragment streams(filter: {isSupportedByClient: true}, offset: 0, limit: $streamsLimit) { __typename ...movieOttStreamsFragment } } ... movieOttNextEpisodeFragment } } fragment movieOttTrailersFragment on Movie { __typename ott { __typename promoTrailer: trailers(onlyPromo: true, limit: 1) { __typename items { __typename ...ottTrailerFragment } } ottTrailers: trailers(limit: 10) @include(if: $isInternational) { __typename items { __typename main ...ottTrailerFragment } } } } fragment movieYearsFragment on Movie { __typename ... on VideoInterface { productionYear(override: OTT_WHEN_EXISTS) } ... on Series { fallbackYear: productionYear releaseYears { __typename start end } } } fragment movieEpisodesFragment on Movie { __typename ... on MiniSeries { episodesCount seasons { __typename total } } ... on TvSeries { episodesCount seasons { __typename total } } ... on TvShow { episodesCount seasons { __typename total } } } fragment reviewsFragment on Movie { __typename criticReviews(limit: $criticReviewsLimit, orderBy: TEXT_DATE_DESC) { __typename total items { __typename ... criticReviewFragment } } criticReviewsTotalPositive: criticReviews(types: [POSITIVE]) { __typename total } criticReviewsTotalNegative: criticReviews(types: [NEGATIVE]) { __typename total } ... userReviewsFragment userReviewsTotalPositive: userReviews(types: [POSITIVE]) { __typename total } userReviewsTotalNegative: userReviews(types: [NEGATIVE]) { __typename total } userReviewsTotalNeutral: userReviews(types: [NEUTRAL]) { __typename total } } fragment movieDetailsAwardsFragment on Movie { __typename mainAwardsInfo: awards(offset: 0, limit: 1, isMain: true, orderBy: WIN_FIRST_YEAR_DESC_NOMINATION_ASC) { __typename total items { __typename ... movieAwardNomineeFragment } } mainAndWinAwardsInfo: awards(offset: 0, limit: 1, isMain: true, isWin: true, orderBy: WIN_FIRST_YEAR_DESC_NOMINATION_ASC) { __typename total } allAwardsInfo: awards(offset: 0, limit: 0, orderBy: WIN_FIRST_YEAR_DESC_NOMINATION_ASC) { __typename total } } fragment imageFragment on Image { __typename avatarsUrl fallbackUrl } fragment movieImageCollectionFragment on PagingList_MovieImage { __typename total offset limit items { __typename ... movieImageFragment } } fragment movieImageFragment on MovieImage { __typename type copyright author { __typename login } image { __typename origSize { __typename width height } ... imageFragment } } fragment membersListFragment on PagingList_FilmCrewMember { __typename total items { __typename ... movieCrewMemberFragment } } fragment movieCrewMemberFragment on FilmCrewMember { __typename role roleDetails: details person { __typename ... personSummaryFragment bestFilms: bestMovies(type: FILM) { __typename ... bestMoviesFilmpographyListFragment } bestSeries: bestMovies(type: SERIES) { __typename ... bestMoviesFilmpographyListFragment } } } fragment personSummaryFragment on Person { __typename id name gender originalName dateOfBirth { __typename ...incompleteDateFragment } dateOfDeath { __typename ...incompleteDateFragment } age poster { __typename ...imageFragment } published } fragment incompleteDateFragment on IncompleteDate { __typename date accuracy } fragment bestMoviesFilmpographyListFragment on PagingList_PersonBestMovie { __typename items { __typename movie { __typename id title { __typename ...titleFragment } rating { __typename ... ratingFragment } } } } fragment titleFragment on Title { __typename localized original } fragment ratingFragment on Rating { __typename kinopoisk { __typename ... ratingValueFragment } expectation { __typename ... ratingValueFragment } } fragment ratingValueFragment on RatingValue { __typename isActive count value(precision: 1) } fragment movieCrewMemberSummaryFragment on FilmCrewMember { __typename role roleDetails: details person { __typename ... personSummaryFragment } } fragment movieSummaryFragment on Movie { __typename id gallery { __typename posters { __typename ... moviePostersFragment } } genres { __typename ... genreFragment } title { __typename ... titleFragment } rating { __typename ... ratingFragment } } fragment genreFragment on Genre { __typename name } fragment moviePostersFragment on MoviePosters { __typename vertical(override: OTT_WHEN_EXISTS) { __typename ... imageFragment } verticalWithRightholderLogo { __typename ... imageFragment } } fragment movieOttNextEpisodeFragment on Ott_AbstractSeries { __typename nextEpisode @include(if: $isAppendUserData) { __typename episode { __typename contentId number season { __typename number } } } } fragment previewFeatureFragment on OttPreview { __typename features(filter: {layout: OTT_TITLE_CARD}) { __typename alias displayName group } } fragment movieOttStreamsFragment on PagingList_OttStream { __typename items { __typename audioMetas { __typename languageName quality studio forAdult } subtitleMetas { __typename languageName studio forAdult type } videoMetas { __typename dynamicRange } videoDescriptorName } } fragment ottTrailerFragment on OttTrailer { __typename streamUrl contentGroupUuid } fragment userReviewsFragment on Movie { __typename userReviews(limit: $userReviewsLimit, orderBy: TOP_USEFULNESS_THEN_CREATED_AT_DESC) { __typename total items { __typename ... userReviewFragment } } } fragment criticReviewFragment on CriticReview { __typename id text author { __typename id firstName lastName } source { __typename icon { __typename ... imageFragment } title } sourceUrl type } fragment userReviewFragment on UserReview { __typename id text title createdAt author { __typename id avatar { __typename ... imageFragment } login } type votes { __typename positiveCount negativeCount } userData @include(if: $isAppendUserData) { __typename ... on UserReviewUserData { voting } } } fragment movieAwardNomineeFragment on MovieAwardNominee { __typename nomination { __typename ... nominationFragment } win awardImage: image { __typename ... imageFragment } persons(offset: 0, limit: 10) { __typename items { __typename ... personSummaryFragment } } } fragment nominationFragment on AwardNomination { __typename title award { __typename ... awardFragment } } fragment awardFragment on Award { __typename title year } fragment movieFullUserDataFragment on MovieUserData { __typename ... movieUserDataFragment friendsVoting(orderBy: VOTE_VALUE_DESC, limit: $friendsVotesLimit) @skip(if: $isInternationalUserData) { __typename averageVote total items { __typename ... friendVoteFragment } } } fragment movieUserDataFragment on MovieUserData { __typename isPlannedToWatch folders @skip(if: $isInternationalUserData) { __typename ... folderFragment } voting @skip(if: $isInternationalUserData) { __typename ... voteFragment } expectation @skip(if: $isInternationalUserData) { __typename value } watchStatuses { __typename ...watchStatusesFragment } } fragment friendVoteFragment on FriendVote_Friend { __typename attitude friend { __typename user { __typename ... userFragment } } vote { __typename ... voteFragment } } fragment voteFragment on Vote { __typename value } fragment userFragment on User { __typename login avatar { __typename ... imageFragment } } fragment folderFragment on Folder { __typename id name } fragment watchStatusesFragment on WatchStatuses { __typename notInterested { __typename value } watched { __typename value } } fragment fullRatingFragment on Rating { __typename kinopoisk { __typename ... ratingValueFragment } expectation { __typename ... percentRatingValueFragment } imdb { __typename ... ratingValueFragment } worldwideCritics { __typename ... ratingWithVotesValueFragment } russianCritics { __typename ... percentRatingValueFragment } positiveReviewRate { __typename ... percentRatingValueFragment } } fragment percentRatingValueFragment on RatingValue { __typename isActive count value(precision: 0) } fragment ratingWithVotesValueFragment on RatingWithVotesValue { __typename isActive count value } fragment viewOptionDetailedFragment on ViewOption { __typename ... movieViewOptionSummaryFragment purchaseRejectionReason { __typename ... watchingRejection } watchingRejectionReason { __typename ... watchingRejection } downloadRejectionReason { __typename ... watchingRejection } subscriptionCompositeOffers(mediaBillingTarget: $mediaBillingTarget, checkSilentInvoiceAvailability: $checkSilentInvoiceAvailability) @include(if: $isTariffSubscriptionActive) { __typename ... subscriptionOfferCompositeDataFragment } watchPeriod { __typename ...movieWatchPeriodFragment } texts { __typename ...viewOptionsTextFragment } descriptionText mainPromotionAbsoluteAmount { __typename ... moneyAmountFragment } mastercardPromotionAbsoluteAmount { __typename ... moneyAmountFragment } } fragment movieViewOptionSummaryFragment on ViewOption { __typename type purchasabilityStatus isWatchableOnDeviceInCurrentRegion: isWatchable(filter: {anyDevice: false, anyRegion: false}) subscriptionPurchaseTag buttonText ... movieViewOptionPurchasedSubscriptionFragment availabilityAnnounce { __typename ... availabilityAnnounceFragment } contentPackageToBuy { __typename ... movieContentPackageFragment } contentPackageToUnfreeze { __typename ... movieContentPackageFragment } transactionalPrice { __typename ... moneyAmountFragment } transactionalMinimumPrice { __typename ... moneyAmountFragment } priceWithTotalDiscount { __typename ... moneyAmountFragment } optionMonetizationModels watchabilityStatus promotionActionType downloadabilityStatus } fragment watchingRejection on WatchingRejection { __typename details reason } fragment subscriptionOfferCompositeDataFragment on SubscriptionCompositeOffers { __typename batchPositionId offers { __typename ... subscriptionOfferCompositeOffersFragment customPayload { __typename ... subscriptionOfferCustomPayloadFragment } } } fragment subscriptionOfferCompositeOffersFragment on OttCompositeOffer { __typename compositeOffer { __typename forActiveOffers { __typename ... subscriptionOfferForActiveOffersFragment } structureType tariffOffer { __typename ... subscriptionOfferTariffFragment } optionOffers { __typename ... subscriptionOfferOptionFragment } positionId silentInvoiceAvailable } } fragment subscriptionOfferForActiveOffersFragment on PlusOfferUnion { __typename ... on PlusOptionOffer { ... subscriptionOfferOptionFragment } ... on PlusTariffOffer { ... subscriptionOfferTariffFragment } } fragment subscriptionOfferOptionFragment on PlusOptionOffer { __typename additionText description name title text option { __typename name } plans { __typename } } fragment subscriptionOfferTariffFragment on PlusTariffOffer { __typename additionText description name title text tariff { __typename name } plans { __typename } } fragment subscriptionOfferCustomPayloadFragment on OttCompositeOfferCustomPayload { __typename overridedAdditionalText overridedText overridedTarget } fragment movieWatchPeriodFragment on WatchPeriod { __typename timeToExpire watchPeriodStatus } fragment viewOptionsTextFragment on ViewOptionText { __typename disclaimer } fragment moneyAmountFragment on MoneyAmount { __typename amount currency { __typename ... currencyFragment } } fragment currencyFragment on Currency { __typename symbol } fragment movieViewOptionPurchasedSubscriptionFragment on ViewOption { __typename purchasedSubscriptionTextId purchasedSubscriptionName } fragment availabilityAnnounceFragment on AvailabilityAnnounce { __typename announcePromise availabilityDate type } fragment movieContentPackageFragment on ContentPackage { __typename billingFeatureName } fragment movieReleaseOptionsFragment on ReleaseOptions { __typename is3d isImax } fragment countryFragment on Country { __typename id name } fragment restrictionFragment on Restriction { __typename age mpaa } fragment distributionFragment on Distribution { __typename countrySpecificPremiere: premieres(limit: 1, countryId: $countryId) { __typename items { __typename ... moviePremiereFragment } } worldPremiere { __typename ... moviePremiereFragment } allReleases: releases(types: [BLURAY, DIGITAL, DVD]) { __typename items { __typename ... movieDetailsReleaseFragment } } premieres(limit: $premieresLimit) { __typename items { __typename ... moviePremiereFragment } } } fragment moviePremiereFragment on Premiere { __typename country { __typename ...countryFragment } incompleteDate { __typename ...incompleteDateFragment } } fragment movieDetailsReleaseFragment on Release { __typename type companies { __typename displayName } country { __typename ... countryFragment } date { __typename ...incompleteDateFragment } } fragment trailerFragment on Trailer { __typename id title isMain createdAt duration movie { __typename id } preview { __typename ... imageFragment } streamUrl } fragment triviaFragment on Trivia { __typename id isSpoiler text type } fragment postFragment on Post { __typename id title publishedAt commentsCount coverImage { __typename ... imageFragment } thumbImage { __typename ... imageFragment } } fragment movieListRelationFragment on MovieListRelation { __typename position movieList { __typename ... movieListFragment movies(offset: 0, limit: 0) { __typename total } } } fragment movieListFragment on MovieListMeta { __typename id autoList name description url cover { __typename ... imageFragment } }'}
    #resp = requests.post('https://graphql.kinopoisk.ru/graphql?operationName=MovieDetails', headers=headers, data=json.dumps(qdata), verify=False)
    try:
        resp = requests.post('https://graphql.kinopoisk.ru/graphql?operationName=MovieDetails', headers=headers, data=json.dumps(qdata), verify=False)
    except:
        resp = None
    if not resp or resp.status_code != 200:
        return {}
    return resp.json()

L=[u'rating', u'restriction', u'related', u'editors', u'facts', u'productionYear', u'allAwardsInfo', u'artists', u'duration', u'viewOption', u'shortDescription', u'id', u'ottSynopsis', u'composers', u'releaseOptions', u'genres', u'title', u'userReviewsTotalNeutral', u'top10', u'__typename', u'mainAndWinAwardsInfo', u'userReviewsTotalNegative', u'writers', u'actors', u'boxOffice', u'editorAnnotation', u'sequelsAndPrequels', u'bloopers', u'kpYear', u'movieLists', u'operators', u'mainTrailer', u'others', u'kpSynopsis', u'mainAwardsInfo', u'ott', u'gallery', u'trailers', u'userReviews', u'countries', u'url', u'contentId', u'posts', u'directors', u'distribution', u'top250']

def get_info(ID = 530):
        inf = kp_get_info_by_id(ID)['data']['movie']
        print (inf)
        info = kodi_info(inf)
        return (info)

def kodi_info(inf):
        ID = str(inf['id'])
        cover = 'https://st.kp.yandex.net/images/film_iphone/iphone360_'+str(ID)+'.jpg'
        try: fanart = 'https:'+inf['gallery']['filteredImagesStill']['items'][0]['image']['avatarsUrl']+'/720x'
        except: fanart = cover
        #print(fanart)
        try: title = inf['title']['localized']
        except:
                try: title = inf['title']['russian']
                except: title = None
        try: originaltitle = inf['title']['original']
        except: originaltitle = None
        if originaltitle != None and title == None: title = originaltitle
        if originaltitle == None: originaltitle = title
        try:
                rating = inf['rating']['kinopoisk']['value']
                if rating == None: rating = inf['rating']['imdb']['value']
                if rating == None: rating = 0
        except: rating = 0
        try: plot = inf['kpSynopsis']
        except: plot = ''
        if plot == None: plot = ''
        try: trailer = inf['trailers']['items'][0]['streamUrl']
        except: trailer = ''
        try: year = inf['productionYear']
        except: 
                try: year = inf['releaseYears'][0]['start']
                except: year = 0
        try: genre = inf['genres'][0]['name']
        except: genre = ''
        try: 
                director = inf['directors']['items'][0]['person']['name']
                if director==None: director = inf['directors']['items'][0]['person']['originalName']
        except: director = ''
        try: countrie = inf['countries'][0]['name']
        except: countrie = ''
        try: duration = inf['duration']
        except: duration = 0
        try: typename = inf['__typename']
        except: typename = ''
        try: Lactors=inf['actors']['items']
        except: Lactors = []
        cast = []
        for a in Lactors:
             try:
                p = a['person']['name']
                if p==None: p = a['person']['originalName']
                if p!=None: cast.append(p)
             except: pass
        
        info = {"title": title,
                "originaltitle": originaltitle,
                "year": year, 
                "duration": duration,
                "genre": genre,
                "studio": countrie,
                "country": countrie,
                "director": director,
                "cast": cast,
                "rating": rating,
                "cover": cover,
                "fanart": fanart,
                "plot": plot,
                "type": typename,
                "id": ID
                }
        if info["fanart"] == '': info["fanart"] = info["cover"]
        return (info)

#print(get_info(4642890))
#time.sleep(30)

def kp_get_person_by_id(ps_id):
    qdata = {"operationName":"FilmographyItems","variables":{"genre":null,"year":null,"orderBy":"KP_RATING_DESC","itemsLimit":50,"itemsOffset":0,"participationsLimit":30,"withUserData":true,"personId":ps_id,"roleSlugs":["ACTOR","DIRECTOR"]},"query":"query FilmographyItems($personId: Long!, $roleSlugs: [String], $genre: Int = null, $year: YearsRangeInput = null, $orderBy: FilmographyItemOrderBy = YEAR_DESC, $itemsLimit: Int = 10, $itemsOffset: Int = 0, $participationsLimit: Int = 10, $withUserData: Boolean = false) { person(id: $personId) { id filmographyRelations(roleSlugs: $roleSlugs, limit: $itemsLimit, offset: $itemsOffset, genre: $genre, year: $year, orderBy: $orderBy) { items { movie { id contentId title { russian english original __typename } genres { id name __typename } ...MoviePosterGallery rating { kinopoisk { ...RatingValue __typename } __typename } countries { id name __typename } viewOption { buttonText originalButtonText promotionIcons { avatarsUrl fallbackUrl __typename } isAvailableOnline: isWatchable(filter: {anyDevice: false, anyRegion: false}) purchasabilityStatus type rightholderLogoUrlForPoster __typename } isTicketsAvailable: isTicketsAvailableInMyRegion ... on Film { productionYear isShortFilm top250 __typename } ... on TvSeries { releaseYears { start end __typename } __typename } ... on MiniSeries { releaseYears { start end __typename } __typename } ... on TvShow { releaseYears { start end __typename } __typename } ... on Video { productionYear __typename } ...FilmographyItemUserData @include(if: $withUserData) __typename } participations(limit: $participationsLimit) { items { notice role { title { russian english __typename } slug __typename } ... on CastMovieParticipation { name __typename } ... on StaffMovieParticipation { relatedCast { name person { id name url __typename } __typename } __typename } __typename } __typename } salaries { items { amount currency { symbol __typename } note __typename } __typename } __typename } limit offset total __typename } __typename } } fragment Folder on Folder { id name public __typename } fragment MovieUserFolders on Movie { userData { userFolders(offset: 0, limit: 20) { items { ...Folder __typename } __typename } isFavorite __typename } __typename } fragment MoviePosterGallery on Movie { gallery { posters { vertical { avatarsUrl __typename } __typename } logos { rightholderForPoster { avatarsUrl __typename } __typename } __typename } __typename } fragment RatingValue on RatingValue { value isActive count __typename } fragment FilmographyItemUserData on Movie { userData { watchStatuses { notInterested { value __typename } watched { value __typename } __typename } voting { value votedAt __typename } isPlannedToWatch __typename } ...MovieUserFolders __typename } "}
    
    
    try:
        resp = requests.post('https://graphql.kinopoisk.ru/graphql/?operationName=FilmographyItems', headers=headers, data=json.dumps(qdata), verify=False)
    except:
        resp = None
    if not resp or resp.status_code != 200:
        return {}
    return resp.json()

def get_person(ID = 797):
        Lid=[]
        Linf=[]
        inf = kp_get_person_by_id(ID)['data']['person']
        L1 = inf['filmographyRelations']['items']
        #L2 = inf['bestSeries']['items']
        for i in L1:
                id = i['movie']['id']
                if id not in L: 
                        Lid.append(id) 
                        #Linf.append(kodi_info(i['movie']))
        #for i in L2:
        #        id = i['movie']['id']
        #        if id not in L: L.append(id) 
        return {'Lid':Lid, 'Linf':Linf}

#get_person(797)
#time.sleep(30)

list_query="query MovieDesktopListPage($slug: String!, $platform: WebClientPlatform!, $withUserData: Boolean!, $supportedFilterTypes: [FilterType]!, $filters: FilterValuesInput, $singleSelectFiltersLimit: Int!, $singleSelectFiltersOffset: Int!, $moviesLimit: Int, $moviesOffset: Int, $moviesOrder: MovieListItemOrderBy, $supportedItemTypes: [MovieListItemType]) { movieListBySlug(slug: $slug, supportedFilterTypes: $supportedFilterTypes, filters: $filters) { ...MovieListCompositeName ...MovieListAvailableFilters ...MovieList ...DescriptionLink __typename } webPage(platform: $platform) { kpMovieListPage(movieListSlug: $slug) { htmlMeta { ...OgImage __typename } footer { ...FooterConfigData __typename } featuring { ...MovieListFeaturingData __typename } __typename } __typename } } fragment ToggleFilter on BooleanFilter { id enabled name { russian __typename } __typename } fragment SingleSelectFilters on SingleSelectFilter { id name { russian __typename } hint { russian __typename } values(offset: $singleSelectFiltersOffset, limit: $singleSelectFiltersLimit) { items { name { russian __typename } selectable value __typename } __typename } __typename } fragment MoviePosterGallery on Movie { gallery { posters { vertical { avatarsUrl __typename } __typename } logos { rightholderForPoster { avatarsUrl __typename } __typename } __typename } __typename } fragment RatingValue on RatingValue { value isActive count __typename } fragment MovieListReleases on Distribution { rusRelease: releases(types: [CINEMA], rerelease: false, countryId: 2, limit: 1) { items { date { date accuracy __typename } __typename } __typename } worldPremiere { incompleteDate { date accuracy __typename } __typename } allReleases: releases(limit: 1) { items { date { date accuracy __typename } __typename } __typename } __typename } fragment Folder on Folder { id name public __typename } fragment MovieUserFolders on Movie { userData { userFolders(offset: 0, limit: 20) { items { ...Folder __typename } __typename } isFavorite __typename } __typename } fragment MovieListUserData on Movie { userData { watchStatuses { notInterested { value __typename } watched { value __typename } __typename } voting { value votedAt __typename } isPlannedToWatch __typename } ...MovieUserFolders __typename } fragment MovieListCompositeName on MovieListMeta { compositeName { parts { ... on FilterReferencedMovieListNamePart { filterValue { ... on SingleSelectFilterValue { filterId __typename } __typename } name __typename } ... on StaticMovieListNamePart { name __typename } __typename } __typename } __typename } fragment MovieListAvailableFilters on MovieListMeta { availableFilters { items { ... on BooleanFilter { ...ToggleFilter __typename } ... on SingleSelectFilter { ...SingleSelectFilters __typename } __typename } __typename } __typename } fragment MovieList on MovieListMeta { id name description cover { avatarsUrl __typename } movies(limit: $moviesLimit, offset: $moviesOffset, orderBy: $moviesOrder, supportedItemTypes: $supportedItemTypes) { total items { movie { id contentId title { russian original __typename } ...MoviePosterGallery countries { id name __typename } genres { id name __typename } cast: members(role: [ACTOR], limit: 3) { items { details person { name originalName __typename } __typename } __typename } directors: members(role: [DIRECTOR], limit: 1) { items { details person { name originalName __typename } __typename } __typename } url rating { kinopoisk { ...RatingValue __typename } plannedToWatch { ...RatingValue __typename } __typename } mainTrailer { id isEmbedded __typename } viewOption { buttonText originalButtonText promotionIcons { avatarsUrl fallbackUrl __typename } isAvailableOnline: isWatchable(filter: {anyDevice: false, anyRegion: false}) purchasabilityStatus type rightholderLogoUrlForPoster availabilityAnnounce { availabilityDate type groupPeriodType announcePromise __typename } __typename } isTicketsAvailable: isTicketsAvailableInMyRegion distribution { ...MovieListReleases __typename } ... on Film { productionYear duration isShortFilm top250 __typename } ... on TvSeries { releaseYears { start end __typename } totalDuration top250 __typename } ... on MiniSeries { releaseYears { start end __typename } totalDuration top250 __typename } ... on TvShow { releaseYears { start end __typename } totalDuration top250 __typename } ... on Video { productionYear duration isShortFilm __typename } ...MovieListUserData @include(if: $withUserData) __typename } ... on TopMovieListItem { position positionDiff rate votes __typename } ... on MostProfitableMovieListItem { boxOffice { amount __typename } budget { amount __typename } ratio __typename } ... on MostExpensiveMovieListItem { budget { amount __typename } __typename } ... on OfflineAudienceMovieListItem { viewers __typename } ... on PopularMovieListItem { positionDiff __typename } ... on BoxOfficeMovieListItem { boxOffice { amount __typename } __typename } ... on RecommendationMovieListItem { __typename } ... on ComingSoonMovieListItem { releaseDate { date accuracy __typename } __typename } ... on MoviesInCinemaListItem { promo __typename } ... on PlannedToWatchMovieListItem { votes __typename } __typename } __typename } __typename } fragment DescriptionLink on MovieListMeta { descriptionLink { title url __typename } __typename } fragment OgImage on HtmlMeta { openGraph { image { avatarsUrl __typename } __typename } __typename } fragment FooterConfigData on FooterConfiguration { socialNetworkLinks { icon { avatarsUrl __typename } url title __typename } appMarketLinks { icon { avatarsUrl __typename } url title __typename } links { title url __typename } __typename } fragment MovieListFeaturingData on MovieListFeaturing { items { title url __typename } __typename } "


def kp_get_MovieList_best(page=1):
    offset = (page-1)*50
    qdata = {"operationName":"MovieDesktopListPage","variables":{"slug":"top500","platform":"DESKTOP","withUserData":true,"supportedFilterTypes":["BOOLEAN","SINGLE_SELECT"],"filters":{"booleanFilterValues":[],"intRangeFilterValues":[],"singleSelectFilterValues":[],"multiSelectFilterValues":[],"realRangeFilterValues":[]},"singleSelectFiltersLimit":700,"singleSelectFiltersOffset":0,"moviesLimit":50,"moviesOffset":offset,"moviesOrder":"POSITION_ASC","supportedItemTypes":["COMING_SOON_MOVIE_LIST_ITEM","MOVIE_LIST_ITEM","TOP_MOVIE_LIST_ITEM","POPULAR_MOVIE_LIST_ITEM","MOST_PROFITABLE_MOVIE_LIST_ITEM","MOST_EXPENSIVE_MOVIE_LIST_ITEM","BOX_OFFICE_MOVIE_LIST_ITEM","OFFLINE_AUDIENCE_MOVIE_LIST_ITEM","RECOMMENDATION_MOVIE_LIST_ITEM","MOVIE_IN_CINEMA_LIST_ITEM","PLANNED_TO_WATCH_LIST_ITEM"]},"query":"query MovieDesktopListPage($slug: String!, $platform: WebClientPlatform!, $withUserData: Boolean!, $supportedFilterTypes: [FilterType]!, $filters: FilterValuesInput, $singleSelectFiltersLimit: Int!, $singleSelectFiltersOffset: Int!, $moviesLimit: Int, $moviesOffset: Int, $moviesOrder: MovieListItemOrderBy, $supportedItemTypes: [MovieListItemType]) { movieListBySlug(slug: $slug, supportedFilterTypes: $supportedFilterTypes, filters: $filters) { ...MovieListCompositeName ...MovieListAvailableFilters ...MovieList ...DescriptionLink __typename } webPage(platform: $platform) { kpMovieListPage(movieListSlug: $slug) { htmlMeta { ...OgImage __typename } footer { ...FooterConfigData __typename } featuring { ...MovieListFeaturingData __typename } __typename } __typename } } fragment ToggleFilter on BooleanFilter { id enabled name { russian __typename } __typename } fragment SingleSelectFilters on SingleSelectFilter { id name { russian __typename } hint { russian __typename } values(offset: $singleSelectFiltersOffset, limit: $singleSelectFiltersLimit) { items { name { russian __typename } selectable value __typename } __typename } __typename } fragment MoviePosterGallery on Movie { gallery { posters { vertical { avatarsUrl __typename } __typename } logos { rightholderForPoster { avatarsUrl __typename } __typename } __typename } __typename } fragment RatingValue on RatingValue { value isActive count __typename } fragment MovieListReleases on Distribution { rusRelease: releases(types: [CINEMA], rerelease: false, countryId: 2, limit: 1) { items { date { date accuracy __typename } __typename } __typename } worldPremiere { incompleteDate { date accuracy __typename } __typename } allReleases: releases(limit: 1) { items { date { date accuracy __typename } __typename } __typename } __typename } fragment Folder on Folder { id name public __typename } fragment MovieUserFolders on Movie { userData { userFolders(offset: 0, limit: 20) { items { ...Folder __typename } __typename } isFavorite __typename } __typename } fragment MovieListUserData on Movie { userData { watchStatuses { notInterested { value __typename } watched { value __typename } __typename } voting { value votedAt __typename } isPlannedToWatch __typename } ...MovieUserFolders __typename } fragment MovieListCompositeName on MovieListMeta { compositeName { parts { ... on FilterReferencedMovieListNamePart { filterValue { ... on SingleSelectFilterValue { filterId __typename } __typename } name __typename } ... on StaticMovieListNamePart { name __typename } __typename } __typename } __typename } fragment MovieListAvailableFilters on MovieListMeta { availableFilters { items { ... on BooleanFilter { ...ToggleFilter __typename } ... on SingleSelectFilter { ...SingleSelectFilters __typename } __typename } __typename } __typename } fragment MovieList on MovieListMeta { id name description cover { avatarsUrl __typename } movies(limit: $moviesLimit, offset: $moviesOffset, orderBy: $moviesOrder, supportedItemTypes: $supportedItemTypes) { total items { movie { id contentId title { russian original __typename } ...MoviePosterGallery countries { id name __typename } genres { id name __typename } cast: members(role: [ACTOR], limit: 3) { items { details person { name originalName __typename } __typename } __typename } directors: members(role: [DIRECTOR], limit: 1) { items { details person { name originalName __typename } __typename } __typename } url rating { kinopoisk { ...RatingValue __typename } plannedToWatch { ...RatingValue __typename } __typename } mainTrailer { id isEmbedded __typename } viewOption { buttonText originalButtonText promotionIcons { avatarsUrl fallbackUrl __typename } isAvailableOnline: isWatchable(filter: {anyDevice: false, anyRegion: false}) purchasabilityStatus type rightholderLogoUrlForPoster availabilityAnnounce { availabilityDate type groupPeriodType announcePromise __typename } __typename } isTicketsAvailable: isTicketsAvailableInMyRegion distribution { ...MovieListReleases __typename } ... on Film { productionYear duration isShortFilm top250 __typename } ... on TvSeries { releaseYears { start end __typename } totalDuration top250 __typename } ... on MiniSeries { releaseYears { start end __typename } totalDuration top250 __typename } ... on TvShow { releaseYears { start end __typename } totalDuration top250 __typename } ... on Video { productionYear duration isShortFilm __typename } ...MovieListUserData @include(if: $withUserData) __typename } ... on TopMovieListItem { position positionDiff rate votes __typename } ... on MostProfitableMovieListItem { boxOffice { amount __typename } budget { amount __typename } ratio __typename } ... on MostExpensiveMovieListItem { budget { amount __typename } __typename } ... on OfflineAudienceMovieListItem { viewers __typename } ... on PopularMovieListItem { positionDiff __typename } ... on BoxOfficeMovieListItem { boxOffice { amount __typename } __typename } ... on RecommendationMovieListItem { __typename } ... on ComingSoonMovieListItem { releaseDate { date accuracy __typename } __typename } ... on MoviesInCinemaListItem { promo __typename } ... on PlannedToWatchMovieListItem { votes __typename } __typename } __typename } __typename } fragment DescriptionLink on MovieListMeta { descriptionLink { title url __typename } __typename } fragment OgImage on HtmlMeta { openGraph { image { avatarsUrl __typename } __typename } __typename } fragment FooterConfigData on FooterConfiguration { socialNetworkLinks { icon { avatarsUrl __typename } url title __typename } appMarketLinks { icon { avatarsUrl __typename } url title __typename } links { title url __typename } __typename } fragment MovieListFeaturingData on MovieListFeaturing { items { title url __typename } __typename } "}
    qdata["query"]=list_query
    try:
        resp = requests.post('https://graphql.kinopoisk.ru/graphql/?operationName=MovieDesktopListPage', headers=headers, data=json.dumps(qdata), verify=False)
    except:
        resp = None
    if not resp or resp.status_code != 200:
        return {}
    return resp.json()

def get_best_list():
        L=[]
        for p in range(5):
                print (p+1)
                inf = kp_get_MovieList_best(p+1)['data']['movieListBySlug']
                L1 = inf['movies']['items']
                for i in L1:
                        id = i['movie']['id']
                        if id not in L: L.append(id) 
        return L


def kp_get_MovieList_pop(page=1):
    offset = (page-1)*50
    qdata = {"operationName":"MovieDesktopListPage","variables":{"slug":"popular-films","platform":"DESKTOP","withUserData":true,"supportedFilterTypes":["BOOLEAN","SINGLE_SELECT"],"filters":{"booleanFilterValues":[],"intRangeFilterValues":[],"singleSelectFilterValues":[],"multiSelectFilterValues":[],"realRangeFilterValues":[]},"singleSelectFiltersLimit":700,"singleSelectFiltersOffset":0,"moviesLimit":50,"moviesOffset":offset,"moviesOrder":"POSITION_ASC","supportedItemTypes":["COMING_SOON_MOVIE_LIST_ITEM","MOVIE_LIST_ITEM","TOP_MOVIE_LIST_ITEM","POPULAR_MOVIE_LIST_ITEM","MOST_PROFITABLE_MOVIE_LIST_ITEM","MOST_EXPENSIVE_MOVIE_LIST_ITEM","BOX_OFFICE_MOVIE_LIST_ITEM","OFFLINE_AUDIENCE_MOVIE_LIST_ITEM","RECOMMENDATION_MOVIE_LIST_ITEM","MOVIE_IN_CINEMA_LIST_ITEM","PLANNED_TO_WATCH_LIST_ITEM"]},"query":"query MovieDesktopListPage($slug: String!, $platform: WebClientPlatform!, $withUserData: Boolean!, $supportedFilterTypes: [FilterType]!, $filters: FilterValuesInput, $singleSelectFiltersLimit: Int!, $singleSelectFiltersOffset: Int!, $moviesLimit: Int, $moviesOffset: Int, $moviesOrder: MovieListItemOrderBy, $supportedItemTypes: [MovieListItemType]) { movieListBySlug(slug: $slug, supportedFilterTypes: $supportedFilterTypes, filters: $filters) { ...MovieListCompositeName ...MovieListAvailableFilters ...MovieList ...DescriptionLink __typename } webPage(platform: $platform) { kpMovieListPage(movieListSlug: $slug) { htmlMeta { ...OgImage __typename } footer { ...FooterConfigData __typename } featuring { ...MovieListFeaturingData __typename } __typename } __typename } } fragment ToggleFilter on BooleanFilter { id enabled name { russian __typename } __typename } fragment SingleSelectFilters on SingleSelectFilter { id name { russian __typename } hint { russian __typename } values(offset: $singleSelectFiltersOffset, limit: $singleSelectFiltersLimit) { items { name { russian __typename } selectable value __typename } __typename } __typename } fragment MoviePosterGallery on Movie { gallery { posters { vertical { avatarsUrl __typename } __typename } logos { rightholderForPoster { avatarsUrl __typename } __typename } __typename } __typename } fragment RatingValue on RatingValue { value isActive count __typename } fragment MovieListReleases on Distribution { rusRelease: releases(types: [CINEMA], rerelease: false, countryId: 2, limit: 1) { items { date { date accuracy __typename } __typename } __typename } worldPremiere { incompleteDate { date accuracy __typename } __typename } allReleases: releases(limit: 1) { items { date { date accuracy __typename } __typename } __typename } __typename } fragment Folder on Folder { id name public __typename } fragment MovieUserFolders on Movie { userData { userFolders(offset: 0, limit: 20) { items { ...Folder __typename } __typename } isFavorite __typename } __typename } fragment MovieListUserData on Movie { userData { watchStatuses { notInterested { value __typename } watched { value __typename } __typename } voting { value votedAt __typename } isPlannedToWatch __typename } ...MovieUserFolders __typename } fragment MovieListCompositeName on MovieListMeta { compositeName { parts { ... on FilterReferencedMovieListNamePart { filterValue { ... on SingleSelectFilterValue { filterId __typename } __typename } name __typename } ... on StaticMovieListNamePart { name __typename } __typename } __typename } __typename } fragment MovieListAvailableFilters on MovieListMeta { availableFilters { items { ... on BooleanFilter { ...ToggleFilter __typename } ... on SingleSelectFilter { ...SingleSelectFilters __typename } __typename } __typename } __typename } fragment MovieList on MovieListMeta { id name description cover { avatarsUrl __typename } movies(limit: $moviesLimit, offset: $moviesOffset, orderBy: $moviesOrder, supportedItemTypes: $supportedItemTypes) { total items { movie { id contentId title { russian original __typename } ...MoviePosterGallery countries { id name __typename } genres { id name __typename } cast: members(role: [ACTOR], limit: 3) { items { details person { name originalName __typename } __typename } __typename } directors: members(role: [DIRECTOR], limit: 1) { items { details person { name originalName __typename } __typename } __typename } url rating { kinopoisk { ...RatingValue __typename } plannedToWatch { ...RatingValue __typename } __typename } mainTrailer { id isEmbedded __typename } viewOption { buttonText originalButtonText promotionIcons { avatarsUrl fallbackUrl __typename } isAvailableOnline: isWatchable(filter: {anyDevice: false, anyRegion: false}) purchasabilityStatus type rightholderLogoUrlForPoster availabilityAnnounce { availabilityDate type groupPeriodType announcePromise __typename } __typename } isTicketsAvailable: isTicketsAvailableInMyRegion distribution { ...MovieListReleases __typename } ... on Film { productionYear duration isShortFilm top250 __typename } ... on TvSeries { releaseYears { start end __typename } totalDuration top250 __typename } ... on MiniSeries { releaseYears { start end __typename } totalDuration top250 __typename } ... on TvShow { releaseYears { start end __typename } totalDuration top250 __typename } ... on Video { productionYear duration isShortFilm __typename } ...MovieListUserData @include(if: $withUserData) __typename } ... on TopMovieListItem { position positionDiff rate votes __typename } ... on MostProfitableMovieListItem { boxOffice { amount __typename } budget { amount __typename } ratio __typename } ... on MostExpensiveMovieListItem { budget { amount __typename } __typename } ... on OfflineAudienceMovieListItem { viewers __typename } ... on PopularMovieListItem { positionDiff __typename } ... on BoxOfficeMovieListItem { boxOffice { amount __typename } __typename } ... on RecommendationMovieListItem { __typename } ... on ComingSoonMovieListItem { releaseDate { date accuracy __typename } __typename } ... on MoviesInCinemaListItem { promo __typename } ... on PlannedToWatchMovieListItem { votes __typename } __typename } __typename } __typename } fragment DescriptionLink on MovieListMeta { descriptionLink { title url __typename } __typename } fragment OgImage on HtmlMeta { openGraph { image { avatarsUrl __typename } __typename } __typename } fragment FooterConfigData on FooterConfiguration { socialNetworkLinks { icon { avatarsUrl __typename } url title __typename } appMarketLinks { icon { avatarsUrl __typename } url title __typename } links { title url __typename } __typename } fragment MovieListFeaturingData on MovieListFeaturing { items { title url __typename } __typename } "}
    qdata["query"]=list_query
    try:
        resp = requests.post('https://graphql.kinopoisk.ru/graphql/?operationName=MovieDesktopListPage', headers=headers, data=json.dumps(qdata), verify=False)
    except:
        resp = None
    if not resp or resp.status_code != 200:
        return {}
    return resp.json()

def get_pop_list():
        L=[]
        for p in range(2):
                print (p+1)
                inf = kp_get_MovieList_pop(p+1)['data']['movieListBySlug']
                L1 = inf['movies']['items']
                for i in L1:
                        id = i['movie']['id']
                        if id not in L: L.append(id) 
        return L

#print(get_pop_list())

def kp_get_MovieListCategory(id=1,page=1):
    offset = (page-1)*50
    qdata = {"operationName":"MovieListCategory","variables":{"id":id,"limit":30,"offset":0,"withUserData":true},"query":"query MovieListCategory($id: Int!, $limit: Int, $offset: Int, $withUserData: Boolean!) { movieListCategory(id: $id) { id name movieLists(limit: $limit, offset: $offset) { total items { name slug movies { total __typename } cover { avatarsUrl __typename } coverBackground { avatarsUrl __typename } currentFilters { booleanFilterValues { filterId value __typename } singleSelectFilterValues { filterId value __typename } __typename } availableFilters(limit: 1, offset: 0, filter: {filterIds: [\"top\"]}) { items { ... on BooleanFilter { enabled __typename } __typename } __typename } userData @include(if: $withUserData) { watched __typename } __typename } __typename } __typename } } "}
    try:
        resp = requests.post('https://graphql.kinopoisk.ru/graphql/?operationName=MovieListCategory', headers=headers, data=json.dumps(qdata), verify=False)
    except:
        resp = None
    if not resp or resp.status_code != 200:
        return {}
    return resp.json()

def get_Category_list():
        L=[]
        for id in [1,3]:
                inf = kp_get_MovieListCategory(id)['data']['movieListCategory']
                L1 = inf['movieLists']['items']
                for i in L1:
                        name = i['name']
                        slug = i['slug']
                        if slug != None:
                                try: cover = 'http:'+i['cover']['avatarsUrl']
                                except: cover = ''
                                currentFilters = i['currentFilters']
                                L.append({'name':name, 'slug':slug, 'cover':cover, 'filters':currentFilters})
        return L

def kp_get_MovieList(type = 'best',page=1):
    offset = (page-1)*50
    qdata = {"operationName":"MovieDesktopListPage","variables":{"slug":"top500","platform":"DESKTOP","withUserData":true,"supportedFilterTypes":["BOOLEAN","SINGLE_SELECT"],"filters":{"booleanFilterValues":[],"intRangeFilterValues":[],"singleSelectFilterValues":[],"multiSelectFilterValues":[],"realRangeFilterValues":[]},"singleSelectFiltersLimit":700,"singleSelectFiltersOffset":0,"moviesLimit":50,"moviesOffset":offset,"moviesOrder":"POSITION_ASC","supportedItemTypes":["COMING_SOON_MOVIE_LIST_ITEM","MOVIE_LIST_ITEM","TOP_MOVIE_LIST_ITEM","POPULAR_MOVIE_LIST_ITEM","MOST_PROFITABLE_MOVIE_LIST_ITEM","MOST_EXPENSIVE_MOVIE_LIST_ITEM","BOX_OFFICE_MOVIE_LIST_ITEM","OFFLINE_AUDIENCE_MOVIE_LIST_ITEM","RECOMMENDATION_MOVIE_LIST_ITEM","MOVIE_IN_CINEMA_LIST_ITEM","PLANNED_TO_WATCH_LIST_ITEM"]},"query":""}
    
    if type == 'new':
        moviesOrder = "YEAR_DESC"
        slug = "popular"
        slug = "popular-films"
        filters = {"booleanFilterValues":[{"filterId":"high_rated","value":true},{"filterId":"released","value":true}],"intRangeFilterValues":[],"singleSelectFilterValues":[],"multiSelectFilterValues":[],"realRangeFilterValues":[]}
    elif type == 'pop':
        moviesOrder = "POSITION_ASC"
        slug = "popular-films"
        filters = {"booleanFilterValues":[],"intRangeFilterValues":[],"singleSelectFilterValues":[],"multiSelectFilterValues":[],"realRangeFilterValues":[]}
    elif type == 'series_top':
        moviesOrder = "POSITION_ASC"
        slug = "series-top250"
        filters = {"booleanFilterValues":[],"intRangeFilterValues":[],"singleSelectFilterValues":[],"multiSelectFilterValues":[],"realRangeFilterValues":[]}
    elif type == 'movie_top':
        moviesOrder = "POSITION_ASC"
        slug = "top250"
        filters = {"booleanFilterValues":[],"intRangeFilterValues":[],"singleSelectFilterValues":[],"multiSelectFilterValues":[],"realRangeFilterValues":[]}
    else:
        moviesOrder = "POSITION_ASC"
        slug = "top500"
        filters = {"booleanFilterValues":[],"intRangeFilterValues":[],"singleSelectFilterValues":[],"multiSelectFilterValues":[],"realRangeFilterValues":[]}
    
    qdata["variables"]["moviesOrder"]=moviesOrder
    qdata["variables"]["slug"]=slug
    qdata["variables"]["filters"]=filters
    qdata["query"]=list_query
    
    try:
        resp = requests.post('https://graphql.kinopoisk.ru/graphql/?operationName=MovieDesktopListPage', headers=headers, data=json.dumps(qdata), verify=False)
    except:
        resp = None
    if not resp or resp.status_code != 200:
        return {}
    return resp.json()

def get_list(type = 'best',total=100):
        pages = int(total/50)
        L=[]
        for p in range(pages):
                print (p+1)
                try:
                        inf = kp_get_MovieList(type, p+1)['data']['movieListBySlug']
                        L1 = inf['movies']['items']
                        for i in L1:
                                id = i['movie']['id']
                                if id not in L: L.append(id) 
                except:
                        print ('ERR: get_list')
        return L

def kp_get_MovieList2(param={},page=1):
    offset = (page-1)*50
    qdata = {"operationName":"MovieDesktopListPage","variables":{"slug":"top500","platform":"DESKTOP","withUserData":true,"supportedFilterTypes":["BOOLEAN","SINGLE_SELECT"],"filters":{"booleanFilterValues":[],"intRangeFilterValues":[],"singleSelectFilterValues":[],"multiSelectFilterValues":[],"realRangeFilterValues":[]},"singleSelectFiltersLimit":700,"singleSelectFiltersOffset":0,"moviesLimit":50,"moviesOffset":offset,"moviesOrder":"POSITION_ASC","supportedItemTypes":["COMING_SOON_MOVIE_LIST_ITEM","MOVIE_LIST_ITEM","TOP_MOVIE_LIST_ITEM","POPULAR_MOVIE_LIST_ITEM","MOST_PROFITABLE_MOVIE_LIST_ITEM","MOST_EXPENSIVE_MOVIE_LIST_ITEM","BOX_OFFICE_MOVIE_LIST_ITEM","OFFLINE_AUDIENCE_MOVIE_LIST_ITEM","RECOMMENDATION_MOVIE_LIST_ITEM","MOVIE_IN_CINEMA_LIST_ITEM","PLANNED_TO_WATCH_LIST_ITEM"]},"query":""}
    
    filtres = {"booleanFilterValues":[],"intRangeFilterValues":[],"singleSelectFilterValues":[],"multiSelectFilterValues":[],"realRangeFilterValues":[]}
    qdata["variables"]["slug"]=param['slug']
    filtres_d = eval(repr(param['filters']).replace('__typename','typename'))
    print (filtres_d)
    for k in filtres_d.keys():
            itms = filtres_d[k]
            #flt=[]
            #for i in itms:
            #        i.pop('typename')
            #        flt.append(i)
            if k!='typename': filtres[k]=itms
    print (filtres)
    #{"booleanFilterValues":[{"filterId":"high_rated","value":true, __typename: "BooleanFilterValue"},{"filterId":"released","value":true}],"intRangeFilterValues":[],"singleSelectFilterValues":[],"multiSelectFilterValues":[],"realRangeFilterValues":[]}
    
    qdata["variables"]["filters"]=filtres#param['filters']
    qdata["query"]=list_query
    
    try: resp = requests.post('https://graphql.kinopoisk.ru/graphql/?operationName=MovieDesktopListPage', headers=headers, data=json.dumps(qdata), verify=False)
    except: resp = None
    if not resp or resp.status_code != 200: return {}
    return resp.json()

def get_list2(param={},total=100):
        pages = int(total/50)
        L=[]
        for p in range(pages):
                print (p+1)
                inf = kp_get_MovieList2(param, p+1)['data']['movieListBySlug']
                L1 = inf['movies']['items']
                for i in L1:
                     try:
                        id = i['movie']['id']
                        if id not in L: L.append(id) 
                     except: pass
        return L


def kp_get_SuggestSearch(keyword='terminator'):
    qdata = {
      "operationName": "SuggestSearch",
      "variables": {
        "keyword": keyword,
        "yandexCityId": 911,
        "limit": 13
      },
      "query": "query SuggestSearch($keyword: String!, $yandexCityId: Int, $limit: Int) { suggest(keyword: $keyword) { top(yandexCityId: $yandexCityId, limit: $limit) { topResult { global { ...SuggestMovieItem ...SuggestPersonItem ...SuggestCinemaItem ...SuggestMovieListItem __typename } __typename } movies { movie { ...SuggestMovieItem __typename } __typename } persons { person { ...SuggestPersonItem __typename } __typename } cinemas { cinema { ...SuggestCinemaItem __typename } __typename } movieLists { movieList { ...SuggestMovieListItem __typename } __typename } __typename } __typename } } fragment SuggestMovieItem on Movie { id contentId title { russian original __typename } rating { kinopoisk { isActive value __typename } __typename } poster { avatarsUrl fallbackUrl __typename } viewOption { buttonText isAvailableOnline: isWatchable(filter: {anyDevice: false, anyRegion: false}) purchasabilityStatus contentPackageToBuy { billingFeatureName __typename } type availabilityAnnounce { groupPeriodType announcePromise availabilityDate type __typename } __typename } ... on Film { type productionYear __typename } ... on TvSeries { releaseYears { end start __typename } __typename } ... on TvShow { releaseYears { end start __typename } __typename } ... on MiniSeries { releaseYears { end start __typename } __typename } __typename } fragment SuggestPersonItem on Person { id name originalName birthDate poster { avatarsUrl fallbackUrl __typename } __typename } fragment SuggestCinemaItem on Cinema { id ctitle: title city { id name geoId __typename } __typename } fragment SuggestMovieListItem on MovieListMeta { id cover { avatarsUrl __typename } coverBackground { avatarsUrl __typename } name url description movies(limit: 0) { total __typename } __typename } "}
    try:
        resp = requests.post('https://graphql.kinopoisk.ru/graphql/?operationName=SuggestSearch', headers=headers, data=json.dumps(qdata), verify=False)
    except:
        resp = None
    if not resp or resp.status_code != 200:
        return {}
    return resp.json()

def KP_Search(keyword='terminator'):
        #keyword='terminator'
        if keyword=='':return []
        j=kp_get_SuggestSearch(keyword)
        
        inf = j['data']['suggest']['top']

        L=[]
        try: L.append(inf['topResult']['global']['id'])
        except: pass
        try:
            for i in inf['movies']:
                L.append(i['movie']['id'])
        except: pass
        return L
#print(KP_Search())
'''
top_series=get_list('series_top',250)
top_list=get_list('movie_top',250)
pop_list =get_list('pop')
new_list =get_list('new')

category_lists = []
for i in get_Category_list():
        if '100' in i['name']: ni=100
        elif '250' in i['name']: ni=250
        elif '500' in i['name']: ni=500
        else: ni=50
        list=get_list2(i,ni)
        category_lists.append({'title':i['name'],'cover':i['cover'],'list':list})
'''
#print(category_lists)
#print(get_info(ID = 7525290))
#time.sleep(30)