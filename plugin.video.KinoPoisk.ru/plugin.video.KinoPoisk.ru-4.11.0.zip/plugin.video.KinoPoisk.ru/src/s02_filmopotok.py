#!/usr/bin/python
# -*- coding: utf-8 -*-

import re
import os, sys
import xbmcgui, xbmcplugin, xbmcaddon
import time, random
try:
  from xbmcvfs import translatePath
except (ImportError, AttributeError):
  from xbmc import translatePath
#-----------------------------------------
import socket
socket.setdefaulttimeout(50)


if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2


def b2s(s):
	if test_torrent(s)==False: return s
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def test_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False


__settings__ = xbmcaddon.Addon(id='plugin.video.KinoPoisk.ru')

icon = ""
siteUrl = 'miyto.ru'#filmopotok.ru
httpSiteUrl = 'http://' + siteUrl

#import Cookie
#sid_file = os.path.join(xbmc.translatePath('special://temp/'), 'fasttor.cookies.sid')
 
#cj = cookielib.FileCookieJar(sid_file) 
#hr  = urllib2.HTTPCookieProcessor(cj) 
#opener = urllib2.build_opener(hr) 
#urllib2.install_opener(opener) 

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return translatePath(x)
def rt(x):
	L=[('&#39;','’'), ('&#145;','‘'), ('&#146;','’'), ('&#147;','“'), ('&#148;','”'), ('&#149;','•'), ('&#150;','–'), ('&#151;','—'), ('&#152;','?'), ('&#153;','™'), ('&#154;','s'), ('&#155;','›'), ('&#156;','?'), ('&#157;',''), ('&#158;','z'), ('&#159;','Y'), ('&#160;',''), ('&#161;','?'), ('&#162;','?'), ('&#163;','?'), ('&#164;','¤'), ('&#165;','?'), ('&#166;','¦'), ('&#167;','§'), ('&#168;','?'), ('&#169;','©'), ('&#170;','?'), ('&#171;','«'), ('&#172;','¬'), ('&#173;',''), ('&#174;','®'), ('&#175;','?'), ('&#176;','°'), ('&#177;','±'), ('&#178;','?'), ('&#179;','?'), ('&#180;','?'), ('&#181;','µ'), ('&#182;','¶'), ('&#183;','·'), ('&#184;','?'), ('&#185;','?'), ('&#186;','?'), ('&#187;','»'), ('&#188;','?'), ('&#189;','?'), ('&#190;','?'), ('&#191;','?'), ('&#192;','A'), ('&#193;','A'), ('&#194;','A'), ('&#195;','A'), ('&#196;','A'), ('&#197;','A'), ('&#198;','?'), ('&#199;','C'), ('&#200;','E'), ('&#201;','E'), ('&#202;','E'), ('&#203;','E'), ('&#204;','I'), ('&#205;','I'), ('&#206;','I'), ('&#207;','I'), ('&#208;','?'), ('&#209;','N'), ('&#210;','O'), ('&#211;','O'), ('&#212;','O'), ('&#213;','O'), ('&#214;','O'), ('&#215;','?'), ('&#216;','O'), ('&#217;','U'), ('&#218;','U'), ('&#219;','U'), ('&#220;','U'), ('&#221;','Y'), ('&#222;','?'), ('&#223;','?'), ('&#224;','a'), ('&#225;','a'), ('&#226;','a'), ('&#227;','a'), ('&#228;','a'), ('&#229;','a'), ('&#230;','?'), ('&#231;','c'), ('&#232;','e'), ('&#233;','e'), ('&#234;','e'), ('&#235;','e'), ('&#236;','i'), ('&#237;','i'), ('&#238;','i'), ('&#239;','i'), ('&#240;','?'), ('&#241;','n'), ('&#242;','o'), ('&#243;','o'), ('&#244;','o'), ('&#245;','o'), ('&#246;','o'), ('&#247;','?'), ('&#248;','o'), ('&#249;','u'), ('&#250;','u'), ('&#251;','u'), ('&#252;','u'), ('&#253;','y'), ('&#254;','?'), ('&#255;','y')]
	for i in L:
		x=x.replace(i[0], i[1])
	return x

p = re.compile(r'<.*?>')


def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def rulower(str):
	str=str.strip()
	str=xt(str).lower()
	str=str.replace('Й','й')
	str=str.replace('Ц','ц')
	str=str.replace('У','у')
	str=str.replace('К','к')
	str=str.replace('Е','е')
	str=str.replace('Н','н')
	str=str.replace('Г','г')
	str=str.replace('Ш','ш')
	str=str.replace('Щ','щ')
	str=str.replace('З','з')
	str=str.replace('Х','х')
	str=str.replace('Ъ','ъ')
	str=str.replace('Ф','ф')
	str=str.replace('Ы','ы')
	str=str.replace('В','в')
	str=str.replace('А','а')
	str=str.replace('П','п')
	str=str.replace('Р','р')
	str=str.replace('О','о')
	str=str.replace('Л','л')
	str=str.replace('Д','д')
	str=str.replace('Ж','ж')
	str=str.replace('Э','э')
	str=str.replace('Я','я')
	str=str.replace('Ч','ч')
	str=str.replace('С','с')
	str=str.replace('М','м')
	str=str.replace('И','и')
	str=str.replace('Т','т')
	str=str.replace('Ь','ь')
	str=str.replace('Б','б')
	str=str.replace('Ю','ю')
	return str

def unlock(url):
	try:
		import xbmcaddon
		tam_settings = xbmcaddon.Addon(id='plugin.video.tam')
		tam_port = int(tam_settings.getSetting("serv_port"))
	except:
		tam_port = 8095
	url='http://127.0.0.1:'+str(tam_port)+'/proxy/'+url
	return url

def GET(target, post=None):
	#if __settings__.getSetting("antizapret") == "true": target = unlock(target)
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return b2s(http)
	except:
		print ('get err')

def POST(url, post = None, ref = None, get_redirect = False):
	if __settings__.getSetting("antizapret") == "true": url = unlock(url)
	if sys.version_info.major > 2: post = post.encode()
	request = urllib2.Request(url, post)
	request.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
	request.add_header('Host',   host)
	request.add_header('Accept', 'text/html, application/xhtml+xml, */*')
	request.add_header('Accept-Language', 'ru-RU')
	if ref!=None: request.add_header('Referer',             ref)
	request.add_header('Content-Type','application/x-www-form-urlencoded')
	try:
		f = urllib2.urlopen(request)
	except:
		return None
	if get_redirect == True:
		html = f.geturl()
	else:
		html = f.read()
	return b2s(html)


def format2(L):
	if L==None: 
		return ["","","","","","","","",""]
	else:
		Li=[]
		Ln=[]
		L1=[]
		qual=""
		i=0
		for itm in L:
			i+=1
			if len(itm)>6:
				if itm[:4]=="flag":
					if itm[:5]=="flag2":
						qual=itm[6:]
					if itm[:5]=="flag1":
						#try:
							L1=eval(itm[6:])
							L1.append(qual)
							qual=""
							Ln.append(L1)
						#except: 
						#	qual=""
					
		return Ln


def gettorlist(str):
	#gettorlist_n(str)
	str=str.replace(chr(13)+chr(10),chr(10))
	str=str.replace(chr(10)+chr(13),chr(10))
	str=str.replace(chr(10),"")
	str=str.replace("\t","")
	str=str.replace("&nbsp;"," ")
	
	n=str.find('<div class="ordering">')
	if n<100: n=str.find('>Как скачать фильм?<')
	if n<1000:n=1000
	k=str.rfind('Сообщить о появлении в хорошем качестве')
	str=str[n:k]
	
	str=str.replace("'",'"')
	#str=str.replace("[",'(')
	#str=str.replace("]",')')
	
	str=str.replace('use_tooltip" title="',chr(10)+"flag2:")
	str=str.replace('::',chr(10))

	str=str.replace('Подробнее</a></td><td ><b>',chr(10)+"flag1:['")
	str=str.replace('Подробнее</a></td><td > ',chr(10)+"flag1:['")
	str=str.replace('Подробнее</a>',chr(10)+"flag1:['")
	str=str.replace('</div><div class="c2">',"")
	str=str.replace('</div><div class="c3">',"', '")
	str=str.replace('</div><div class="c4">',"', '")
	str=str.replace('</div><div class="c5">',"', '")
	str=str.replace('</div><div class="c6">',"', '")
	str=str.replace('</div><div class="c7">',"', '")
	str=str.replace('<font color="green" nowrap="nowrap" title="Раздают">', '')
	str=str.replace('</font><br/><font color="red" title="Качают" nowrap="nowrap">', "', '")
	
	str=str.replace('</td><td title="Открыть подробное описание торрента">',"', '")
	str=str.replace('<font color="green" nowrap="nowrap" title="Раздают">',"")
	str=str.replace('</font><br/><font color="red" title="Качают" nowrap="nowrap">',"', '")
	str=str.replace('</font></td><td class="right"><a href="',"', '")
	str=str.replace('.torrent"><img alt="Скачать"',".torrent']"+chr(10))
	str=str.replace('.torrent"><em class="download-button">',".torrent']"+chr(10))
	str=str.replace('.torrent"',".torrent']"+chr(10))
	str=p.sub('', str)
	
	
	L=str.splitlines()
	Ln=format2(L)
	return Ln

def OpenList_old(url, dict,title):
	print ('http://filmopotok.ru/'+url.replace(".html", "/torrents.html"))
	hp = GET('http://filmopotok.ru'+url.replace(".html", "/torrents.html"))
	L=gettorlist(hp)
	LL=[]
	for Li in L:
		if len(Li)!=7: Li=["","","","","","","","",""]
		if Li[0]!="":
			Title = ""
			
		Lang = Li[0].strip()
		Size = Li[1]
		Size=Size[:10]
		if Size.find("М")>0: Size=Size[:Size.find(".")]+" MB"
		Size=Size.replace('ГБ', "GB")

		Sids = Li[3].strip()
		Urlt = Li[5].replace('<a href="', httpSiteUrl)
		Qual = Li[6].strip()
		
		Title = rt(title)
		row_name = Title+"  "+Qual+" | "+Lang
		
		row_url = Urlt
		LL.append({'sids':Sids, 'size':Size, 'title':row_name, 'url':row_url, 'quality':Qual})#LL.append([SL,Size,row_name,row_url])
	return LL

def OpenList(url, dict, title):
	hp = GET(httpSiteUrl+url.replace(".html", "/torrents.html"))
	L=mfindal(hp, "<div class='upload1'>", "class='torrent-row open' row_id")#<em class='download-button'>
	LL=[]
	for i in L:
		i=i.replace('\t','').replace("\\'","'").replace(chr(10),'').replace(chr(13),'').replace("c2 voice","c2").replace("c10 voice","c10")
		qual=mfind(i,"qa-icon qa-"," use_tooltip")
		if 'Русский фильм' in i: 
			lang=''
		else:
			if "<div class='c10" in i:
				if "c10'><b>" in i: lang=mfind(i,"class='c10'><b>","</b>")
				else: lang=mfind(i,"class='c10'>","<")
				if '_blank">' in i: lang=lang+" "+mfind(i,'_blank">',"</a>")
			else:
				if "c2'><b>" in i: lang=mfind(i,"class='c2'><b>","</b>")
				else: lang=mfind(i,"class='c2'>","<")
		size=mfind(i,"class='c3'>","</div>")
		if size.find("М")>0: size=size[:size.find(".")]+" MB"
		size=size.replace('ГБ', "GB")
		if "class='c6'>--/--" in i: sids='?'
		else: sids=mfind(i,"<em class='upload-icon l","'><")
		if len(sids) > 10: sids = '?'
		curl=httpSiteUrl+"/download/"+mfind(i,"/download/",'.torrent')+".torrent"
		
		if "<div class='c9'>" in i: 
			if "c9'><b>" in i: sez=mfind(i,"class='c9'><b>","</b>").replace('&nbsp;','-')
			else: sez=mfind(i,"class='c9'>","<").replace('&nbsp;','-').replace('-й-',' ')
		else: sez=""
		ttl = mfind(i.replace("-event'><em",''),"class='download-event'>", '</a><br/><span>')
		row_name = ttl+" "+sez+" "+qual+" | "+lang
		LL.append({'sids':sids, 'size':size, 'title':row_name, 'url':curl, 'quality':qual})
	return LL

def formatKP(s):
	return quote(s)


def upd_off(text):
	stext=text.replace(" ", "%20")
	categoryUrl = httpSiteUrl+'/search/'+stext+'/1.html'
	post = "search_pages=50&sort=8"
	http = POST(categoryUrl, post)
	if http == None:
		return None
	else:
		LL=formtext_n(http)
		return LL

def autocomplete(t):
	url = httpSiteUrl+'/search/autocomplete/all/'+quote(t)
	null=''
	D = eval(GET(url))[1]
	L=[]
	for i in D:
		L.append({'title' : D[i]['value'], 'url' : D[i]['href']})
	return L


def Search2(text):
	RootList=autocomplete(text)
	L=[]
	n=0
	
	for t in RootList:
				n+=1
				dict=t
				title=t['title']
				row_url = t['url']
				if row_url!='': LL=OpenList(row_url, dict, title)
				L.extend(LL)
				if n>5: return L
	return L


def cp1251(x):
	L=list(x)
	s=""
	for i in L:
		try:s+=i.decode('cp1251')
		except: pass
	return s

def mid1 (x):
	d=10-len(x)
	p=" "*d
	r= p+ x +p
	return r

def formtext_n(http):
	http=http.replace(chr(13),chr(10))
	http=http.replace(chr(10)+chr(10),chr(10))
	http=http.replace(chr(10)+chr(10),chr(10))
	http=http.replace("\t","")
	http=http.replace('\\"','"')
	http=http.replace("'",'"')
	ss='<div class="film-item'
	ss='<div class="film-wrap'
	ss='<div itemscope itemtype'
	es='class="film-download'
	if es not in http: es='<em class="film-downloaded">'
	L=mfindal(http, ss, es)
	RL=[]
	for i in L:
		try:
			dict={}
		#------------------- ищем ссылку ----------------
			url=mfind(i, '<meta itemprop="url" content="', '"')
			dict['url']=url
		#------------------- ищем название ----------------
			nm=mfind(i, '<h2><span itemprop="name">', '<br/></h2><div')
			try:nm=nm.replace("<br/>",'').replace("</span>",'').replace('<span itemprop="alternativeHeadline">','').strip()
			except: nm="НАЗВАНИЕ"
			dict['title']=nm
			RL.append(dict)
		except: pass
	return RL


class Tracker:
	def Search(self, info):
		text=info['originaltitle']
		Lout=Search2(text)
		return Lout
