#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys, json, time

prov = 'pma'
D_UA='|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 OPR/77.0.4054.203'

if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2


def b2s(s):
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def test_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False

def CRC32(buf):
		import binascii
		if sys.version_info.major > 2: buf = (binascii.crc32(buf.encode('utf-8')) & 0xFFFFFFFF)
		else: buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		r=str("%08X" % buf)
		return r

def add_ch(id, D):
	try:
		import settings
		settings.set(prov+'_ch_'+id, {'ch':D, 'tm': time.time()})
	except: pass


def get_ch(id):
	try:
		import settings
		Dch  = settings.get(prov+'_ch_'+id)
		D  = Dch['ch']
		tm = Dch['tm']
		if (time.time()-tm<3600*3): return D
		else: return None
	except:
		return None

def unlock(url):
	try:
		import xbmcaddon
		tam_settings = xbmcaddon.Addon(id='plugin.video.tam')
		tam_port = int(tam_settings.getSetting("serv_port"))
	except:
		tam_port = 8095
	url='http://127.0.0.1:'+str(tam_port)+'/proxy/'+url
	return url


def findall(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def add_ch(id, D):
	try:
		import settings
		settings.set(prov+'_ch_'+id, {'ch':D, 'tm': time.time()})
	except: pass


def get_ch(id):
	try:
		import settings
		Dch  = settings.get(prov+'_ch_'+id)
		D  = Dch['ch']
		tm = Dch['tm']
		if (time.time()-tm<3600*3): return D
		else: return None
	except:
		return None


def GET(target, referer='', post=None):
		import requests
		s = requests.session()
		r=s.get(target, timeout=(0.6, 4), verify=False).text
		return r
		print ('GET err')


def get_movie(info={}):
	Lr=[]
	try:
		en_title = quote(info['originaltitle'])
		ru_title = quote(info['title'])
		year = str(info['year'])
		kp_id = info['id']
		url='https://api.manhan.one/late/'+prov+'?serial=0&kinopoisk_id='+kp_id+'&original_title='+en_title+'&title='+ru_title+'&year='+year#&kinopoisk_id=5457899&title=Дикий%20робот&original_language=en&source=tmdb&clarification=0'
	except:
		url='https://api.manhan.one/late/'+prov+'?kinopoisk_id=5457899&title=Дикий%20робот&original_title=The%20Wild%20Robot&serial=0&original_language=en&year=2024'#id=1184918&imdb_id=tt29623480&&source=tmdb&clarification=0
	
	h=GET(url)
	L=findall(h,"data-json='{","}'><div class")
	for i in L:
		try:
			j=i.replace("data-json='","")+"}"
			#print (j)
			if 'UKR' not in j and ' Ukr' not in j:
				D=json.loads(j)
				t=D['translate'].replace('4K','').replace('SDR','').replace(',','').replace('  ',' ').replace('  ',' ').replace('[ ]','')
				if ' Ukr,' not in t:
					try:
						Lq=D['quality']
						for q in Lq.keys():
							stream = Lq[q]
							#print (t+' '+q)
							Lr.append ({"sids":'0',"size":'0', "title": '[ '+prov+' ] '+t+' '+q, "url":stream})
					except:
						stream = D['url']
						ttl = D['title']
						if t not in ttl: ttl=ttl+' '+t
						Lr.append ({"sids":'0',"size":'0', "title": '[ '+prov+' ] '+ttl, "url":stream})
		except: pass
	return Lr

#print (get_movie())

def get_serial(info={}):
	Lr=[]
	try:
		en_title = quote(info['originaltitle'])
		ru_title = quote(info['title'])
		year = str(info['year'])
		kp_id = str(info['id'])
		url='https://api.manhan.one/late/'+prov+'?serial=1&kinopoisk_id='+kp_id+'&original_title='+en_title+'&title='+ru_title+'&year='+year#&kinopoisk_id=5457899&title=Дикий%20робот&original_language=en&source=tmdb&clarification=0'
		#print (url)
	except:
		url='https://api.manhan.one/late/'+prov+'?title=%D0%98%D0%B7%D0%B2%D0%BD%D0%B5&original_title=FROM&serial=1&original_language=en&year=2022'
	h=GET(url)
	Ls=findall(h,"data-json='{","}'><div class")
	for si in Ls:
		try:
			j=si.replace("data-json='","")+"}"
			#print (j)
			D=json.loads(j)
			S=mfind(j,'&s=','"')
			if len(S)==1:S='0'+S
			tl_url=D['url']
			tlh=GET(tl_url)
			
			Lt=findall(tlh,"data-json='{","div></div>")
			for ti in Lt:
				t=mfind(ti,'videos__season-title">','<')
				jt=mfind(ti,"data-json='","}'>")+'}'
				
				#print (jt)
				if '"method":"link"' in jt and 'UKR' not in jt and ' Ukr' not in jt:
					Dt=json.loads(jt)
					link=Dt['url']
					q=Dt['details'].replace('SDR','').replace('HDR','').replace('/','').replace('  ',' ').replace('  ',' ')#.replace('4K','').replace(',','').replace('[ ]','').replace('</div>','')
					#print (t+' '+q)
					#print (link)
					Lr.append ({"sids":'0',"size":'0', "title": '[ '+prov+' ] s'+S+' '+t+' '+q, "url":"manhan_"+prov+"_season:"+link})
		except: pass
	return Lr

#print(get_serial())

def get_episodes(url):
	Lr=[]
	h=GET(url.replace('manhan_'+prov+'_season:',''))
	Le=findall(h,'{"method":"play"',"}'><div class")
	for ei in Le:
		j=ei.replace("data-json='","")+"}"
		print (j)
		if '"method":"play"' in j :
			D=json.loads(j)
			method = D['method']
			if method == 'play':
				stream=D['url']
				qse=stream[stream.rfind('/')+1:stream.rfind('.')]
				ttl=D['title']#+' [COLOR 00ffffff]'++'[/COLOR]'
				Lr.append ({"sids":'0',"size":'0', "title": '['+qse+'] '+ttl, "url":stream})
	return Lr


class Tracker:
	def Search(self, info):
		id=info['id']
		Dc=get_ch(id)
		if Dc!=None: return Dc
		
		Lout = []
		if info['type']=='': Lout = get_movie(info)
		else:                Lout = []#get_serial(info)
		
		if Lout != []: add_ch(id, Lout)
		return Lout

		
	def Episodes(self, url):
		id=CRC32(url)
		Dc=get_ch(id)
		if Dc!=None: return Dc
		
		Lout = []
		Lout = get_episodes(url)
		
		if Lout != []: add_ch(id, Lout)
		return Lout
