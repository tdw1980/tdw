# -*- coding: utf-8 -*-
import sys, os
import json, time
from ftplib import FTP
temp_dir = "d:\\"

null = ''
false = False
true = True

cch = {}

if sys.version_info.major > 2:  # Python 3 or later
	import urllib.request
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2

#try:
#	import ssl
#	context = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
#	opener = urllib2.build_opener(urllib2.HTTPSHandler(context=context))
#	urllib2.install_opener(opener)
#except: pass

def b2s(s):
	if test_torrent(s)==False: return s
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def test_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False

def info_to_utf(inf):
	if sys.version_info.major > 2: 
		cinfo = eval(inf.replace("\\x", "\\\\x").replace("\\r", "\\\\r").replace("\\n", "\\\\n").replace("\\\\xa0", " "))
		for id in cinfo.keys():
			info = cinfo[id]
			for key in info.keys():
				try: 
					info[key]=eval("b'"+info[key]+"'").decode()
					print (info[key])
				except: pass
			cast = []
			try:
				L = info["cast"]
				for a in L:
					cast.append(eval("b'"+a+"'").decode())
				info["cast"]=cast
			except: pass
			info[id]=info
	else:
		cinfo = eval(inf)
	return cinfo


def ru(x):
	if sys.version_info.major > 2: return x
	return unicode(x,'utf8', 'ignore')

def j2d(j):
	d=json.loads(j)
	#d=eval(j)
	return d

def d2j(d):
	j=json.dumps(d, ensure_ascii=False)
	return j

def GET(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	response = urllib2.urlopen(req, timeout=3)
	link=response.read()
	response.close()
	return b2s(link)

def GET2(url):
		import requests
		s = requests.session()
		r=s.get(url, timeout=(0.5, 3), verify=False).text
		return r


def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		#sn=http[s:]
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def CRC32(buf):
		import binascii
		if sys.version_info.major > 2: buf = (binascii.crc32(buf.encode('utf-8')) & 0xFFFFFFFF)
		else: buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		r=str("%08X" % buf)
		return r

def save_inf(s):
	if sys.version_info.major > 2: s=s.encode()
	p = os.path.join(ru(temp_dir),"temp.txt")
	f = open(p, "wb")
	f.write(s)
	f.close()
	return p

def upload(ftp, path, ftp_path):
	with open(path, 'rb') as fobj:
		ftp.storbinary('STOR ' + ftp_path, fobj, 1024)


def get_path(id):
	pref='xxx'
	id=pref+id
	s=[id[-2:],id[-4:-2]]
	return s

def make_id(ftp, id):
	s='/db'
	i=get_path(id)
	for c in [i[0], i[1]]:
		s+='/'+c
		try:ftp.mkd(s)
		except: pass
	ret=s+'/'+i[2]
	#print ret
	return ret

def get_request(q):
	id=CRC32(q)
	HUP=get_host('request')
	HOST=HUP['HOST']
	url='http://'+HOST+'/request/'+id[0]+'/'+id[1]+'/'+id[2:]+'.txt'
	#print (url)
	request=eval(GET(url))
	try:request=eval(GET(url))
	except: request={}
	return request

def save_request(q, r):
	#print 'ADD request: '+q
	HUP=get_host('request')
	HOST=HUP['HOST']
	USER=HUP['USER']
	PASS=HUP['PASS']
	ftp = FTP(HOST)
	ftp.login(USER, PASS)
	
	id=CRC32(q)
	try:
		ftp.mkd('/request/'+id[0])
	except: pass
	try:
		ftp.mkd('/request/'+id[0]+'/'+id[1])
	except: pass
	path = save_inf(repr(r))
	upload(ftp, path, '/request/'+id[0]+'/'+id[1]+'/'+id[2:]+'.txt')
	ftp.quit()


def add(info):
	return add_compression_info(info)


def update(info):
	return add_compression_info(info)

def get_info(id):
	return get_compression_info(id)

def get_host(id):
	if id=='request': return {'HOST':'roms.my1.ru',    'USER':'5roms',   'PASS':'19111980'}
	else:             return {'HOST':'td-soft.narod.ru', 'USER':'otd-soft',  'PASS':'19111980'}


def make_compression_info(id):
	#print ('make_compression_info')
	c=get_path(id)
	HUP=get_host(id)
	HOST=HUP['HOST']
	USER=HUP['USER']
	PASS=HUP['PASS']
	cinfo=d2j({})
	ftp = FTP(HOST)
	ftp.login(USER, PASS)
	try:ftp.mkd('/db/'+c[0])
	except: pass
	
	path = save_inf(cinfo)
	url='/db/'+c[0]+'/'+c[1]+'.info'
	upload(ftp, path, url)
	ftp.quit()
	return cinfo

def get_compression_info(id):
	#print ('get_compression_info')
	#print (cch.keys())
	c=get_path(id)
	
	HOST=get_host(id)['HOST']
	url='http://'+HOST+'/db/'+c[0]+'/'+c[1]+'.info'
	
	try: 
		if c[0]+'/'+c[1] in cch.keys(): 
			cinfo = cch [c[0]+'/'+c[1]]
			#print ('cinfo из кэша')
		else: 
			cinfo=eval(GET(url))
			#print ('cinfo загружен')
	except: 
		#print ('cinfo не найден')
		cinfo=make_compression_info(id)
		#print ('cinfo создан')
	cch [c[0]+'/'+c[1]] = cinfo
	info=cinfo[id]
	return info

def add_compression_info(nfo):
	#print ('add_compression_info')
	id=nfo['id']
	c=get_path(id)
	HUP=get_host(id)
	HOST=HUP['HOST']
	USER=HUP['USER']
	PASS=HUP['PASS']
	
	if c[0]+'/'+c[1] in cch.keys(): 
		cinfo = cch [c[0]+'/'+c[1]]
	else:
		url='http://'+HOST+'/db/'+c[0]+'/'+c[1]+'.info'
		try:    r = GET(url)
		except: r = make_compression_info(id)
		if r == None or r == '': r = make_compression_info(id)
		cinfo=eval(r)#j2d
	cinfo[id]=nfo
	
	ftp = FTP(HOST)
	ftp.login(USER, PASS)
	#print ('SAVEcomp KinoDB: '+id)
	
	path = save_inf(d2j(cinfo))
	ftp_url='/db/'+c[0]+'/'+c[1]+'.info'
	upload(ftp, path, ftp_url)
	ftp.quit()
	cch [c[0]+'/'+c[1]] = cinfo

#add({"test":"тест", 'id':'365'})
#print (get_info('1009017'))
#time.sleep(10)