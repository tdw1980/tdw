# coding: utf-8
# Module: server
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys
import xbmc, xbmcgui, xbmcaddon
__settings__ = xbmcaddon.Addon(id='plugin.video.KinoPoisk.ru')

print('----- KinoPoisk.ru 2.0 started -----')
xbmc.sleep(10000)
monitor = xbmc.Monitor()

while not monitor.abortRequested():
		xbmc.executebuiltin('RunPlugin("plugin://plugin.video.KinoPoisk.ru/?mode=check")')
		monitor.waitForAbort(6*60*60)

print('----- KinoPoisk.ru 2.0 stopped -----')