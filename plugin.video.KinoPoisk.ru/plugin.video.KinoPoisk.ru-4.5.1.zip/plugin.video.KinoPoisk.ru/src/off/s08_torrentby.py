#!/usr/bin/python
# -*- coding: utf-8 -*-

import time
import os, sys
import string, xbmc, xbmcgui, xbmcplugin, xbmcaddon
#-------------------------------

icon = ""
siteUrl = 'torrent.by'
httpSiteUrl = 'http://' + siteUrl
__settings__ = xbmcaddon.Addon(id='plugin.video.KinoPoisk.ru')


if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2


def b2s(s):
	if test_torrent(s)==False: return s
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def test_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False


def unlock(url):
	url='http://127.0.0.1:8095/proxy/'+url
	return url


def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def lower(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in range (65,90):
		t=t.replace(chr(i),chr(i+32))
	for i in RUS.keys():
		t=t.replace(i,RUS[i])
	return t


def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "wb")
	fl.write(s)
	fl.close()


def GET(target, referer='http://torrent.by', post=None):
		if __settings__.getSetting("antizapret") == "true": target = unlock(target)
		if sys.version_info.major > 2 and post!=None: post = post.encode()
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36 OPR/50.0.2762.67')
		req.add_header('Content-Type', 'application/x-www-form-urlencoded')
		req.add_header('Referer', referer)
		req.add_header('Origin', referer)
		
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return b2s(http)

def clear(s):
	L=['<b>','</b>','</a>','</td>']
	for i in L:
		s=s.replace(i,'')
	s=s.replace(chr(10),'').replace(chr(13),'').replace('\t','').strip()
	return s

def Parser(hp):
	Lout=[]
	ss='class="ttable_col'
	es='color="red"'
	Lid=[]
	L=mfindal(hp, ss,es)
	L2=[]
	for i in L:
		#try:
					url=httpSiteUrl+mfind(i, 'class="dwnld" href="', '">')
					title=mfind(i, 'font-size:12px;text-decoration:none;" href="', '</a>')#mfind(, '">', '')
					title=title[title.find('">')+2:]
					sids = mfind(i, '<font color="green">&uarr; ', '<')#↑ 
					size = mfind(i, '</td><td style="white-space:nowrap;">', '<')
					if __settings__.getSetting("antizapret") == "true": url = unlock(url)
					Lout.append({"sids":sids, "size":size, "title":title, "url":url, "quality": ""})
					#print Lout
		#except:
					#print i
		#			print 'err'
	return Lout


def Storr(info):
	Lout=[]
	text=lower(info['originaltitle'])
	
	url='http://torrent.by/search/'
	post='search='+quote(text)
	
	http=GET(url,'http://torrent.by', post)
	Lout=Parser(http)
	return Lout



class Tracker:
	def __init__(self):
		pass

	def Search(self, info):
		Lout=Storr(info)
		return Lout

#Storr('info')