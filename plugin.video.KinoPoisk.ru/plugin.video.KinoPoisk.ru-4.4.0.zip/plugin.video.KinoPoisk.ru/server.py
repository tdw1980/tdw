# coding: utf-8
# Module: server
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys
import xbmc, xbmcgui, xbmcaddon
__settings__ = xbmcaddon.Addon(id='plugin.video.KinoPoisk.ru')

print('----- KinoPoisk.ru 2.0 started -----')
start_trigger = False
xbmc.sleep(10000)

def abortRequested():
	if sys.version_info.major > 2: return xbmc.Monitor().abortRequested()
	else: return xbmc.abortRequested


while not abortRequested():
		xbmc.executebuiltin('RunPlugin("plugin://plugin.video.KinoPoisk.ru/?mode=check")')
		for i in range(0, 6000):
				xbmc.sleep(3000)
				if abortRequested(): break
				xbmc.sleep(3000)
				if abortRequested(): break

print('----- KinoPoisk.ru 2.0 stopped -----')

