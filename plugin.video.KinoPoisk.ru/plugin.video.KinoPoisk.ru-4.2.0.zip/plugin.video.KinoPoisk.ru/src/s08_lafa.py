#!/usr/bin/python
# -*- coding: utf-8 -*-

import urllib, urllib2, time, ssl
#import os
#import Cookie

#import string, xbmc, xbmcgui, xbmcplugin, urllib, cookielib, xbmcaddon
#-------------------------------

#try:
#	import ssl
#	context = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
	#opener = urllib2.build_opener(urllib2.HTTPSHandler(context=context))
	#urllib2.install_opener(opener)
#except: pass
try:
	ctx = ssl.create_default_context()
	ctx.check_hostname = False
	ctx.verify_mode = ssl.CERT_NONE
except: pass


icon = ""
siteUrl = 't.lafa.site'
httpSiteUrl = 'http://' + siteUrl
#addon = xbmcaddon.Addon(id='plugin.video.KinoPoisk.ru')
#__settings__ = xbmcaddon.Addon(id='plugin.video.KinoPoisk.ru')

#__settings__ = xbmcaddon.Addon(id='plugin.video.tvshow.tdw')
def unlock(url):
	url='http://127.0.0.1:8095/proxy/'+url
	return url

'''
if __settings__.getSetting("antizapret") == "true":
	try:
		import azpt
		opener = azpt.get_opener()
		urllib2.install_opener(opener)
		print 'antizapret ok'
	except:
		print 'except set proxy'
'''

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def encod(x):
	try:x=x.decode('Windows-1251')
	except:pass
	try:x=x.encode('utf-8')
	except:pass
	return x


def coder(x):
	x=x.decode('utf-8')
	x=x.encode('Windows-1251')
	return x

def lower(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in range (65,90):
		t=t.replace(chr(i),chr(i+32))
	for i in RUS.keys():
		t=t.replace(i,RUS[i])
	return t


def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "wb")
	fl.write(s)
	fl.close()


def GET(target, referer='http://torrent.by', post=None):
		#if __settings__.getSetting("antizapret") == "true": target = unlock(target)
		print target
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36 OPR/50.0.2762.67')
		req.add_header('Content-Type', 'application/x-www-form-urlencoded')
		req.add_header('Referer', referer)
		req.add_header('Origin', referer)
		#req.add_header('Content-Type', 'application/x-www-form-urlencoded')
		#req.add_header('Content-Type', 'application/x-www-form-urlencoded')
		try: resp = urllib2.urlopen(req)
		except: resp = urllib2.urlopen(req, context=ctx)
		http = resp.read()
		resp.close()
		return http#encod()

def clear(s):
	L=['<b>','</b>','</a>','</td>']
	for i in L:
		s=s.replace(i,'')
	s=s.replace(chr(10),'').replace(chr(13),'').replace('\t','').strip()
	return s

def Parser2(hp):
	#print ('======= parser2 ==========')
	sr_title = mfind(hp,'notop"><span itemprop="name">', '</td>').replace('</span>', '').replace('<br>', '')#ListItem"><span itemprop="name">
	#print (sr_title)
	Lout=[]
	ss='class="expand-child"'
	es='width=36 height=36 src=/pic/document_save.svg></a>'
	Lid=[]
	#hp=hp[hp.find('<tr class="zebra"'):]  
	L=mfindal(hp, ss,es)
	L2=[]
	#print len(L)
	for i in L:
		#try:
					#print '---------------------'
					#print i
					url=httpSiteUrl+'/downloadt'+mfind(i, 'href="/downloadt', '">')
					#print url
					title=mfind(i, '<div style="float:left;">', '</')
					title=title[title.find('('):]
					if 'hild id' in title: title=title[:title.find('hild id')]
					#print title
					if '<td width="20%">' in i: sez=mfind(i, '<td width="20%">', '</')
					else: sez=''
					
					lng=mfind(i, 'dl_trad">', '</td>').replace('</span>', '').replace('<br>', '').replace('<i>', '').replace('</i>', '')
					
					sids = '?'#mfind(i, '<font color="green">&uarr; ', '<')
					#print sids
					size = mfind(mfind(i, 'data-sort-value', 'td>'), '>', '<')
					#print size
					quality = mfind(mfind(i, 'class="ttip"', 'span>'), '>', '<')
					
					#if __settings__.getSetting("antizapret") == "true": url = unlock(url)
					f_title = sr_title+' '+title+' '+sez+' '+lng
					f_title = f_title.replace('torrent', '').replace('<img src=/pic/rk.svg>', '')
					Lout.append({"sids":sids, "size":size, "title":f_title, "url":url, "quality": quality})
					#print Lout
		#except:
					#print '=================================='
					#print i
		#			print 'err'
	return Lout

def Parser1(hp, info):
	#print 'parser'
	Lout=[]
	ss='<tr><td>'
	es='</td></tr>'
	Lid=[]
	#hp=hp[hp.find('<tr class="zebra"'):]
	L=mfindal(hp, ss,es)
	L2=[]
	#print len(L)
	for i in L:
		url = httpSiteUrl+mfind(i, '<a href="', '">')
		#print (url)
		#title = mfind(i, 'htm">', '<')
		#if info['title'] in title: 
		L2.append(url)
	return L2



def Storr(info):
	Lout=[]
	text=lower(info['title'])#'termitator'
	
	url='http://t.lafa.site/ajax.php?action=quicksearch&keyword='+urllib.quote_plus(text)
	#post='search='+urllib.quote_plus(text)+'&cat=3&search_in=0'
	
	http=GET(url)#,'http://torrent.by', post)
	L2=Parser1(http, info)
	Lout=[]
	for i in L2:
		#print i
		r=encod(GET(i))
		Lout.extend(Parser2(r))
	
	
	return Lout



class Tracker:
	def __init__(self):
		pass

	def Search(self, info):
		Lout=Storr(info)
		return Lout

#Storr('info')