#!/usr/bin/python
# -*- coding: utf-8 -*-

import httplib
import os
import Cookie

import string, xbmc, xbmcgui, xbmcplugin, urllib, cookielib, xbmcaddon, urllib, urllib2, time
#-------------------------------


icon = ""
siteUrl = 'btdig.com'
httpSiteUrl = 'http://' + siteUrl
addon = xbmcaddon.Addon(id='plugin.video.KinoPoisk.ru')
__settings__ = xbmcaddon.Addon(id='plugin.video.KinoPoisk.ru')

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "wb")
	fl.write(s)
	fl.close()


def GET(target, referer='http://btdig.com', post=None):
	#print target
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		print e
		return ''

def GET2(target, referer='http://btdig.com'):
		import requests
		s = requests.session()
		r=s.get(url, verify=False).text
		#rd=r.encode('windows-1251')
		return r


def upd(text):
	search=text.replace(' ','+')#urllib.quote()
	url= 'http://btdig.com/search?order=0&q='+search
	print url
	http = GET(url)
	#print http
	if http == None:
		print 'torrentino: Сервер не отвечает'
		return None
	else:
		return http

def Parser(http, info):
	print 'Parser'
	title=info['title']
	year1=str(info['year'])
	year2=str(int(info['year'])+1)
	
	ss='display:table-row;background-color:#e8e8e8'
	es='<div style="padding-top:15px">'
	http=http.replace('</div></div></div><hr/>','<div style="padding-top:15px">')
	L=mfindal(http, ss,es)
	L2=[]
	for i in L:
			
		#if title in i and (year1 in i or year2 in i):
			#print i
			i_url = mfind(i,'href="','">')
			L2.append(i_url)
	return L2
	

def get_torrents(url, info):
			print url
			ht=GET(url)
			seed='0'
			size=mfind(ht, 'Size:</td><td style="color:rgb(0, 0, 0);background-color: rgb(238, 238, 238); border-width: 1px; border-style: solid; padding: 3px 7px 2px; border-color: rgb(172, 172, 172);">', '</td>')
			quality=''
			sound=''
			title=mfind(ht, '<title>', '</title>')
			magnet = 'magnet:'+mfind (ht,'href="magnet:','" title')
			Lout={"sids":seed, "size":size, "title":xt(title),"url":magnet, "quality": quality}
			print Lout
			return Lout

def get_sz(url):
	http=GET(url)
	L=[25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1]
	for i in L:
		if 'season-'+str(i) in http: return i
	return 0

def Storr(info):
	#print info
	Lout=[]
	text=info['originaltitle']
	#http=upd(text)
	#RL=Parser(http, info)
	http=upd(info['title'])
	RL=Parser(http, info)
	for i in RL:
			Lout.append(get_torrents(i, info))
	return Lout



class Tracker:
	def __init__(self):
		pass

	def Search(self, info):
		Lout=Storr(info)
		return Lout