# -*- coding: utf-8 -*-
import sys, os
import urllib, urllib2
from ftplib import FTP
temp_dir = "c:\\"
print '-=-=- kinodb -=-=-'


def ru(x):return unicode(x,'utf8', 'ignore')

def getURL(url,Referer = 'http://emulations.ru/'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		#sn=http[s:]
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def save_inf(s):
	p = os.path.join(ru(temp_dir),"temp.txt")
	f = open(p, "w")
	f.write(s)
	f.close()
	return p

def upload(ftp, path, ftp_path):
	with open(path, 'rb') as fobj:
		ftp.storbinary('STOR ' + ftp_path, fobj, 1024)

def make_id(ftp, id):
	pref='0'*(6-len(id))
	id=pref+id
	s=''
	for i in [0,2,4]:
		c=id[i:i+2]
		s+='/'+c
		try:ftp.mkd(s)
		except: pass
	print s
	return s

def verifid_id(ftp, id):
	pref='0'*(6-len(id))
	id=pref+id
	s=''
	for i in [0,2,4]:
		c=id[i:i+2]
		s+='/'+c
	try:size=ftp.size(s+'/0.nfo')
	except: size=0
	print size
	return size

def add(info):
	HOST='kinodb.my1.ru'
	USER='5kinodb'
	PASS='19111980'
	id=info['id']
	ftp = FTP(HOST)
	ftp.login(USER, PASS)
	#data = ftp.retrlines('LIST')
	#print(data)
	if verifid_id(ftp, id) == 0:
		dir=make_id(ftp, id)
		path = save_inf(repr(info))#'d:\\dir.txt'
		upload(ftp, path, dir+'/0.nfo')
	
	#data = ftp.retrlines('LIST')
	#print(data)
	ftp.quit()


#add({"id":"123"})

