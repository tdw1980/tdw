#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys, time
#try:
#  from xbmcvfs import translatePath
#except (ImportError, AttributeError):
#  from xbmc import translatePath
#import Cookie
#import string, xbmc, xbmcgui, xbmcplugin, xbmcaddon
#-------------------------------


icon = ""
siteUrl = 'krasfs.ru'
httpSiteUrl = 'https://' + siteUrl
#addon = xbmcaddon.Addon(id='plugin.video.KinoPoisk.ru')
#__settings__ = xbmcaddon.Addon(id='plugin.video.KinoPoisk.ru')

try:
	import ssl
	ctx = ssl.create_default_context()
	ctx.check_hostname = False
	ctx.verify_mode = ssl.CERT_NONE
except: pass


if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2


def b2s(s):
	if test_torrent(s)==False: return s
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def test_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False


def ru(x):return unicode(x,'utf8', 'ignore')
#def xt(x):return translatePath(x)

def encod(x):
	try:x=x.decode('Windows-1251')
	except:pass
	try:x=x.encode('utf-8')
	except:pass
	return x


def coder(x):
	if sys.version_info.major > 2: return x
	x=x.decode('utf-8')
	x=x.encode('Windows-1251')
	return x

def lower(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in range (65,90):
		t=t.replace(chr(i),chr(i+32))
	for i in RUS.keys():
		t=t.replace(i,RUS[i])
	return t


def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "wb")
	fl.write(s)
	fl.close()


def GET(target, referer='http://torrent.by', post=None):
		if sys.version_info.major > 2 and post!=None: post = post.encode()
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36 OPR/50.0.2762.67')
		try: resp = urllib2.urlopen(req)
		except: resp = urllib2.urlopen(req, context=ctx)
		http = resp.read()
		resp.close()
		return b2s(http)

def Parser(hp):
	Lout=[]
	true = True
	false = False
	null = None
	J = eval(hp)["message"]
	
	for k in J:
		#try:
					i=J[k]
					url = 'magnet:?xt=urn:btih:'+i['hash']
					title = i['name'].replace('\\/', '/')
					alt_name = i['alt_name']
					size = float(i['size'])/1024/1024
					if size < 1024: 
						size = str(int(size))+'MB'
					else: 
						size = str(size/1024)+'GB'
						if '.' in size: size = size[:size.find('.')+2]+'GB'
					sids = '?'
					Lout.append({"sids":sids, "size":size, "title":title, "url":url, "quality": alt_name})
		#except:
		#			print ('err')
	return Lout


def Storr(info):
	Lout=[]
	text=info['originaltitle']
	#text=coder('terminator')
	post='data=%7B%22search_string%22%3A%22'+quote(text)+'%22%2C%22search_torrent%22%3Atrue%2C%22search_torrent_in%22%3Afalse%2C%22search_ftp%22%3Afalse%2C%22search_parameters%22%3A%7B%7D%2C%22url%22%3A%22%2Fajax%22%2C%22action%22%3A%22%D0%9F%D0%BE%D0%B8%D1%81%D0%BA%D0%A4%D0%B0%D0%B9%D0%BB%D0%B0%22%7D'
	http=GET('https://krasfs.ru/ajax', 'https://krasfs.ru', post)
	
	Lout=Parser(http)
	return Lout


class Tracker:
	def __init__(self):
		pass

	def Search(self, info):
		Lout=Storr(info)
		return Lout

#print(Storr('info'))
