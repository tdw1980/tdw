# -*- coding: utf-8 -*-
#serv_list=['1/hi','1/lo','2/hi','2/lo','3/hi', '3/lo']
serv_list=['1/hi','2/hi','3/hi','4/hi']
