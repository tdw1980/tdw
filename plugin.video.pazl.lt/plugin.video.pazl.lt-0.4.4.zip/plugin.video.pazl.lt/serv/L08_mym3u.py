#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import os, sys, time, json

if sys.version_info.major > 2:  # Python 3 or later
	import urllib.request
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
	from urllib.parse import urlencode
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote_plus as unquote
	import urllib2
	from urllib import urlencode

def translatePath(s):
	try:
		return xbmcvfs.translatePath(s)
	except:
		return xbmc.translatePath(s)


addon = xbmcaddon.Addon(id='plugin.video.pazl.lt')
__settings__ = xbmcaddon.Addon(id='plugin.video.pazl.lt')
#-----------------------------------------

icon = ""
serv_id = '8'
siteUrl = 'mym3u:'
httpSiteUrl = 'http://' + siteUrl
#sid_file = os.path.join(translatePath('special://temp/'), siteUrl+'.sid')

#cj = cookielib.FileCookieJar(sid_file) 
#hr  = urllib2.HTTPCookieProcessor(cj) 
#opener = urllib2.build_opener(hr) 
#urllib2.install_opener(opener) 

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return translatePath(x)
def fs_enc(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode('utf-8').encode(sys_enc)

def fs_dec(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode(sys_enc).encode('utf-8')

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def b2s(s):
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def win2utf(s):
	return s.encode('windows-1251').decode('utf-8')

def is_libreelec():
	try:
		if os.path.isfile('/etc/os-release'):
			f = open('/etc/os-release', 'r')
			str = f.read()
			f.close()
			if "LibreELEC" in str and "Generic" in str: return True
	except: pass
	return False

def rt(s):
	try:s=s.decode('utf-8')
	except: pass
	if not is_libreelec():
		try:s=s.decode('windows-1251')
		except: pass
	try:s=s.encode('utf-8')
	except: pass
	return s

def eval_u(inf):
	#print (inf)
	if sys.version_info.major > 2: 
		inf2 = 'b'+repr(inf).replace("\\\\x", "\\x")
		#print (inf2)
		info = eval(eval(inf2))##.replace("\\x", "\\\\x").replace("\\r", "\\\\r").replace("\\n", "\\\\n")
		#print (info)
	else:
		info = eval(inf)
	return info

def getURL(url,Referer = 'http://emulations.ru/'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req, timeout=20)
	link=b2s(response.read())
	response.close()
	return link

def getURL2(url):
	try:
		import requests
		try:
			s = requests.session()
			r=s.get(url, timeout=(0.1, 5), verify=False).text#0.00001
		except:
			print ('requests: timeout')
			r=''
		#r=r.encode('windows-1251')
		r=b2s(r)
		return r
	except:
		return ''

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def lower_old(s):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.lower().encode('utf-8')
	return s

def lower(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in range (65,90):
		t=t.replace(chr(i),chr(i+32))
	for i in RUS.keys():
		t=t.replace(i,RUS[i])
	return t

def upper(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in RUS.keys():
		t=t.replace(RUS[i],i)
	for i in range (65,90):
		t=t.replace(chr(i+32),chr(i))
	return t

def get_idx(name):
	name=lower(name).replace(" #1","").replace(" #2","").replace(" #3","").replace(" #4","")
	try:
		id="x"+xmlid[name]
	except: 
		id=''
	return id

def save_channels(n, L):
		ns=str(n)
		fp=translatePath(os.path.join(addon.getAddonInfo('path'), 'Channels'+ns+'.py'))
		#fl = open(fp, "w", encoding="utf-8")
		try: fl = open(fp, "w", encoding="utf-8")
		except: fl = open(fp, "w")
		fl.write('# -*- coding: utf-8 -*-\n')
		fl.write('Channels=[\n')
		for i in L:
			try:
				fl.write(i)
				fl.write(',\n')
			except: pass
		fl.write(']\n')
		fl.write('udata545='+str(time.strftime('%Y%m%d')))
		fl.close()

def BL(name):
	bl=['[Premium]','(резерв','(тест)']
	for i in bl:
		if i in name: return False
	return True

def utf(x):
	if sys.version_info.major <= 2: x=x.encode('utf-8')
	return x

class PZL:
	def Streams(self, url):
		url=url[6:]
		#try:
		#	import Channels8
		#	udata=int(Channels8.udata545)
		#except:udata = 0
		#cdata = int(time.strftime('%Y%m%d'))
		#if cdata>udata: self.Canals()
		return [url,]
	
	
	def Canals(self):
		LL=[]
		L2=[]
		passw = str(__settings__.getSetting("passw"))
		
		if passw == '':
				xbmc.executebuiltin("Addon.OpenSettings(plugin.video.pazl.lt)")
				return []
		
		pDialog = xbmcgui.DialogProgressBG()
		
		pDialog.create('TV', 'Update canals')
		url1='http://'+passw+'.tdwvt.keenetic.pro/channels/json'
		url2='http://193.124.130.96/channels/json'
		#print (url2)
		print (url1)
		#http=getURL(url)
		try:http=getURL(url2)
		except: 
			try:http=getURL(url1)
			except: 
				http=''
				print ('err load playlist')
		d=json.loads(http)
		L=d['channels']
		#if http == '':
		#	showMessage('Korona-tv', 'Проверьте логин и пароль.')
		#	return []
		#if len(http)<10: 
		#	L=[]
		#else:
		#	L=mfindal(http, '<channel id', '</channel>')
		
		for i in L:
			print (i)
			try:
				#i=win2utf(i)
				url='mym3u:'+utf(i['url']).replace('/streams/json/','/stream/')
				title=utf(i['name'])
				try:gr = utf(i['group'][0])
				except: gr = ''
				img = utf(i['icon'])
				arh = '0'
				tvg = utf(i['id'])
				LL.append({'url':url, 'img':img, 'title':title, 'group': gr, 'arhive':arh, 'tvg':tvg, 'id':tvg})
				L2.append("{'url':'"+url+"', 'img':'"+img+"', 'title':'"+title+"', 'group': '"+gr+"', 'arhive':'"+arh+"', 'tvg':'"+tvg+"', 'id':'"+tvg+"'}")
			except:
				pass
				print ('errr')
				print (i)
		
		pDialog.close()
		if L2!=[]: save_channels(serv_id, L2)
		#if LL!=[]:save_channels(serv_id, LL)
		#else: showMessage('Korona-tv', 'Не удалось загрузить каналы', 3000)
		return LL
