# -*- coding: utf-8 -*-
import time, os, sys

sid_file = os.path.join(os.getcwd(), 'BS.sid')

#cj = cookielib.FileCookieJar(sid_file) 
#hr  = urllib2.HTTPCookieProcessor(cj) 
#opener = urllib2.build_opener(hr)
#urllib2.install_opener(opener)


if sys.version_info.major > 2:  # Python 3 or later
	import urllib.request
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2


block_sz = 1024*2#81920

stack = []
dstack = {}
STOP = False

from threading import Thread
class MyThread(Thread):
	def __init__(self, url):
		self.buf_max = 60000
		self.comp = 0
		Thread.__init__(self)
		self.url=url
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 OPR/77.0.4054.203')
		self.resp = urllib2.urlopen(req, timeout=5)
		print ('connection ok')
		#self.n = n
	
	def run(self):
		global dstack,dstack_old, url_last
		print ('run download loop')
		if dstack != {}:return
		
		while not STOP:
			if len(dstack) < self.buf_max:
				try: buf=self.resp.read(block_sz)
				except: buf=''
				if len(buf)>1000:
					dstack[self.comp] = buf
					self.comp += 1
					time.sleep(0.001)
				else:
					self.resp.close()
					req = urllib2.Request(self.url)
					req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 OPR/77.0.4054.203')
					self.resp = urllib2.urlopen(req, timeout=10)
					#self.buf_max += 100
					#time.sleep(1)
					print ('-RE-')
		
		dstack = {}
		self.resp.close()
		

def save(val):
	key=str(int(time.time()/60))
	try:
		db_dir = os.path.join(os.getcwd(), "record" )
		fp=os.path.join(db_dir, key)
		with open(fp,'ab') as fl:
		#fl = open(fp, "w")
			fl.write(val)
		#fl.close()
		return ('ok')
	except:
		return ('error set '+key)

class BS():
	def __init__(self, url):
		#req = urllib2.Request(url)
		#self.resp = urllib2.urlopen(req, timeout=3)
		#buf = self.resp.read(block_sz)
		self.last = None#buf
		self.url = url
		self.list = []
		self.run = 0
		self.complit = 0
		self.n = 0
		self.t1 = ''
		self.t2 = ''
		#self.stack = [None,None,None,None,None,None,None,None,None,None]
		self.stop(False)
		self.create_thread()

	def GET(self):
		try: data=self.resp.read(block_sz)
		except: data=None
		#response.close()
		return self.resp
		return data

	def get_head(self, url):
		return url[:url.rfind('/')+1]

	def get_data(self):
		
		for i in range(10):
			if self.n not in dstack.keys(): time.sleep(0.1)
		
		try: 
			data=dstack[self.n]#self.GET()
			del dstack[self.n]
			self.n+=1
		except: 
			data=None
		if len(dstack)<2:
			time.sleep(0.5)
			print ('stack<2')
		elif len(dstack)<3:
			time.sleep(0.1)
		#print 'ok'
		#save(data)
		return data

	def get_status(self):
		return len(dstack)

	def create_thread(self):
		print ('--- create_strim_thread ---')
		my_thread = MyThread(self.url)
		my_thread.start()
		time.sleep(1)
	
	def stop(self, s=True):
		global STOP
		STOP=s