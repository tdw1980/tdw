# -*- coding: utf-8 -*-
import xbmc
lang=xbmc.getLanguage()

#lang='en'
print ('====')
print (lang)

D_en = {
'Добавить в группу':		'Add to group',
'Удалить из группы':		'Remove from group',
'Переместить в группе':		'Move to group',
'Объеденить с каналом':		'Merge with channel',
'Разделить канал':			'Split channel',
'Переименовать канал':		'Rename channel',
'Удалить канал':			'Delete channel',
'Установить EPG':			'Set EPG',
'Установить логотип':		'Set logo',
'Создать группу':			'Create a group',
'Удалить группу':			'Delete group',
'Переместить группу':		'Move group',
'Переименовать группу':		'Rename group',
'Объединить с группой':		'Merge with group',
'Установить пароль':		'Set password',
'Редактор каналов':			'Channel editor',
'Обновить каналы':			'Update channels',
'Обновить телепрограмму':	'Update EPG',
'Найти канал':				'Find a channel',
'Выберите программу передач:':'Select EPG:',
'Архив':					'Archive',
'Группа: ':					'Group: ',
'Группа:':					'Group:',
'Все каналы':				'All',
'Источники:':				'Streams:',
'Обновление базы каналов...':'Updating the channel database...',
'Выделить как канал:': 		'Select a channel:',
'Разделить нельзя':			'it is impossible to divide',
'Обновление списка каналов':'Updating the channel list',
' - В конец списка - ': 	'To the end of the list',
'Перед каналом:':			'In front of the channel:',
'Вставить перед группой:':	'Insert in front of a group:',
'Отклонено!':				'Forbidden!',
'Неверный пароль':			'Invalid password',
'бъединить с группой:':		'To unite with the group:',
'Недоступно': 				'Forbidden!',
'Группа заблокирована':		'The group is blocked',
'Порядок: Свой': 			'Order: User',
'Порядок: ABC':				'Order: ABC',
'Настройки':				'Settings',
}

D_de={
'Добавить в группу': 		'zur Gruppe hinzufügen',
'Удалить из группы': 		'aus der Gruppe entfernen',
'Переместить в группе': 	'zur Gruppe wechseln',
'Объеденить с каналом': 	'mit Kanal verschmelzen',
'Разделить канал': 			'Geteilter Kanal',
'Переименовать канал': 		'Kanal umbenennen',
'Удалить канал': 			'Kanal löschen',
'Установить EPG': 			'EPG setzen',
'Установить логотип': 		'Logo setzen',
'Создать группу': 			'Gruppe erstellen',
'Удалить группу': 			'Gruppe löschen',
'Переместить группу': 		'Gruppe verschieben',
'Переименовать группу': 	'Gruppe umbenennen',
'Объединить с группой': 	'mit der Gruppe verschmelzen',
'Установить пароль': 		'Passwort festlegen',
'Редактор каналов': 		'Channel editor',
'Обновить каналы': 			'Kanäle aktualisieren',
'Обновить телепрограмму': 	'Update EPG',
'Найти канал': 				'einen Kanal finden',
'Выберите программу передач:':'wählen Sie EPG:',
'Архив': 					'Archiv',
'Группа: ': 				'Gruppe: ',
'Группа:': 					'Gruppe:',
'Все каналы':				'All',
'Источники:': 				'Streams:',
'Обновление базы каналов...': 'Aktualisierung der kanaldatenbank...',
'Выделить как канал:': 		'wählen Sie einen Kanal:',
'Разделить нельзя': 		'es ist unmöglich zu teilen',
'Обновление списка каналов':'Kanalliste aktualisieren',
'- В конец списка -': 		'bis zum Ende der Liste',
'Перед каналом:':			' vor dem channelanal: ',
'Вставить перед группой:': 'vor einer Gruppe einfügen:',
'Отклонено!': 				'Verboten!',
'Неверный пароль': 			'ungültiges Passwort',
'бъединить с группой:': 	'mit der Gruppe zu vereinen:',
'Недоступно': 				'Verboten!',
'Группа заблокирована': 	'die Gruppe ist blockiert',
'Порядок: Свой': 			'Bestellung: Benutzer',
'Порядок: ABC': 			'Bestellung: ABC',
'Настройки':				'Einstellungen',
}

def lcl(t):
	if 'English' in lang: D=D_en
	elif 'German' in lang: D=D_de
	else: D={}
	if t in D.keys():
		return D[t]
	else: return t