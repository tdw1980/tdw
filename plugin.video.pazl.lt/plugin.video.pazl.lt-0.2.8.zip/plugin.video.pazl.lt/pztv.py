# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, sys, time, xbmcvfs

if sys.version_info.major > 2:  # Python 3 or later
	import urllib.request
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
	from urllib.parse import urlencode
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote_plus as unquote
	import urllib2
	from urllib import urlencode

def translatePath(s):
	try:
		return xbmcvfs.translatePath(s)
	except:
		return xbmc.translatePath(s)

#nt=time.time()
PLUGIN_NAME   = 'plugin.video.pazl.lt'
#handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.pazl.lt')
__settings__ = xbmcaddon.Addon(id='plugin.video.pazl.lt')
__settings__.setSetting("creator", "_")
#try: arhive = xbmcaddon.Addon(id='plugin.video.pazl.arhive')
#except: pass

Pdir = addon.getAddonInfo('path')
icon = translatePath(os.path.join(addon.getAddonInfo('path'), 'icon.png'))
fanart = translatePath(os.path.join(addon.getAddonInfo('path'), 'fanart.png'))
UserDir = translatePath(os.path.join(translatePath("special://masterprofile/"),"addon_data","plugin.video.pazl.lt"))
Logo = UserDir#translatePath(os.path.join(addon.getAddonInfo('path'), 'logo'))

UA='|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 OPR/77.0.4054.203'

def b2s(s):
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s


def eval_u(inf):
	#print (inf)
	if sys.version_info.major > 2: 
		inf2 = 'b'+repr(inf).replace("\\\\x", "\\x")
		#print (inf2)
		info = eval(eval(inf2))##.replace("\\x", "\\\\x").replace("\\r", "\\\\r").replace("\\n", "\\\\n")
		#print (info)
	else:
		info = eval(inf)
	return info


#xbmcplugin.setContent(int(sys.argv[1]), 'movies')

sys.path.append(os.path.join(addon.getAddonInfo('path'),"serv"))
ld=os.listdir(os.path.join(addon.getAddonInfo('path'),"serv"))
Lserv=[]
for i in ld:
	if i[-3:]=='.py': Lserv.append(i[:-3])


#sys.path.append(os.path.join(addon.getAddonInfo('path'),"arh"))
#ld=os.listdir(os.path.join(addon.getAddonInfo('path'),"arh"))
#Larh=[]
#for i in ld:
#	if i[-3:]=='.py': Larh.append(i[:-3])

try:
	epg_settings = xbmcaddon.Addon(id='plugin.video.pazl.lt')
	epg_port=epg_settings.getSetting("serv_port")
except:
	epg_port='8085'

UrlCashe={}
BanCashe=[]
Lthread=[]

#from DefGR import *
Ldf=[]

from lng import *

def save_DBC(DBC):
	try:
		#if not os.path.exists(UserDir): os.mkdir(UserDir)
		path = os.path.join(Pdir, 'DBcnl.py')
		fp=translatePath(path)
		try: fl = open(fp, "w", encoding="utf-8")
		except: fl = open(fp, "w")
		fl.write('# -*- coding: utf-8 -*-\n')
		fl.write('DBC={\n')
		for i in DBC.items():
			try:fl.write("'"+i[0]+"':"+repr(i[1])+',\n')
			except: pass
		fl.write('}\n')
		fl.close()
	except: pass

sys.path.append(UserDir)
#try: 
#	from UserDBcnl import *
#except: 
#from DBcnl import *
try:
	from DBcnl import *
except:
	DBC={}
#DBC={}
try: save_DBC(DBC)
except: pass

try:
	from PICONSdb import *
except:
	PICONS={}

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return translatePath(x)

def CRC32(buf):
		import binascii
		if sys.version_info.major > 2: buf = (binascii.crc32(buf.encode('utf-8')) & 0xFFFFFFFF)
		else: buf = (binascii.crc32(repr(buf)) & 0xFFFFFFFF)
		r=str("%08X" % buf)
		return r

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(lcl(heading), lcl(message), times, icon))

def fs_enc(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode('utf-8').encode(sys_enc)

def fs_dec(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode(sys_enc).encode('utf-8')


def lower(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in range (65,91):
		t=t.replace(chr(i),chr(i+32))
	for i in RUS.keys():
		t=t.replace(i,RUS[i])
	t=t.lower()
	return t

def lower_old(s):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.lower().encode('utf-8')
	return s


def is_libreelec():
	try:
		if os.path.isfile('/etc/os-release'):
			f = open('/etc/os-release', 'r')
			str = f.read()
			f.close()
			if "LibreELEC" in str and "Generic" in str: return True
	except: pass
	return False

def rt(s):
	try:s=s.decode('utf-8')
	except: pass
	#if not is_libreelec():
	try:s=s.decode('windows-1251')
	except: pass
	try:s=s.encode('utf-8')
	except: pass
	return s


def upper(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in RUS.keys():
		t=t.replace(RUS[i],i)
	for i in range (65,90):
		t=t.replace(chr(i+32),chr(i))
	return t


def getURL2(url):
	try:
		import requests
		try:
			s = requests.session()
			r=s.get(url, timeout=(0.1, 5), verify=False).text#0.00001
		except:
			print ('requests: timeout')
			r=''
		#r=r.encode('windows-1251')
		r=b2s(r)
		return r
	except:
		return ''

def getURL3(url,Referer = 'http://emulations.ru/'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def getURL(url, Referer = 'http://viks.tv/'):
	return getURL2(url)
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	#link=b2s(link)
	response.close()
	return link

def testURL(url):
	return 0



def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es, s+len(ss))
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "w")
	fl.write(s)
	fl.close()

def inputbox(t=''):
	skbd = xbmc.Keyboard(t, ' ')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return t



def next (dr='>'):
		ccn=__settings__.getSetting("cplayed")
		print ('=NEXT=')
		print (ccn)
		SG=get_SG()

		if dr=='>':
			__settings__.setSetting("lastnx",">")
			id =__settings__.getSetting("next_itm")
		else: 
			id =__settings__.getSetting("prev_itm")
			__settings__.setSetting("lastnx","<")
		__settings__.setSetting("v_id", id)
		name  = ''#DBC[id]['title']
		play(id, name, ref=False)
		return id


def set_np ():
	id=__settings__.getSetting("cplayed")
	CL=get_cut_gr()
	n=CL.index(id)
	nn=n+1
	np=n-1
	if nn>=len(CL):nn=0
	__settings__.setSetting("next_itm",CL[nn])
	__settings__.setSetting("prev_itm",CL[np])


playlist = xbmc.PlayList (xbmc.PLAYLIST_VIDEO)


def update_Lt(d):
	global Lthread
	if d == 'reset':	Lthread=[]
	else:				Lthread.append(d)

from threading import Thread
class MyThread(Thread):
	def __init__(self, param):
		Thread.__init__(self)
		self.param = param
	
	def run(self):
		update_Lt(get_stream(self.param))


def create_thread(param):
		my_thread = MyThread(param)
		my_thread.start()


def fast_stream(id):
	#serv_list=['1_hi','1_lo','2_hi','2_lo','3_hi', '3_lo']
	L = get_all_channeles()
	urls=get_allurls(id, L)
	for url in urls:
		try:
			Lcurl=get_stream(url)
			stream = Lcurl[0]
			return stream
		except: pass
	return ''


def play_off(id, name='' ,cover='', ref=True):
	if id not in DBC.keys(): return
	if __settings__.getSetting("xplay")=='true': return play_vfs(id, name ,cover, ref)
	
	print ('=-=-=-=-=-=-=-=-=-=-=-PLAY=-=-=-=-=-=-=-=-=-=-=-=-=-')
	if name=='':name  = DBC[id]['title']
	pDialog = xbmcgui.DialogProgressBG()
	try:pDialog.create(name, 'Поиск потока ...')
	except: pass
	
	if cover =='': cover = get_picon(id)
	print ('=-=-=-=-=-=-=-=-=-=-=-PLAY get_all_channeles=-=-=-=-=-=-=-=-=-=-=-=-=-')
	L = get_all_channeles()
	urls=get_allurls(id, L)
	
	Player.stop()
	
	Lpurl=[]
	print ('=-=-=-=-=-=-=-=-=-=-=-PLAY get_streams =-=-=-=-=-=-=-=-=-=-=-=-=-')
	
	for url in urls:
			get_stream(url)
			try: Lcurl=get_stream(url)
			except:Lcurl=[]
			Lpurl.extend(Lcurl)
	print ('=-=-=-=-=-=-=-=-=-=-=-PLAY get_streams end =-=-=-=-=-=-=-=-=-=-=-=-=-')
	#print (Lpurl)
	
	if Lpurl==[]:
		pDialog.close()
		try:
			pDialog.create(name, '[COLOR FFFF5555]![/COLOR]')
			xbmc.sleep(1000)
			pDialog.close()
		except: pass
		return ""
	else:
		playlist.clear()
		k=0
		#serv_list=['1_hi','1_lo','2_hi','2_lo','3_hi', '3_lo']
		for purl in Lpurl:
			k+=1
			name2="500 каналов за 10р в настройках"#[ Server "+purl[:purl.find('://')]+"]"
			try: item = xbmcgui.ListItem(name2+" [ "+str(k)+"/"+str(len(Lpurl))+" ]", path=purl, thumbnailImage=cover, iconImage=cover)
			except: 
				item = xbmcgui.ListItem(name2+" [ "+str(k)+"/"+str(len(Lpurl))+" ]", path=purl)
				item.setArt({'thumb':cover, 'icon':cover})
			if '/udp/' in purl: 
						item.setMimeType('video/mpeg')
						item.setContentLookup(False)
						purl = purl+UA

			playlist.add(url=purl, listitem=item)
		pDialog.close()
		__settings__.setSetting("cplayed",id)
		
		try: r=int(__settings__.getSetting("servql"))
		except: r=0

		Player.play(playlist, startpos=r)
		
		set_np ()
		print ('=-=-=-=-=-=-=-=-=-=-=-PLAY-end=-=-=-=-=-=-=-=-=-=-=-=-=-')

def play(id, name='' ,cover='', ref=True):
	try: PlayingFile=xbmc.Player().getPlayingFile()
	except: PlayingFile=''
	if id in PlayingFile:
		xbmc.executebuiltin("Action(FullScreen)")
		return
	
	#pDialog = xbmcgui.DialogProgressBG()
	#try:pDialog.create(name, 'Поиск потока ...')
	#except: pass
	try:
		if xbmc.Player().isPlaying(): Player.play(playlist, startpos=999999)
		passw = str(__settings__.getSetting("passw"))
		pl_url='http://'+passw+'.tdwvt.keenetic.pro/streams/list/'+id#+'/nofollow'
		#getURL(pl_url)
	except: pass
	#pDialog.close()
	
	for n in range(0,playlist.size()):
		item=playlist.__getitem__(n)
		#print (item.getPath())
		if id in item.getPath(): 
			#if __settings__.getSetting("xplay")=='true': 	Player.play(playlist, windowed=True, startpos=n)
			#else: 
			#if xbmcgui.getCurrentWindowId() != 12005: 
			xbmc.executebuiltin("Action(FullScreen)")
			Player.play(playlist, windowed=False, startpos=n)#
			
			break



def play_vfs(id, name='' ,cover='', ref=True):
	if id not in DBC.keys(): return
	print ('=-=-=-=-=-=-=-=-=-=-=-PLAY=-=-=-=-=-=-=-=-=-=-=-=-=-')
	if name=='': name  = DBC[id]['title']
	if __settings__.getSetting("popup")=='true':
		pDialog = xbmcgui.DialogProgressBG()
		try:pDialog.create(name, 'Wait ...')
		except: pass
	
	print (name)
	if cover =='': cover = get_picon(id)
	print ('=-=-=-=-=-=-=-=-=-=-=-PLAY get_all_channeles=-=-=-=-=-=-=-=-=-=-=-=-=-')
	L = get_all_channeles()
	urls=get_allurls(id, L)
	
	Player.stop()
	
	Lpurl=[]
	Lsign=[]
	print ('=-=-=-=-=-=-=-=-=-=-=-PLAY get_streams =-=-=-=-=-=-=-=-=-=-=-=-=-')
	fpl=0
	
	for url in urls:
			try: Lcurl=get_stream(url)
			except:Lcurl=[]
			Lpurl.extend(Lcurl)
	print ('=-=-=-=-=-=-=-=-=-=-=-PLAY get_streams end =-=-=-=-=-=-=-=-=-=-=-=-=-')
	
	if Lpurl==[]:
		try: pDialog.close()
		except: pass
		__settings__.setSetting("cplayed",id)
		set_np ()
		try: pDialog.close()
		except: pass
		return
	else:
		playlist.clear()
		k=0
		#serv_list=['1_hi','1_lo','2_hi','2_lo','3_hi', '3_lo']
		for purl in Lpurl:
				k+=1
				name2="500 каналов за 10р в настройках"#"[ Server "+purl[:purl.find('://')]+"]"
				
				item = xbmcgui.ListItem(name2+" [ "+str(k)+"/"+str(len(Lpurl))+" ]", path=purl)#, thumbnailImage=cover, iconImage=cover)
				if '/udp/' in purl: 
						item.setMimeType('video/mpeg')
						item.setContentLookup(False)
						purl = purl+UA

				playlist.add(url=purl, listitem=item)
		try: pDialog.close()
		except: pass
		
		__settings__.setSetting("cplayed",id)
		try: PlayingFile=Player.getPlayingFile()
		except: PlayingFile=''
		
		try: r=int(__settings__.getSetting("servql"))
		except: r=0
		if PlayingFile=='': Player.play(playlist, windowed=True, startpos=r)
		
		set_np ()

def select_stream():
	L=[]
	for i in range(0,playlist.size()):
		item=playlist.__getitem__(i)
		L.append(item.getLabel())#getfilename()
	
	sel = xbmcgui.Dialog()
	r = sel.select(lcl("Источники:"), L)
	
	if r>=0:
		Player.play(playlist, windowed=True, startpos=r)


def play_archive_off(urls, name ,cover, ref=True):
	#print urls
	Player.stop()
	pDialog = xbmcgui.DialogProgressBG()
	try:pDialog.create('TV', 'Wait ...')
	except: pass
	Lpurl=[]
	for url in urls:
		#Lcurl=get_stream(url)
		try: Lcurl=get_archive(url)
		except:Lcurl=[]
		#print Lcurl
		try:Lpurl.extend(Lcurl)
		except:Lcurl=[]
	
	Lpurl2=[]
	Lm3u8 =[]
	Lrtmp =[]
	Lp2p  =[]
	Lourl =[]
	Ltmp=[]
	
	for i in Lpurl:
		if '.m3u8' in i and i not in Lm3u8:  Lm3u8.append(i)
		elif 'rtmp' in i and i not in Lrtmp: Lrtmp.append(i)
		elif '/ace/' in i and i not in Lp2p: Lp2p.append(i)
		elif i not in Ltmp:                  Lourl.append(i)
		Ltmp.extend(Lp2p)
		Ltmp.extend(Lm3u8)
		Ltmp.extend(Lrtmp)
		Ltmp.extend(Lourl)
	
	
	if __settings__.getSetting("p2p_start")=='true':
			Lpurl2.extend(Lp2p)
			Lpurl2.extend(Lm3u8)
			Lpurl2.extend(Lrtmp)
			Lpurl2.extend(Lourl)
	else:
			Lpurl2.extend(Lm3u8)
			Lpurl2.extend(Lourl)
			Lpurl2.extend(Lp2p)
			Lpurl2.extend(Lrtmp)
	
	if Lpurl2==['12321',]:
		pDialog.close()
		showMessage('Пазл ТВ', 'Канал недоступен')
		return ""
	else:
		playlist = xbmc.PlayList (xbmc.PLAYLIST_VIDEO)
		playlist.clear()
		
		n=1
		if len(Lpurl2)>1:n=3
		
		for j in range (0,n): # несколько копий в плейлист
			k=0
			for purl in Lpurl2:
				k+=1
				if __settings__.getSetting("split")=='true':name2=unmark(name)#.replace(" #1","")
				else:name2=colormark(name)#.replace(" #1","[COLOR 40FFFFFF] #1[/COLOR]")
				item = xbmcgui.ListItem(name2+" [ "+str(k)+"/"+str(len(Lpurl2))+" ]", path=purl, thumbnailImage=cover, iconImage=cover)
				playlist.add(url=purl, listitem=item)
		
		for j in range (0,5):
			purl2=os.path.join(addon.getAddonInfo('path'),"2.mp4")
			item = xbmcgui.ListItem(" > ", path=purl2, thumbnailImage=cover, iconImage=cover)
			playlist.add(url=purl2, listitem=item)
		
		
		pDialog.close()
		
		Player.play(playlist)
		xbmc.sleep(1000)
		#xbmcplugin.endOfDirectory(handle)



Lmrk=[]
for i in range (0,100):
		Lmrk.append(str(i))
Lmrk.reverse()

def unmark(nm):
	for i in Lmrk:
		nm=nm.replace(" #"+str(i),"")
	return nm

def uni_mark_old(nm):
	try:nm=ru(nm)
	except:pass
	try:nm=lower(nm)
	except:pass
	return nm

def uni_mark(nm):
	try:nm=lower(nm.strip())
	except:pass
	return nm

def colormark(nm):
	for i in Lmrk:
		nm=nm.replace(" #"+str(i),"[COLOR 40FFFFFF] #"+str(i)+"[/COLOR]")
	return nm


def get_sign(st):
	n=st.replace('http://','')
	n=n[:n.find('.m3u')]
	return n


def get_stream(url):
	buf=CRC32(url)
	if buf in UrlCashe.keys():
		Cashe=UrlCashe[buf]
		if time.time()-Cashe['time'] < 300:
			print ('==== Cashe ====')
			return Cashe['urls']
	
	#for i in Lserv:
	if True:
			i='L08_mym3u'
			ids=i[4:]
			if ids in url:
				exec ("global serv; import "+i+"; serv="+i+".PZL()")
				Lcurl = serv.Streams(url)
				UrlCashe[CRC32(url)]={'urls':Lcurl, 'time': time.time()}
				return Lcurl
	return []


def upd_canals_db(i):
	exec ("global serv; import "+i+"; serv="+i+".PZL()")
	L=serv.Canals()
	#if __settings__.getSetting("addcnl")=='true': 
	aggregate_cnl(L)
	return L

#upd_canals_db('p23_proxytv')

def get_id(name, gr=''):
	try:id = CRC32(uni_mark(name))#+gr
	except: id = 0
	return id

def get_gid(name):
	import GID
	return GID.get_id(name)

def aggregate_cnl(L):
	global DBC
	DBC2={}
	try:Lgr=open_Groups()
	except:Lgr=Ldf
	pDialog = xbmcgui.DialogProgressBG()
	pDialog.create('TV', lcl('Обновление базы каналов...'))
	n=0
	for i in L:
		n+=1
		prz = n*100/len(L)
		name=i['title']
		#pDialog.update(prz, message='Обработка '+name)
		img=i['img']
		if 'group' in i.keys():group = i['group']
		else: group = ''
		if 'tvg' in i.keys():tvg = i['tvg']
		else: tvg = ''
		if 'img' in i.keys():img = i['img']
		else: img = ''
		if group !="": lgroup=[group,]
		else:          lgroup=[]
		
		#id = CRC32(uni_mark(name))#+group
		id = i['id']
		
		DBC2[id]={'title': i['title'], 'group': lgroup, 'names':[uni_mark(i['title']),], 'tvg':tvg, 'img':img}
		#if img!='': GETimg(img, id)
		#if __settings__.getSetting("addgr")=='true': 
		Lgr = appendgroup(group, id, Lgr)
	pDialog.close()
	xbmc.sleep(100)
	#pDialog.update(100, message='Сохранение базы')
	DBC=DBC2
	save_DBC(DBC)
	clear_Groups()
	pDialog.close()
	

def update_DBC():
	try:agt=eval(__settings__.getSetting("ag_tm"))
	except: agt=0
	if time.time()-agt<60*60: return
	L=upd_canals_db('L08_mym3u')
	__settings__.setSetting("ag_tm",repr(time.time()))


def appendgroup(group, id, L=[]):
		if group !='':
			if L==[]:
				try:L=open_Groups()
				except:L=Ldf
			CD={}
			for i in L:
				CD[i[0]]=i[1]
			
			if group in CD.keys():
				Lg=CD[group]
				if id not in Lg:
					L=add_to_gr(id, group, L)
			else:
				L=add_gr(group)
				L=add_to_gr(id, group, L)
		return L


def append_cnl(id):
	nm2id={}
	nml=[]
	for a in DBC.items():
		namet=a[1]['title']
		idt=a[0]
		nm2id[namet]=idt
		nml.append(namet)
	nml.sort()
	sel = xbmcgui.Dialog()
	r = sel.select(lcl("Добавить к каналу:"), nml)
	
	if r>=0:
		name=nml[r]
		print (name)
		id2=nm2id[name]
		print (id2)
	
	DBC[id2]['names'].extend(DBC[id]['names'])
	#print (DBC[id2])
	DBC.pop(id)
	save_DBC(DBC)


def split_cnl(id=''):
	if id!='':
		nm_list=DBC[id]['names']
		if len(nm_list)>1:
			sel = xbmcgui.Dialog()
			r = sel.select(lcl("Выделить как канал:"), nm_list)
			if r>=0 :
				name=nm_list[r]
				id2=CRC32(name)
				DBC[id2]={'group': [], 'names': [name,], 'title': name}
				nm_list.remove(name)
				DBC[id]['names']=nm_list
				save_DBC(DBC)
				showMessage('ОК:', name)
		else:
			showMessage('Разделить нельзя', '1 item')

def remove_cnl(id=''):
	if id!='':
		DBC.pop(id)
		save_DBC(DBC)

def rename_cnl(ids):
	nt=inputbox(DBC[ids]['title'])
	if nt!='': 
		DBC[ids]['title']=nt
		save_DBC(DBC)

def upd_archive_db(i):
	exec ("import "+i+"; serv="+i+".ARH()")
	return serv.name2id()

cahe_lists={}
def add_cahe_lists(s, t, c):
	cahe_lists[s]={'time': t, 'cahe': c}

def get_cahe_list(s):
		print ('==get_cahe_list start==')
		fp=translatePath(os.path.join(addon.getAddonInfo('path'), 'Channels'+s+'.py'))
		tm=os.path.getmtime(fp)
		if s in cahe_lists.keys():
			if cahe_lists[s]['time'] == tm:
				return cahe_lists[s]['cahe']
		
		#fl = open(fp, "r", encoding="utf-8")
		try: fl = open(fp, "r", encoding="utf-8")
		except: fl = open(fp, "r")

		t=fl.read()
		fl.close()
		#L=eval(mfind(t,'Channels=',']')+']')
		L=eval(t[t.find('Channels=')+9:t.rfind(']')+1])
		add_cahe_lists(s, tm, L)
		return L

def get_all_channeles():
	print ('==get_all_channeles start==')
	
	L=[]
#	filtr=[]
#	if __settings__.getSetting("split_1") == 'false':filtr.append('h')
#	if __settings__.getSetting("split_2") == 'false':filtr.append('u')
#	if __settings__.getSetting("split_3") == 'false':filtr.append('p')

	#for i in Lserv:
	if True:
				i='L08_mym3u'
				#if i[:1] not in filtr:
				serv_id=str(int(i[1:3]))
				#if __settings__.getSetting("serv"+serv_id+"")=='true' :
				try: 
					#exec ("import Channels"+serv_id+"; Ls=Channels"+serv_id+".Channels")
					Ls=get_cahe_list(serv_id)
					#for t in Ls:
					#	print t
				except:Ls=[]
				if Ls==[]:
					pDialog = xbmcgui.DialogProgressBG()
					pDialog.create('TV', lcl('Обновление списка каналов'))
					try: Ls=upd_canals_db(i)
					except: Ls=[]
					pDialog.close()
			#else: Ls=[]
			#L.extend(Ls)
	print ('==get_all_channeles end==')
	return Ls

def get_allurls(id, L):
	cl_name = uni_mark(DBC[id]['title'])
	try: cl_group = uni_mark(DBC[id]['group'][0])
	except: cl_group = ''
	L3=[]
	for j in L:
		if cl_name == uni_mark(j['title']) and cl_group == uni_mark(j['group']): L3.append(j['url'])
			
	#cl_names = DBC[id]['names']
	#for j in L:
	#	name = uni_mark(j['title'])
	#	if name in cl_names:
	#		L3.append(j['url'])
	return L3

def get_picon(id):
	picon_dict=get_picon_dict()
	if id =='':nmi = '0000'
	try: picon = picon_dict[id]
	except: picon = os.path.join(Pdir,'0000.png')
	return picon
	'''
	else: nmi = str(id)
	path1 = fs_enc(os.path.join(Logo, nmi+'.png'))
	
	if os.path.isfile(path1): return path1
	else: 
		if nmi in picon_dict.keys(): 
			return picon_dict[nmi]
		else:
			return fs_enc(os.path.join(Logo,'0000.png'))
	'''

def get_picon_dict():
	D={}
	tmb=os.path.join(Pdir,'0000.png')
	try:
		for id in DBC.keys():
			img = DBC[id]['img']
			if img == '': img = tmb
			D[id]=img
	except: 
		update_cnl()
	L=os.listdir(Logo)
	for i in L:
		D[i[:-4]]=os.path.join(Logo,i)
	D['0000']= os.path.join(Pdir,'0000.png')
	return D

def get_picon_dict_off():
		picon_dir=os.path.join(Pdir,'logo')
	#try:
		fp=os.path.join(picon_dir, 'picon_list.txt')
		fl = open(fp, "r")
		t=fl.read()
		fl.close()
		L=t.splitlines()
		D={}
		for i in L:
			D[i[:-4]]='http://td-soft.narod.ru/logo/picon/'+i
		
		D['0000']= os.path.join(Pdir,'0000.png')
		return D
	#except:
	#	return {}

def get_all_archive_off():
	pDialog = xbmcgui.DialogProgressBG()
	L=[]
	for i in Larh:
		serv_id=str(int(i[1:3]))
		if True:#__settings__.getSetting("serv"+serv_id+"")=='true' :
			
			try: exec ("import aid"+serv_id+"; Ds=aid"+serv_id+".n2id")
			except:Ds={}
			if Ds=={}: 
				pDialog.create('Пазл ТВ', 'Обновление архива #'+serv_id+' ...')
				Ds=upd_archive_db(i)
				pDialog.close()
		else: Ds={}
		if Ds !={}:
			Ds['srv_id']=i
			L.append(Ds)
	return L


if __settings__.getSetting("grincm")=='true':
	ContextGr=[('[B]Все каналы[/B]', 'Container.Update("plugin://plugin.video.pazl.lt/?mode=context_gr&name=Все каналы")'),]
	for grn in list_gr():
		ContextGr.append(('[B]'+grn+'[/B]','Container.Update("plugin://plugin.video.pazl.lt/?mode=context_gr&name='+urllib.quote_plus(grn)+'")'))
		ContextGr.append(('[COLOR FF55FF55][B]ПЕРЕДАЧИ[/B][/COLOR]', 'Container.Update("plugin://plugin.video.pazl.lt/?mode=tvgide")'))



def root_old(SG=''):
		print ('=root=')
		Lret=[]
		if SG=="":SG=get_SG()
		Lnm=[]
		Lserv=get_all_channeles()
		L=DBC.keys()
		nml=[]
		print (len(Lserv))
		for a in Lserv:
			nm=uni_mark(a['title'])
			nml.append(nm)
		CL=get_gr()
		print (len(CL))
		for id in CL:
				try:
					names = DBC[id]['names']
					enable=False
					for b in names:
						if b in nml: enable=True
					
					if enable:
						name  = DBC[id]['title']
						cover = get_picon(id)
						Lret.append({'title':name, 'id': id, 'picon': cover})
				except:
					pass
		__settings__.setSetting("Sel_sday",'0')
		return Lret

def find_picon(name):
	name2=name[:name.find('(')].strip()
	tvg   = get_gid(name)
	tvg2   = get_gid(name.replace(' HD', ''))
	tvg3   = get_gid(name2)
	tvg4   = get_gid(name2.replace(' HD', ''))
	tvg5   = get_gid(name.replace(' ТВ', ''))
	tvg6   = get_gid(name.replace('-', ''))
	if   tvg  in PICONS.keys(): cover = PICONS[tvg]#'http://epg.it999.ru/img2/'+str(PICONS[tvg])+'.png'
	elif tvg2 in PICONS.keys(): cover = PICONS[tvg2]#'http://epg.it999.ru/img2/'+str(PICONS[tvg2])+'.png'
	elif tvg3 in PICONS.keys(): cover = PICONS[tvg3]#'http://epg.it999.ru/img2/'+str(PICONS[tvg3])+'.png'
	elif tvg4 in PICONS.keys(): cover = PICONS[tvg4]#'http://epg.it999.ru/img2/'+str(PICONS[tvg4])+'.png'
	elif tvg5 in PICONS.keys(): cover = PICONS[tvg5]#'http://epg.it999.ru/img2/'+str(PICONS[tvg5])+'.png'
	elif tvg6 in PICONS.keys(): cover = PICONS[tvg6]#'http://epg.it999.ru/img2/'+str(PICONS[tvg6])+'.png'
	else: cover = ''
	return cover

def root(SG=''):
		#print '=root='
		#tm=time.time()
		Lret=[]
		if SG=="":SG=get_SG()
		Lnm=[]
		Ls=get_all_channeles()
		#print (Ls)
		#picons = get_picon_dict()
		CL=get_gr()
		nml=[]
		bl=[]
		dn={}
		
		A=[]
		for id in CL:
			try:
				i = DBC[id]
				names = i['names']
				name  = i['title']
				A.extend(names)
				for b in names:
					dn[b]=name
			except: pass
		#print (A)
		
		B=[]
		for a in Ls:
			B.append(uni_mark(a['title']))
		#print(B)
		
		
		Bset = frozenset(B)
		C = [item for item in A if item in Bset] 
		
		#print (C)
		
		for nm in C:
			nml.append(dn[nm])
		#print 'root C: '+ str(time.time()-tm)
		
		for id in CL:
				try:
					name  = DBC[id]['title']
					cover = DBC[id]['img']
					tvg   = DBC[id]['tvg']#get_gid(name)
					#print (tvg)
					if name in nml:
						#if cover =='': cover = find_picon(name)
						#if cover =='': cover = picons['0000']
						#cover = get_picon(id)
						Lret.append({'title':name, 'id': id, 'picon': cover, 'tvg':tvg})
				except:
					pass
		#print 'root for CL2: '+ str(time.time()-tm)
		__settings__.setSetting("Sel_sday",'0')
		#print 'root tm: '+ str(time.time()-tm)
		return Lret



def sort_abc(L):
	L2=[]
	for id in L:
		try: L2.append((DBC[id]['title'],id))
		except: pass
	L2.sort()
	L=[]
	for i in L2:
		L.append(i[1])
	return L



def recover_Groups():
	Lgr=[]
	pDialog = xbmcgui.DialogProgressBG()
	pDialog.create('TV', 'Recover...')
	n=0
	L=DBC.keys()
	Dgr={}
	Lp=[]
	for k in L:
		i=DBC[k]
		n+=1
		prz = n/len(L)*100
		name=i['title']
		pDialog.update(prz, message='Recover '+name)
		try:group = i['group'][0]
		except: group = ''
		id = CRC32(uni_mark(name+group))
		#Lgr = appendgroup(group, id, Lgr)
		if group !='':
			if group not in Lp: Lp.append(group)
			if group not in Dgr.keys(): Dgr[group]=[]
			Lg=Dgr[group]
			if id not in Lg: 
					Lg.append(id)
					Dgr[group]=Lg
	for i in Lp:#Dgr.keys()
		Lgr.append((i,Dgr[i]))
	
	save_Groups(Lgr)
	pDialog.close()
	return Lgr

def clear_Groups():
	L=open_Groups()
	L2=[]
	for i in L:
		if i[1]!=[]: 
			L3=[]
			for id in i[1]:
				if id in DBC.keys(): L3.append(id)
			if L3!=[]:
				L2.append((i[0],L3))
	save_Groups(L2)

def open_Groups():
	try:
		fp=translatePath(os.path.join(UserDir, 'UserGR.py'))
		
		try:sz=os.path.getsize(fp)
		except:sz=0
		if sz==0:
			save_Groups(Ldf)
			return Ldf
		
		#fl = open(fp, "r", encoding="utf-8")
		try: fl = open(fp, "r", encoding="utf-8")
		except: fl = open(fp, "r")
		
		ls=fl.read().replace('\n','')#.replace('# -*- coding: utf-8 -*-Lgr=','')
		fl.close()
		return eval(ls)
	except:
		print ('err open_Groups')
		return recover_Groups()

def save_Groups(L):
	try:
		fp=os.path.join(UserDir, 'UserGR.py')
		#fl = open(fp, "w", encoding="utf-8")
		try: fl = open(fp, "w", encoding="utf-8")
		except: fl = open(fp, "w")

		#fl.write('# -*- coding: utf-8 -*-\n')
		#fl.write('Lgr=[\n')
		fl.write('[\n')
		for i in L:
			try:fl.write(repr(i)+',\n')
			except: pass
		fl.write(']\n')
		fl.close()
	except:
		print ('Error save_Groups')

def get_SG():
	try:SG=__settings__.getSetting("Sel_gr")
	except:SG=''
	if SG=='':
		SG='Все каналы'
		__settings__.setSetting("Sel_gr",SG)
	return SG

def get_gr(SG='', blacklist=True):
	if SG=='':SG=get_SG()
	CLf=[]
	if SG=='Все каналы':
		CLf=DBC.keys()
	else:
		try:L=open_Groups()
		except:L=[]
		for i in L:
			if i[0]==SG: CLf=i[1]
	
	if CLf==[]:CLf=DBC.keys()
	
	if blacklist: BL=get_blacklist_cn(SG)
	else: BL=[]
	if BL==[]: CL=CLf
	else:
		CL=[]
		for c in CLf:
			if c not in BL: CL.append(c)
	
	if __settings__.getSetting("abc")=='true' or SG=='Все каналы': CL=sort_abc(CL)
	return CL

def get_outbase():
	CL=DBC.keys()
	L=[]
	Lt=[]
	lid=[]
	for i in Lserv:
			serv_id=str(int(i[1:3]))
			try: Ls=get_cahe_list(serv_id)
			except:Ls=[]
			for c in Ls:
				name = c['title']
				#picon = c['img']
				try:group = c['group']
				except:group =''
				id = CRC32(uni_mark(name+group))
				if id not in CL:
					if id not in lid:
						lid.append(id)
						Lt.append(name)
						L.append({'title':name,'id':id,'group':group})#,'picon':picon
	
	sel = xbmcgui.Dialog()
	Lt.sort()
	#r = sel.multiselect("Добавить каналы:", Lt)
	r = sel.select(lcl("Добавить канал:"), Lt)
	if r>0:
		st=Lt[r]
		for a in L:
			if a['title'] == st:
				DBC[a['id']]={'group': [a['group']], 'names': [uni_mark(a['title'])], 'title': a['title']}
				try: save_DBC(DBC)
				except: pass

				return True

	return False

def get_blacklist_cn(cgr=''):
		BL=[]
		try:L=open_Groups()
		except:L=[]
		for i in L:
			if len(i)==3 and i[0]!=cgr: BL.extend(i[1])
		return BL

def get_autoexit_gr():
		SG=get_SG()
		try:L=open_Groups()
		except:L=[]
		for i in L:
			if len(i)==3 and i[0]==SG: return True
		return False

def get_cut_gr():
		Lnm=[]
		Lserv=get_all_channeles()
		CL=get_gr()
		nml=[]
		for a in Lserv:
			nm=uni_mark(a['title'])
			nml.append(nm)
		for id in CL:
				try:
					names = DBC[id]['names']
					enable=False
					for b in names:
						if b in nml: enable=True
					
					if enable:
						#name  = DBC[id]['title']
						#cover = get_picon(id)
						if id not in Lnm:
							Lnm.append(id)
				except:
					pass
		return Lnm


def select_gr(ind, gui=False):
	L=open_Groups()
	Lg=['Все каналы',]
	for i in L:
		if len(i)==2:Lg.append(i[0])
		elif len(i)==3: Lg.append('[COLOR 44FFFFFF]'+i[0]+'[/COLOR]')
	
	if gui: return Lg

def set_num_cn(id):
	L=open_Groups()
	try:SG=__settings__.getSetting("Sel_gr")
	except:SG=''
	if SG=='All':SG='Все каналы'
	if SG=='':SG='Все каналы'
	
	if SG!='Все каналы':
		CL=get_gr()
		CL.remove(id)
		CLn=[]
		for c in CL:
			try:CLn.append(DBC[c]['title'])
			except: CL.remove(c)
		CLn.append(lcl(' - В конец списка - '))
		sel = xbmcgui.Dialog()
		r = sel.select(lcl("Перед каналом:"), CLn)
		if r>=0:
			CL.insert(r, id)
			L2=[]
			for i in L:
				if i[0]==SG:
					if len(i)==2:igr=(SG,CL)
					elif len(i)==3:igr=(SG,CL,i[2])
					L2.append(igr)
				else:
					L2.append(i)
				#k+=1
			save_Groups(L2)



def add_to_gr(id, group='', L=[]):
	if L==[]:
		try:L=open_Groups()
		except:L=Ldf
	Lg=[]
	for i in L:
		Lg.append(i[0])
		
	if Lg!=[]:
		if group=='':
			sel = xbmcgui.Dialog()
			r = sel.select(lcl("Группа:"), Lg)
		else:
			r=Lg.index(group)
		if r!=-1:
			if id not in L[r][1]:
					L[r][1].append(id)
					save_Groups(L)
	return L

def rem_from_gr(id):
	try:	SG=__settings__.getSetting("Sel_gr")
	except: SG=''
	try:L=open_Groups()
	except:L=Ldf
	L2=[]
	for i in L:
		if SG=='' or SG=='Все каналы' or SG=='All':
				ng=i[1]
				if id in ng: i[1].remove(id)#ng.remove(id)
				#=ng
				#if len(i)==2:
				#L2.append([i[0],ng])
				L2.append(i)
		else:
			if SG == i[0]:
				ng=i[1]
				if id in ng: i[1].remove(id)#ng.remove(id)
				#L2.append([i[0],ng])
				#i[1]=ng
			#else:
			L2.append(i)
	save_Groups(L2)
	#xbmc.executebuiltin("Container.Refresh")

def update_cnl():
		#filtr=[]
		#if __settings__.getSetting("split_1") == 'false':filtr.append('h')
		#if __settings__.getSetting("split_2") == 'false':filtr.append('u')
		#if __settings__.getSetting("split_3") == 'false':filtr.append('p')
		
		#pDialog = xbmcgui.DialogProgressBG()
		#pDialog.create('Корона ТВ', 'Обновление списка каналов ...')
		#for i in Lserv:
		#	if i[:1] not in filtr:
		if True:
				i='L08_mym3u'
				#serv_id=str(int(i[1:3]))
				#if __settings__.getSetting("serv"+serv_id)=='true' :
				#		pDialog.update(int(serv_id)*100/len(Lserv), message='Обновление списка каналов ...')
				Ls=upd_canals_db(i)
		#pDialog.close()
		__settings__.setSetting("ag_tm",repr(time.time()))
		xbmc.executebuiltin("Container.Refresh")

def add_gr(name=''):
	if name == '': name=inputbox('')
	try:L=open_Groups()
	except:L=Ldf
	st=(name,[])
	if st not in L:L.append(st)
	save_Groups(L)
	return L

def rem_gr(name=''):
	try:L=open_Groups()
	except:L=Ldf
	Lg=[]
	for i in L:
		Lg.append(i[0])
	
	if name=="":
		if Lg!=[]:
			sel = xbmcgui.Dialog()
			r = sel.select(lcl("Группа:"), Lg)
		if r>=0:
			name=Lg[r]
	
	if name!="":
		L2=[]
		for i in L:
			if i[0]!=name: L2.append(i)
		save_Groups(L2)

def move_gr(name=''):
	if name!="":
		try:L=open_Groups()
		except:L=Ldf
		Lg=[]
		gi=None
		for i in L:
			if i[0]==name: gi=i
			else: Lg.append(i[0])
		Lg.append(' - В конец списка - ')
		
		sel = xbmcgui.Dialog()
		r = sel.select(lcl("Вставить перед группой:"), Lg)
		if r>=0:
			L2=[]
			
			for i in L:
				if i[0]!=name: L2.append(i)
			L2.insert(r, gi)
			save_Groups(L2)

def set_pass_gr(name=''):
	if name!="":
		try:L=open_Groups()
		except:L=Ldf
		Lg=[]
		for i in L:
			if i[0]==name and len(i)==2: 
					pas=inputbox()
					i=[i[0],i[1], pas]
			Lg.append(i)
			save_Groups(Lg)


def rem_pass_gr(name=''):
	if name!="":
		try:L=open_Groups()
		except:L=Ldf
		Lg=[]
		for i in L:
			if i[0]==name and len(i)==3: 
				pas=inputbox()
				if pas==i[2]: i=[i[0],i[1]]
				else: showMessage('Отклонено!', 'Неверный пароль')
			Lg.append(i)
			save_Groups(Lg)

def get_access_gr(name=''):
	if name!="":
		true_name=name.replace('[COLOR 44FFFFFF]','').replace('[/COLOR]','')
		try:L=open_Groups()
		except:L=Ldf
		for i in L:
			if i[0]==true_name and len(i)==3:
				pas=inputbox()
				if pas==i[2]: return true_name
				else: showMessage('Отклонено!', 'Неверный пароль')
		return name

def rename_gr(name=''):
	ng=inputbox()
	if name!="" and ng!='':
		try:L=open_Groups()
		except:L=Ldf
		Lg=[]
		gi=None
		for i in L:
			if i[0]==name: i=[ng,i[1]]
			Lg.append(i)
			save_Groups(Lg)

def extend_gr(name=''):
	if name!="":
		try:L=open_Groups()
		except:L=Ldf
		Lg=[]
		gi=None
		for i in L:
			if i[0]==name: gi=i[1]
			else: Lg.append(i[0])
		
		sel = xbmcgui.Dialog()
		r = sel.select(lcl("Объединить с группой:"), Lg)
		if r>=0:
			r_nm=Lg[r]
			gr=[]
			for i in L:
				if i[0]==r_nm:
					if len(i)==3: 
						showMessage('Недоступно', 'Группа заблокирована')
						return ""
					gr=i[1]
			
			for i in gi:
				if i not in gr: gr.append(i)
			
			L2=[]
			for i in L:
				if i[0]!=name:
					if i[0]==r_nm:   L2.append([r_nm, gr])
					else:            L2.append(i)
			save_Groups(L2)

def add_rec(name):
	for i in Larh:
		serv_id=str(int(i[1:3]))
		try: 
			exec ("import aid"+serv_id+"; dict=aid"+serv_id+".n2id")
			nm=lower(unmark(name))
			#print nm
			if nm in dict.keys():
				return name+" [COLOR 5FFF1010][R][/COLOR]"
		except: pass
	return name



def archive(name):#, sd='0'
	try:sd=__settings__.getSetting("Sel_sday")
	except: sd='0'
	if sd=="":sd='0'
	La=get_all_archive()
	ssec=int(sd)*24*60*60
	t=time.localtime(time.time() - ssec)
	add_item ('[COLOR FF10FF10][B]'+time.strftime('%d.%m.%Y',t)+" - "+unmark(name)+"[/B][/COLOR]", "select_date", 'url', '0' )
	da={}
	Lm=[]
	for n2id in La:
		serv_id=n2id['srv_id']
		#try: 
		exec ("import "+serv_id+"; arh="+serv_id+".ARH()")
		#n2id=arh.name2id()
		try:aid=n2id[lower(unmark(name))]
		except: aid=""
		#from aid3 import *
		#n2id
		if aid!="":
			L=arh.Archive(aid, t)
			for i in L:
				#url=i['url']
				#title=i['title']
				st=i['time']
				#add_item (st+" - "+title, "play2", [url,], 'archive' )
				try: 
					i2=da[st]
					urls=i2['url']
					url=i['url']
					urls.append(url)
					i2['url']=urls
					da[st]=i2
				except: 
					url=i['url']
					i['url']=[url,]
					da[st]=i
	for d in da.keys():
			urls=da[d]['url']
			title=da[d]['title']
			st=da[d]['time']
			add_item (st+" - "+title, "play2", urls, 'archive' )
			
	#xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	#xbmcplugin.endOfDirectory(handle)


def select_date():
		L=[]
		for i in range (0,10):
			ssec=i*24*60*60
			t=time.localtime(time.time() - ssec)
			st=time.strftime('%d.%m.%Y',t)
			L.append(st)
		sel = xbmcgui.Dialog()
		r = sel.select("Дата:", L)
		arhive.setSetting("Sel_sday",str(r))
		xbmc.executebuiltin("Container.Refresh")

def get_arhive_date():
	try:sd=__settings__.getSetting("Sel_sday")
	except: sd='0'
	if sd=="":sd='0'
	ssec=int(sd)*24*60*60
	t=time.localtime(time.time() - ssec)
	return time.strftime('%d.%m.%Y',t)

def set_arhive_date(r):
	__settings__.setSetting("Sel_sday",str(r))

# ----------------------------------- данные ----------------------------------------------------


def get_arhive_directory():
	print ('=get_arhive_directory=')
	L=get_all_channeles()
	D={}
	for i in L:
		#try:
			if i['arhive']!='0':
				name = i['title']
				#print name
				try: gr=i['group']
				except: gr=''
				id = get_id(name, gr)
				D[id]=i['arhive']
		#except: pass
	return D


def get_arhive_canale(id):
	day=__settings__.getSetting("Sel_sday")
	t2=time.gmtime()
	#print t2
	t1=time.strftime("%d-%m-%Y", t2)
	#print t1
	t0=time.strptime(t1,"%d-%m-%Y")
	#print t0
	t=time.mktime(t0)
	stream = fast_stream(id)
	gid = DBC[id]['tvg']
	try: c_epg=eval(getURL3('http://127.0.0.1:'+epg_port+'/channel/full/id='+str(gid)))
	except: c_epg={}
	Lk=c_epg.keys()
	L=[]
	for k in Lk:
		L.append(k)
	L.sort()

	if __settings__.getSetting('autoshift')=='true':
		dts=time.timezone 
	else:
		dts=(int(__settings__.getSetting('shift'))-11)*3600
	
	if __settings__.getSetting('DST_shift')=='true': dts -= time.localtime()[8]*3600
	#print dts

	LL=[]
	st = t-int(day)*24*60*60
	if day=='0': et = time.time()
	else:        et = st+24*60*60
	print (st)
	print (et)
	print ('---')
	for tms in L:
		print(tms)
		if tms!='title':
			tm = float(tms)
			if st<tm<et:
				d=c_epg[tms]
				d['time']=tm
				d['tms']=time.strftime('%H:%M',time.localtime(tm-3*60*60-dts))
				arh_stream = stream+'?time_start='+str(int(tm-3*60*60-dts))#+tms[:-2]
				d['stream']=arh_stream#.replace('index.','video.')
				LL.append(d)
	return LL

def get_arhive_strm(dir):
	dir=dir.replace('mode=play2', 'mode=strm')
	response = eval(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Files.GetDirectory", "params": {"directory": "'+dir+'"},"id": 1}'))
	files=response["result"]["files"]
	D={}
	for i in files:
		name=i["label"]
		curl=i["file"]
		D[name]=curl
	return D

def get_picons(title):
	#print '== select_icon =='
	if " TV" not in title: title=title+" TV"
	title=title.replace(' HD', '').replace('(+1)', '').replace('(+2)', '').replace('(+3)', '').replace('(+4)', '').replace('(+5)', '').replace('(+6)', '')
	url='http://yandex.ru/images/search?text='+urllib.quote_plus(title)+'&isize=small&iorient=square'#&type=clipart
	#print url
	hp=getURL3(url)
	ss='&quot;img_href&quot;:&quot;'
	L=mfindal(hp, ss, '&quot;')
	L2=[]
	for i in L:
		#print i
		if 'http' in i: L2.append(i.replace(ss,''))
	return L2

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param


#if __settings__.getSetting("xplay")=='true': 
#	Player=pPlayer()
#else:
Player=xbmc.Player()

#Player=pPlayer()
#Player2=p2Player()

if DBC=={}: update_cnl()
if open_Groups()==[]: update_cnl()#recover_Groups()
#root('PRIVATE (DE)')

def billing_off():
		try:agt=eval(__settings__.getSetting("ab_tm"))
		except: agt=0
		if time.time()-agt<60*60: return
		
		tariffs = {'0':'RU.TV', '1': 'DE/AT/CH', '997': 'ALL-Minute', '999': 'All'}
		login = str(__settings__.getSetting("login"))
		passw = str(__settings__.getSetting("passw"))
		url='http://pl.strah-tv.top/'+login+'/'+passw+'/custinfo.json'
		#print (url)
		h=getURL(url)
		#print (h)
		null = ''
		true = 'true'
		false = 'false'
		jsn=eval(h)
		print (jsn)
		t=jsn['current_tariff_id']
		if t in tariffs.keys(): t=tariffs[t]
		__settings__.setSetting("tariff", t)
		__settings__.setSetting("balance",jsn['acc_balance'])
		__settings__.setSetting("ex_date",jsn['expiry_date'])
		__settings__.setSetting("active", jsn['active'])
		__settings__.setSetting("aac",    jsn['acc_no'])
		__settings__.setSetting("ab_tm",repr(time.time()))

#billing()
print (root())