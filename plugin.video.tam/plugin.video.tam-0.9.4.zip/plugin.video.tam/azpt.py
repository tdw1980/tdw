#!/usr/bin/python
# -*- coding: utf-8 -*-
# - ====================================== antizapret ====================================================
import xbmc, xbmcaddon
import time, cookielib, urllib, urllib2, os, sys
__settings__ = xbmcaddon.Addon(id='plugin.video.tam')
sid_file = os.path.join(xbmc.translatePath('special://temp/'), 'vpn.sid')
cj = cookielib.FileCookieJar(sid_file) 
hr  = urllib2.HTTPCookieProcessor(cj) 

proxy_list=[
	'http://xawos.ovh/index.php?q=',             #Франция
	'http://prx.afkcz.eu/prx/index.php?q=',      #Чехия
	'https://dev.chamoun.fr/proxy/index.php?q=', #Франция
	'http://thely.fr/proxy/?q=',                 #Франция
	'https://derzeko.de/Proxy/index.php?q=',     #Германия
]
#	'http://www.pitchoo.net/zob_/index.php?q=',  #Франция

def test_url(url):
	import urllib2
	url=url.replace('?q=', '')
	try:
		response = urllib2.urlopen(url, timeout=3)
		return response.getcode()
	except:
		return '404'

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es,s)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def GETvpn():
	import httplib
	conn = httplib.HTTPConnection("antizapret.prostovpn.org")
	conn.request("GET", "/proxy.pac", headers={"User-Agent": 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)'})
	r1 = conn.getresponse()
	data = r1.read()
	conn.close()
	return data

'''
def GETdata(url):
	import httplib
	head = mfind(url,'://', '/')
	tail = url[url.find(head)+len(head):]
	conn = httplib.HTTPConnection(head)
	conn.request("GET", tail, headers={"User-Agent": 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)'})
	r1 = conn.getresponse()
	data = r1.read()
	conn.close()
	return data
'''

def GETdata(url):
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link


def proxy_update():
	try:
		print 'proxy_update'
		#url='https://antizapret.prostovpn.org/proxy.pac'
		pac=GETvpn()#url)
		prx=pac[pac.find('PROXY ')+6:pac.find('; DIRECT')]
		__settings__.setSetting("proxy_serv", prx)
		__settings__.setSetting("proxy_time", str(time.time()))
	except: 
		print 'except get proxy'

def get_opener():
		try:pt=float(__settings__.getSetting("proxy_time"))
		except:pt=0
		print pt
		if time.time()-pt > 36000: proxy_update()
		prx=__settings__.getSetting("proxy_serv")
		print prx
		if prx.find('http')<0 : prx="http://"+prx
		proxy_support = urllib2.ProxyHandler({"http" : prx})
		opener = urllib2.build_opener(proxy_support, hr)
		#urllib2.install_opener(opener)
		print 'opener ok'
		return opener

def convert(url):
	try: id=int(__settings__.getSetting("proxy_id"))
	except: id=-1
	try: tm=float(__settings__.getSetting("proxy_tm"))
	except: tm=0
	dt = time.time()-tm
	if id!=-1: 
		if dt<3600:
			proxy=proxy_list[id]
			c=test_url(proxy)
		else:
			c='200'
	if id<0 or c=='404':
		for id in range (len(proxy_list)):
				proxy=proxy_list[id]
				c=test_url(proxy)
				if c!='404': 
					__settings__.setSetting("proxy_id", str(id))
					__settings__.setSetting("proxy_tm", str(time.time()))
					break
	
	import base64
	sign=base64.b64encode(url)
	redir=proxy_list[id]+urllib.quote_plus(sign)
	return redir

def decoder(hp, id=0):
	if ':announce' in hp: return hp
	import base64, urllib
	id=int(__settings__.getSetting("proxy_id"))
	if id=='': id=0
	L=mfindal(hp, proxy_list[id], '"')
	for i in L:
		try:
			#print i
			url=base64.b64decode(urllib.unquote_plus(i.replace(proxy_list[id],'')))
			print url
			hp=hp.replace(i, url)
		except:
			pass
			print i
	#print hp
	return hp

def GET(url):
	curl = convert(url)
	data = GETdata(curl)
	dd = decoder(data)
	return dd