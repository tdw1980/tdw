# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, urllib, urllib2, os, sys, xbmcvfs

PLUGIN_NAME   = 'TAM'
handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.tam')
__settings__ = xbmcaddon.Addon(id='plugin.video.tam')

Pdir = addon.getAddonInfo('path')
icon = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'icon.png'))
xbmcplugin.setContent(int(sys.argv[1]), 'movies')
engine_t2h=None
engine_ts=None
index_ts =0

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)
def f2u(x): return 'file:///'+x.replace('\\','/')
def rt(s):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.encode('utf-8')
	return s

def ut(s):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	return s

def fs_dec(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode(sys_enc).encode('utf-8')

def fs_enc(path):
	path=xbmc.translatePath(path)
	sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
	try:path2=path.decode('utf-8')
	except: pass
	try:path2=path2.encode(sys_enc)
	except: 
		try: path2=path2.encode(sys_enc)
		except: path2=path
	return path2

class xPlayer(xbmc.Player):
	def __init__(self):
		self.tsserv = None
		self.active = True
		self.started = False
		self.ended = False
		self.paused = False
		self.buffering = False
		xbmc.Player.__init__(self)
		width, height = xPlayer.get_skin_resolution()
		w = width
		h = int(0.14 * height)
		x = 0
		y = (height - h) / 2
		self._ov_window = xbmcgui.Window(12005)
		self._ov_label = xbmcgui.ControlLabel(x, y, w, h, '', alignment=6)
		self._ov_background = xbmcgui.ControlImage(x, y, w, h, fs_dec(xPlayer.get_ov_image()))
		self._ov_background.setColorDiffuse('0xD0000000')
		self.ov_visible = False
		self.onPlayBackStarted()


	def onPlayBackPaused(self):
		self.ov_show()
		#engine=get_engine()
		#status=''
		#if   engine=="1": status = get_t2h_status()
		#elif engine=="6": status = get_ace_status()
		#elif engine=="8": status = get_ts_status()
		#self.ov_update(status)


	def onPlayBackStarted(self):
		self.ov_hide()
		xbmc.sleep(2000)
		engine=get_engine()
		status = ''
		while xbmc.Player().isPlaying():
			if self.ov_visible == True:
				if   engine=="1": status = get_t2h_status()
				elif engine=="6": status = get_ace_status()
				elif engine=="8": status = get_ts_status()
				self.ov_update(status)
			xbmc.sleep(800)


	def onPlayBackResumed(self):
		self.ov_hide()
		
	def onPlayBackStopped(self):
		self.ov_hide()
	
	def __del__(self):
		self.ov_hide()

	@staticmethod
	def get_ov_image():
		import base64
		ov_image = fs_enc(os.path.join(addon.getAddonInfo('path'), 'bg.png'))
		if not os.path.isfile(ov_image):
			fl = open(ov_image, 'wb')
			fl.write(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII='))
			fl.close()
		return ov_image

	@staticmethod
	def get_skin_resolution():
		import xml.etree.ElementTree as Et
		skin_path = fs_enc(xbmc.translatePath('special://skin/'))
		tree = Et.parse(os.path.join(skin_path, 'addon.xml'))
		res = tree.findall('./extension/res')[0]
		return int(res.attrib['width']), int(res.attrib['height'])

	def ov_show(self):
		if not self.ov_visible:
			self._ov_window.addControls([self._ov_background, self._ov_label])
			self.ov_visible = True

	def ov_hide(self):
		if self.ov_visible:
			self._ov_window.removeControls([self._ov_background, self._ov_label])
			self.ov_visible = False

	def ov_update(self, txt=" "):
		if self.ov_visible:
			self._ov_label.setLabel(txt)#'[B]'+txt+'[/B]'

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def inputbox(t=''):
	skbd = xbmc.Keyboard(t, 'Название:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return t

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


try:
	from kodidb import*
except: pass

def convert(url):
	import base64
	sign=base64.b64encode(url)
	redir='http://www.proxy.zee18.info/index.php?q='+urllib.quote_plus(sign)
	return redir

def compress(info):
	import base64
	sinfo=repr(info)
	sign=base64.b64encode(sinfo)
	return sign

def decompress(encoded):
	print encoded
	import base64
	sinfo=base64.b64decode(encoded)
	print sinfo
	return eval(sinfo)


def chek_in():
	try:
		#print '====chek_in===='
		if xbmc.getInfoLabel('ListItem.FileName') == '': FileName = urllib.unquote_plus(get_params()['strm'])
		else:                                            FileName = xbmc.getInfoLabel('ListItem.FileName')
		if xbmc.getInfoLabel('ListItem.Path') == '':     Path = __settings__.getSetting("SaveDirectory")#os.path.join(, FileName[:FileName.find('.')])
		else:                                            Path = xbmc.getInfoLabel('ListItem.Path')
		try: 
			FileName = ut(FileName)#.decode('utf-8')
			Path = ut(Path)#.decode('utf-8')
		except: pass
		#print repr(FileName)
		#print repr(Path)
		k_db = KodiDB(FileName, Path, sys.argv[0] + sys.argv[2])
		k_db.PlayerPreProccessing()
		#print '==============='
		return k_db
	except: 
		return None
	
def chek_out(k_db):
	k_db.PlayerPostProccessing()
	xbmc.sleep(300)
	xbmc.executebuiltin('Container.Refresh')
	xbmc.sleep(200)
	if not xbmc.getCondVisibility('Library.IsScanningVideo'):
		xbmc.executebuiltin('UpdateLibrary("video", "", "false")')


def POST(target, post=None, referer='http://ya.ru'):
	#print target
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		req.add_header('X-Requested-With', 'XMLHttpRequest')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		print e
		return ''

def GET(target, XML = False):
	try:
			req = urllib2.Request(url = target)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			if XML: req.add_header('X-Requested-With', 'XMLHttpRequest')
			resp = urllib2.urlopen(req)
			return resp.read()
	except Exception, e:
			print 'HTTP ERROR ' + str(e)
			return None

def READ(fn):
		#fl = open(fn, "rb")
		fl = xbmcvfs.File(fn)
		r=fl.read()
		fl.close()
		return r


def open_file():
	dialog = xbmcgui.Dialog()
	fn = dialog.browseSingle(1, 'Открыть', 'files', '.torrent')#fs_enc()
	
	if fn!='':
		#fl = open(fn, "rb")
		fl = xbmcvfs.File(fn)
		r=fl.read()
		fl.close()
		import bencode, hashlib
		metainfo = bencode.bdecode(r)
		infohash = hashlib.sha1(bencode.bencode(metainfo['info'])).hexdigest()
		magneturi  = 'magnet:?xt=urn:btih:'+str(infohash)+'&dn='+urllib.quote_plus(metainfo['info']['name'])
		return {'magnet': magneturi, 'file': fn, 'title': metainfo['info']['name']}
	else:
		return {}

def open_strm_old(url, ind=0, purl='', info={}):
	cancel=False
	if purl!='':
		progressBar = xbmcgui.DialogProgress()
		progressBar.create('ТАМ', 'Запуск сохраненного файла')
		for i in range (0,5):
			progressBar.update(20*i, '', '[COLOR FFFFFF33][B]Нажмите "Отмена" для выбора качества[/B][/COLOR]')
			xbmc.sleep(1600)
			if progressBar.iscanceled():
						print '=== cancel ==='
						progressBar.update(0)
						cancel=True
						break
		progressBar.close()
	if cancel: 
		xbmcplugin.endOfDirectory(handle, False, False)
		xbmc.executebuiltin('ActivateWindow(10025,"'+purl+'", return)')
		xbmc.executebuiltin("Container.Refresh()")
	else:
		play(url, ind)
		pass

def open_strm(url, ind=0, purl='', name=''):
	if purl!='':
		if __settings__.getSetting("SaveMagnet")=='true' and 'magnet' not in url and 'acestream:' not in url: url=t2m(url)
		data={'name':name, 'url':url, 'purl':purl, 'ind':ind}
		__settings__.setSetting("saver_data", repr(data))
		import saver
		break_play=saver.open_strm()
		if break_play == 'false': play(url, ind)
	else:
		play(url, ind)

def save(url, ind=0, purl='', info={}):
	if List(url)>1: save_series(url, info, purl)
	else:           save_strm(url, ind, purl, info)

def save_series(url, info={}, purl=''):
		xbmcplugin.endOfDirectory(handle, False, False)
		list=[]
		for i in List(url):
			list.append(i[0])
		if __settings__.getSetting("SaveMagnet")=='true' and 'magnet' not in url and 'acestream:' not in url: url=t2m(url)
		data={'info':info, 'list':list, 'url':url, 'purl':purl}
		__settings__.setSetting("saver_data", repr(data))
		import saver
		saver.main()

def save_strm(url, ind=0, purl='', info={}):
		if __settings__.getSetting("SaveMagnet")=='true' and 'magnet' not in url and 'acestream:' not in url: url=t2m(url)
		SaveDirectory = __settings__.getSetting("SaveDirectory")
		if SaveDirectory=="":SaveDirectory=Pdir
		try:
			name = info['originaltitle'].replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"")+" ("+str(info['year'])+")"
			title = info['originaltitle']
		except:
			try: t=info['title']
			except: t=''
			title=inputbox(t)
			name = title.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"")
		
		uri = sys.argv[0] + '?mode=open_strm'
		uri = uri+ '&url='+urllib.quote_plus(url)
		uri = uri+ '&ind='+str(ind)
		if purl!='': uri = uri+ '&purl='+urllib.quote_plus(purl)
		if info!={}: uri = uri+ '&name='+urllib.quote_plus(title)
		uri = uri+ '&strm='+urllib.quote_plus(name+".strm")
		
		fl = open(os.path.join(fs_enc(SaveDirectory),fs_enc(name+".strm")), "w")
		fl.write(uri)
		fl.close()
		
		try: 
			if __settings__.getSetting("SaveNFO")=='true': save_film_nfo(info)
		except:pass
		
		xbmc.executebuiltin('UpdateLibrary("video", "", "false")')

def save_film_nfo(info):
		title=info['title']
		fanart=info['fanart']
		cover=info['cover']
		year=info['year']
		fanarts=[fanart,cover]
		
		try:plot=info['plot']
		except:plot=''
		try:rating=info['rating']
		except:rating=0
		try:originaltitle=info['originaltitle']
		except:originaltitle=title
		
		try:duration=info["duration"]
		except:duration=''
		try:genre=info["genre"].replace(', ', '</genre><genre>')
		except:genre=''
		try:studio=info["studio"]
		except:studio=''
		
		try: director=info["director"]
		except: director=''
		try:cast=info["cast"]
		except:cast=[]
		try: actors=info["actors"]
		except: actors={}
		
		name = info['originaltitle'].replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"")+" ("+str(info['year'])+")"
		cn=name.find(" (")
		
		SaveDirectory = __settings__.getSetting("SaveDirectory")
		if SaveDirectory=="":SaveDirectory=Pdir
		
		nfo='<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>'+chr(10)
		nfo+='<movie>'+chr(10)
		
		nfo+="	<title>"+title+"</title>"+chr(10)
		nfo+="	<originaltitle>"+originaltitle+"</originaltitle>"+chr(10)
		nfo+="	<genre>"+genre+"</genre>"+chr(10)
		nfo+="	<studio>"+studio+"</studio>"+chr(10)
		nfo+="	<director>"+director+"</director>"+chr(10)
		nfo+="	<year>"+str(year)+"</year>"+chr(10)
		nfo+="	<plot>"+plot+"</plot>"+chr(10)
		nfo+='	<rating>'+str(rating)+'</rating>'+chr(10)
		nfo+='	<runtime>'+duration+' min.</runtime>'+chr(10)
		
		nfo+="	<fanart>"+chr(10)
		for fan in fanarts:
			nfo+="		<thumb>"+fan+"</thumb>"+chr(10)
		nfo+="		<thumb>"+cover+"</thumb>"+chr(10)
		nfo+="	</fanart>"+chr(10)
		
		nfo+="	<thumb>"+cover+"</thumb>"+chr(10)
		
		for actor in cast:
			nfo+="	<actor>"+chr(10)
			nfo+="		<name>"+actor+"</name>"+chr(10)
			nfo+="	</actor>"+chr(10)
		
		nfo+="</movie>"+chr(10)
		
		fl = open(os.path.join(fs_enc(SaveDirectory),fs_enc(name+".nfo")), "w")
		fl.write(nfo)
		fl.close()

def t2m(url):
	try:
		import bencode, hashlib
		r = GET(url)
		metainfo = bencode.bdecode(r)
		announce=''
		if 'announce-list' in metainfo.keys():
			for ans in metainfo['announce-list']:
				announce=announce+'&tr='+urllib.quote_plus(ans[0])
		infohash = hashlib.sha1(bencode.bencode(metainfo['info'])).hexdigest()
		#announce=metainfo['info']['announce']
		#print announce
		magneturi  = 'magnet:?xt=urn:btih:'+str(infohash)+'&dn='+urllib.quote_plus(metainfo['info']['name'])+announce
		return magneturi
	except:
		return url

def get_fid(url, ind):
	L=List(url)
	Lt=[]
	Li=[]
	for i in L:
		Lt.append(i[0])
		Li.append(i[0])
	Lt.sort()
	t=Li[int(ind)]
	n=0
	for i in Lt:
		if i == t: return n
		n+=1
	return 0

def get_engine():
	global engine
	if engine!='':
		de={'ace':'0', 't2http':'1', 'yatp':'2', 'torrenter':'3', 'elementum':'4', 'xbmctorrent':'5', 'ace_proxy':'6', 'quasar':'7', 'torr_server':'8', 'torrserver':'8'}
		try:    tengine=de[engine]
		except: tengine= __settings__.getSetting("Engine")
	if engine=='': 
				tengine=__settings__.getSetting("Engine")
	return tengine

#def play18(url, ind=0):
#	uri = sys.argv[0]+'?mode=play&ind='+str(ind)+'&url='+urllib.quote_plus(url)+'&engine='+urllib.quote_plus(engine)
#	xbmc.executebuiltin('PlayMedia("'+uri+'")')
#	xbmcplugin.endOfDirectory(handle, False, False)

def play(url, ind=0):
	print url
	k_db=chek_in()
	engine=get_engine()
	
	if 'magnet:' in url:
		if   engine=="0": play_ace_proxy(url, ind)
		elif engine=="1": play_t2h (url, ind)
		elif engine=="2": play_yatp(url, ind)
		elif engine=="3": play_torrenter(url, ind)
		elif engine=="4": play_elementum(url, ind)
		elif engine=="5": play_xbmctorrent(url, ind)
		elif engine=="6": play_ace_proxy(url, ind)
		elif engine=="7": play_quasar(url, ind)
		elif engine=="8": play_torr_server(url, ind)
		else:             play_t2h (url, ind)
	
	elif 'acestream:' in url:
						  play_ace_proxy(url, ind)
	
	else:
		if engine=="0": play_ace (url, ind)
		if engine=="1": play_t2h (url, ind)
		if engine=="2": play_yatp(url, ind)
		if engine=="3": play_torrenter(url, ind)
		if engine=="4": play_elementum(url, ind)
		if engine=="5": play_xbmctorrent(url, ind)
		if engine=="6": play_ace_proxy(url, ind)
		if engine=="7": play_quasar(url, ind)
		if engine=="8": play_torr_server(url, ind)
		if engine=="9": play_ltorrent(url, ind)
	
	#xbmc.executebuiltin('Action("ToggleWatched")')
	
	if k_db != None: chek_out(k_db)
	


def play_torr_server(url, ind):
	#if 'magnet' not in url: url=t2m(url)
	global engine_ts
	global index_ts
	index_ts = int(ind)
	import torrserve_stream
	tss = torrserve_stream.Settings()
	engine_ts =  torrserve_stream.Engine(uri=url, host=tss.host, port=tss.port)
	if __settings__.getSetting('ts_info')== 'true': Player=xPlayer()
	player = torrserve_stream.Player(uri=url, index=ind)

def play_torr_server_off(url, ind):
	print '-=-=-=-= play_torr_server =-=-=-=-'
	host='127.0.0.1'
	port='8090'
	fid = get_fid(url, ind)
	uri='http://'+host+':'+port+'/torrent/play?link='+ urllib.quote_plus(t2m(url))+"&file="+str(fid)
	#print uri
	Player=xPlayer()
	#print 'xPlayer'
	item = xbmcgui.ListItem(path=uri)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	

def play_ace(torr_link, ind=0):
	try:
		title=get_item_name(url, ind)
		from TSCore import TSengine as tsengine
		TSplayer=tsengine()
		out=TSplayer.load_torrent(torr_link,'TORRENT')
		#print out
		if out=='Ok': TSplayer.play_url_ind(int(ind),title, icon, icon, True)
		TSplayer.end()
		return out
	except: 
		return '0'

def play_t2h(uri, file_id=0):
	global engine_t2h
	#if 'magnet' not in uri: uri=t2m(uri)
	try:
		DDir=__settings__.getSetting("DownloadDirectory")
		sys.path.append(os.path.join(xbmc.translatePath("special://home/"),"addons","script.module.torrent2http","lib"))
		from torrent2http import State, Engine, MediaType
		progressBar = xbmcgui.DialogProgress()
		from contextlib import closing
		if DDir=="": DDir=os.path.join(xbmc.translatePath("special://home/"),"userdata")
		progressBar.create('Torrent2Http', 'Запуск')
		# XBMC addon handle
		# handle = ...
		# Playable list item
		# listitem = ...
		# We can know file_id of needed video file on this step, if no, we'll try to detect one.
		# file_id = None
		# Flag will set to True when engine is ready to resolve URL to XBMC
		ready = False
		# Set pre-buffer size to 15Mb. This is a size of file that need to be downloaded before we resolve URL to XMBC 
		pre_buffer_bytes = 15*1024*1024
		
		engine = Engine(uri, download_path=DDir, enable_dht=True, dht_routers=["router.bittorrent.com:6881","router.utorrent.com:6881"], user_agent = 'uTorrent/2200(24683)')
		engine_t2h = engine
		with closing(engine):
			# Start engine and instruct torrent2http to begin download first file, 
			# so it can start searching and connecting to peers  
			engine.start(file_id)
			progressBar.update(0, 'Torrent2Http', 'Загрузка торрента', "")
			while not xbmc.abortRequested and not ready:
				xbmc.sleep(500)
				status = engine.status()
				# Check if there is loading torrent error and raise exception 
				engine.check_torrent_error(status)
				# Trying to detect file_id
				
				if file_id is None:
					if xbmc.abortRequested: break
					# Get torrent files list, filtered by video file type only
					files = engine.list(media_types=[MediaType.VIDEO])
					# If torrent metadata is not loaded yet then continue
					if files is None:
						continue
					# Torrent has no video files
					if not files:
						break
						progressBar.close()
					# Select first matching file
					file_id = files[0].index
					file_status = files[0]
				else:
					# If we've got file_id already, get file status
					file_status = engine.file_status(file_id)
					# If torrent metadata is not loaded yet then continue
					
					if not file_status:
						if progressBar.iscanceled(): break
						continue
						#break
				
				if status.state == State.DOWNLOADING:
					# Wait until minimum pre_buffer_bytes downloaded before we resolve URL to XBMC
					if file_status.download >= pre_buffer_bytes:
						ready = True
						break
					#print file_status
					#downloadedSize = status.total_download / 1024 / 1024
					getDownloadRate = status.download_rate / 1024 * 8
					#getUploadRate = status.upload_rate / 1024 * 8
					getSeeds = status.num_seeds
					
					progressBar.update(100*file_status.download/pre_buffer_bytes, xt('Предварительная буферизация: '+str(file_status.download/1024/1024)+" MB"), "Сиды: "+str(getSeeds), "Скорость: "+str(getDownloadRate)[:4]+' Mbit/s')#
					
				elif status.state in [State.FINISHED, State.SEEDING]:
					#progressBar.update(0, 'T2Http', 'We have already downloaded file', "")
					# We have already downloaded file
					ready = True
					break
				
				if progressBar.iscanceled():
					progressBar.update(0)
					progressBar.close()
					break
				# Here you can update pre-buffer progress dialog, for example.
				# Note that State.CHECKING also need waiting until fully finished, so it better to use resume_file option
				# for engine to avoid CHECKING state if possible.
				# ...
			progressBar.update(0)
			progressBar.close()
			if ready:
				# Resolve URL to XBMC
				Player=xPlayer()
				item = xbmcgui.ListItem(path=file_status.url)
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
				if __settings__.getSetting("t2h_play") == '1':
					playlist = xbmc.PlayList (xbmc.PLAYLIST_VIDEO)
					playlist.clear()
					playlist.add(url=file_status.url, listitem=item)
					xbmc.Player().play(playlist)
				xbmc.sleep(3000)
				#xbmc.Player().Play(item)
				xbmc.sleep(3000)
				# Wait until playing finished or abort requested
				while not xbmc.abortRequested and xbmc.Player().isPlaying():
					xbmc.sleep(500)
	except: pass

def play_yatp(url, ind):
	purl ="plugin://plugin.video.yatp/?action=play&torrent="+ urllib.quote_plus(url)+"&file_index="+str(ind)
	item = xbmcgui.ListItem(path=purl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def play_torrenter(url, ind):
	purl ="plugin://plugin.video.torrenter/?action=playSTRM&url="+ urllib.quote_plus(url)+"&file_index="+str(ind)+"&index="+str(ind)
	item = xbmcgui.ListItem(path=purl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def play_elementum(url, ind):
	purl ="plugin://plugin.video.elementum/play?uri="+ urllib.quote_plus(url)+"&index="+str(ind)
	item = xbmcgui.ListItem(path=purl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def play_quasar(url, ind):
	purl = "plugin://plugin.video.quasar/play?uri=" + urllib.quote_plus(url)+"&index="+str(ind)
	item = xbmcgui.ListItem(path=purl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def play_ace_proxy(url, ep=0, id='0'):
	#print url
	#print ep
	if 'magnet' not in url and 'acestream:' not in url: url=t2m(url)
	title=url
	cover=''
	progressBar = xbmcgui.DialogProgress()
	progressBar.create('ACE Stream', 'Запуск')
	try:ACE_start()
	except: pass
	srv=__settings__.getSetting("p2p_serv")#'127.0.0.1'
	prt=__settings__.getSetting("p2p_port")#'6878'
	if 'btih:' in url:
		if '&' not in url: url=url+'&'
		CID=mfind(url+'&', 'btih:', '&')
		as_url='http://'+srv+':'+prt+'/ace/getstream?infohash='+CID+"&format=json&_idx="+str(ep)
	elif 'acestream:' in url:
		CID=url.replace('acestream://','')
		as_url='http://'+srv+':'+prt+'/ace/getstream?id='+CID+"&format=json&_idx="+str(ep)
	else:
		as_url='http://'+srv+':'+prt+'/ace/getstream?url='+url+"&format=json&_idx="+str(ep)
	
	if __settings__.getSetting("p2p_dlnk") == 'true':
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, xbmcgui.ListItem(path=as_url.replace("&format=json", "")))
		return
	
	#print as_url
	if as_url!='':
		json=eval(GET(as_url).replace('null','"null"'))["response"]
		print json
		progressBar.update(0, 'ACE Stream', 'Контент найден', "")
		stat_url=json["stat_url"]
		stop_url=json["command_url"]+'?method=stop'
		purl=json["playback_url"]
		
		__settings__.setSetting("stat_url", stat_url)
		progressBar.update(0, 'ACE Stream', 'Подключение', "")
		while not xbmc.abortRequested:
			xbmc.sleep(300)
			j=eval(GET(stat_url).replace('null','"null"'))["response"]
			if j=={}:
				pass
				progressBar.update(0, 'ACE Stream', 'Ожидание', "")
			else:
				status=j['status']
				if status=='dl': break
				try:
					download=j['downloaded']
					progress=j['total_progress']
					#if progress>90: break
					seeds=j['peers']
					speed=j['speed_down']
					progressBar.update(progress*10, xt('Предварительная буферизация: '+str(download/1024/1024)+" MB"), "Сиды: "+str(seeds), "Скорость: "+str(speed)+' Kbit/s')
				except: pass
			if progressBar.iscanceled():
				progressBar.update(0)
				progressBar.close()
				GET(stop_url)
				return
		
		progressBar.update(0)
		progressBar.close()
		GET(stat_url)
		print purl
		item = xbmcgui.ListItem(path=purl, iconImage=cover, thumbnailImage=cover)
		#item.setInfo('video', inf)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
		#xbmc.Player().play(purl)
		xbmc.sleep(5000)
		
		Player=xPlayer()
		while not xbmc.abortRequested and xbmc.Player().isPlaying():
					xbmc.sleep(500)
		GET(stop_url)
	else:
		showMessage('Кинопоиск','Поток не найден')

def play_xbmctorrent(url, ind):
	purl ="plugin://plugin.video.xbmctorrent/play/"+ urllib.quote_plus(url)+"/"+str(ind)
	item = xbmcgui.ListItem(path=purl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def play_ltorrent(url, ind):
	false=False
	true=True
	post = '{"action":"open_torrent", "url":"'+url+'"}'
	#post = '{"action":"open_torrent", "url":"http://td-soft.narod.ru/suits.torrent"}'
	rec = POST('http://localhost:8888/api', post)
	print rec
	if rec!='':
		info_hash = eval(rec)['info_hash']
		#post = '{"action":"get_file_list"}'
		#print POST('http://localhost:8888/api', post)
		purl = 'http://localhost:8888/play/'+info_hash+'/'+str(ind)+'/'
		#xbmc.Player().play(purl)
		item = xbmcgui.ListItem(path=purl)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def get_item_name(url, ind):
	torrent_data = GET(url)
	if torrent_data != None:
		import bencode
		torrent = bencode.bdecode(torrent_data)
		try:
			L = torrent['info']['files']
			name=L[ind]['path'][-1]
		except:
			name=torrent['info']['name']
		return name
	else:
		return ' '



def get_ace_status():
	stat_url=__settings__.getSetting("stat_url")
	j=eval(GET(stat_url).replace('null','"null"'))["response"]
	if j=={}:
		return '{}'
	else:
		status=j['status'] #if status=='dl': 
		try:
			progress=j['total_progress']
			if progress > 99: return 'Загрузка завершена'
			
			download=j['downloaded']
			seeds=j['peers']
			speed=j['speed_down']
			return "Загружено "+str(download/1024/1024)+" MB ("+str(progress)+" %) \nСиды: "+str(seeds)+" \nСкорость: "+str(speed)+' Kbit/s'
		except:
			return 'err'

def get_ts_status():
	try:
		false=False
		true=True
		null=None
		i=engine_ts.stat()
		seeds=i["ConnectedSeeders"]
		speed=int(i["DownloadSpeed"])/1024
		download=i["LoadedSize"]
		size = int(i['FileStats'][index_ts]['Length'])
		progress= int(float(download) * 100 / size)
		return "Загружено: "+str(download/1024/1024)+" MB ("+str(progress)+" %) \nСиды: "+str(seeds)+" \nСкорость: "+str(speed)+' Kbit/s'
	except:
		return 'err'

def get_t2h_status():
	try:
		from torrent2http import MediaType
		try:
			status   = engine_t2h.status()
			speed    = status.download_rate / 1024 * 8
			seeds    = status.num_seeds
		except:
			speed    = '?????'
			seeds    = '?'
		
		try:    tdownload = status.total_download / 1024 / 1024
		except: tdownload = '???'
		
		try:
			files = engine_t2h.list(media_types=[MediaType.VIDEO])
			file_id = files[0].index
			file_status = engine_t2h.file_status(file_id)
			download = file_status.download / 1024 / 1024
		except:
			download = tdownload
		#
		return "Загружено "+str(download)+" MB \nСиды: "+str(seeds)+" \nСкорость: "+str(speed)[:4]+' Mbit/s'
	except:
		return 'err'

def Add2List(n):
	L2=[]
	try:L=eval(__settings__.getSetting("List"))
	except: L=[]
	if len(L)> 99: L=L[1:]
	
	for i in L:
		if i['title']!=n['title'] and i['url']!=n['url']: L2.append(i)
		elif i['url']==n['url']: n=i# and n['info']=={}:
			#n['title']=i['title']
			#if i['info']!={}: 	n['info']=i['info']
			#else: 				n['info']={'title':i['title']}
	
	L2.append(n)
	__settings__.setSetting("List", repr(L2))

def RemList(url):
	L2=[]
	try:L=eval(__settings__.getSetting("List"))
	except: L=[]
	for i in L:
		if i['url']!=url: L2.append(i)
	__settings__.setSetting("List", repr(L2))
	if __settings__.getSetting("TorrDir") in url and __settings__.getSetting("del_on")=='true': xbmcvfs.delete(url)

def root():
	if __settings__.getSetting("open_on")== 'true': xbmcplugin.addDirectoryItem(handle, sys.argv[0]+'?mode=file', xbmcgui.ListItem('[B][ Открыть файл ][/B]'), True)
	if __settings__.getSetting("dir_on") == 'true': GetDir()
	
	try:L=eval(__settings__.getSetting("List"))
	except: L=[]
	
	if L==[]:
		Ld=[
		['test torrent','http://td-soft.narod.ru/suits.torrent'],
		['test magnet','magnet:?xt=urn:btih:3bf8d2203474bde4189546c8f33e6a65cbabfe62&tr=http://bt.animedia.tv/announce.php&tr=retracker.local/announce'],
		['test CID','acestream://ef9778d589f3d3e90a479318e4078a81ca2bfc5f'],
		]
		for i in Ld:
					listitem = xbmcgui.ListItem(i[0])
					uri = sys.argv[0]+'?mode=open&url='+urllib.quote_plus(i[1])
					xbmcplugin.addDirectoryItem(handle, uri, listitem, True)
	
	L.reverse()
	
	for i in L:
		try:
			try:info = i["info"]
			except: info = {}
			title= i["title"]
			url  = i["url"]
			try:    cover=info['cover']
			except: cover=icon
			try:    fanart=info['fanart']
			except: fanart=''
			Context=[('[B]Удалить[/B]', 'Container.Update("plugin://plugin.video.tam/?mode=rem&url='+urllib.quote_plus(url)+'")'), ('[B]Очистить историю[/B]', 'Container.Update("plugin://plugin.video.tam/?mode=clear")')]
			listitem = xbmcgui.ListItem(title, iconImage=cover, thumbnailImage=cover)
			try:listitem.setInfo(type = "Video", infoLabels = info)
			except: pass
			try: listitem.setArt({ 'poster': cover, 'fanart' : fanart, 'thumb': cover, 'icon': cover})
			except: pass
			listitem.setProperty('fanart_image', fanart)
			uri = sys.argv[0]+'?mode=open&url='+urllib.quote_plus(url)+'&info='+repr(info)
			listitem.addContextMenuItems(Context)
			xbmcplugin.addDirectoryItem(handle, uri, listitem, True)
		except:
			pass
	
	xbmcplugin.endOfDirectory(handle)

def GetDir():
	L1=[]
	try:L=eval(__settings__.getSetting("List"))
	except: L=[]
	if len(L)> 99: L=L[1:]
	
	path = __settings__.getSetting("TorrDir")
	dirs, files = xbmcvfs.listdir(path)
	
	for i in L:
		if path in i['url']:
			if xbmcvfs.exists(i['url']): 	L1.append(i)
		else: 								L1.append(i)
	
	L=L1
	
	for i in files:
		if '.torrent' in i or '.TORRENT' in i:
			title = i.replace('.torrent','').replace('.TORRENT','')
			url = os.path.join(path,i)
			#L1.append([i.replace('.torrent','').replace('.TORRENT',''), ])
			n={'title':title, 'url':url}#, 'info':{}
			
			if n not in L: L.append(n)
	
	__settings__.setSetting("List", repr(L))


def Open(url, info={}, purl='', engine=''):
	try:    cover=info['cover']
	except: cover=icon
	try:    fanart=info['fanart']
	except: fanart=''
	try:    ttl=info['title']
	except: ttl=url
	
	Add2List({'info':info, 'title':ttl, 'url':url})
	
	L=List(url)
	
	if len(L)==1 and __settings__.getSetting("Autoplay")=='true':
			xbmc.executebuiltin('PlayMedia("plugin://plugin.video.tam/?mode=play&url='+urllib.quote_plus(url)+'")')
			xbmcplugin.endOfDirectory(handle, False, False)
			return
	
	ind=0
	for i in L:
		try:name=str(i[0])
		except:name=i[0]
		listitem = xbmcgui.ListItem(name, iconImage=cover, thumbnailImage=cover)
		try: listitem.setInfo(type = "Video", infoLabels = {})#info
		except: pass
		try: listitem.setArt({ 'poster': cover, 'fanart' : fanart, 'thumb': cover, 'icon': cover})
		except: pass
		listitem.setProperty('fanart_image', fanart)
		listitem.setProperty('IsPlayable', 'true')
		Context=[]
		try:
			Context.append(('[B]Настройки ТАМ[/B]', 'Container.Update("plugin://plugin.video.tam/?mode=settings")'))
			if info == {}: info = {'originaltitle': name, 'year':ind}
			if len(L)>1: 
				Context.append(('[B]Сохранить как сериал[/B]', 'Container.Update("plugin://plugin.video.tam/?mode=save_series&url='+urllib.quote_plus(url)+'&info='+urllib.quote_plus(repr(info))+ '&purl=' + urllib.quote_plus(purl)+'")'))
			if len(L)<3: Context.append(('[B]Сохранить как фильм[/B]', 'Container.Update("plugin://plugin.video.tam/?mode=save_movie&url='+urllib.quote_plus(url)+'&info='+urllib.quote_plus(repr(info))+'&ind='+str(ind)+ '&purl=' + urllib.quote_plus(purl)+'")'))
			listitem.addContextMenuItems(Context)
		except: pass
		
		uri = sys.argv[0]+'?mode=play&ind='+str(ind)+'&url='+urllib.quote_plus(url)+'&engine='+urllib.quote_plus(engine)
		
		
		#if __settings__.getSetting("Forceplay")=='true':
		#	uri = sys.argv[0]+'?mode=play18&ind='+str(ind)+'&url='+urllib.quote_plus(url)+'&engine='+urllib.quote_plus(engine)
		#	xbmcplugin.addDirectoryItem(handle, uri, listitem, True)
		#else:
		xbmcplugin.addDirectoryItem(handle, uri, listitem)
		ind+=1
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(handle)
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmc.sleep(300)
	SetViewMode()
	
	

def List(url):
	if 'magnet:' in url: 				return list_magnet(url)
	elif 'acestream:' in url: 			return list_ace(url)
	else: 								return list_bencode(url)

def list_magnet(url):
	cache=magnet_cache(url)
	if cache!=[]: return cache
	if __settings__.getSetting('Engine2') == '0':
				try: 		return list_ts(url)
				except:
					try:    return list_ace(url)
					except: return list_t2h(url)
	if __settings__.getSetting('Engine2') == '1': 
							return [['Начать просмотр', 0]]
	if __settings__.getSetting('Engine2') == '2': 
							try: return list_ace(url)
							except: return [['Ошибка загрузки контента', 0]]
	if __settings__.getSetting('Engine2') == '3': 
							try: return list_ts(url)
							except: return [['Ошибка загрузки контента', 0]]
	if __settings__.getSetting('Engine2') == '4': 
							try: return list_t2h(url)
							except: return [['Ошибка загрузки контента', 0]]

def list_bencode(url):
	torrent_data = GET(url)
	if torrent_data == None: torrent_data = READ(url)
	L2=[]
	if torrent_data != None:
		import bencode
		torrent = bencode.bdecode(torrent_data)
		try:
			L = torrent['info']['files']
			ind=0
			for i in L:
				L2.append([ru(i['path'][-1]), ind])
				ind+=1
		except:
				L2.append([torrent['info']['name'], 0])
	return L2

def list_ts(url):
	import torrserve_stream
	tss = torrserve_stream.Settings()
	ts =  torrserve_stream.Engine(uri=url, host=tss.host, port=tss.port)
	host = 'http://'+tss.host+':'+str(tss.port)
	#print host
	#hash='6378f92db90d9129cade6bc26ce01c27dd1ef034'
	hash=mfind(url+'&', 'btih:', '&')
	hash=ts.hash
	
	false=False
	true=True
	null=None
	xbmc.sleep(1000)
	'''
	for p in range(0,3):
		try:
			L=eval(POST(host+'/torrent/list', hash))
			preload=''
			for i in L:
				if hash in i['Files'][0]['Preload']:
					preload=i['Files'][0]['Preload']
					break
		except:
			xbmc.sleep(1000)
	#for i in L:
	#	print i#['Name']
	print preload
	GET (host+preload)
	L2=eval(POST(host+'/torrent/stat', '{"Hash":"'+hash+'"}'))['FileStats']
	'''
	L2=ts.stat()['FileStats']
	#print L2
	L3=[]
	Lc=[]
	for ind in range(0, len(L2)):
		for i in L2:
			if i['Id'] == ind:
				L3.append([i['Path'],ind])
				Lc.append(i['Path'])
				print str(i['Id'])+' '+i['Path']
	if Lc!=[]: save_cache(url, Lc)
	return L3


def list_t2h(uri):
		#cache=magnet_cache(uri)
		#if cache!=[]: return cache

		from contextlib import closing
		sys.path.append(os.path.join(xbmc.translatePath("special://home/"),"addons","script.module.torrent2http","lib"))
		# Create instance of Engine 
		from torrent2http import State, Engine, MediaType
		engine = Engine(uri)
		files = []
		# Ensure we'll close engine on exception 
		progressBar = xbmcgui.DialogProgress()
		progressBar.create('Torrent2Http', 'Запуск')
		with closing(engine):
		# Start engine 
			engine.start()
			# Wait until files received 
			while not files and not xbmc.abortRequested:
				progressBar.update(0, 'Torrent2Http', 'Примагничиваемся', "")
				
				# Will list only video files in torrent
				files = engine.list(media_types=[MediaType.VIDEO])
				# Check if there is loading torrent error and raise exception 
				engine.check_torrent_error()
				xbmc.sleep(200)
				if progressBar.iscanceled() or xbmc.abortRequested:
							progressBar.update(0)
							progressBar.close()
							return []
				
		progressBar.close()
		
		if files==None: return []
		L=[]
		for i in files:
			L.append(i[0])
		save_cache(uri, L)
		print files
		return files

def list_ace(url):
	print '==list_ace=='
	try:
		engine=get_engine()
		if engine=="0" or engine=="6": ACE_start()
	except: pass
	
	progressBar = xbmcgui.DialogProgress()
	progressBar.create('ACE', 'Примагничиваемся')
	srv=__settings__.getSetting("p2p_serv")
	prt=__settings__.getSetting("p2p_port")
	
	if 'btih:' in url:
		if '&' not in url: url=url+'&'
		CID=mfind(url+'&', 'btih:', '&')
		as_url='http://'+srv+':'+prt+'/ace/getstream?infohash='+CID+"&format=json"
	elif 'acestream:' in url:
		CID=url.replace('acestream://','')
		as_url='http://'+srv+':'+prt+'/ace/getstream?id='+CID+"&format=json"
	else:
		as_url='http://'+srv+':'+prt+'/ace/getstream?url='+url+"&format=json"
	
	m3u=GET(as_url)
	if m3u == None: progressBar.close()#return [['Ошибка загрузки контента', 0]]
	
	if '#EXTINF' not in m3u: 
						progressBar.close()
						if 'failed to load content' in m3u: return [['Ошибка загрузки контента', 0]]
						else: 
							if '&dn=' in url: 
								tmp=url[url.find('&dn=')+4:]
								if '&' in tmp: tmp=tmp[:tmp.find('&')]
								ttl=urllib.unquote_plus(tmp)
								return [[ttl, 0]]
							else: 
								return [['Начать просмотр', 0]]
	L = m3u.splitlines()
	Lt=[]
	Lu=[]
	for e in L:
		if '#EXTINF' in e: Lt.append(e.replace('#EXTINF:-1,',''))
		if 'http:'   in e: Lu.append(e)
	
	LL=[]
	Lc=[]
	for n in range(0, len(Lu)):
		for i in range(0, len(Lu)):
			u=Lu[i]
			ind=int(u[u.rfind('idx=')+4:])
			if ind == n: 
				LL.append ([Lt[i], Lu[i]])
				Lc.append (Lt[i])
			
	progressBar.close()
	if Lc!=[]: save_cache(url, Lc)
	return LL

def list_lt(url):
	import SkorbaLoader
	lt = SkorbaLoader.SkorbaLoader(os.path.join(xbmc.translatePath("special://home/"),"userdata"), url)
	lt.initSession()
	L=lt.getContentList()#getMagnetInfo()
	print L
	
	for e in L:
		Lt.append(e['title'])
		Li.append(e['ind'])
	
	LL=[]
	for n in range(0, len(Li)):
		for i in range(0, len(Li)):
			if Lu[i] == n: LL.append ([Lt[i], Lu[i]])
	return LL


try:
	import magnetdb
	magnetdb.temp_dir=addon.getAddonInfo('path')
except:
	pass

def get_web_cache(uri):
	if __settings__.getSetting('GCache')=='false': return []
	if 'btih:' in uri :
		try:
			hash=uri[uri.find('btih:')+5:uri.find('&')].lower()
			L=magnetdb.get_info(hash)['list']
			return L
		except:
			return []

def add_web_cache(uri, L):
	if __settings__.getSetting('GCache')=='false': return []
	if 'btih:' in uri:
		try:
			hash=uri[uri.find('btih:')+5:uri.find('&')].lower()
			info = {'id': hash, 'list': L}
			magnetdb.add(info)
		except:
			pass

def magnet_cache(uri):
	hash=uri[uri.find('btih:')+5:uri.find('&')]
	path=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'cache', hash))
	if os.path.exists(path)== True:
		fl = open(path, "r")
		cache = eval(fl.read())
		fl.close()
		L=[]
		ind=0
		for i in cache:
			L.append([i,ind])
			ind+=1
		if L!=[]: add_web_cache(uri, cache)
		return L
	else:
		cache=get_web_cache(uri)
		if cache!=[]: save_cache(uri, cache, False)
		else: return []
		ind=0
		L=[]
		for i in cache:
			L.append([i,ind])
			ind+=1
		return L

def save_cache(uri, cache, webc=True):
	print 'save_cache'
	hash=uri[uri.find('btih:')+5:uri.find('&')]
	print hash
	path=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'cache', hash))
	
	fl = open(path, "w")
	fl.write(repr(cache))
	fl.close()
	if webc: add_web_cache(uri, cache)

def ACE_start():
	srv=__settings__.getSetting("p2p_serv")
	prt=__settings__.getSetting("p2p_port")
	lnk='http://'+srv+':'+prt+'/webui/api/service?method=get_version&format=jsonp&callback=mycallback'#getstream?id='+CID
	print lnk
	pDialog = xbmcgui.DialogProgressBG()
	resp=GET(lnk)
	print resp
	if resp != '' and resp != None:
		return False
	else:
		showMessage('ТАМ', 'Запуск Ace Stream')
		pDialog.create('ТАМ', 'Запуск Ace Stream ...')
		pDialog.update(0, message='Запуск Ace Stream ...')
		start_linux()
		start_windows()
		for i in range (0,10):
			pDialog.update(i*10, message='Запуск Ace Stream ...')
			xbmc.sleep(1500)
			resp=GET(lnk)
			if resp != '' and resp != None:
				pDialog.close()
				return True
		pDialog.close()
		return False

def start_linux():
        import subprocess
        try:
            subprocess.Popen(['acestreamengine', '--client-console'])
        except:
            try:
                subprocess.Popen('acestreamengine-client-console')
            except: 
                try:
                    xbmc.executebuiltin('XBMC.StartAndroidActivity("org.acestream.media")')
                    xbmc.sleep(2000)
                    xbmc.executebuiltin('XBMC.StartAndroidActivity("org.xbmc.kodi")')
                except:
                    return False
        return True
    
def start_windows():
        try:
            import _winreg
            try:
                t = _winreg.OpenKey(_winreg.HKEY_CURRENT_USER, r'Software\AceStream')
            except:
                t = _winreg.OpenKey(_winreg.HKEY_CURRENT_USER, r'Software\TorrentStream')
            path = _winreg.QueryValueEx(t, r'EnginePath')[0]
            os.startfile(path)
            return True
        except:
            return False

def SetViewMode():
	n = int(__settings__.getSetting("ListView"))
	if n>0:
		xbmc.executebuiltin("Container.SetViewMode(0)")
		for i in range(1,n):
			xbmc.executebuiltin("Container.NextViewMode")

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

params = get_params()

try:mode = urllib.unquote_plus(params["mode"])
except:mode =""
try:name = urllib.unquote_plus(params["name"])
except:name =""
try:url = urllib.unquote_plus(params["url"])
except:url =""
try:purl = urllib.unquote_plus(params["purl"])
except:purl =""
try:ind = urllib.unquote_plus(params["ind"])
except:ind ="0"
try:engine = urllib.unquote_plus(params["engine"])
except:engine = ""
try:L = eval(urllib.unquote_plus(params["L"]))
except:L =[]
try:ss = eval(urllib.unquote_plus(params["s"]))
except:ss = []
try:ee = eval(urllib.unquote_plus(params["e"]))
except:ee = []
try:nf = int(urllib.unquote_plus(params["nf"]))
except:nf = 0
try:info = eval(urllib.unquote_plus(params["info"]))
except:info = {}
#	try:info = decompress(urllib.unquote_plus(params["info"]))
#	except:info = {}
try:manual = eval(urllib.unquote_plus(params["manual"]))
except:manual = True

if mode==""           : root()
if mode=="open"       : Open(url, info, purl, engine)
if mode=="play"       : play(url, int(ind))
if mode=="open_strm"  : open_strm(url, int(ind), purl, name)
if mode=="save_movie" : save_strm(url, int(ind), purl, info)
if mode=="save_series": save_series(url, info, purl)
if mode=="save"       : save(url, int(ind), purl, info)
if mode=="settings"   : __settings__.openSettings()
if mode=="rem"        : RemList(url)
if mode=="clear"      : __settings__.setSetting('List','[]')
if mode=="run"        : xbmc.executebuiltin('ActivateWindow(10025,"'+purl+'", return)')
if mode=="file"       : 
	f=open_file()
	if f!={}: 
		if __settings__.getSetting("OpenMagnet")=='true' :
			Open(f['magnet'], {'title':f['title']})
		else:
			engine=get_engine()
			if   engine=="0": file=f2u(f['file'])
			elif engine=="1": file=f2u(f['file'])
			elif engine=="2": file=f2u(f['file'])
			elif engine=="3": file=f2u(f['file'])
			elif engine=="4": file=f['file']
			elif engine=="5": file=f['file']
			elif engine=="6": file=f2u(f['file'])
			elif engine=="7": file=f['file']
			elif engine=="8": file=f['file']
			#file='file:///'+f['file'].replace('\\','/')
			#file=f['file']
			Open(file, {'title':f['title']})


#open_strm(url, ind, purl, info)