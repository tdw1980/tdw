# -*- coding: utf-8 -*-
import sys
import json
import socket
import threading
PY2 = sys.version_info.major == 2
if PY2:
       from urllib2 import HTTPError, URLError, HTTPRedirectHandler, Request, urlopen, HTTPHandler, build_opener
       from urllib import urlencode
else:
       from urllib.parse import urlencode
       from urllib.error import HTTPError, URLError
       from urllib.request import HTTPRedirectHandler, Request, urlopen, HTTPHandler, build_opener


LT2HTTP_HOST = "http://127.0.0.1:65225"

def Init():
    try:
        import xbmcaddon
        global LT2HTTP_HOST
        addon = xbmcaddon.Addon()
        LT2HTTP_HOST = "http://"+addon.getSetting("lt_serv")+':'+addon.getSetting("lt_port")
    except: pass

Init()

class closing(object):
    def __init__(self, thing):
        self.thing = thing

    def __enter__(self):
        return self.thing

    def __exit__(self, *exc_info):
        self.thing.close()


class NoRedirectHandler(HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        import urllib
        infourl = urllib.addinfourl(fp, headers, headers["Location"])
        infourl.status = code
        infourl.code = code
        return infourl

    http_error_300 = http_error_302
    http_error_301 = http_error_302
    http_error_303 = http_error_302
    http_error_307 = http_error_302


def client(url, post_data=None, get_data=None, raw=False, host=None, ljs=True):
    socket.setdefaulttimeout(30)
    if get_data:
        url += '?' + urlencode(get_data)
    if post_data and raw:
        post_data = post_data
    elif post_data:
        try:
            post_data = json.dumps(post_data)
            if not PY2: post_data = post_data.encode('utf8')
        except:
            post_data = {"": ""}
    if host:
        url = host + url
    else:
        url = LT2HTTP_HOST+url
    req = Request(url, post_data)
    req.add_header('Content-Type', 'application/json')
    req.add_header('Accept-Charset', 'utf-8')
    req.add_header('User-Agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:21.0) Gecko/20100101 Firefox/21.0')

    try:
        with closing(urlopen(req)) as response:
            payload = response.read()

            try:
                if payload and ljs:
                    return json.loads(payload.decode('utf-8', 'replace'))
                else:
                    return payload
            except:
                return payload
    except HTTPError as e:
        print(e)
        print(e.readlines())
        print(e.code)
        print(e.reason)
        print(e.args)
        return None
    except URLError as e:
        print(e)
        print(e.args)
        print(e.reason)
        return None
    except Exception as e:
        print(e)
        return None

class MyHandler(HTTPHandler):
    def http_response(self, req, response):
        return response


def touch(url):
    o = build_opener(MyHandler())
    t = threading.Thread(target=o.open, args=(url,))
    t.start()


def addTorrent(uri):
    return client('/service/add/uri', get_data={'uri': uri})

def torrentsList():
    return client('/torrents')

def filesList(hash):
    return client('/torrents/'+str(hash)+'/files')

def removeTorrent(hash):
    return client('/torrents/'+str(hash)+'/remove')

def statusTorrent(hash):
    return client('/torrents/'+str(hash)+'/status')

def getStreamUri(hash, id):
    for i in filesList(hash):
       if i['id'] == int(id): return i['stream']
    return None

if __name__ == "__main__" :

    print('test!')

    print(client('/info'))

    t = addTorrent('http://rutor.lib/download/825464')
#    t = addTorrent('magnet:?xt=urn:btih:')

    print(t)

    print(torrentsList())

    if t:
          print(filesList(t['hash']))
          print(getStreamUri(t['hash'], 0))
          print(statusTorrent(t['hash']))

    import time
    time.sleep(2)

    for t in torrentsList():
         print(removeTorrent(t['hash']))
