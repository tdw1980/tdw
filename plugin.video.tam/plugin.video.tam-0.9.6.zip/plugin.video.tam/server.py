# coding: utf-8
# Module: server
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

#from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer
import threading, SocketServer, BaseHTTPServer
#quit_event = threading.Event()


import sys, os
import xbmc, xbmcgui, xbmcaddon
import time
import urllib2, urllib
import base64
#import socket

__settings__ = xbmcaddon.Addon(id='plugin.video.tam')
port = 8095 #int(__settings__.getSetting("serv_port"))

addon = xbmcaddon.Addon(id='plugin.video.tam')


# - ====================================== antizapret ====================================================
import cookielib
sid_file = os.path.join(xbmc.translatePath('special://temp/'), 'servtam.sid')
cj = cookielib.FileCookieJar(sid_file) 
hr  = urllib2.HTTPCookieProcessor(cj) 

def GETvpn():
	import httplib
	conn = httplib.HTTPConnection("antizapret.prostovpn.org")
	conn.request("GET", "/proxy.pac", headers={"User-Agent": 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)'})
	r1 = conn.getresponse()
	data = r1.read()
	conn.close()
	return data

def proxy_update():
	try:
		print 'proxy_update'
		#url='https://antizapret.prostovpn.org/proxy.pac'
		pac=GETvpn()#url)
		prx=pac[pac.find('PROXY ')+6:pac.find('; DIRECT')]
		__settings__.setSetting("proxy_serv", prx)
		__settings__.setSetting("proxy_time", str(time.time()))
	except: 
		print 'except get proxy'

try:
		try:pt=float(__settings__.getSetting("proxy_time"))
		except:pt=0
		print pt
		if time.time()-pt > 36000: proxy_update()
		prx=__settings__.getSetting("proxy_serv")
		print prx
		if prx.find('http')<0 : prx="http://"+prx
		proxy_support = urllib2.ProxyHandler({"http" : prx})
		opener = urllib2.build_opener(proxy_support, hr)
		urllib2.install_opener(opener)
		print 'antizapret ok'
except:
		print 'except set proxy'
		opener = urllib2.build_opener(hr) 
		urllib2.install_opener(opener)

AL = ["http://acg.rip:6699/announce","http://open.acgnxtracker.com:80/announce","http://open.acgtracker.com:1096/announce","http://opentracker.i2p.rocks:6969/announce","http://pow7.com:80/announce","http://tracker.gbitt.info:80/announce","http://tracker.internetwarriors.net:1337/announce","http://tracker.kamigami.org:2710/announce","http://tracker.lelux.fi:80/announce","http://tracker.nyap2p.com:8080/announce","http://tracker.torrentyorg.pl:80/announce","http://tracker.yoshi210.com:6969/announce","http://tracker01.loveapp.com:6789/announce","http://tracker1.itzmx.com:8080/announce","http://tracker2.itzmx.com:6961/announce","http://tracker3.itzmx.com:6961/announce","http://tracker4.itzmx.com:2710/announce","http://vps02.net.orel.ru:80/announce","http://www.loushao.net:8080/announce","http://www.proxmox.com:6969/announce","https://tracker.gbitt.info:443/announce","https://tracker.lelux.fi:443/announce","https://tracker.parrotlinux.org:443/announce","udp://bt2.54new.com:8080/announce","udp://qg.lorzl.gq:2710/announce","udp://tr.bangumi.moe:6969/announce","udp://tracker.kamigami.org:2710/announce","udp://tracker.swateam.org.uk:2710/announce","udp://tracker2.itzmx.com:6961/announce","udp://tracker4.itzmx.com:2710/announce","http://h4.trakx.nibba.trade:80/announce","http://mail2.zelenaya.net:80/announce","http://retracker.sevstar.net:2710/announce","http://t.nyaatracker.com:80/announce","http://tracker.bt4g.com:2095/announce","http://tracker.bz:80/announce","http://tracker.corpscorp.online:80/announce","http://tracker.opentrackr.org:1337/announce","http://tracker.tvunderground.org.ru:3218/announce","https://tracker.nanoha.org:443/announce","https://tracker.opentracker.se:443/announce","https://zqzx.xyz:443/announce","udp://bt.okmp3.ru:2710/announce","udp://bt1.archive.org:6969/announce","udp://bt2.archive.org:6969/announce","udp://chihaya.toss.li:9696/announce","udp://open.nyap2p.com:6969/announce","udp://opentracker.i2p.rocks:6969/announce","udp://retracker.akado-ural.ru:80/announce","udp://retracker.netbynet.ru:2710/announce","udp://tracker-udp.gbitt.info:80/announce","udp://tracker.dler.org:6969/announce","udp://tracker.ds.is:6969/announce","udp://tracker.filemail.com:6969/announce","udp://tracker.iamhansen.xyz:2000/announce","udp://tracker.lelux.fi:6969/announce","udp://tracker.nextrp.ru:6969/announce","udp://tracker.nyaa.uk:6969/announce","udp://tracker.sbsub.com:2710/announce","udp://tracker.tvunderground.org.ru:3218/announce","udp://tracker.uw0.xyz:6969/announce","udp://tracker.yoshi210.com:6969/announce","udp://tracker.zum.bi:6969/announce","udp://tracker3.itzmx.com:6961/announce","udp://xxxtor.com:2710/announce","udp://zephir.monocul.us:6969/announce","http://explodie.org:6969/announce","udp://explodie.org:6969/announce","udp://opentor.org:2710/announce","udp://valakas.rollo.dnsabr.com:2710/announce","udp://open.demonii.si:1337/announce","udp://ipv4.tracker.harry.lu:80/announce","udp://retracker.lanta-net.ru:2710/announce","udp://tracker.cyberia.is:6969/announce","udp://tracker.moeking.me:6969/announce","udp://tracker.torrent.eu.org:451/announce","udp://denis.stalker.upeer.me:6969/announce","udp://open.stealth.si:80/announce","udp://tracker.tiny-vps.com:6969/announce","udp://exodus.desync.com:6969/announce","udp://tracker.openbittorrent.com:80/announce","udp://9.rarbg.me:2710/announce","udp://9.rarbg.to:2710/announce","udp://p4p.arenabg.com:1337/announce","udp://tracker.internetwarriors.net:1337/announce","udp://tracker.opentrackr.org:1337/announce","udp://tracker.leechers-paradise.org:6969/announce","udp://tracker.coppersurfer.tk:6969/announce"]


def editor(url):
	print url
	import bencode
	r = GET(url)
	metainfo = bencode.bdecode(r)
	#print metainfo
	metainfo['announce']='http://127.0.0.1:8095/proxy/'+metainfo['announce']
	#announce=''
	announce_list=[]
	if 'announce-list' in metainfo.keys():
		try:
			for ans in metainfo['announce-list']:
				announce_list.append(['http://127.0.0.1:8095/proxy/'+ans[0]])
				announce_list.append([ans[0]])
				#announce=announce+'&tr='+urllib.quote_plus('http://127.0.0.1:8095/proxy/'+ans[0])
		except: pass
	
	try:
		for i in AL:
			announce_list.append([i])
	except: pass
		
	metainfo['announce-list'] = announce_list
	#print '=============='
	#print metainfo
	tr=bencode.encode(metainfo)
	#print '=============='
	#print len(tr)
	#print '=============='
	return tr

print('----- Starting TAM_serv -----')
start_trigger = True

# =========================== Базовые функции ================================
def GET(url):
	if __settings__.getSetting("unlock")=='2':
		import azpt
		return azpt.GET(url)
	else:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link

def POST(target, post=None, referer=''):
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36 OPR/46.0.2597.39')
		req.add_header('Accept', 'application/json, text/javascript, */*; q=0.01')
		req.add_header('Accept-Language', 'ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4')
		req.add_header('Referer', referer)
		req.add_header('x-requested-with', 'XMLHttpRequest')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		print e
		return ''

def xt(x):return xbmc.translatePath(x)


def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))


def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2
	

#==================================================================



from threading import Thread
class MyThread(Thread):
	def __init__(self, param):
		Thread.__init__(self)
		self.param = param
	
	def run(self):
		update_Lt(pztv.get_stream(self.param))

def create_thread(param):
		my_thread = MyThread(param)
		my_thread.start()


#===================================================================

def get_on(addres):
		print addres
		data='ERR 404'
		if 'torrent/' in addres:
			try:
				id=addres[addres.find('torrent/')+8:]
				print urllib.unquote_plus(id)
				url=base64.b64decode(urllib.unquote_plus(id))
				print url
				data = GET(url)
			except:
				pass
		if 'proxy/' in addres:
			url=addres[addres.find('proxy/')+6:]
			print url
			data = GET(url)
			#print data
		if 'unlocker/' in addres:
			url=addres[addres.find('unlocker/')+9:]
			data = editor(url)
		return data

# ================================ server =====================================



class HttpProcessor(BaseHTTPServer.BaseHTTPRequestHandler):
	
	def do_POST(self):
		print 'POST'
		print self.path
		self.data_string = self.rfile.read(int(self.headers['Content-Length']))
		print self.data_string
		
		addres = self.path
		data = ''
		post = None
		if 'proxy/' in self.path:
			url=addres[addres.find('proxy/')+6:]
			post = self.data_string
			data = POST(url, post)
		self.send_response(200)
		self.end_headers()
		self.wfile.write(data)
	
	def do_GET(self):
		data=get_on(self.path)
		
		if data == 'ERR 404':
			self.send_response(404)
		elif data[:4]=='http': 
			self.send_response(302)
			self.send_header('Location', data)
			self.send_header('content-type','application/octet-stream')
		else:
			self.send_response(200)
			self.send_header('content-type','application/octet-stream')
		
		self.end_headers()
		self.wfile.write(data)

class MyThreadingHTTPServer(SocketServer.ThreadingMixIn, BaseHTTPServer.HTTPServer):
	pass

errors = False
try:
	serv = MyThreadingHTTPServer(("localhost",port), HttpProcessor)
	threading.Thread(target=serv.serve_forever).start()
except:
	errors = True
	
if errors:
	print('----- TAM_serv ERROR -----')
else:
	print('----- TAM_serv OK -----')
	while not xbmc.abortRequested:
				xbmc.sleep(4000)
				
print('----- TAM_serv shutdown -----')
try:serv.shutdown()
except:pass

print('----- TAM_serv stopped -----')

