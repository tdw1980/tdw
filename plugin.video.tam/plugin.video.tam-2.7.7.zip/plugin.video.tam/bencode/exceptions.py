"""bencode.py - encoder + decode exceptions."""


class BencodeDecodeError(Exception):
    """Bencode decode error."""

    pass
