# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, urllib, sys, urllib2, cookielib

PLUGIN_NAME   = 'newstudio.tv'
handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.newstudio.tv')
__settings__ = xbmcaddon.Addon(id='plugin.video.newstudio.tv')

Pdir = addon.getAddonInfo('path')
icon = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'icon.png'))
xbmcplugin.setContent(int(sys.argv[1]), 'movies')
xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')


def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

fcookies = os.path.join(addon.getAddonInfo('path'), r'cookies.txt')
cj = cookielib.FileCookieJar(fcookies)
hr  = urllib2.HTTPCookieProcessor(cj)
opener = urllib2.build_opener(hr)
urllib2.install_opener(opener)

def debug(s):
	fl = open(os.path.join(ru(addon.getAddonInfo('path')),"test.txt"), "w")
	fl.write(s)
	fl.close()

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		#sn=http[s:]
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def lower(s):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.lower().encode('utf-8')
	return s

def inputbox(t):
	skbd = xbmc.Keyboard(t, 'Название:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return t


def play(url, ind=0, name=''):
	#print url
	engine=__settings__.getSetting("Engine")
	if engine=="0": play_ace (url, ind, name)
	if engine=="1": play_t2h (url, ind, __settings__.getSetting("DownloadDirectory"))
	if engine=="2": play_yatp(url, ind)
	if engine=="3": play_torrenter(url, ind)
	if engine=="4": play_tam(url, ind)

def play_tam(url, ind=0):
	purl ="plugin://plugin.video.tam/?mode=play&url="+ urllib.quote_plus(url)+"&ind="+str(ind)
	item = xbmcgui.ListItem(path=purl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def play_ace(torr_link, ind=0, title=''):
	try:
		#title=get_item_name(torr_link, ind)
		from TSCore import TSengine as tsengine
		TSplayer=tsengine()
		out=TSplayer.load_torrent(torr_link,'TORRENT')
		#print out
		if out=='Ok': TSplayer.play_url_ind(int(ind),title, icon, icon, True)
		TSplayer.end()
		return out
	except: 
		return '0'

def play_t2h(uri, file_id=0, DDir=""):
	uri='file:///'+GETtorr(uri).replace('\\','/')
	try:
		sys.path.append(os.path.join(xbmc.translatePath("special://home/"),"addons","script.module.torrent2http","lib"))
		from torrent2http import State, Engine, MediaType
		progressBar = xbmcgui.DialogProgress()
		from contextlib import closing
		if DDir=="": DDir=os.path.join(xbmc.translatePath("special://home/"),"userdata")
		progressBar.create('Torrent2Http', 'Запуск')
		# XBMC addon handle
		# handle = ...
		# Playable list item
		# listitem = ...
		# We can know file_id of needed video file on this step, if no, we'll try to detect one.
		# file_id = None
		# Flag will set to True when engine is ready to resolve URL to XBMC
		ready = False
		# Set pre-buffer size to 15Mb. This is a size of file that need to be downloaded before we resolve URL to XMBC 
		pre_buffer_bytes = 15*1024*1024
		engine = Engine(uri, download_path=DDir)
		with closing(engine):
			# Start engine and instruct torrent2http to begin download first file, 
			# so it can start searching and connecting to peers  
			engine.start(file_id)
			progressBar.update(0, 'Torrent2Http', 'Загрузка торрента', "")
			while not xbmc.abortRequested and not ready:
				xbmc.sleep(500)
				status = engine.status()
				# Check if there is loading torrent error and raise exception 
				engine.check_torrent_error(status)
				# Trying to detect file_id
				if file_id is None:
					# Get torrent files list, filtered by video file type only
					files = engine.list(media_types=[MediaType.VIDEO])
					# If torrent metadata is not loaded yet then continue
					if files is None:
						continue
					# Torrent has no video files
					if not files:
						break
						progressBar.close()
					# Select first matching file                    
					file_id = files[0].index
					file_status = files[0]
				else:
					# If we've got file_id already, get file status
					file_status = engine.file_status(file_id)
					# If torrent metadata is not loaded yet then continue
					if not file_status:
						continue
				if status.state == State.DOWNLOADING:
					# Wait until minimum pre_buffer_bytes downloaded before we resolve URL to XBMC
					if file_status.download >= pre_buffer_bytes:
						ready = True
						break
					#print file_status
					progressBar.update(100*file_status.download/pre_buffer_bytes, 'Torrent2Http', xt('Предварительная буферизация: '+str(file_status.download/1024/1024)+" MB"), "")
					
				elif status.state in [State.FINISHED, State.SEEDING]:
					#progressBar.update(0, 'T2Http', 'We have already downloaded file', "")
					# We have already downloaded file
					ready = True
					break
				
				if progressBar.iscanceled():
					progressBar.update(0)
					progressBar.close()
					break
				# Here you can update pre-buffer progress dialog, for example.
				# Note that State.CHECKING also need waiting until fully finished, so it better to use resume_file option
				# for engine to avoid CHECKING state if possible.
				# ...
			progressBar.update(0)
			progressBar.close()
			if ready:
				# Resolve URL to XBMC
				item = xbmcgui.ListItem(path=file_status.url)
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
				xbmc.sleep(3000)
				# Wait until playing finished or abort requested
				while not xbmc.abortRequested and xbmc.Player().isPlaying():
					xbmc.sleep(500)
	except: pass


def play_yatp(url, ind):
	purl ="plugin://plugin.video.yatp/?action=play&torrent="+ urllib.quote_plus(url)+"&file_index="+str(ind)
	item = xbmcgui.ListItem(path=purl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def play_torrenter(url, ind):
	purl ="plugin://plugin.video.torrenter/?action=playSTRM&url="+ urllib.quote_plus(url)+"&file_index="+str(ind)
	item = xbmcgui.ListItem(path=purl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def favor(id=''):
	try:L=eval(__settings__.getSetting("FAV"))
	except: L=[]
	if id == "":
		return L
	else:
		if id in L:
			L.remove(id)
		else:
			L.append(id)
		__settings__.setSetting("FAV", repr(L))
		return L

def muf(r, id=''):
	if id=='':id=r
	L=favor()
	if id in L: r='[COLOR ffffffff]'+r+'[/COLOR]'
	return(r)

def add_item (name, mode="", path = Pdir, ind="0", cover=None, funart=None, id='0'):
	#print name
	#print path
	if cover==None:	listitem = xbmcgui.ListItem("[B]"+muf(name)+"[/B]")
	else:			listitem = xbmcgui.ListItem("[B]"+muf(name)+"[/B]", iconImage=cover, thumbnailImage=cover)
	if funart==None: funart=icon
	listitem.setProperty('fanart_image', funart)
	uri = sys.argv[0] + '?mode='+mode
	uri += '&url='  + urllib.quote_plus(path.encode('utf-8'))
	uri += '&name='  + urllib.quote_plus(xt(name))
	uri += '&ind='  + urllib.quote_plus(ind)
	if cover!=None:uri += '&cover='  + urllib.quote_plus(cover)
	if funart!=None and funart!="":uri += '&funart='  + urllib.quote_plus(funart)
	
	if mode=="play": 
		fld=False
		#listitem.setInfo(type = "Video", infoLabels = {})
		listitem.setProperty('IsPlayable', 'true')
	else: 
		fld=True
	
	if '/ ' in name: lf_name=name[name.find('/ ')+2:]
	else: lf_name=name
	if ' (' in name: tc_name=lf_name[lf_name.find(' (')+2:]
	else: tc_name=lf_name

	if id=='0':
		lf_url='plugin://plugin.video.newstudio.tv/?mode=GetTC&name='+urllib.quote_plus(lf_name)
	else: 
		lf_url='plugin://plugin.video.newstudio.tv/?mode=GetTC&name='+urllib.quote_plus(id)
	
	if mode=="play": listitem.addContextMenuItems([('[B]Отслеживать в ТС[/B]', 'Container.Update("plugin://plugin.video.torrent.checker/?mode=add&url='+urllib.quote_plus(lf_url)+'&name='+lf_name+'&manual=0")'), ('[B]Фавориты[/B]', 'Container.Update("plugin://plugin.video.newstudio.tv/?mode=FAV&name='+lf_name+'")')])
	if mode=="open": listitem.addContextMenuItems([
			('[B]Отслеживать в ТС[/B]', 'Container.Update("plugin://plugin.video.torrent.checker/?mode=add&manual=0&url='+urllib.quote_plus(path)+'&name='+urllib.quote_plus(tc_name)+'")'),
			('[B]Сохранить сериал[/B]', 'Container.Update("plugin://plugin.video.torrent.checker/?mode=save_episodes_api&url='+urllib.quote_plus(path)+'&name='+urllib.quote_plus(tc_name)+ '&info={}")'), ('[B]Фавориты[/B]', 'Container.Update("plugin://plugin.video.newstudio.tv/?mode=FAV&name='+lf_name+'")')])
	xbmcplugin.addDirectoryItem(handle, uri, listitem, fld)

def getURL(url,Referer = 'http://newstudio.tv/'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def GETtorr(target):
	Login()
	try:
			req = urllib2.Request(url = target)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			fl = open(os.path.join( addon.getAddonInfo('path'),'tmp.torrent'), "wb")
			fl.write(resp.read())
			fl.close()
			return os.path.join( addon.getAddonInfo('path'),'tmp.torrent')
			#return resp.read()
	except Exception, e:
			print 'HTTP ERROR ' + str(e)
			return None

def GETtorr2(target):
	Login()
	try:
			req = urllib2.Request(url = target)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			#req.add_header('Accept', 'application/octet-stream')
			#req.add_header('Referer', 'http://hdpicture.ru')
			#req.add_header('Content-Transfer-Encoding', 'binary')
			resp = urllib2.urlopen(req)
			#resp = urllib2.urlopen(target)
			#debug (resp.read())
			return resp.read()
	except Exception, e:
			print 'HTTP ERROR ' + str(e)
			return None

def get_HTML(url, post = None, ref = None, get_redirect = False):
    import urlparse
    if url.find('http')<0 :
        if CT=="0": url='http:'+url
        else: url='https:'+url
    #url="http://translate.googleusercontent.com/translate_c?u="+url
    request = urllib2.Request(url, post)

    host = urlparse.urlsplit(url).hostname
    if ref==None:
        try:
           ref='http://'+host
        except:
            ref='localhost'

    request.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
    request.add_header('Host',   host)
    request.add_header('Accept', 'text/html, application/xhtml+xml, */*')
    request.add_header('Accept-Language', 'ru-RU')
    request.add_header('Referer',             ref)
    request.add_header('Content-Type','application/x-www-form-urlencoded')

    try:
        f = urllib2.urlopen(request)
    except IOError, e:
        if hasattr(e, 'reason'):
           print('We failed to reach a server.')
        elif hasattr(e, 'code'):
           print('The server couldn\'t fulfill the request.')
        return 'We failed to reach a server.'

    if get_redirect == True:
        html = f.geturl()
    else:
        html = f.read()

    return html


login = __settings__.getSetting("login")
passw = __settings__.getSetting("password")

def Login():
	url1 = 'http://newstudio.tv/login.php'
	if login == '' or passw == '': return False
	
	values = {
				'login_username'     : login,
				'login_password'  : passw,
				'autologin'    : 'on',
				'login'    : 'Вход'
		}
	post = urllib.urlencode(values)
	html = get_HTML(url1, post, 'http://newstudio.tv/')
	return True

def get_rss():
	url='http://newstudio.tv/'
	rss=getURL(url)
	return rss

def pars_rss(rss):
	L=mfindal(rss, '<div class="torrent">', '</div>'+chr(10)+'</div>')
	L2=[]
	for i in L:
		try:
			title2=mfindal(i, ') / ', ' (20')[0][4:]
			title=mfindal(i, '<div class="tdesc">', ' (20')[0][25:].replace('&#039;','')
			#description=mfindal(i, '<description>', '</description>')[0][13:]
			try: cover='http://newstudio.tv'+mfindal(i, '/images/posters', '" alt="pic" class="img-tracker"')[0]
			except: cover=""
			#content=mfindal(i, '<div class="pull-right taright">', '<div class="ttitle">')[0]
			Lt=mfindal(i, '/download.php?id=', '</span></a>')
			n=0
			for t in Lt:
				n+=1
				try:
					url='http://newstudio.tv'+mfindal(t, '/download.php?id=', '"><span class=')[0]
					qual=t[t.find('link">Скачать '):]
					dict={'title':title, 'title2':title2, 'url':url, 'cover':cover, 'qual':qual}
					if n==1 or __settings__.getSetting("Qual")=="1":
						L2.append(dict)
				except: pass
		except: pass
	return L2

def GetTC2(ntc):
	rss=get_rss()
	L=pars_rss(rss)
	for i in L:
		name  = i['title']
		url   = i['url']
		if login !="": url = url +'&user='+login+'&pass='+passw
		cover = i['cover']
		qual  = i['qual']
		if name.find(ntc)>0:
			s=name.find(" (")
			e=name.find(") ")
			nm=ntc+name[s:e]+".strm"
			nm=nm.replace(" (Сезон ",".s")
			nm=nm.replace(", Серия ","e")
			for n in range(1,10):
				nm=nm.replace("s"+str(n)+"e","s0"+str(n)+"e")
				nm=nm.replace("e"+str(n)+".","e0"+str(n)+".")
				
			sys.path.append(os.path.join(xbmc.translatePath("special://home/"),"addons","plugin.video.torrent.checker"))
			import updatetc
			LD=updatetc.file_list(ntc)
			if  nm not in LD:
				if __settings__.getSetting("Qual")=="1":
					if   qual.find("720p")>0: updatetc.save_strm(ntc, nm, url, 0)
				else:
					updatetc.save_strm(ntc, nm, url, 0)
	#xbmc.executebuiltin('UpdateLibrary("video")')


def GetTC(f):
	try:
		tmp=int(f)
		cover='http://newstudio.tv/images/posters/'+f+'.jpg'
		#cover=''
		L2=[]
		for s in range (0, 5):
			st=str(s*50)
			url='http://newstudio.tv/viewforum.php?f='+f+'&start='+st
			#print url
			Login()
			html=getURL(url)#get_HTML(url)
			#debug (html)
			#t=html[html.find('viewtopic.php?t=')+16:html.find('" class="tor')]
			#if cover=='': cover=get_cover(t)
			ss='<div class="span9">'
			es='<div class="row-fluid" style="font-weight:bold;">'
			L=mfindal(html, ss, es)
			for i in L:
				try:
					if 'alt="Перейти"' not in i:
						L1=i.splitlines()
						turl = ''
						for j in L1:
							if 'download.php' in j: 
								turl = 'http://newstudio.tv'+j[j.find('<a href=".')+10:j.find('" class="small"')]
								size = j[j.find('none">')+6:j.find('</a>')]
							if 'viewtopic.php?t' in j:
								title = j[j.find('"><b>')+5:j.find('</b></a>')].replace('<wbr>','')
						if turl !='':
							if turl in L2:
								#print turl
								return
							else: L2.append(turl)
							
							#print title
							#print turl
							ntc=title[title.find(' / ')+3:title.find(' (2')]
							s=title.find(" (")
							e=title.find(") ")
							nm=ntc+title[s:e]+".strm"
							nm=nm.replace(" (Сезон ",".s")
							nm=nm.replace(", Серия ","e")
							for n in range(1,10):
								nm=nm.replace("s"+str(n)+"e","s0"+str(n)+"e")
								nm=nm.replace("e"+str(n)+".","e0"+str(n)+".")
							
							add_item (title, 'play', turl, str(0),cover)
							sys.path.append(os.path.join(xbmc.translatePath("special://home/"),"addons","plugin.video.torrent.checker"))
							import updatetc
							LD=updatetc.file_list(ntc)
							if  nm not in LD:
								#print turl
								if __settings__.getSetting("Qual")=="1":
									if   qual.find("720p")>0: updatetc.save_strm(ntc, nm, turl, 0)
								else:
									updatetc.save_strm(ntc, nm, turl, 0)
				except:
					pass
				#print i
	except:
		GetTC2(f)


def root():
	Login()
	add_item ('Сериалы', "serials", "0", "0", icon)
	rss=get_rss()
	L=pars_rss(rss)
	ind=0
	for i in L:
		name  = i['title']
		url   = i['url']
		cover = i['cover']
		qual  = i['qual']
		
		if   qual.find("720p")>0: qual="[COLOR FFA900EF][ 720p ] [/COLOR]"
		elif qual.find("480p")>0: qual="[COLOR FFFF0090][ 480p ] [/COLOR]"
		elif qual.find("400p")>0: qual="[COLOR FFFF0090][ 400p ] [/COLOR]"
		elif qual.find("1080p")>0:qual="[COLOR FF50FF50][1080p] [/COLOR]"
		else: qual="[ "+qual+" ] "
		if 'Серия' in name: add_item (qual+name, 'play', url, str(0),cover)
		else:               add_item (qual+name, 'open', url, str(0),cover)

		ind+=1
	#viewforum('344')
	xbmcplugin.endOfDirectory(handle)



def viewforum(f):
	cover='http://newstudio.tv/images/posters/'+f+'.jpg'
	#cover=''
	L2=[]
	for s in range (0, 5):
		st=str(s*50)
		url='http://newstudio.tv/viewforum.php?f='+f+'&start='+st
		#print url
		Login()
		#print url
		html=getURL(url)#get_HTML(url)
		#debug (html)
		#t=html[html.find('viewtopic.php?t=')+16:html.find('" class="tor')]
		#if cover=='': cover=get_cover(t)
		ss='<div class="span9">'
		es='<div class="row-fluid" style="font-weight:bold;">'
		L=mfindal(html, ss, es)
		for i in L:
			try:
				if 'alt="Перейти"' not in i:
					L1=i.splitlines()
					turl = ''
					for j in L1:
						if 'download.php' in j: 
							turl = 'http://newstudio.tv'+j[j.find('<a href=".')+10:j.find('" class="small"')]
							size = j[j.find('none">')+6:j.find('</a>')]
						if 'viewtopic.php?t' in j:
							title = j[j.find('"><b>')+5:j.find('</b></a>')].replace('<wbr>','')
					if turl !='':
						if turl in L2:
							#print turl
							return
						else: L2.append(turl)
						
						#print title
						#print turl
						if 'Серия' in name: add_item (title, 'play', turl, str(0),cover, None, f)
						else:               add_item (title, 'open', turl, str(0),cover, None, f)
			except:
				pass
			#print i

def OpenTorrent(url):
	print 'OpenTorrent'
	torrent_data = GETtorr2(url)
	#print torrent_data
	if torrent_data != None:
		import bencode
		try:torrent = bencode.bdecode(torrent_data)
		except: return
		cover = icon
		try:
			L = torrent['info']['files']
			ind=0
			for i in L:
				name=ru(i['path'][-1])
				#size=i['length']
				listitem = xbmcgui.ListItem(name, iconImage=cover, thumbnailImage=cover)
				listitem.setProperty('IsPlayable', 'true')
				uri = sys.argv[0]+'?mode=play&ind='+str(ind)+'&url='+urllib.quote_plus(url)+'&name='+urllib.quote_plus(name)
				xbmcplugin.addDirectoryItem(handle, uri, listitem)
				ind+=1
		except:
				ind=0
				name=torrent['info']['name']
				listitem = xbmcgui.ListItem(name, iconImage=cover, thumbnailImage=cover)
				listitem.setProperty('IsPlayable', 'true')
				uri =sys.argv[0]+'?mode=play&ind='+str(ind)+'&url='+urllib.quote_plus(url)+'&name='+urllib.quote_plus(name)
				xbmcplugin.addDirectoryItem(handle, uri, listitem)
	xbmcplugin.endOfDirectory(handle)

def get_cover(t):
	url='http://newstudio.tv/viewtopic.php?t='+t
	#print url
	html=getURL(url)
	cover=html[html.find('postImg" title="')+16:html.find('.png">')]+'.png'
	return cover

def serials():
	url='http://newstudio.tv/ajax/html/jumpbox_user.html'
	html=getURL(url)
	html=html[:html.find('</optgroup>')]
	ss='value="'
	es='&nbsp;</option'
	L=mfindal(html, ss, es)
	for i in L:
		f=i[7:i.find('">&nbsp;')]
		title=i[i.find('">&nbsp;')+8:]
		cover='http://newstudio.tv/images/posters/'+f+'.jpg'
		add_item (title, "viewforum", f, "0", cover, None, f)
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(handle)

def US(t):
	url='http://newstudio.tv/ajax/html/jumpbox_user.html'
	html=getURL(url)
	html=html[:html.find('</optgroup>')]
	ss='value="'
	es='&nbsp;</option'
	L=mfindal(html, ss, es)
	for i in L:
		f=i[7:i.find('">&nbsp;')]
		title=i[i.find('">&nbsp;')+8:]
		cover='http://newstudio.tv/images/posters/'+f+'.jpg'
		if lower(t) in lower(title):
			add_item (title, "viewforum", f, "0", cover, None, f)
	xbmcplugin.endOfDirectory(handle)

def SetViewMode():
	n = int(__settings__.getSetting("ListView"))
	if n>0:
		xbmc.executebuiltin("Container.SetViewMode(0)")
		for i in range(1,n):
			xbmc.executebuiltin("Container.NextViewMode")

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

params = get_params()

try:mode = urllib.unquote_plus(params["mode"])
except:mode =""
try:name = urllib.unquote_plus(params["name"])
except:name =""
try:url = urllib.unquote_plus(params["url"])
except:url =""
try:ind = urllib.unquote_plus(params["ind"])
except:ind ="0"


if mode==""         : root()
if mode=="add"      : add(name, url)
if mode=="play"     : play(url, int(ind), name)#updatetc.play(url, int(ind))
if mode=="rename"   : updatetc.rename_list(int(ind))
if mode=="viewforum": 
	viewforum(url)
	xbmcplugin.endOfDirectory(handle)
	#xbmc.sleep(200)
	SetViewMode()
	#xbmc.executebuiltin("Container.SetViewMode(51)")
if mode=="open": OpenTorrent(url)

if mode=="serials": serials()

if mode=="epd_lst"  : 
	if url[:4]!='plug':epd_lst(name, url, ind)
if mode=="add_filtr": add_filtr(url, ind)
if mode=="rem_filtr": 
	updatetc.rem_filtr(int(ind))
	xbmc.executebuiltin("Container.Refresh")
if mode=="rem_files": 
	updatetc.rem(name)
	updatetc.update()
if mode=="rem": 
	updatetc.rem_list(int(ind))
	xbmc.executebuiltin("Container.Refresh")

if mode == "FAV":
	favor(name)
	xbmc.executebuiltin('Container.Refresh')

if mode=="GetTC": GetTC(name)

if mode == "US":
	US(name)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)
