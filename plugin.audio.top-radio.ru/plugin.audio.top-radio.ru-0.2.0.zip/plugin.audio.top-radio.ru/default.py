#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,urllib2,re,sys,os,io,random
import xbmcplugin,xbmcgui,xbmcaddon
import time

pluginhandle = int(sys.argv[1])
__settings__ = xbmcaddon.Addon(id='plugin.audio.top-radio.ru')
thumb = os.path.join( __settings__.getAddonInfo('path'), 'icon.png')
Clist=['files', 'songs', 'artists', 'albums', 'movies', 'tvshows', 'episodes', 'musicvideos', 'addons']
vn=int(__settings__.getSetting("CL"))
xbmcplugin.setContent(int(sys.argv[1]), Clist[vn])

def showMessage(heading, message, times = 3000):
	heading = heading.encode('utf-8')
	message = message.encode('utf-8')
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, thumb))

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def decompress(data):
	import gzip
	with gzip.GzipFile(fileobj=io.BytesIO(data)) as f:
		return f.read()

def get_stations():
	d={}
	pDialog = xbmcgui.DialogProgressBG()
	pDialog.create('top-radio.ru', 'Поиск ...')
	for j in range (0,1000):
		id=str(j)
		url='http://vse.fm/station_'+id
		try:
			hp=GET(url)
			L=hp.splitlines()
			for i in L:
				if 'og:title' in i: 
					title= mfind(i,'content="',' — ').replace('РАДИО ','')
					sity = mfind(i,' — ',' (')
					if 'VSE.FM' in sity: sity = ''
					if ' (' in i : fm = mfind(i,' (',') ')
					else: fm = ''
					if title=='РОССИИ': title='РАДИО РОССИИ'
			if title!='ВСЕ ФМ': 
				pDialog.update(int(j/10), message=title+' '+sity)
				d[id]={'title':title, 'sity':sity, 'fm':fm}
				print id+' : '+title
		except: pass
	pDialog.close()
	save(d)
	return d

def save(d):
	s=repr(d)
	p = os.path.join(__settings__.getAddonInfo('path'),"fmst.py")
	f = open(p, "w")
	f.write('ds=')
	f.write(s)
	f.close()
	return p

def GET(url,Referer = 'http://top-radio.ru'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	req.add_header('X-Requested-With', 'XMLHttpRequest')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def POST(target, post=None, referer=''):
	#print target
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36 OPR/49.0.2725.64')
		req.add_header('Accept', 'application/json; q=0.01')
		req.add_header('Accept-Encoding', 'deflate, br')
		req.add_header('Referer', referer)
		#req.add_header('X-Requested-With', 'XMLHttpRequest')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		print 'err'
		print e
		return ''

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		#sn=http[s:]
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def Root(url=""):
	title="[COLOR F050F050][B]СТАНЦИИ[/B][/COLOR]"
	uri = sys.argv[0] + '?mode=Stations'
	item = xbmcgui.ListItem(title, iconImage = thumb, thumbnailImage = thumb)
	item.addContextMenuItems([('[COLOR F050F050]Обновить станции[/COLOR]', 'Container.Update("plugin://plugin.audio.vse.fm?mode=update")'),])
	xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
	
	title="[COLOR F050F050][B]ИЗБРАННОЕ[/B][/COLOR]"
	uri = sys.argv[0] + '?mode=Favorites'
	item.addContextMenuItems([('[COLOR F050F050]Обновить станции[/COLOR]', 'Container.Update("plugin://plugin.audio.vse.fm?mode=update")'),])
	item = xbmcgui.ListItem(title, iconImage = thumb, thumbnailImage = thumb)
	xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)

	xbmcplugin.endOfDirectory(pluginhandle)

def Stations():
	curl='http://top-radio.ru/web'
	hp=GET(curl)
	L=mfindal(hp,'<a href="web/','</p></div></a>')
	for i in L:
				print i
				url   = 'http://top-radio.ru/'+mfind(i,'<a href="','"')
				img   = 'http://top-radio.ru/'+mfind(i,'<img src="','"')
				title = mfind(i,'title="','"').replace('Радио ', '')
				
				uri = sys.argv[0] + '?mode=PlayStation'
				uri += '&url='  + urllib.quote_plus(url)
				uri += '&name='  + urllib.quote_plus(title)
				uri += '&img='  + urllib.quote_plus(img)
				
				item = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
				item.setInfo(type="Music", infoLabels={'artist': title})
				
				urc1 = sys.argv[0] + '?mode=add'
				urc1 += '&url='  + urllib.quote_plus(url)
				urc1 += '&name='  + urllib.quote_plus(title)
				urc1 += '&img='  + urllib.quote_plus(img)
				
				item.addContextMenuItems([('[COLOR F050F050] Добавить в избранное [/COLOR]', 'Container.Update("plugin://plugin.audio.top-radio.ru/'+urc1+'")'),('[COLOR F050F050] Избранное [/COLOR]', 'Container.Update("plugin://plugin.audio.top-radio.ru/?mode=Favorites")')])
				if title!="":xbmcplugin.addDirectoryItem(pluginhandle, uri, item, False)
	
	xbmcplugin.setPluginCategory(pluginhandle, 'Радиостанции')
	xbmcplugin.addSortMethod(pluginhandle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(pluginhandle)


def PlayStation(curl, img):
	hp=GET(curl)
	url=mfind(hp, '<source src="', '"')
	item = xbmcgui.ListItem(name, iconImage = img, thumbnailImage = img)
	item.setInfo(type="Music", infoLabels={"Title": name})
	#xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	xbmc.Player().play(url, item)

def add(url, name, img):
	try:L=eval(__settings__.getSetting("Favorites"))
	except:L=[]
	st=(url, name, img)
	if st not in L:L.append(st)
	__settings__.setSetting("Favorites",repr(L))


def rem(url):
	try:L=eval(__settings__.getSetting("Favorites"))
	except:L=[]
	L2=[]
	for i in L:
		if i[0] != url: L2.append(i)
	__settings__.setSetting("Favorites",repr(L2))


def Favorites():
	try:L=eval(__settings__.getSetting("Favorites"))
	except:L=[]
	if len(L)==0 and __settings__.getSetting("FP")=="1":
		title="[COLOR F050F050][B]ПОИСК[/B][/COLOR]"
		uri = sys.argv[0] + '?mode=Stations'
		item = xbmcgui.ListItem(title, iconImage = thumb, thumbnailImage = thumb)
		xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)

	for i in L:
			url = i[0]
			title=i[1]
			img = i[2]
			
			uri = sys.argv[0] + '?mode=PlayStation'
			uri += '&url='  + urllib.quote_plus(url)
			uri += '&name='  + urllib.quote_plus(title)
			uri += '&img='  + urllib.quote_plus(img)

			item = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
			item.setInfo(type="Music", infoLabels={"Title": title})
			
			urc1 = sys.argv[0] + '?mode=rem'
			urc1 += '&url='  + urllib.quote_plus(url)
			urc1 += '&name='  + urllib.quote_plus(title)

			item.addContextMenuItems([('[COLOR F050F050] Удалить [/COLOR]', 'Container.Update("plugin://plugin.audio.top-radio.ru/'+urc1+'")'),('[COLOR F050F050] Поиск станций [/COLOR]', 'Container.Update("plugin://plugin.audio.top-radio.ru/?mode=Stations")')])
			xbmcplugin.addDirectoryItem(pluginhandle, uri, item, False)
	xbmcplugin.endOfDirectory(pluginhandle)




params = get_params()
url  =	''
mode =	"Root"
name =	''
img =	' '

try: url = urllib.unquote_plus(params["url"])
except: pass
try: id = urllib.unquote_plus(params["id"])
except: pass
try: mode = urllib.unquote_plus(params["mode"])
except: pass
try: name = urllib.unquote_plus(params["name"])
except: pass
try: img = urllib.unquote_plus(params["img"])
except: pass


if   mode == "Root":
	if __settings__.getSetting("FP")=="1" and url=="":Favorites()
	else:Root(url)
elif mode == 'PlayStation':	PlayStation(url, img)
elif mode == 'add':			add(url,name,img)
elif mode == 'rem':			rem(url)
elif mode == 'Favorites':	Favorites()
elif mode == 'Category':	Category()
elif mode == 'Stations':	Stations()
elif mode == 'all':			all(url)
elif mode == 'dir':			dir(url)
elif mode == 'update':		get_stations()
elif mode == 'list':		List(id)