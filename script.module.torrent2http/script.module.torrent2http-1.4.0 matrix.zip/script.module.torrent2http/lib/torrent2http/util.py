import sys
import socket


def can_bind(host, port):
	"""
	Checks we can bind to specified host and port

	:param host: Host
	:param port: Port
	:return: True if bind succeed
	"""
	try:
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		s.bind((host, port))
		s.close()
	except socket.error:
		return False
	return True


def find_free_port(host, range=[]):

	for port in range:
		if can_bind(host, port):
			return port

	"""
	Finds free TCP port that can be used for binding

	:param host: Host
	:return: Free port
	"""
	try:
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		s.bind((host, 0))
		port = s.getsockname()[1]
		s.close()
	except socket.error:
		return False
	return port


def ensure_fs_encoding(string):
	if sys.version_info < (3, 0):
		if isinstance(string, str):
			string = string.decode('utf-8')
		return string.encode(sys.getfilesystemencoding() or 'utf-8')
	else:
		if isinstance(string, bytes):
			string = string.decode('utf-8')
		return string
