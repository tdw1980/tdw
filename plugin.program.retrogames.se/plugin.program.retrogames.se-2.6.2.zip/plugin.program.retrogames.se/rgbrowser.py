# -*- coding: utf-8 -*-
# CONSTANTS
#__author__ = 'TDW'
#__version__ = '1.0.0'
#__url__ = 'http://xbmc.ru'
#__date__ = '2/2015'

# IMPORTS
import sys, os
import urllib, urllib2
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
import subprocess
#import rarfile

# custom
#lib_path = xbmcaddon.Addon('plugin.program.isybrowse'). \
#    getAddonInfo('path') + '/resources/lib/'
#sys.path.append(lib_path)
#import shared
#import actions
#import menus

addon=xbmcaddon.Addon('plugin.program.retrogames.se')
handle=int(sys.argv[1])

try:
	if addon.getSetting("RD")<>"":
		RDir = os.path.join( addon.getSetting("RD"), "roms" )
		if os.path.exists(RDir) == False: os.makedirs(RDir)
	else: RDir = os.path.join( addon.getAddonInfo('path'), "roms" )
except:
	RDir = os.path.join( addon.getAddonInfo('path'), "roms" )

TMPdir = os.path.join( addon.getAddonInfo('path'), "temp" )
CDir = os.path.join( addon.getAddonInfo('path'), "images", "covers" )
#xbmcplugin.setContent(int(sys.argv[1]), 'game')

#Mpath = "D:\\1\\med\\mednafen.exe"
Mpath = addon.getSetting("MD")
fsp=' -video.fs "1" '
MedList=[".nes", ".gen", ".gbc", ".gba", ".ngp", ".snes", ".sms", ".smc", ".pce", ".gg", ".lnx", ".ngc", ".vb",".32x" ,".32X" ,".a26" ,".A26" ,".a78" ,".A78" ,".adf" ,".ADF" ,".bin" ,".BIN" ,".bin" ,".BIN" ,".bin" ,".BIN" ,".bin" ,".BIN" ,".bin" ,".BIN" ,".bin" ,".BIN" ,".bin" ,".BIN" ,".bin" ,".BIN" ,".bin" ,".BIN" ,".bin" ,".BIN" ,".ccd" ,".CCD" ,".cdi" ,".CDI" ,".col" ,".COL" ,".cso" ,".CSO" ,".cue" ,".CUE" ,".cue" ,".CUE" ,".cue" ,".CUE" ,".cue" ,".CUE" ,".dsk" ,".DSK" ,".dsk" ,".DSK" ,".fba" ,".FBA" ,".gb" ,".GB" ,".gba" ,".GBA" ,".gbc" ,".GBC" ,".gdi" ,".GDI" ,".gen" ,".GEN" ,".gg" ,".GG" ,".gz" ,".GZ" ,".img" ,".IMG" ,".img" ,".iso" ,".ISO" ,".iso" ,".ISO" ,".j64" ,".J64" ,".jag" ,".JAG" ,".lnx" ,".LNX" ,".md" ,".MD" ,".md" ,".MD" ,".md" ,".MD" ,".mdf" ,".MDF" ,".mds" ,".MDS" ,".mgt" ,".MGT" ,".mx1" ,".MX1" ,".mx2" ,".MX2" ,".n64" ,".N64" ,".nds" ,".NDS" ,".nes" ,".NES" ,".ngc" ,".ngp" ,".pce" ,".PCE" ,".rom" ,".ROM" ,".scl" ,".SCL" ,".sfc" ,".SFC" ,".sg" ,".SG" ,".smc" ,".SMC" ,".smd" ,".SMD" ,".sms" ,".SMS" ,".sna" ,".st" ,".stx" ,".szx" ,".SZX" ,".tap" ,".TAP" ,".trd" ,".TRD" ,".tzx" ,".TZX" ,".udi" ,".UDI" ,".v64" ,".V64" ,".vb" ,".VB" ,".ws" ,".wsc" ,".z64" ,".Z64" ,".z80" ,".Z80" ,".zip" ,".ZIP" ,"SNA"]

def rt(x):
	L=[('&#8216;',''), ('&#8212;','-'), ('&#133;','…'), ('&#34;','&'), ('&#39;','’'), ('&#145;','‘'), ('&#146;','’'), ('&#147;','“'), ('&#148;','”'), ('&#149;','•'), ('&#150;','–'), ('&#151;','—'), ('&#152;','?'), ('&#153;','™'), ('&#154;','s'), ('&#155;','›'), ('&#156;','?'), ('&#157;',''), ('&#158;','z'), ('&#159;','Y'), ('&#160;',''), ('&#161;','?'), ('&#162;','?'), ('&#163;','?'), ('&#164;','¤'), ('&#165;','?'), ('&#166;','¦'), ('&#167;','§'), ('&#168;','?'), ('&#169;','©'), ('&#170;','?'), ('&#171;','«'), ('&#172;','¬'), ('&#173;',''), ('&#174;','®'), ('&#175;','?'), ('&#176;','°'), ('&#177;','±'), ('&#178;','?'), ('&#179;','?'), ('&#180;','?'), ('&#181;','µ'), ('&#182;','¶'), ('&#183;','·'), ('&#184;','?'), ('&#185;','?'), ('&#186;','?'), ('&#187;','»'), ('&#188;','?'), ('&#189;','?'), ('&#190;','?'), ('&#191;','?'), ('&#192;','A'), ('&#193;','A'), ('&#194;','A'), ('&#195;','A'), ('&#196;','A'), ('&#197;','A'), ('&#198;','?'), ('&#199;','C'), ('&#200;','E'), ('&#201;','E'), ('&#202;','E'), ('&#203;','E'), ('&#204;','I'), ('&#205;','I'), ('&#206;','I'), ('&#207;','I'), ('&#208;','?'), ('&#209;','N'), ('&#210;','O'), ('&#211;','O'), ('&#212;','O'), ('&#213;','O'), ('&#214;','O'), ('&#215;','?'), ('&#216;','O'), ('&#217;','U'), ('&#218;','U'), ('&#219;','U'), ('&#220;','U'), ('&#221;','Y'), ('&#222;','?'), ('&#223;','?'), ('&#224;','a'), ('&#225;','a'), ('&#226;','a'), ('&#227;','a'), ('&#228;','a'), ('&#229;','a'), ('&#230;','?'), ('&#231;','c'), ('&#232;','e'), ('&#233;','e'), ('&#234;','e'), ('&#235;','e'), ('&#236;','i'), ('&#237;','i'), ('&#238;','i'), ('&#239;','i'), ('&#240;','?'), ('&#241;','n'), ('&#242;','o'), ('&#243;','o'), ('&#244;','o'), ('&#245;','o'), ('&#246;','o'), ('&#247;','?'), ('&#248;','o'), ('&#249;','u'), ('&#250;','u'), ('&#251;','u'), ('&#252;','u'), ('&#253;','y'), ('&#254;','?'), ('&#255;','y'), ('&laquo;','"'), ('&raquo;','"'), ('&nbsp;',' ')]
	for i in L:
		x=x.replace(i[0], i[1])
	return x


from core_conf import*
#try:
if addon.getSetting("cores")<>"":
		user_set = addon.getSetting("cores")
		user_list= eval("[('."+user_set.replace(" ","").replace(",","'),('.").replace(";","'),('.").replace("=","','")+"'),]")
		for i in user_list:
			CoreDict[i[0]]=i[1]
#except:pass

#rarfile.UNRAR_TOOL=os.path.join( addon.getAddonInfo('path'), 'resources','lib','unrar.exe')

if os.name=="nt":	Z7path=os.path.join( addon.getAddonInfo('path'), 'resources','lib','7za.exe')
else:				Z7path=os.path.join( addon.getAddonInfo('path'), 'resources','lib','7za_rpi')

#xbmcplugin.setContent(int(sys.argv[1]), 'movies')

cover=os.path.join( addon.getAddonInfo('path'), "icon.png" )
def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def inputbox():
	skbd = xbmc.Keyboard()
	skbd.setHeading('Название:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return ""

def browse():
	dialog = xbmcgui.Dialog()
	fn = dialog.browse(1, 'Выбрать запускаемый файл', 'files')
	return fn

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, cover))

def getURL(url,Referer = 'http://emulations.ru/'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def add_item (name, mode="", path = RDir, cover=None, funart=None, type="x", inf=''):
	if cover==None:	listitem = xbmcgui.ListItem(name)
	else:			listitem = xbmcgui.ListItem(name, iconImage=cover, thumbnailImage=cover)
	listitem.setProperty('fanart_image', funart)
	try:ginfo = local_info(path)
	except: ginfo = {}
	#print ginfo
	try: listitem.setInfo(type = "video", infoLabels = ginfo)
	except: pass
	uri = sys.argv[0] + '?mode='+mode
	uri += '&path='  + urllib.quote_plus(path)
	uri += '&name='  + urllib.quote_plus(name)
	uri += '&type='  + urllib.quote_plus(type)
	if inf!='':uri += '&inf='  + urllib.quote_plus(inf)
	if cover!=None:uri += '&cover='  + urllib.quote_plus(cover)
	if funart!=None and funart!="":uri += '&funart='  + urllib.quote_plus(funart)
	
	print uri
	
	urr = sys.argv[0] + '?mode=rem'
	urr += '&path='  + urllib.quote_plus(path)
	
	urr2 = sys.argv[0] + '?mode=rem2'
	urr2 += '&path='  + urllib.quote_plus(path)
	
	urr3 = sys.argv[0] + '?mode=info'
	urr3 += '&path='  + urllib.quote_plus(path)
	
	urr4 = sys.argv[0] + '?mode=SelectCover'
	urr4 += '&path='  + urllib.quote_plus(path)
	urr4 += '&name='  + urllib.quote_plus(name)
	
	urr5 = sys.argv[0] + '?mode=MakeRGL'
	urr5 += '&path='  + urllib.quote_plus(path)

	try:ext=path[-3:]
	except:ext=''
	
	if mode=="run" and ext=='.dr':listitem.addContextMenuItems([('[COLOR F050F050] Описание [/COLOR]', 'Container.Update("'+urr3+'")'), ('[COLOR F0F05050] Удалить [/COLOR]', 'Container.Update("'+urr+'")')])
	elif mode=="run" and ext!='.dr':listitem.addContextMenuItems([('[COLOR F0F05050] Удалить [/COLOR]', 'Container.Update("'+urr+'")'), ('[COLOR F0F05050] Оставить только это [/COLOR]', 'Container.Update("'+urr2+'")'), ('[COLOR F050F050] Добавить игру [/COLOR]', 'Container.Update("'+urr5+'")'), ('[COLOR F050F050] Выбрать обложку [/COLOR]', 'Container.Update("'+urr4+'")')])
	
	xbmcplugin.addDirectoryItem(handle, uri, listitem, True)

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es, s+len(ss))
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def root():
	cover=os.path.join(CDir, "Download.png")
	add_item ("Каталог", 'OnlRoot', RDir, cover)
	try:dir(RDir, end=False)
	except: pass#xbmcplugin.endOfDirectory(handle)
	if addon.getSetting("add")=="true": add_item ("Создать папку", 'AddDir', RDir, os.path.join(CDir, "Add.png"))
	xbmcplugin.endOfDirectory(handle, cacheToDisc=False)

def OnlRoot():
	L=eval(getURL('http://td-soft.narod.ru/roms/root.txt'))
	for i in L:
		add_item(i['title'], 'OnlList',i['url'],i['url']+'/cover.png',type=i['type'])
	xbmcplugin.endOfDirectory(handle)


def my1(type):
	type=__settings__.getSetting('type')
	dom='http://td-soft.narod.ru/roms/'
	
	url=dom+type+'/info.txt'
	#print url
	L=eval(getURL(url))
	LL=[]
	for i in L:
		info=i['info']
		info['url']=dom+type+'/'+i['url']+'/roms.zip'
		info['cover']=dom+type+'/'+i['url']+'/cover.png'
		info['fanart']=dom+type+'/'+i['url']+'/fanart.png'
		info['type']=type
		LL.append(info)
	return LL

def debug(s):
	fl = open(os.path.join( ru(RDir),"test.txt"), "w")
	fl.write(s)
	fl.close()

def svnfo(L):
	fl = open(os.path.join( ru(RDir),"info.txt"), "w")
	fl.write('[')
	for k in L:
		i=k['info']
		fl.write('{"url":"'+k['url']+'",')
		fl.write('"info": {"title":"'+i['title']+'", "year": "'+i['year']+'", "genre": "'+i['genre']+'", "plot": "'+i['plot']+'"}},')
	fl.write(']')
	fl.close()

def local_info(RDir):
	fl = open(os.path.join( ru(RDir),"info.txt"), "r")
	
	t=fl.read()
	fl.close()
	L=t.splitlines()
	info={"title":"", "year": "", "genre": "", "plot": "", "type": ""}
	for k in L:
		if 'Название:' in k: 	info['title']=k[17:]
		if 'Жанр:' in k: 		
								info['genre']=k[9:]
								info['genres']=[k[9:],]
		if 'Описание:' in k: 	
								info['plot']=k[17:]
								info['overview']=k[17:]
								
		if 'Год:' in k: 		info['year']=k[7:]
		if 'Платформа:' in k: 
								info['type']=k[19:]
								info['platform']=k[19:]
	return info



def dir(path, cover=None, end=True):
	print '===== dir ====='
	hide=[".png", ".jpg", ".7z", ".txt", ".sav"]
	ld=os.listdir(path)
	print ld
	for i in ld:
		print i
		if os.path.isdir(path):
			ncover=os.path.join(path, i, "cover.png")
			if os.path.exists(ncover): cover=ncover
			else: cover=None
			nart=os.path.join(path, i, "funart.png")
			if os.path.exists(nart): funart=nart
			else: funart=None
		ecover=os.path.join(path, os.path.splitext(i)[0]+".png")
		if os.path.exists(ecover):cover=ecover
		ext=os.path.splitext(i)[1]
		cl_name=i.replace(ext,"")
		if cover==None:
			lcover=os.path.join(CDir, cl_name+".png")
			if os.path.exists(lcover):cover=lcover
		if ext not in hide: add_item(cl_name, "run", os.path.join(path, i),cover, funart)
	if end: xbmcplugin.endOfDirectory(handle)

def drl(path):
	rlst=[]
	ld=os.listdir(path)
	for i in ld:
		ext=os.path.splitext(i)[1]
		if ext in MedList: rlst.append(i)
	return rlst

def tolnx(s):
	lstr="'"+s.replace("'","'\\''")+"'"
	return lstr


def run(path):
	ext=os.path.splitext(path)[1]
	if os.path.isdir(path):
		#print ext
		if ext ==".dr":
			rlst=drl(path)
			if len(rlst)==1:
				newpath=os.path.join(path,rlst[0])
				print newpath
				gameplay(newpath)
			else:dir(path)
		else:dir(path)
	else:
		if ext=='.rgl': path=read_rgl(path)
			
		if ext in MedList:
			gameplay(path)
		else:
			if os.name=="nt":os.system('"'+path+'"')
			else:os.system(tolnx(path))

def read_rgl(path):
		fl = open(path, "r")
		newpath=fl.read()
		fl.close()
		return newpath


def gameplay(path):
	if addon.getSetting("RP")=="true": return xbmc.Player().play(path)
	print 'gameplay '+path
	if Mpath.find("mednafen")>0:
		command=Mpath+fsp+'"'+path+'"'
	elif Mpath.find("retroarch")>0:
		ext=os.path.splitext(path)[1]
		try:core=CoreDict[ext]
		except: core=''
		print '-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-='
		print os.name
		if os.name=="nt":command=Mpath+' -L '+os.path.join(os.path.split(Mpath)[0], "cores", core)+'_libretro.dll "'+path+'"'
		else:command=Mpath+' '+core+' '+tolnx(path)
	else:
		command=Mpath+' "'+path+'"'
	print command
	print '-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-='
	#subprocess.call(command)
	subprocess.Popen(command, shell = True)
	#os.system(command)

def add_dir():
	title = inputbox()
	title=ru(title.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"").replace('>',"").replace('<',""))
	if title !='':
		Dldir = RDir
		if Dldir == "":Dldir = os.path.join( addon.getAddonInfo('path'), "roms" )
		fp = os.path.join(ru(Dldir), title)
		if os.path.exists(fp)== False: os.makedirs(fp)

def select_cover(title, path):
	print '== select_icon =='
	print path
	title=title+" cover"
	url='https://yandex.ru/images/search?text='+urllib.quote_plus(title)+'&isize=small&iorient=square'#&type=clipart
	hp=getURL(url)
	#print hp
	#debug (hp)
	ss='&quot;img_href&quot;:&quot;'
	L=mfindal(hp, ss, '&quot;')
	for i in L:
		if 'http' in i:
			img=i.replace(ss,'')
			print img
			add_item (img, "SetCover", path, img)
	xbmcplugin.endOfDirectory(handle)

def set_cover(img, fp):
	print 'set cover'
	print img
	print fp
	if os.path.isdir(fp): cp=os.path.join(fp, "cover.png")
	else: cp=os.path.splitext(fp)[0]+".png"
	print cp
	try:
		req = urllib2.Request(url = img, data = None)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		resp = urllib2.urlopen(req)
		fl = open(cp, "wb")
		fl.write(resp.read())
		fl.close()
	except: pass

def make_rgl(fp):
	print '== make_rgl =='
	title = inputbox()
	title=ru(title.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"").replace('>',"").replace('<',""))
	if title !='':
		path=browse()
		if path !='':
			print fp
			if os.path.isdir(fp): gp=os.path.join(fp, title+'.rgl')
			else: gp=os.path.splitext(fp)[0]+".png"
			print gp
			fl = open(gp, "w")
			fl.write(path)
			fl.close()


def sel_dload(title, type, url, cover, funart):
		http=getURL(url)
		#debug(http)
		ss='<center><div class="preview-pp2"><img src="'
		es='" width="240" height="160" alt='
		funart=mfindal(http, ss, es)[0][len(ss):]
		
		ss='<div style="margin-left:5px;">'
		es='.rar"><img src="/wp'
		t1=mfindal(http, ss, es)[0]
		n=t1.find("http://gbaroms.ru/")
		url=t1[n:]+".rar"
		
		#print title
		#print funart
		#print url
		dload(title, type, url, cover, funart)
		#add_item (title, "sel_dload", url, cover, funart, type)


def dload(title, type, target):
	cover=target.replace('roms.zip','cover.png')
	funart=target.replace('roms.zip','fanart.png')
	text=target.replace('roms.zip','info.txt')
	type=type.upper()
	title=ru(title.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"").replace('>',"").replace('<',""))
	#print target
	Dldir = RDir
	if Dldir == "":Dldir = os.path.join( addon.getAddonInfo('path'), "roms" )
	
	fp = os.path.join(ru(Dldir), type, title+'.dr')
	if os.path.exists(fp)== False: os.makedirs(fp)
	cp=os.path.join(fp, "cover.png")
	ap=os.path.join(fp, "fanart.png")
	tp=os.path.join(fp, "info.txt")
	fp = os.path.join(fp, "roms.zip")
	
	try:
	#if 1==1:
			#debug( getURL(target))
			print target
			#target=sevn2zip(target)
			#print target
			req = urllib2.Request(url = target, data = None)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			fl = open(fp, "wb")
			fl.write(resp.read())
			fl.close()
			try:
				req = urllib2.Request(url = cover, data = None)
				req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
				resp = urllib2.urlopen(req)
				fl = open(cp, "wb")
				fl.write(resp.read())
				fl.close()
			except: pass
			try:
				req = urllib2.Request(url = funart, data = None)
				req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
				resp = urllib2.urlopen(req)
				fl = open(ap, "wb")
				fl.write(resp.read())
				fl.close()
			except: pass
			try:
				req = urllib2.Request(url = text, data = None)
				req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
				resp = urllib2.urlopen(req)
				fl = open(tp, "wb")
				fl.write(resp.read())
				fl.close()
			except: pass
			#un7zip(fp)
			unzip(fp)
			os.remove(fp)
			showMessage('Сохранено', title)
			return os.path.join( ru(Dldir),nmi)
	except Exception, e:
			#xbmc.log( '[%s]: GET EXCEPT [%s]' % (addon_id, e), 4 )
			return target
			print 'HTTP ERROR ' + str(e)

def dload2(info):
	title=info['title']
	type=info['type']
	target=info['url']
	cover=info['cover']
	funart=info['funart']
	
	text='Название: '+title+'\n'
	text+='Платформа: '+type+'\n'
	text+='Жанр: '+info['genre']+'\n'
	text+='Год: '+info['year']+'\n'
	text+='Описание: '+info['plot']
	
	title=ru(title.replace('\\','').replace('?',''))
	#print target
	Dldir = RDir
	if Dldir == "":Dldir = os.path.join( addon.getAddonInfo('path'), "roms" )
	
	fp = os.path.join(ru(Dldir), type, title+'.dr')
	if os.path.exists(fp)== False: 
		os.makedirs(fp)
	else: 
		return
	cp=os.path.join(fp, "cover.png")
	ap=os.path.join(fp, "funart.png")
	tp=os.path.join(fp, "info.txt")
	fp = os.path.join(fp, title+".7z")
	
	try:
	#if 1==1:
			#debug( getURL(target))
			print target
			#target=sevn2zip(target)
			#print target
			req = urllib2.Request(url = target, data = None)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			fl = open(fp, "wb")
			fl.write(resp.read())
			fl.close()
			try:
				req = urllib2.Request(url = cover, data = None)
				req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
				resp = urllib2.urlopen(req)
				fl = open(cp, "wb")
				fl.write(resp.read())
				fl.close()
				
				if funart=="":req = urllib2.Request(url = cover.replace("_0.","_1."), data = None)
				else:req = urllib2.Request(url = funart, data = None)
				req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
				resp = urllib2.urlopen(req)
				fl = open(ap, "wb")
				fl.write(resp.read())
				fl.close()
			except: pass
			fl = open(tp, "w")
			fl.write(text)
			fl.close()
			
			#unzip(fp)
			#os.remove(fp)
			return os.path.join( ru(Dldir),nmi)
	except Exception, e:
			#xbmc.log( '[%s]: GET EXCEPT [%s]' % (addon_id, e), 4 )
			return target
			print 'HTTP ERROR ' + str(e)

def rem(path):
	if os.path.isdir(path):
		lst=os.listdir(path)
		for i in lst:
			pf=os.path.join(path, i)
			os.remove(pf)
		os.rmdir(path)
	else:
		d=os.path.split(path)[0]
		sp=path
		if len(os.listdir(d))<=4:dir(os.path.split(d)[0])
		try:os.remove(sp)
		except: pass

def rem2(path):
	dr=os.path.split(path)[0]
	hide=[".png", ".jpg", ".7z", ".sav"]
	if os.path.isdir(path)==False:
		lst=os.listdir(dr)
		for i in lst:
			ext=os.path.splitext(i)[1]
			pf=os.path.join(dr, i)
			if pf!=path and ext not in hide: os.remove(pf)
	xbmc.executebuiltin('Container.Refresh')


def sel_play(url):
		http=getURL(url)
		
		ss='<div style="margin-left:5px;">'
		es='.rar"><img src="/wp'
		t1=mfindal(http, ss, es)[0]
		n=t1.find("http://gbaroms.ru/")
		url=t1[n:]+".rar"
		
		play(url)


def play(target):
		print '=== play ==='
		try:rem(TMPdir)
		except: pass
		if os.path.exists(TMPdir)== False: os.makedirs(TMPdir)
		fp = os.path.join(TMPdir, "tmp.zip")
		#target=sevn2zip(target)
		try:
			req = urllib2.Request(url = target, data = None)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			fl = open(fp, "wb")
			fl.write(resp.read())
			fl.close()
			#un7zip(fp)
			unzip(fp)
			os.remove(fp)
			print 'dir '+TMPdir
			rom=os.listdir(TMPdir)[0]
			gameplay(os.path.join(TMPdir, rom))
		except: pass

def unzip(filename):
	from zipfile import ZipFile
	fil = ZipFile(filename, 'r')
	for name in fil.namelist():
		#print name
		try:
			unicode_name = name.decode('UTF-8').encode('UTF-8')
		except UnicodeDecodeError:
			unicode_name = name.decode('cp866').encode('UTF-8')
		# открываем файл и пишем в него из архива
		f2 = open(os.path.join(os.path.split(filename)[0],unicode_name), 'wb')
		f2.write(fil.read(name))
		f2.close()
	fil.close()



def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

'''
params = get_params()

try:mode = urllib.unquote_plus(params["mode"])
except:mode =""
try:path = urllib.unquote_plus(params["path"])
except:path = RDir
try:name = urllib.unquote_plus(params["name"])
except:name = "noname"
try:cover = urllib.unquote_plus(params["cover"])
except:cover = ""
try:funart = urllib.unquote_plus(params["funart"])
except:funart = ""

try:type = urllib.unquote_plus(params["type"])
except:type = "x"

try:inf = urllib.unquote_plus(params["inf"])
except:inf = ""



#if mode=="":root()
if mode=="run":run(path)
if mode=="OnlRoot":OnlRoot()
if mode=="OnlList":OnlList(path, type)
if mode=="GBAList":GBAList(path, type, cover)
if mode=="GBAGenre":GBAGenre(path, type)
if mode=="Genre":Genre(path, type)
if mode=="sel_dload":
	try:
		r=select(name, cover, funart)
		if r=="save":sel_dload(name, type, path, cover, funart)
		if r=="run":sel_play(path)
	except:
		sel_dload(name, type, path, cover, funart)

if mode=="dload":
	try:
		r=select(name, cover)
		if r=="save":dload(name, type, path, cover, funart, inf)
		if r=="run":play(path)
	except:
		dload(name, type, path, cover, funart)

if mode=="rem":rem(path)
if mode=="rem2":rem2(path)
'''
#debug(getURL('http://roms.my1.ru/nes/Dragon/info.inf', 'http://roms.my1.ru/'))