# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, sys, time, urllib
import rgbrowser
PLUGIN_NAME   = 'plugin.program.retrogames.se'
handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id=PLUGIN_NAME)
__settings__ = xbmcaddon.Addon(id=PLUGIN_NAME)
rgbrowser.__settings__=__settings__
icon = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'icon.png'))
background = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'fanart.png'))
xbmcplugin.setContent(int(sys.argv[1]), 'movies')
#from DBcnl import *

def log(text, x3=''):
	print text

#Action Codes
# See guilib/Key.h
ACTION_CANCEL_DIALOG = (9,10,51,92,110)
ACTION_PLAYFULLSCREEN = (12,79,227)
ACTION_MOVEMENT_LEFT = (1,)
ACTION_MOVEMENT_RIGHT = (2,)
ACTION_MOVEMENT_UP = (3,)
ACTION_MOVEMENT_DOWN = (4,)
ACTION_MOVEMENT = (1, 2, 3, 4, 5, 6, 159, 160)
ACTION_INFO = (11,)
ACTION_CONTEXT = (117,)
ACTION_MOVEMENT_ALL = (1, 2, 3, 4, 5, 6, 159, 160, 104, 105, 106, 107)


#ControlIds
CONTROL_CONSOLES = 500
CONTROL_GENRE = 600
CONTROL_YEAR = 700
CONTROL_PUBLISHER = 800
CONTROL_CHARACTER = 900
FILTER_CONTROLS = (500, 600, 700, 800, 900,)
GAME_LISTS = (50, 51, 52,53, 54, 55, 56, 57, 58)
CONTROL_SCROLLBARS = (2200, 2201, 60, 61, 62)

CONTROL_GAMES_GROUP_START = 600
CONTROL_GAMES_GROUP_END = 59

#CONTROL_BUTTON_CHANGE_VIEW = 2
CONTROL_BUTTON_FAVORITE = 1000
CONTROL_BUTTON_SEARCH = 1100
CONTROL_BUTTON_VIDEOFULLSCREEN = (2900, 2901,)
NON_EXIT_RCB_CONTROLS = (500, 600, 700, 800, 900, 2, 1000, 1100)

CONTROL_LABEL_MSG = 4000
CONTROL_BUTTON_MISSINGINFODIALOG = 4001

class UI_INF(xbmcgui.WindowXML):
	def __init__(self,strXMLname, strFallbackPath, strDefaultName, forceFallback):
		self.dir=__settings__.getSetting("path")
		self.info=rgbrowser.local_info(__settings__.getSetting("path"))
		print self.info
	
	def onInit(self):
		self.showList()
		#self.setFocus(self.getControl(600))
	
	def showList(self):
		win = xbmcgui.Window (xbmcgui.getCurrentWindowId())
		#picon = os.path.join(self.dir, 'cover.png'))
		win.setProperty('fanart', self.info['fanart'])
		win.setProperty('picon',  self.info['cover'])
		win.setProperty('title',  self.info['title'])
		win.setProperty('plot',   self.info['plot'])
		win.setProperty('year',   self.info['year'])
		win.setProperty('genre',  self.info['genre'])
		win.setProperty('type',   self.info['type'])
		#win.setProperty('date',  arhive_date)
		#win.setProperty('update', 'update.gif')
		#даты
		#list1=self.getControl(500)
		#list1.reset()
		#win.setProperty('update', '')

	def onClick(self, controlID):
		print 'onClick ' +str(controlID)
		
		if controlID == 600:
			
			list=self.getControl(controlID)
			listitem=list.getSelectedItem()
			curl=listitem.getProperty('curl')
			#xbmc.executebuiltin('ActivateWindow(10025,"'+curl+'", return)')
			
			D=pztv.get_arhive_strm(curl)
			playlist = xbmc.PlayList (xbmc.PLAYLIST_VIDEO)
			playlist.clear()
			for title in D.keys():
				purl=D[title]
				item = xbmcgui.ListItem(title, path=purl)
				playlist.add(url=purl, listitem=item)
			player=xbmc.Player()
			__settings__.setSetting("cplayed",'arh')
			player.play(playlist)
			
		if controlID == 500:
			list=self.getControl(controlID)
			r=list.getSelectedPosition()
			pztv.set_arhive_date(r)
			self.showList()


class UI_XML(xbmcgui.WindowXML):#Dialog
	selectedControlId = 0
	def __init__(self,strXMLname, strFallbackPath, strDefaultName, forceFallback):
		# Changing the three varibles passed won't change, anything
		# Doing strXMLname = "bah.xml" will not change anything.
		# don't put GUI sensitive stuff here (as the xml hasn't been read yet
		# Idea to initialize your variables here
		#xbmcplugin.endOfDirectory(handle, False, False)
		self.CurrentListPosition=0
		self.uptime=0
		if __settings__.getSetting("arhon")=='true': update_Arhive()
		pass

	def onInit(self):
		try:
			# Put your List Populating code/ and GUI startup stuff here
			self.setFocus(self.getControl(CONTROL_GAMES_GROUP_START))
			#self.clearList()
			
			self.showList()
			
			abc=__settings__.getSetting("abc")
			btn=self.getControl(1)
			if abc == 'false':	btn.setLabel('Порядок: Свой')
			else:				btn.setLabel('Порядок: ABC')
			
			if __settings__.getSetting("cllogo")=='true':
				__settings__.setSetting("cllogo",'false')
				pztv.cllogo()
			
		except:
			pass


	def onAction(self, action):
		log("onAction: "+ str(action.getId()))
		# Same as normal python Windows.
		if(action.getId() == 0):
			log("actionId == 0. Input ignored")
			return
		
		#try:
		if(action.getId() in ACTION_CANCEL_DIALOG):
				log("onAction: ACTION_CANCEL_DIALOG")
				self.exit()
		#except:
		#	log("onAction: ERRR")
		elif (action.getId() in ACTION_CONTEXT):
				self.showContextMenu()
		
		if action.getId() in ACTION_MOVEMENT_ALL:
			self.CurrentListPosition=self.getCurrentListPosition()
			self.setINFO()
			#try:uptime=eval(__settings__.getSetting("uptime"))
			#except: uptime=0
			delta=time.time()-self.uptime
			#if delta > 55: 
			#	self.updateEPG()
				#__settings__.setSetting("uptime", repr(time.time()))
		if(action.getId() == 13):# stop
			#self.showList()
			self.setPlayed()
		if(action.getId() == 11):# info
			if self.selectedControlId == 600:
				list1=self.getControl(600)
				listitem = list1.getSelectedItem()
				curl = listitem.getProperty('arhive')
				id   = listitem.getProperty('id')
				if curl!='': 
					__settings__.setSetting("arhive_cnl", curl)
					__settings__.setSetting("arhive_cnl_id", id)
					self.run_arhive()#xbmc.executebuiltin('ActivateWindow(10025,"'+curl+'", return)')


	def onClick(self, controlID):
		print 'onClick ' +str(controlID)
		if controlID == 600:
			info = self.get_game_info()
			sel = xbmcgui.Dialog()
			r = sel.select("Выбор:", ['Сохранить','Запустить'])
			if r == 0: rgbrowser.dload(info['title'], info['type'], info['url'])
			if r == 1: rgbrowser.play(info['url'])
			
		if controlID == 800:
			list=self.getControl(controlID)
			clp=list.getSelectedPosition()
			listitem=list.getSelectedItem()
			SG=listitem.getLabel()
			__settings__.setSetting("Sel_gr",SG)
			self.CurrentListPosition=0
			self.showList()
			list.selectItem(clp)
		if controlID == 5:
			__settings__.openSettings()
			self.showList()
		if controlID == 1:
			abc=__settings__.getSetting("abc")
			btn=self.getControl(controlID)
			if abc == 'true':
				__settings__.setSetting("abc", 'false')
				btn.setLabel('Порядок: Свой')
			else:
				__settings__.setSetting("abc", 'true')
				btn.setLabel('Порядок: ABC')
			self.showList()

	def onFocus(self, controlID):
		self.setINFO()
		self.selectedControlId = controlID
		if controlID == 6: 
			list=self.getControl(800)
			self.setFocusId(800)
			list.selectItem(list.size()-1)
			
		#print controlID
		pass

	def exit(self):
		log("PTV exit")
		self.close()
	
	def get_game_info(self):
			list1=self.getControl(600)
			listitem = list1.getSelectedItem()
			info={}
			info['url'] = listitem.getProperty('url')
			info['type'] = listitem.getProperty('type')
			info['title'] = listitem.getProperty('title')
			info['cover'] = listitem.getProperty('cover')
			info['fanart'] = listitem.getProperty('fanart')
			info['genre'] = listitem.getProperty('genre')
			info['year'] = listitem.getProperty('year')
			info['plot'] = listitem.getProperty('plot')
			return info
	
	def getCurrentListPosition_off(self):
		list1=self.getControl(600)
		n=list1.getSelectedPosition()
		return n
	
	def setCurrentListPosition_off(self, n):
		list1=self.getControl(600)
		list1.selectItem(n)
	
	def set_cnl_epg_off(self, cid1):
		D2=eval(pztv.getURL('http://127.0.0.1:'+epg_port+'/channels/dict'))
		D2['- НЕ СВЯЗАН']='000000'
		L=D2.keys()
		L.sort()
		sel = xbmcgui.Dialog()
		r = sel.select("Выберите программу передач:", L)
		if r>-1:
			nm=L[r]
			cid2=D2[nm]
			#print cid2+' to '+cid1
			pztv.getURL('http://127.0.0.1:'+epg_port+'/change/id='+cid2+'/to='+cid1)
		update_list_epg()
		#self.updateEPG()

	def showContextMenu(self):
		clp=self.getCurrentListPosition()
		controlID=self.selectedControlId
		print 'showContextMenu '+ str(controlID)
		if controlID == 600:
			id = self.get_cnl_id()
			if __settings__.getSetting("abc")=='true': 
				  context=['Добавить в группу','Удалить из группы','Объеденить с каналом', 'Разделить канал','Переименовать канал', 'Установить EPG']
			else: context=['Добавить в группу','Удалить из группы','Переместить в группе','Объеденить с каналом', 'Разделить канал','Переименовать канал', 'Установить EPG']
			if id in Arhive.keys(): context.append('Архив')
			
			sel = xbmcgui.Dialog()
			r = sel.select("", context)
			if r>=0:
				func=context[r]
				if   func=='Добавить в группу':    pztv.add_to_gr(id)
				elif func=='Удалить из группы':    pztv.rem_from_gr(id)
				elif func=='Переместить в группе': pztv.set_num_cn(id)
				elif func=='Объеденить с каналом': pztv.append_cnl(id)
				elif func=='Разделить канал':      pztv.split_cnl(id)
				elif func=='Переименовать канал':  pztv.rename_cnl(id)
				elif func=='Установить EPG':       self.set_cnl_epg(id)
				elif func=='Архив':                self.context_arhive()
				
				if   func!='Добавить в группу': self.showList()
		if controlID == 800:
			context1=['Создать группу','Удалить группу','Переместить группу','Переименовать группу', 'Объединить с группой','Установить пароль','Редактор каналов','Обновить каналы','Обновить телепрограмму']
			context2=['Создать группу','Переместить группу','Снять пароль','Редактор каналов','Обновить каналы','Обновить телепрограмму']
			list2=self.getControl(800)
			listitem=list2.getSelectedItem()
			label=listitem.getLabel()
			if 'COLOR' in label:
				label=label.replace('[COLOR 44FFFFFF]','').replace('[/COLOR]','')
				context=context2
			else:
				context=context1
			sel = xbmcgui.Dialog()
			r = sel.select("", context)
			if r>=0:
				func=context[r]
				
				if   func=='Создать группу':       pztv.add_gr()
				elif func=='Удалить группу':       pztv.rem_gr(label)
				elif func=='Переместить группу':   pztv.move_gr(label)
				elif func=='Переименовать группу': pztv.rename_gr(label)
				elif func=='Объединить с группой': pztv.extend_gr(label)
				elif func=='Установить пароль':    pztv.set_pass_gr(label)
				elif func=='Снять пароль':         pztv.rem_pass_gr(label)
				elif func=='Редактор каналов':     self.run_editor()
				elif func=='Обновить каналы':      pztv.update_cnl()
				elif func=='Обновить телепрограмму': pztv.getURL('http://127.0.0.1:'+epg_port+'/update')

				if label == __settings__.getSetting("Sel_gr"): __settings__.setSetting("Sel_gr", 'Все каналы')
				self.showList()
		self.setCurrentListPosition(clp)

	def context_arhive(self):
				list1=self.getControl(600)
				listitem = list1.getSelectedItem()
				id = listitem.getProperty('id')
				curl = listitem.getProperty('arhive')
				if curl!='': 
					__settings__.setSetting("arhive_cnl", curl)
					__settings__.setSetting("arhive_cnl_id", id)
					self.run_arhive()

	def setINFO(self):
			list1=self.getControl(600)
			item=list1.getSelectedItem()
			win = xbmcgui.Window (xbmcgui.getCurrentWindowId())
			
			try:
					win.setProperty('EPG2_time',  item.getProperty('EPG2_time'))
					win.setProperty('EPG2_title', item.getProperty('genre'))
					win.setProperty('EPG1_time',  item.getProperty('EPG1_time'))
					win.setProperty('EPG1_title', item.getProperty('year'))
					win.setProperty('EPG0_title', item.getProperty('title'))
					win.setProperty('EPG0_time',  item.getProperty('year'))
					win.setProperty('EPG0_img',   item.getProperty('fanart'))
					win.setProperty('EPG0_plot',  item.getProperty('plot'))
					for i in range(0,11):
						if item.getProperty('EPG_pr'+str(i*10)) == 'true': win.setProperty('EPG_pr'+str(i*10), 'true')
						else: win.setProperty('EPG_pr'+str(i*10), '')
			except:
				print '=========== set_info ERRRRRRRRRRRRRRR =========='


	def set_epg(self, item):
		self.uptime=time.time()
		id=item.getProperty('id')
		#print '===== set_epg '+id+' ====='
		#if id in Lepg:
					#lnk='http://127.0.0.1:'+epg_port+'/channels/'+id
					#print lnk
		EPG={}
		try:
			if id in current_epg.keys(): EPG=current_epg[id]#eval(pztv.getURL(lnk))
		except: 
			print 'err current_epg '+id
		
		if EPG!={}:
					try:EPG0_time=time.ctime(eval(EPG[0]['time']))[-13:-8]
					except: EPG0_time=''
					try:EPG0_title=EPG[0]['title']
					except: EPG0_title=''
					try:EPG0_img=EPG[0]['img']
					except: EPG0_img=background
					if EPG0_img=='':EPG0_img=background
					try:EPG0_plot=EPG[0]['plot']
					except: EPG0_plot=''
					try:EPG0_type=EPG[0]['type']
					except: EPG0_type=''
					
					try:EPG1_time=time.ctime(eval(EPG[1]['time']))[-13:-8]
					except: EPG1_time=''
					try:EPG1_title=EPG[1]['title']
					except: EPG1_title=''
					
					try:EPG2_time=time.ctime(eval(EPG[2]['time']))[-13:-8]
					except: EPG2_time=''
					try:EPG2_title=EPG[2]['title']
					except: EPG2_title=''
					
		else:
					EPG0_time=''
					EPG0_title=''
					EPG0_img=background
					EPG0_plot=''
					EPG0_type=''
					EPG1_time=''
					EPG1_title=''
					EPG2_time=''
					EPG2_title=''
		
		if EPG0_time!='' and EPG1_time!='':
				t0=eval(EPG[0]['time'])
				t1=eval(EPG[1]['time'])
				tc=time.time()
				total=t1-t0
				back=tc-t0
				percent=int(back*100/total)
				for i in range(0,11):
					if i*10 <= percent < i*10+10 :  item.setProperty('EPG_pr'+str(i*10), 'true')
					else:				item.setProperty('EPG_pr'+str(i*10), 'false')
		
		if __settings__.getSetting("fanart")=='false': EPG0_img=background
		
		if __settings__.getSetting("typeart")=='true': 
			if EPG0_type=='':EPG0_type=get_type(EPG0_title)
			if EPG0_type!='' and EPG0_img==background: EPG0_img=get_type_art(EPG0_type)
		item.setProperty('EPG0_time',  EPG0_time)
		item.setProperty('EPG0_title', EPG0_title)
		item.setProperty('EPG0_img',   EPG0_img)
		item.setProperty('EPG0_plot',  EPG0_plot)#EPG0_type+"\n"+
		
		item.setProperty('EPG1_time',  EPG1_time)
		item.setProperty('EPG1_title', EPG1_title)
		item.setProperty('EPG2_time',  EPG2_time)
		item.setProperty('EPG2_title', EPG2_title)
		self.setINFO()
		#return item
		
	def showList(self):
		
		#url='http://emu-russia.net/ru/roms/nes/rac/full/'
		type='snes'
		type=__settings__.getSetting('type')
		L=rgbrowser.my1(type)
		list1=self.getControl(600)
		list1.reset()
		
		pos_set=True
		Lgr=['Все',]
		genre =__settings__.getSetting("Sel_gr")
		for i in L:
				#print i
				title=i['title']
				if i['genre'] not in Lgr: Lgr.append(i['genre'])
				item = xbmcgui.ListItem(title)
				item.setProperty('background', background)
				item.setProperty('title', i['title'])
				item.setProperty('picon', i['cover'])
				item.setProperty('fanart', i['fanart'])
				item.setProperty('plot', i['plot'])
				item.setProperty('year', i['year'])
				item.setProperty('genre', i['genre'])
				item.setProperty('url', i['url'])
				item.setProperty('type', i['type'])
				
				if genre == i['genre'] or genre == 'Все': list1.addItem(item)
		
		#Группы
		self.getControl(95).setLabel('Консоль: '+type.upper()+'      Жанр: '+__settings__.getSetting("Sel_gr"))
		list2=self.getControl(800)
		list2.reset()
		#Lgr=['Все', 'Файтинг', 'Платформер']#pztv.select_gr('', True)
		n=0
		for i in Lgr:
				item = xbmcgui.ListItem(str(i))
				list2.addItem(item)
		
		if len(L)>0: self.setFocus(self.getControl(CONTROL_GAMES_GROUP_START))
		else:self.setFocus(self.getControl(800))







def main():
	#settings = util.getSettings()
	#skin = settings.getSetting(util.SETTING_RCB_SKIN)
	#if(skin == "Confluence"):
	skin = "Default"
	ui = UI_XML("RG-main.xml", addon.getAddonInfo('path'), skin, "720p")
	ui.doModal()
	del ui

def info(path):
	__settings__.setSetting('path', path)
	skin = "Default"
	ui2 = UI_INF("RG-info.xml", addon.getAddonInfo('path'), skin, "720p")
	ui2.doModal()
	del ui2


def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

params = get_params()

try:mode = urllib.unquote_plus(params["mode"])
except:mode =""
try:path = urllib.unquote_plus(params["path"])
except:path = rgbrowser.RDir
try:name = urllib.unquote_plus(params["name"])
except:name = "noname"
try:cover = urllib.unquote_plus(params["cover"])
except:cover = ""
try:funart = urllib.unquote_plus(params["funart"])
except:funart = ""

try:type = urllib.unquote_plus(params["type"])
except:type = "x"

try:inf = urllib.unquote_plus(params["inf"])
except:inf = ""


if mode=="":rgbrowser.root()
if mode=="run":rgbrowser.run(path)
if mode=="info": 
	xbmcplugin.endOfDirectory(handle, False, False)
	info (path)
	print path #rgbrowser.run(path)

if mode=="OnlRoot":
	rgbrowser.OnlRoot()
	#xbmcplugin.endOfDirectory(handle, False, False)
	#main()
	
if mode=="OnlList":
	#OnlList(path, type)
	__settings__.setSetting('type', type)
	__settings__.setSetting("Sel_gr",'Все')
	xbmcplugin.endOfDirectory(handle, False, False)
	main()

if mode=="GBAList":GBAList(path, type, cover)
if mode=="GBAGenre":GBAGenre(path, type)
if mode=="Genre":Genre(path, type)
if mode=="sel_dload":
	try:
		r=select(name, cover, funart)
		if r=="save":sel_dload(name, type, path, cover, funart)
		if r=="run":sel_play(path)
	except:
		sel_dload(name, type, path, cover, funart)

if mode=="dload":
	try:
		r=select(name, cover)
		if r=="save":dload(name, type, path, cover, funart, inf)
		if r=="run":play(path)
	except:
		dload(name, type, path, cover, funart)

if mode=="rem":rgbrowser.rem(path)
if mode=="rem2":rgbrowser.rem2(path)

#xbmcplugin.endOfDirectory(handle, False, False)
