# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, sys, time, random
PLUGIN_NAME   = 'plugin.game.startime'
handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id=PLUGIN_NAME)
__settings__ = xbmcaddon.Addon(id=PLUGIN_NAME)
icon = os.path.join(addon.getAddonInfo('path'), 'icon.png')
background = os.path.join(addon.getAddonInfo('path'), 'fanart.jpg')
dict_path = os.path.join(addon.getAddonInfo('path'), 'dict.txt')
mp3_path = os.path.join(addon.getAddonInfo('path'), 'beep.mp3')
word_length_max = int(__settings__.getSetting("max"))+10
word_length_min = int(__settings__.getSetting("min"))+5
tm = (int(__settings__.getSetting("tm"))+2)*20

if sys.version_info.major > 2:  # Python 3 or later
	import urllib.request
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
	from urllib.parse import urlencode
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote_plus as unquote
	import urllib2
	from urllib import urlencode

def b2s(s):
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		return s
	else:
		return s

def abortRequested():
	if sys.version_info.major > 2: return xbmc.Monitor().abortRequested()
	else: return xbmc.abortRequested

def READ(fn):
	fl = open(fn, "rb")
	r=b2s(fl.read())
	fl.close()
	return r

def filtr(line):
	line = line[:80]
	if ' м. ' in line or ' ж. ' in line or ' с. ' in line and 'II сущ.' not in line and 'сов. и несов.' not in line: return True
	else: return False

def get_word():
	dict_str = READ(dict_path)
	L = dict_str.splitlines()
	for i in range(1000):
		line = L[random.randint (1,len(L)-1)]
		if filtr(line):
			w = line [:line.find(' ')].replace(',','').replace('.','')
			if sys.version_info.major > 2: k=1
			else: k=2
			if len(w) >= word_length_min*k and len(w) <= word_length_max*k: return w
	return 'АКВАМАРИН'


def get_timer(t):
	h=int(t/60)
	s=t-h*60
	sh = str(h)
	ss = str(s)
	if s<10: ss='0'+ss
	return sh+':'+ss

def new_game():
	W=get_word()
	pref = '[COLOR 00000000]'+'_'*(30-int(len(W)/4))+'[/COLOR]'
	progressBar = xbmcgui.DialogProgress()
	progressBar.create('Звездный Час', ' ')
	progressBar.update(0, ' ')
	#xbmc.Player().play(mp3_path)
	for i in range(tm):
		timer = get_timer(tm-i)
		try:    progressBar.update(int(i*100/tm), ' ', pref+'[B]'+W+'[/B]', timer)
		except: progressBar.update(int(i*100/tm), '\n'+pref+'[B]'+W+'[/B]'+'\n'+ timer)
		if progressBar.iscanceled() or abortRequested(): break
		xbmc.sleep(1000)
		
	progressBar.update(100)
	xbmc.Player().play(mp3_path)
	progressBar.close()

def root():
	listitem = xbmcgui.ListItem('Новая игра')
	listitem.setArt({ 'poster': icon, 'fanart' : background, 'thumb': icon, 'icon': icon})
	uri = sys.argv[0]+'?mode=new'
	xbmcplugin.addDirectoryItem(handle, uri, listitem, False)
	xbmcplugin.endOfDirectory(handle)


def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param


try:    mode = unquote(get_params()["mode"])
except: mode = ""

if mode==""          : root()
if mode=="new"       : new_game()

