# -*- coding: utf-8 -*-
print ('-=-=- muzofond.fm -=-=-')
import sys, os, time
import uscode
import ssl
try: # Игнорирование SSl сертификата
	ctx = ssl.create_default_context()
	ctx.check_hostname = False
	ctx.verify_mode = ssl.CERT_NONE
except: pass

httpurl='https://muzofond-fm.translate.goog'


# =========================функции для совместимости с коди 19 ===============================
if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2

def b2s(s):
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		return s
	else:
		return s
# ============================== текстовые функции ====================================
def rt(s): return uscode.decode(s)
def ru(x):return unicode(x,'utf8', 'ignore')

def find_all(http, ss, es): # Ищет все элементы начинающиеся с ss и заканчивающиеся на es
	L=[]
	while http.find(es)>0:
		s=http.find(ss)+len(ss)
		http=http[s:]
		e=http.find(es)
		i=http[:e]
		L.append(i)
		http=http[e+1:]
	return L

def mfind(t,s,e): # Ищет первый встреченый текст с ss и заканчивающиеся на es
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

# ============================== функции загрузки данных с сайта ====================================
def POST(target, post=None, referer=httpurl):
	#print target
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
		req.add_header('Accept', 'application/json, text/javascript, */*; q=0.01')
		req.add_header('Accept-Language', 'ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4')
		req.add_header('Referer', referer)
		resp = urllib2.urlopen(req)
		http = b2s(resp.read())
		resp.close()
		return http
	except:
		return ''

def GET(url, Referer = ''):
	print (url)
	req = urllib2.Request(goo(url))
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	try:    response = urllib2.urlopen(req)
	except: response = urllib2.urlopen(req, context=ctx)
	link=b2s(response.read())
	response.close()
	return link

def title_parser(t):
	if '(' in t: 
		title = t[:t.find('(')]
		tmp = mfind(t,'(',')')
		if ' ' in tmp:
			year = tmp[-4:]
			album = tmp[:-4].strip()
		else: 
			year = tmp
			album = ''
		return {'title':title, 'album':album, 'year':year}
	else: return {'title':t, 'album':'', 'year':''}
# ============================== функции запросов к сайту и их парсингу ====================================

def get_tracks(hp): # Ищет строки с треками и парсит из них ссылку, автора и название трека
	img = mfind(hp, '<img src="/images/album.svg" lazyload loading="lazy" data-src="', '"').replace('small','large')
	L1=find_all(hp, '<li class="item"', '<div class="addedSuccess">')
	L=[]
	for i in L1:
		#print (i)
		info={
		'artist':		mfind(i,'class="artist">', '<'),
		'title':		mfind(i,'class="track">', '<'),
		'url':			mfind(i,'data-url="', '"'),
		'cover':		httpurl+mfind(i,'data-img="', '"'),
		'duration':		mfind(i,'data-duration="', '"'),
		'type':			'track'
		}
		
		ti = title_parser(info['title'])
		info['title'] = ti['title']
		info['album'] = ti['album']
		info['year'] = ti['year']
		
		if info['cover'] == httpurl: info['cover'] = httpurl+img
		
		#print (info)
		L.append(info)
		
	return L

def get_dirs(hp): # Ищет строки с альбомами и парсит из них ссылку, название
	#print(hp)
	L1=find_all(hp, ' class="item"', '</a>')#<li
	
	L=[]
	for i in L1:
		if 'lazyload' in i:
			#print (i)
			info={
			#'artist':		mfind(i,'class="artist">', '<'),
			'title':		mfind(i,'class="title">', '<'),
			'url':			mfind(i,'<a href="', '"'),
			'cover':		httpurl+mfind(i,'lazyload data-src="', '"'),
			'type':			'album'
			}
			print (info)
			L.append(info)
		
	return L


def get_list(cat): # Составляет запрос к каталогам сайту и загружает страницу
	#if cat == 'porular': cat = '?page=1'
	#url=httpurl+'/'+cat+'/'
	if httpurl in cat : url=quote(cat).replace('%3A//','://')
	else: url=httpurl+'/'+quote(cat).replace('%3A//','://')
	
	hp=rt(GET(url))
	L = get_tracks(hp)
	return L

def get_collect(cat): # Составляет запрос к каталогам сайту и загружает страницу
	if httpurl in cat : url=quote(cat).replace('%3A//','://')
	else: url=httpurl+'/'+quote(cat).replace('%3A//','://')
	hp=rt(GET(url))
	L = get_dirs(hp)
	return L

def get_genres():
	hp=rt(GET(httpurl+'/popular'))
	L1=find_all(hp, '<li>', '</li>')
	L=[]
	for i in L1:
			info={
			'title':		mfind(i,'">', '<').replace('\n','').strip(),
			'url':			mfind(i,'<a href="', '"'),
			'type':			'album'
			}
			print (info)
			if len(info['title'])>3: L.append(info)
		
	return L



def serch(s):# Составляет поисковый запрос к сайту и загружает страницу
	url=httpurl+'/search/'+quote(s)
	hp=rt(GET(url))
	L = get_tracks(hp)
	return L
	
	
def goo(url):
	url=url.replace('?_x_tr_sl=en&amp;_x_tr_tl=ru&amp;_x_tr_hl=ru&amp;_x_tr_pto=wapp','')
	if '%3F_x_tr' in url: url=url[:url.find('%3F_x_tr')]
	url=url+'?_x_tr_sl=en&_x_tr_tl=ru&_x_tr_hl=ru&_x_tr_pto=wapp'
	return url
#get_collect('collections/new')
#serch('машина')
#time.sleep(10)
