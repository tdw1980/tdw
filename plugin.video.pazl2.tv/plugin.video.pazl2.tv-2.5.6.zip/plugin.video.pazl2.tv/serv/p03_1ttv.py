#!/usr/bin/python
# -*- coding: utf-8 -*-

import string, xbmc, xbmcgui, xbmcplugin, xbmcaddon
import os, cookielib, urllib, urllib2, time
addon = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
__settings__ = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
#-----------------------------------------

icon = ""
serv_id = '3'
siteUrl = 'Torrent-tv.ru'
httpSiteUrl = 'http://' + siteUrl
sid_file = os.path.join(xbmc.translatePath('special://temp/'), siteUrl+'.sid')

cj = cookielib.FileCookieJar(sid_file) 
hr  = urllib2.HTTPCookieProcessor(cj) 
opener = urllib2.build_opener(hr) 
urllib2.install_opener(opener) 

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def unmark(nm):
	for i in range (0,20):
		nm=nm.replace(" #"+str(i),"")
	return nm

def lower_old(s):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.lower().encode('utf-8')
	return s

def lower(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in range (65,90):
		t=t.replace(chr(i),chr(i+32))
	for i in RUS.keys():
		t=t.replace(i,RUS[i])
	return t

def upper(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in RUS.keys():
		t=t.replace(RUS[i],i)
	for i in range (65,90):
		t=t.replace(chr(i+32),chr(i))
	return t

def get_HTML(url, post = None, ref = None, get_redirect = False):
    import urlparse
    if url.find('http')<0 :
        if CT=="0": url='http:'+url
        else: url='https:'+url
    #url="http://translate.googleusercontent.com/translate_c?u="+url
    request = urllib2.Request(url, post)

    host = urlparse.urlsplit(url).hostname
    if ref==None:
        try:
           ref='http://'+host
        except:
            ref='localhost'

    request.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
    request.add_header('Host',   host)
    request.add_header('Accept', 'text/html, application/xhtml+xml, */*')
    request.add_header('Accept-Language', 'ru-RU')
    request.add_header('Referer',             ref)
    request.add_header('Content-Type','application/x-www-form-urlencoded')

    try:
        f = urllib2.urlopen(request)
    except IOError, e:
        if hasattr(e, 'reason'):
           print('We failed to reach a server.')
        elif hasattr(e, 'code'):
           print('The server couldn\'t fulfill the request.')
        return 'We failed to reach a server.'

    if get_redirect == True:
        html = f.geturl()
    else:
        html = f.read()

    return html

def Login():
	url1 = 'http://torrent-tv.ru/auth.php'
	login = __settings__.getSetting("ttv_login")
	passw = __settings__.getSetting("ttv_password")
	if login == '' or passw == '': return False
	
	values = {
				'email'     : login,
				'password'  : passw,
				'remember'    : 'on',
				'enter'    : 'Войти'
		}
	post = urllib.urlencode(values)
	html = get_HTML(url1, post, 'http://torrent-tv.ru/')
	return True

def getURL(url, Referer = httpSiteUrl):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def get_ttv(url):
		#print '====================================='
		NoxBit=__settings__.getSetting("NoxBit")
		url=url.replace('http://1ttv.net/iframe.php?site=1714&channel=', 'http://torrent-tv.ru/torrent-online.php?translation=')
		if NoxBit=='true': url+='&engine=noxbit'
		else: url+='&engine=acestream'
		print url
		Login()
		#print 'login'
		http=getURL(url)
		#http=getURL('http://1ttv.net/acestream.php', url)
		#print http
		
		ss1='this.loadPlayer("'
		ss2='.acelive'
		es='",{autoplay: true})'
		srv=__settings__.getSetting("p2p_serv")
		prt=__settings__.getSetting("p2p_port")
		
		if NoxBit=='true':
			url2=http[http.find('http://1ttvapi'):http.find('" data-quick_auth3')]
			m3u=getURL(url2)
			Ls=m3u.split()
			for i in Ls:
				if 'http://' in i :
					#print i
					return i
			return ""
		else:
			try:
				if ss2 in http:
					#print 'acelive'
					AL=mfindal(http,'http://content.','.acelive')[0]+'.acelive'
					#print AL
					if 'cdn/0_' in AL: return ""
					lnk='http://'+srv+':'+prt+'/ace/getstream?url='+AL
					if len(AL)<30:lnk=''
					return lnk
				else: return ""
			except:
				return ""

def dload_epg_xml():
	#try:
			target='http://api.torrent-tv.ru/ttv.xmltv.xml.gz'
			#print "-==-=-=-=-=-=-=- download =-=-=-=-=-=-=-=-=-=-"
			fp = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'tmp.zip'))
			
			req = urllib2.Request(url = target, data = None)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			fl = open(fp, "wb")
			fl.write(resp.read())
			fl.close()
			#print "-==-=-=-=-=-=-=- unpak =-=-=-=-=-=-=-=-=-=-"
			xml=ungz(fp)
			#print "-==-=-=-=-=-=-=- unpak ok =-=-=-=-=-=-=-=-=-=-"
			#os.remove(fp)
			return xml[:120000]
	#except Exception, e:
	#		print 'HTTP ERROR ' + str(e)
	#		return ''

def ungz(filename):
	import gzip
	with gzip.open(filename, 'rb') as f:
		file_content = f.read()
		return file_content

def save_channels(ns, L):
		fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'Channels'+ns+'.py'))
		fl = open(fp, "w")
		fl.write('# -*- coding: utf-8 -*-\n')
		fl.write('Channels=[\n')
		for i in L:
			fl.write(repr(i)+',\n')
		fl.write(']\n')
		fl.close()

def save_aid(ns, d):
		fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'aid'+ns+'.py'))
		fl = open(fp, "w")
		fl.write('# -*- coding: utf-8 -*-\n')
		fl.write('n2id=')
		fl.write(repr(d))
		fl.close()



def logos(id, img):
		import logodb
		Ldb=logodb.ttvlogo
		try: dbimg=Ldb[id]
		except: 
			Ldb[id]=img
			fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'logodb.py'))
			fl = open(fp, "w")
			fl.write('# -*- coding: utf-8 -*-\n')
			fl.write('ttvlogo={\n')
			for i in Ldb.items():
				fl.write('"'+i[0]+'":"'+i[1]+'",\n')
			fl.write('}')
			fl.close()

def titles(id, title):
		title=lower(title).strip()
		import xid
		Tdb=xid.xmlid
		try: dbt=Tdb[title]
		except:
			Tdb[title]='ttv'+id
			fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'xid.py'))
			fl = open(fp, "w")
			fl.write('# -*- coding: utf-8 -*-\n')
			fl.write('xmlid={\n')
			for i in Tdb.items():
				fl.write('"'+i[0]+'":"'+i[1]+'",\n')
			fl.write('}')
			fl.close()

def get_category(hp):
	try:
		Lr=[]
		L=mfindal(hp,'ory.php?cat','<a href="/cate')
		for i in L:
			cat=upper(i[i.find('">')+2:i.find('</a>')])
			if cat!='' and len(cat)<40:
				Lr.append([cat, i])
		return Lr
	except:
		return []

class PZL:
	def __init__(self):
		pass

	def Streams(self, url):
		try:
			print url
			trst=get_ttv(url)
			if trst=="":return []
			else:return [trst,]
		except:
			return []

	def Canals(self):
		url='http://torrent-tv.ru/channels.php'
		Login()
		http=getURL(url)
		category=get_category(http)
		for i in category:
			print i[0]
			print i[1]
		ss='<div class="best-channels-content'
		es='</h5>'
		L=mfindal(http, ss, es)
		LL=[]
		Lid=['',]
		for i in L:
			title = i[i.find('<strong>')+8:i.find('</strong>')]
			title = title.replace('(резерв)','').replace('Резерв 1','').replace('Резерв 2','').replace('Резерв 3','').replace('(4:3)','').replace('[LQ]','').strip()
			url=''
			img=''
			id= ''
			for j in i.splitlines():
				if 'translation' in j:
									id  = j[j.find('translation=')+12:j.find('">')]
									url = 'http://1ttv.net/iframe.php?site=1714&channel='+id
				if 'img src' in j:  img   = 'http://torrent-tv.ru/'+j[j.find('<img src="')+10:j.find('.png')]+'.png'
				
			if id not in Lid:
				Lid.append(id)
				
				gr=''
				for i in category:
					if title in i[1]:gr=i[0]
				print title+' > '+gr
				LL.append({'url':url, 'img':img, 'title':title, 'group':gr})

		if LL!=[]: save_channels(serv_id, LL)
		else: showMessage('torrent-tv.ru', 'Не удалось загрузить каналы', times = 3000)

		return LL

