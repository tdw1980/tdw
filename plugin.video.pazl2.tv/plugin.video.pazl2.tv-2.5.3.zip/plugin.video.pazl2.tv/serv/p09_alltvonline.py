#!/usr/bin/python
# -*- coding: utf-8 -*-

import string, xbmc, xbmcgui, xbmcplugin, xbmcaddon
import os, cookielib, urllib, urllib2, time
addon = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
__settings__ = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
#-----------------------------------------

icon = ""
serv_id = '9'
siteUrl = 'www.alltvonline.ru'
httpSiteUrl = 'http://' + siteUrl
sid_file = os.path.join(xbmc.translatePath('special://temp/'), siteUrl+'.sid')

cj = cookielib.FileCookieJar(sid_file) 
hr  = urllib2.HTTPCookieProcessor(cj) 
opener = urllib2.build_opener(hr) 
urllib2.install_opener(opener) 

def fs(s):return s.decode('windows-1251').encode('utf-8')
def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def getURL(url, Referer = httpSiteUrl):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def save_channels(n, L):
		ns=str(n)
		fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'Channels'+ns+'.py'))
		fl = open(fp, "w")
		fl.write('# -*- coding: utf-8 -*-\n')
		fl.write('Channels=[\n')
		for i in L:
			fl.write(repr(i)+',\n')
		fl.write(']\n')
		fl.close()

def bllist(url):
	L=['qwer666','tvrec','peers']
	for i in L:
		if i in url: return False
	return True

class PZL:
	def __init__(self):
		pass

	def Streams(self, url):
		if 'alltvonline.ru' in url:
			L=[]
			try:
				#print url
				http=getURL(url)
				ht=http
				http=http[http.find('var m_link = ')+14:]
				http=http[:http.find("';")]
				#print http
				import base64
				url1=base64.decodestring(http)
				if bllist(url1): L.append(url1)
				#print url1
				
				if 'source=2' in ht:
					http=getURL(url+'?source=2')
					http=http[http.find('var m_link = ')+14:]
					http=http[:http.find("';")]
					#print http
					import base64
					url2=base64.decodestring(http)
					if bllist(url2): L.append(url2)
					#print url2
				return L
			except:
				return []

	def Canals(self):
			LL=[]
			url=httpSiteUrl+'/api/channels?language_id=2'
			http=getURL(url)
			
			L=eval(http)["channels"]
			
			for i in L:
				url=httpSiteUrl+'/channel/'+i["url"]
				img=httpSiteUrl+'/data/channels/'+i["url"]
				title=xt(eval('u"'+i["name"].replace('\\\\','\\')+'"'))
				title=title.replace('Крик ТВ', 'Крик-ТВ')
				
				LL.append({'url':url, 'img':img, 'title':title})
				
			if LL!=[]:save_channels(serv_id, LL)
			else:showMessage('peers.tv', 'Не удалось загрузить каналы', times = 3000)
			
			return LL
