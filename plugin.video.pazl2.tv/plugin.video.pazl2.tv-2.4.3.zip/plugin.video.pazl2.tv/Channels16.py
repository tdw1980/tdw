# -*- coding: utf-8 -*-
Channels=[
{'url': 'https://player.vgtrk.com/iframe/live/id/55333/showZoomBtn/false/isPlay/true/', 'group': '', 'img': 'http://live.russia.tv/i/small_logo/ch-logo-86.png', 'title': '\xd0\xa0\xd0\xbe\xd1\x81\xd1\x81\xd0\xb8\xd1\x8f HD'},
{'url': 'https://player.vgtrk.com/iframe/live/id/4941/showZoomBtn/false/isPlay/true/', 'group': '', 'img': 'http://live.russia.tv/i/small_logo/ch-logo-82.png', 'title': '\xd0\xa0\xd0\xbe\xd1\x81\xd1\x81\xd0\xb8\xd1\x8f \xd0\xa0\xd0\xa2\xd0\xa0'},
{'url': 'https://player.vgtrk.com/iframe/live/id/19201/showZoomBtn/false/isPlay/true/', 'group': '', 'img': 'http://live.russia.tv/i/small_logo/ch-logo-4.png', 'title': '\xd0\x9a\xd1\x83\xd0\xbb\xd1\x8c\xd1\x82\xd1\x83\xd1\x80\xd0\xb0'},
{'url': 'https://player.vgtrk.com/iframe/live/id/2961/showZoomBtn/false/isPlay/true/', 'group': '', 'img': 'http://live.russia.tv/i/small_logo/ch-logo-1.png', 'title': '\xd0\xa0\xd0\xbe\xd1\x81\xd1\x81\xd0\xb8\xd1\x8f 1'},
{'url': 'https://player.vgtrk.com/iframe/live/id/1661/showZoomBtn/false/isPlay/true/', 'group': '', 'img': 'http://live.russia.tv/i/small_logo/ch-logo-76.png', 'title': '\xd0\x9c\xd0\xbe\xd1\x81\xd0\xba\xd0\xb2\xd0\xb0 24'},
{'url': 'https://player.vgtrk.com/iframe/live/id/52035/showZoomBtn/false/isPlay/true/', 'group': '', 'img': 'http://live.russia.tv/i/small_logo/ch-logo-199.png', 'title': '\xd0\x92\xd0\xb5\xd1\x81\xd1\x82\xd0\xb8 FM'},
{'url': 'https://player.vgtrk.com/iframe/live/id/21/showZoomBtn/false/isPlay/true/', 'group': '', 'img': 'http://live.russia.tv/i/small_logo/ch-logo-3.png', 'title': '\xd0\xa0\xd0\xbe\xd1\x81\xd1\x81\xd0\xb8\xd1\x8f 24'},
]
