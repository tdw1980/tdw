# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, urllib, sys, urllib2, time
#nt=time.time()
PLUGIN_NAME   = 'plugin.video.pazl2.tv'
#handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
__settings__ = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
try: arhive = xbmcaddon.Addon(id='plugin.video.pazl.arhive')
except: pass

Pdir = addon.getAddonInfo('path')
icon = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'icon.png'))
fanart = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'fanart.png'))
Logo = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'logo'))
UserDir = xbmc.translatePath(os.path.join(xbmc.translatePath("special://masterprofile/"),"addon_data","plugin.video.pazl2.tv"))

#xbmcplugin.setContent(int(sys.argv[1]), 'movies')

sys.path.append(os.path.join(addon.getAddonInfo('path'),"serv"))
ld=os.listdir(os.path.join(addon.getAddonInfo('path'),"serv"))
Lserv=[]
for i in ld:
	if i[-3:]=='.py': Lserv.append(i[:-3])


#sys.path.append(os.path.join(addon.getAddonInfo('path'),"arh"))
#ld=os.listdir(os.path.join(addon.getAddonInfo('path'),"arh"))
#Larh=[]
#for i in ld:
#	if i[-3:]=='.py': Larh.append(i[:-3])

UrlCashe={}
BanCashe=[]

from DefGR import *


def save_DBC(DBC):
		fp=xbmc.translatePath(os.path.join(UserDir, 'UserDBcnl.py'))
		fl = open(fp, "w")
		fl.write('# -*- coding: utf-8 -*-\n')
		fl.write('DBC={\n')
		for i in DBC.items():
			fl.write("'"+i[0]+"':"+repr(i[1])+',\n')
		fl.write('}\n')
		fl.close()

sys.path.append(UserDir)
try: 
	from UserDBcnl import *
except: 
	from DBcnl import *
	try: save_DBC(DBC)
	except: pass

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def CRC32(buf):
		import binascii
		buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		return str("%08X" % buf)

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def fs_enc(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode('utf-8').encode(sys_enc)

def fs_dec(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode(sys_enc).encode('utf-8')

def lower_old(s):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.lower().encode('utf-8')
	return s

def lower(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in range (65,90):
		t=t.replace(chr(i),chr(i+32))
	for i in RUS.keys():
		t=t.replace(i,RUS[i])
	return t

def upper(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in RUS.keys():
		t=t.replace(RUS[i],i)
	for i in range (65,90):
		t=t.replace(chr(i+32),chr(i))
	return t

if __settings__.getSetting("ACE_API")=='true': 
	import socket, threading, re

	class _TSServ(threading.Thread):
		def __init__(self, socket):
			self.pkey = 'n51LvQoTlJzNGaFxseRK-uvnvX-sD4Vm5Axwmc4UcoD-jruxmKsuJaH0eVgE'
			threading.Thread.__init__(self)
			self._sock = socket
			self._buffer = 65 * 1024
			self._last_received = ''
			self.active = True
			self.err = False
			self.auth_ok = False
			self.version = None
			self.files = None
			self.key = None
			self.index = None
			self.content_url = None
			self.can_save = False
			self.save_info = None
			self.state = 0
			self.status = [0, '', '']
			self.pause = False
			self.vod = True

		def push(self, command):
			print ('TSSERV: [%s]' % command)
			try:
				self._sock.send(command + '\r\n')
			except:
				self.err = True

		def run(self):
			while self.active and not self.err:
				try:
					self.temp = self._sock.recv(self._buffer)
				except:
					self.temp = ''
				self._last_received += self.temp
				ind = self._last_received.find('\r\n')
				if ind != -1:
					fcom = self._last_received
					while ind != -1:
						self._last_received = fcom[:ind]
						self.exec_com()
						fcom = fcom[(ind + 2):]
						ind = fcom.find('\r\n')
					self._last_received = ''

		def exec_com(self):
			line = self._last_received
			cmd = self._last_received.split(' ')[0]
			params = self._last_received.split(' ')[1::]
			if cmd != 'STATUS':
				print('TSSERV: {%s}' % self._last_received)
			if cmd == 'HELLOTS':
				try:
					self.version = params[0].split('=')[1]
				except:
					self.version = '1.0.6'
				try:
					if params[2].split('=')[0] == 'key':
						self.key = params[2].split('=')[1]
				except: 
					try:
						self.key = params[1].split('=')[1]
					except:
						print('TSSERV: no HELLO key received')
			elif cmd == 'AUTH':
				self.auth_ok = True
			elif cmd == 'LOADRESP':
				self.files = line[line.find('{'):len(line)]
			elif cmd == 'EVENT':
				if params[0] == 'cansave':
					if int(self.index) == int(params[1].split('=')[1]):
						self.can_save = True
						self.save_info = [params[1], params[2]]
				elif params[0] == 'getuserdata':
					self.push('USERDATA [{"gender": 1}, {"age": 3}]')
					self.err = True
			elif cmd == 'START':
				try:
					self.content_url = urllib2.unquote(params[0].split('=')[1])
				except:
					self.content_url = params[0]
			elif cmd == 'RESUME':
				self.pause = False
			elif cmd == 'PAUSE':
				self.pause = True
			elif cmd == 'SHUTDOWN':
				self.active = False
			elif cmd == 'STATE':
				self.state = int(params[0])
				if self.state == 6:
					self.err = True
			elif cmd == 'STATUS':
				self._get_status(params[0])

		def _get_status(self, params):
			ss = re.compile(r'main:[a-z]+', re.S)
			s1 = re.findall(ss, params)[0]
			st = s1.split(':')[1]

		def end(self):
			self.active = False

	try:
		import _winreg
		try:
			t = _winreg.OpenKey(_winreg.HKEY_CURRENT_USER, r'Software\AceStream')
		except:
			t = _winreg.OpenKey(_winreg.HKEY_CURRENT_USER, r'Software\TorrentStream')
		port_file = os.path.join(os.path.dirname(_winreg.QueryValueEx(t, 'EnginePath')[0]), r'acestream.port')
		gf = open(port_file, 'r')
		tsport=int(gf.read())
	except:
			#return "X PORT"
			tsport=62062

	sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	sock.connect(('127.0.0.1', tsport))
	#sock.settimeout(3)
	tsserv = _TSServ(sock)





class pPlayer(xbmc.Player):
	def __init__(self):
		print '===================================================================================== init ============================================'
		pass
		
	def onPlayBackStarted(self):
		print '===================================================================================== PlayBackStarted ============================================'
		xbmc.sleep(1000)
		#try: PlayingFile = self.getPlayingFile()
		#except: PlayingFile = ''
		Duration='0'
		n=0
		while xbmc.Player().isPlaying():
				print '===================================================================================== PlayBack ============================================'
				xbmc.sleep(1000)
				print xbmc.getInfoLabel('Player.Duration')
				if Duration==xbmc.getInfoLabel('Player.Duration'):
					n+=1
					print n
					#if n > 20: 
					#	Player.stop()
					#	Player.play(playlist, windowed=True)
				else:
					n=0
				Duration=xbmc.getInfoLabel('Player.Duration')
		print '===================================================================================== PlayBack STOP ============================================'
		
	def onPlayBackEnded(self):
		print '===================================================================================== onPlayBackEnded ============================================'



def getURL2(url):
	try:
		import requests
		try:
			s = requests.session()
			r=s.get(url, timeout=(0.1, 5), verify=False).text#0.00001
		except:
			print 'requests: timeout'
			r=''
		#r=r.encode('windows-1251')
		return r
	except:
		return ''


def getURL(url, Referer = 'http://viks.tv/'):
	return getURL2(url)
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def testURL(url):
	try:
		if 'gavrilovka.iptvbot' in url: return 999
		if 'ace/getstream' in url: 
			if __settings__.getSetting("p2p_test")=='true': url=url.replace('ace/getstream', 'ace/manifest.m3u8')
			else: return 0
		import requests
		from datetime import datetime
		s = requests.session()
		d = datetime.now()
		try:
			r=s.get(url, timeout=(1, 0.00001))
		except requests.exceptions.ReadTimeout:
				return int(str(datetime.now() - d)[-6:-3])
		except requests.exceptions.ConnectTimeout:
				return 999
	except:
		return 999


def GETimg(target, nmi):
	#lfimg=os.listdir(Logo)
	if nmi =='':return target
	
	LogoDir=__settings__.getSetting("logodir")
	if LogoDir=="":LogoDir=Logo
	path1 = fs_enc(os.path.join(LogoDir,nmi+'.png'))
	path2 = fs_enc(os.path.join(Logo,nmi+'.png'))
	try:
		print path1
		if os.path.isfile(path1): return path1
		else:
			if __settings__.getSetting("dllogo")=='false': return target
			print 'Загрузка логотипа: '+ nmi
			pDialog = xbmcgui.DialogProgressBG()
			pDialog.create('Пазл ТВ', 'Загрузка логотипа: '+ nmi)
			req = urllib2.Request(url = target, data = None)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			fl = open(path2, "wb")
			fl.write(resp.read())
			fl.close()
			pDialog.close()
			return path2
	except:
		print "err: "+target
		return target

def cllogo():
	LogoDir=__settings__.getSetting("logodir")
	if LogoDir=="":LogoDir=Logo
	L=os.listdir(LogoDir)
	BL=['0000','background']
	for i in L:
		id=i.replace('.png','')
		if id not in BL and 'png' in i:
			if id not in DBC.keys():
				path = fs_enc(os.path.join(LogoDir, i))
				os.remove(path)
				print i


def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		#sn=http[s:]
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "w")
	fl.write(s)
	fl.close()

def inputbox(t=''):
	skbd = xbmc.Keyboard(t, ' ')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return t



def next (dr='>'):
		ccn=__settings__.getSetting("cplayed")
		print ccn
		SG=get_SG()

		if dr=='>':
			__settings__.setSetting("lastnx",">")
			id =__settings__.getSetting("next_itm")
			
			#drs='>> \n'
		else: 
			id =__settings__.getSetting("prev_itm")
			__settings__.setSetting("lastnx","<")
			#drs='<< \n'
		__settings__.setSetting("v_id", id)
		name  = DBC[id]['title']
		#if __settings__.getSetting("epgosd")=='true':cgide=get_cgide(get_idx(Lnu[1]), 'serv')
		#else:
		#cgide=""
		#if __settings__.getSetting("split")=='true':nmc=unmark(Lnu[1])#.replace(" #1","")
		#else: nmc=Lnu[1]
		
		#Player.ov_update('[B]'+drs+"[COLOR FFFFFF00]"+name+"[/COLOR][/B]\n"+xt(cgide))
		play(id, name, ref=False)
		return id


def set_np ():
	id=__settings__.getSetting("cplayed")
	CL=get_cut_gr()
	n=CL.index(id)
	nn=n+1
	np=n-1
	if nn>=len(CL):nn=0
	__settings__.setSetting("next_itm",CL[nn])
	__settings__.setSetting("prev_itm",CL[np])
	
	L = get_all_channeles()
	next_urls=get_allurls(CL[nn], L)
	for url in next_urls:
		try: get_stream(url)
		except: pass
	
	prev_urls=get_allurls(CL[np], L)
	for url in prev_urls:
		try: get_stream(url)
		except: pass



def play_ace2(url):
	s=url.find('getstream?id=')
	if s<0: return ""
	PID=url[s+13:]
	print PID
	
	tsserv.start()
	tsserv.push('HELLOBG version=3')
	#command='HELLOBG version=3'
	#sock.send(command + '\r\n')
	n=0
	while not tsserv.version:
			print tsserv.version
			n+=1
			xbmc.sleep(200)
			if n>50: return "X HELLOBG"
	import hashlib
	sha1 = hashlib.sha1()
	pkey = tsserv.pkey
	sha1.update(tsserv.key + pkey)
	key = sha1.hexdigest()
	pk = pkey.split('-')[0]
	ready_key = 'READY key=%s-%s' % (pk, key)
	tsserv.push(ready_key)
	#sock.send(ready_key + '\r\n')

	n=0
	while not tsserv.auth_ok:
			n+=1
			xbmc.sleep(200)
			if n>50: return "X READY"
	#PID=url
	tsserv.push('START PID '+PID+' 0')
	while not tsserv.state == 2:
			n+=1
			xbmc.sleep(200)
			if n>50: return "X START"
	return tsserv.content_url

def ACE2_end():
	try:
		tsserv.push('SHUTDOWN')
		sock.shutdown(socket.SHUT_RDWR)
		sock.close()
	except:
		pass


playlist = xbmc.PlayList (xbmc.PLAYLIST_VIDEO)
def play(id, name='' ,cover='', ref=True):
	print '=-=-=-=-=-=-=-=-=-=-=-PLAY=-=-=-=-=-=-=-=-=-=-=-=-=-'
	if name=='':name  = DBC[id]['title']
	#xbmcplugin.endOfDirectory(handle, False, False)
	pDialog = xbmcgui.DialogProgressBG()
	try:pDialog.create(name, 'Поиск потоков ...')
	except: pass
	
	print name
	#print id
	#if name =='': name  = DBC[id]['title']
	if cover =='': cover = get_picon(id)
	
	L = get_all_channeles()
	urls=get_allurls(id, L)
	
	#print urls
	
	#__settings__.setSetting("play_tm",time.strftime('%Y%m%d%H%M%S'))
	#if ref==True:Player.stop()
	#Player.pause()
	Player.stop()
	
	Lpurl=[]
	for url in urls:
		#Lcurl=get_stream(url)
		try: Lcurl=get_stream(url)
		except:Lcurl=[]
		#print Lcurl
		for st in Lcurl:
			if st not in Lpurl: Lpurl.append(st)
		#try:Lpurl.extend(Lcurl)
		#except:pass
	
	Lpurl2=[]
	Lm3u8 =[]
	Lrtmp =[]
	Lp2p  =[]
	Lourl =[]
	Ltmp=[]
	
	if __settings__.getSetting("ace_start")=='true':
		for i in Lpurl:
			if '/ace/' in i: 
				ASE_start()
				break
	
	for i in Lpurl:
		tout=testURL(i)
		print str(tout)+" : "+i
		if i not in BanCashe and tout < 999:
			if '.m3u8' in i and i not in Lm3u8:  Lm3u8.append(i)
			elif 'rtmp' in i and i not in Lrtmp: Lrtmp.append(i)
			elif '/ace/' in i and i not in Lp2p: 
					if __settings__.getSetting("ACE_API")=='true': Lp2p.append(play_ace2(i))
					else: Lp2p.append(i)
			elif i not in Ltmp:                  Lourl.append(i)
			Ltmp.extend(Lp2p)
			Ltmp.extend(Lm3u8)
			Ltmp.extend(Lrtmp)
			Ltmp.extend(Lourl)
	
	#if __settings__.getSetting("ace_start")=='true' and len(Lp2p)>0: ASE_start()
	
	if __settings__.getSetting("p2p_link")=='true':
		L2n=[]
		for purl in Lp2p:
			tlnk=purl+'&format=json'
			try: json=eval(getURL(tlnk).replace('null','"None"'))
			except: json={"error":'404'}
			err=json["error"]
			if err=="None":
				purl=json["response"]["playback_url"]
				L2n.append(purl)
		Lp2p=L2n
	
	if __settings__.getSetting("p2p_start")=='true':
			Lpurl2.extend(Lp2p)
			Lpurl2.extend(Lm3u8)
			Lpurl2.extend(Lrtmp)
			Lpurl2.extend(Lourl)
	else:
			Lpurl2.extend(Lm3u8)
			Lpurl2.extend(Lourl)
			Lpurl2.extend(Lp2p)
			Lpurl2.extend(Lrtmp)
	
	if Lpurl2==[]:
		pDialog.close()
		#showMessage('Пазл ТВ', 'Канал недоступен')
		try:pDialog.create(name, '[COLOR FFFF5555]Канал недоступен[/COLOR]')
		except: pass

		#if __settings__.getSetting("xplay")=='true': Player.ov_hide()
		__settings__.setSetting("cplayed",id)
		try:n_play=int(__settings__.getSetting("n_play"))
		except:n_play=0
		if n_play<5:
			set_np ()
			__settings__.setSetting("n_play",str(n_play+1))
			pDialog.close()
			print 'NEXT '+__settings__.getSetting("lastnx")
			next (__settings__.getSetting("lastnx"))
		else:
			pDialog.close()
			return ""
		
	else:
		
		playlist.clear()
		
		n=1
		#if len(Lpurl2)>1:n=3
		
		for j in range (0,n): # несколько копий в плейлист
			k=0
			for purl in Lpurl2:
				k+=1
				if ':6878' in purl: name2='[P2P]'
				else:
					name2='['+purl.replace('://',']')
					name2=name2[:name2.find('/')]
				item = xbmcgui.ListItem(name2+" [ "+str(k)+"/"+str(len(Lpurl2))+" ]", path=purl, thumbnailImage=cover, iconImage=cover)
				playlist.add(url=purl, listitem=item)
		
		pDialog.close()
		#print Lpurl2
		__settings__.setSetting("cplayed",id)
		
		if __settings__.getSetting("xplay")=='false':
			Player.play(playlist)
		else:
			Player.play(playlist, windowed=True)
		#time.sleep(1)
		set_np ()
		#xbmc.sleep(300)
		
		try: PlayingFile=Player.getPlayingFile()
		except: PlayingFile=''
		if PlayingFile=='':
			try:BanCashe.append(Lpurl2[0])
			except: pass
			
			try:n_play=int(__settings__.getSetting("n_play"))
			except:n_play=0
			if n_play<3:
				__settings__.setSetting("n_play",str(n_play+1))
				next (__settings__.getSetting("lastnx"))
		
		print '=-=-=-=-=-=-=-=-=-=-=-PLAY-end=-=-=-=-=-=-=-=-=-=-=-=-=-'
		#xbmcplugin.endOfDirectory(handle)

def select_stream():
	#playlist = xbmc.PlayList (xbmc.PLAYLIST_VIDEO)
	L=[]
	for i in range(0,playlist.size()):
		item=playlist.__getitem__(i)
		L.append(item.getfilename())
	
	sel = xbmcgui.Dialog()
	r = sel.select("Источники:", L)
	
	if r>=0:
		Player.play(playlist, windowed=True, startpos=r)


def play_archive(urls, name ,cover, ref=True):
	#print urls
	Player.stop()
	pDialog = xbmcgui.DialogProgressBG()
	try:pDialog.create('Пазл ТВ', 'Поиск потоков ...')
	except: pass
	Lpurl=[]
	for url in urls:
		#Lcurl=get_stream(url)
		try: Lcurl=get_archive(url)
		except:Lcurl=[]
		#print Lcurl
		try:Lpurl.extend(Lcurl)
		except:Lcurl=[]
	
	Lpurl2=[]
	Lm3u8 =[]
	Lrtmp =[]
	Lp2p  =[]
	Lourl =[]
	Ltmp=[]
	
	for i in Lpurl:
		if '.m3u8' in i and i not in Lm3u8:  Lm3u8.append(i)
		elif 'rtmp' in i and i not in Lrtmp: Lrtmp.append(i)
		elif '/ace/' in i and i not in Lp2p: Lp2p.append(i)
		elif i not in Ltmp:                  Lourl.append(i)
		Ltmp.extend(Lp2p)
		Ltmp.extend(Lm3u8)
		Ltmp.extend(Lrtmp)
		Ltmp.extend(Lourl)
	
	if __settings__.getSetting("ace_start")=='true' and len(Lp2p)>0: ASE_start()
	
	if __settings__.getSetting("p2p_start")=='true':
			Lpurl2.extend(Lp2p)
			Lpurl2.extend(Lm3u8)
			Lpurl2.extend(Lrtmp)
			Lpurl2.extend(Lourl)
	else:
			Lpurl2.extend(Lm3u8)
			Lpurl2.extend(Lourl)
			Lpurl2.extend(Lp2p)
			Lpurl2.extend(Lrtmp)
	
	if Lpurl2==['12321',]:
		pDialog.close()
		showMessage('Пазл ТВ', 'Канал недоступен')
		return ""
		
	else:
		playlist = xbmc.PlayList (xbmc.PLAYLIST_VIDEO)
		playlist.clear()
		
		n=1
		if len(Lpurl2)>1:n=3
		
		for j in range (0,n): # несколько копий в плейлист
			k=0
			for purl in Lpurl2:
				k+=1
				if __settings__.getSetting("split")=='true':name2=unmark(name)#.replace(" #1","")
				else:name2=colormark(name)#.replace(" #1","[COLOR 40FFFFFF] #1[/COLOR]")
				item = xbmcgui.ListItem(name2+" [ "+str(k)+"/"+str(len(Lpurl2))+" ]", path=purl, thumbnailImage=cover, iconImage=cover)
				playlist.add(url=purl, listitem=item)
		
		for j in range (0,5):
			purl2=os.path.join(addon.getAddonInfo('path'),"2.mp4")
			item = xbmcgui.ListItem(" > ", path=purl2, thumbnailImage=cover, iconImage=cover)
			playlist.add(url=purl2, listitem=item)
		
		
		pDialog.close()
		
		Player.play(playlist)
		xbmc.sleep(1000)
		#xbmcplugin.endOfDirectory(handle)



Lmrk=[]
for i in range (0,100):
		Lmrk.append(str(i))
Lmrk.reverse()

def unmark(nm):
	for i in Lmrk:
		nm=nm.replace(" #"+str(i),"")
	return nm

def uni_mark(nm):
	try:nm=lower(nm)
	except:pass
	return nm

def colormark(nm):
	for i in Lmrk:
		nm=nm.replace(" #"+str(i),"[COLOR 40FFFFFF] #"+str(i)+"[/COLOR]")
	return nm


def get_stream(url):
	buf=CRC32(url)
	if buf in UrlCashe.keys():
		Cashe=UrlCashe[buf]
		if time.time()-Cashe['time'] < 300:
			print '==== Cashe ===='
			return Cashe['urls']
	
	for i in Lserv:
		ids=i[4:].replace('_','-')
		print ids
		if 'torrent-tv.ru' in url and ids=='1ttv': ids='torrent-tv'
		if ids in url:
			#print ids
			exec ("import "+i+"; serv="+i+".PZL()")
			Lcurl = serv.Streams(url)
			UrlCashe[CRC32(url)]={'urls':Lcurl, 'time': time.time()}
			#print UrlCashe
			return Lcurl
	return []


def get_archive(url):
	for i in Larh:
		ids=i[4:].replace('_','-')
		#print ids
		if ids in url:
			print ids
			exec ("import "+i+"; serv="+i+".ARH()")
			return serv.Streams(url)
	return []


def upd_canals_db(i):
	exec ("import "+i+"; serv="+i+".PZL()")
	L=serv.Canals()
	if __settings__.getSetting("addcnl")=='true': aggregate_cnl(L)
	return L

def aggregate_cnl(L):
	nm2id={}
	nml=[]
	for a in DBC.items():
		id=a[0]
		names=a[1]['names']
		for nm in names:
			nm2id[nm]=id
			nml.append(nm)
	
	for i in L:
		name=i['title']
		img=i['img']
		if 'group' in i.keys():group = i['group']
		else: group = ''
		
		if uni_mark(name) in nml:
			id = nm2id[uni_mark(name)]
			if group !="" and group not in DBC[id]['group']:
				DBC[id]['group'].append(group)
			#DBC[id]={'title': i['title'], 'group': [], 'names':[uni_mark(i['title']),]}
		else:
			id = CRC32(uni_mark(name))
			print id+" : "+name
			if group !="": lgroup=[group,]
			else:          lgroup=[]
			DBC[id]={'title': i['title'], 'group': lgroup, 'names':[uni_mark(i['title']),]}
		if img!='': GETimg(img, id)
		if __settings__.getSetting("addgr")=='true': appendgroup(group, id)
	save_DBC(DBC)

def appendgroup(group, id):
		if group !='':
			try:L=open_Groups()
			except:L=Ldf
			CL=[]
			for i in L:
				CL.append(i[0])
			
			if group in CL:
				add_to_gr(id, group)
			else:
				add_gr(group)
				add_to_gr(id, group)


def append_cnl(id):
	nm2id={}
	nml=[]
	for a in DBC.items():
		namet=a[1]['title']
		idt=a[0]
		nm2id[namet]=idt
		nml.append(namet)
	nml.sort()
	sel = xbmcgui.Dialog()
	r = sel.select("Добавить к каналу:", nml)
	
	if r>=0:
		name=nml[r]
		print name
		id2=nm2id[name]
		print id2
	
	DBC[id2]['names'].extend(DBC[id]['names'])
	print DBC[id2]
	DBC.pop(id)
	save_DBC(DBC)


def split_cnl(id=''):
	if id!='':
		nm_list=DBC[id]['names']
		if len(nm_list)>1:
			sel = xbmcgui.Dialog()
			r = sel.select("Выделить как канал:", nm_list)
			if r>=0 :
				name=nm_list[r]
				id2=CRC32(name)
				DBC[id2]={'group': [], 'names': [name,], 'title': name}
				nm_list.remove(name)
				DBC[id]['names']=nm_list
				save_DBC(DBC)
				showMessage('Канал выделен:', name)
		else:
			showMessage('Разделить нельзя', 'Канал содержит 1 имя')

def rename_cnl(ids):
	nt=inputbox(DBC[ids]['title'])
	if nt!='': 
		DBC[ids]['title']=nt
		save_DBC(DBC)

def upd_archive_db(i):
	exec ("import "+i+"; serv="+i+".ARH()")
	return serv.name2id()

def get_all_channeles():
	pDialog = xbmcgui.DialogProgressBG()
	L=[]
	for i in Lserv:
		serv_id=str(int(i[1:3]))
		if __settings__.getSetting("serv"+serv_id+"")=='true' :
			
			try: exec ("import Channels"+serv_id+"; Ls=Channels"+serv_id+".Channels")
			except:Ls=[]
			if Ls==[]: 
				pDialog.create('Пазл ТВ', 'Обновление списка каналов #'+serv_id+' ...')
				Ls=upd_canals_db(i)
				pDialog.close()
		else: Ls=[]
		L.extend(Ls)
	return L

def get_allurls(id, L):
	cl_names = DBC[id]['names']
	L3=[]
	for j in L:
		name = uni_mark(j['title'])
		if name in cl_names:
			L3.append(j['url'])
	return L3

def get_picon(id):
	if id =='':nmi = '0000'
	else: nmi = str(id)
	LogoDir=__settings__.getSetting("logodir")
	if LogoDir=="": LogoDir=Logo
	path1 = fs_enc(os.path.join(LogoDir,nmi+'.png'))
	path2 = fs_enc(os.path.join(Logo,nmi+'.png'))
	
	if os.path.isfile(path1): return path1
	elif os.path.isfile(path2): return path2
	else: return fs_enc(os.path.join(Logo,'0000.png'))


def get_all_archive():
	pDialog = xbmcgui.DialogProgressBG()
	L=[]
	for i in Larh:
		serv_id=str(int(i[1:3]))
		if True:#__settings__.getSetting("serv"+serv_id+"")=='true' :
			
			try: exec ("import aid"+serv_id+"; Ds=aid"+serv_id+".n2id")
			except:Ds={}
			if Ds=={}: 
				pDialog.create('Пазл ТВ', 'Обновление архива #'+serv_id+' ...')
				Ds=upd_archive_db(i)
				pDialog.close()
		else: Ds={}
		if Ds !={}:
			Ds['srv_id']=i
			L.append(Ds)
	return L


if __settings__.getSetting("grincm")=='true':
	ContextGr=[('[B]Все каналы[/B]', 'Container.Update("plugin://plugin.video.pazl2.tv/?mode=context_gr&name=Все каналы")'),]
	for grn in list_gr():
		ContextGr.append(('[B]'+grn+'[/B]','Container.Update("plugin://plugin.video.pazl2.tv/?mode=context_gr&name='+urllib.quote_plus(grn)+'")'))
		ContextGr.append(('[COLOR FF55FF55][B]ПЕРЕДАЧИ[/B][/COLOR]', 'Container.Update("plugin://plugin.video.pazl2.tv/?mode=tvgide")'))



def root(SG=''):
		Lret=[]
		if SG=="":SG=get_SG()
		Lnm=[]
		Lserv=get_all_channeles()
		L=DBC.keys()
		nml=[]
		for a in Lserv:
			nm=uni_mark(a['title'])
			nml.append(nm)
		CL=get_gr()
		for id in CL:
				try:
					names = DBC[id]['names']
					enable=False
					for b in names:
						if b in nml: enable=True
					
					if enable:
						name  = DBC[id]['title']
						cover = get_picon(id)
						Lret.append({'title':name, 'id': id, 'picon': cover})
				except:
					pass
		__settings__.setSetting("Sel_sday",'0')
		return Lret

def sort_abc(L):
	L2=[]
	for id in L:
		try: L2.append((DBC[id]['title'],id))
		except: pass
	L2.sort()
	L=[]
	for i in L2:
		L.append(i[1])
	return L


def open_Groups():
		fp=xbmc.translatePath(os.path.join(UserDir, 'UserGR.py'))
		
		try:sz=os.path.getsize(fp)
		except:sz=0
		if sz==0:
			save_Groups(Ldf)
			return Ldf
		
		fl = open(fp, "r")
		ls=fl.read().replace('\n','')#.replace('# -*- coding: utf-8 -*-Lgr=','')
		fl.close()
		return eval(ls)

def save_Groups(L):
		fp=xbmc.translatePath(os.path.join(UserDir, 'UserGR.py'))
		fl = open(fp, "w")
		#fl.write('# -*- coding: utf-8 -*-\n')
		#fl.write('Lgr=[\n')
		fl.write('[\n')
		for i in L:
			fl.write(repr(i)+',\n')
		fl.write(']\n')
		fl.close()

def get_SG():
	try:SG=__settings__.getSetting("Sel_gr")
	except:SG=''
	if SG=='':
		SG='Все каналы'
		__settings__.setSetting("Sel_gr",SG)
	return SG

def get_gr(SG='', blacklist=True):
	if SG=='':SG=get_SG()
	if SG=='Все каналы':
		CLf=DBC.keys()
	else:
		try:L=open_Groups()
		except:L=[]
		for i in L:
			if i[0]==SG: CLf=i[1]
	
	if blacklist: BL=get_blacklist_cn(SG)
	else: BL=[]
	if BL==[]: CL=CLf
	else:
		CL=[]
		for c in CLf:
			if c not in BL: CL.append(c)
	
	if __settings__.getSetting("abc")=='true' or SG=='Все каналы': CL=sort_abc(CL)
	return CL

def get_blacklist_cn(cgr=''):
		BL=[]
		try:L=open_Groups()
		except:L=[]
		for i in L:
			if len(i)==3 and i[0]!=cgr: BL.extend(i[1])
		return BL

def get_autoexit_gr():
		SG=get_SG()
		try:L=open_Groups()
		except:L=[]
		for i in L:
			if len(i)==3 and i[0]==SG: return True
		return False

def get_cut_gr():
		Lnm=[]
		Lserv=get_all_channeles()
		CL=get_gr()
		nml=[]
		for a in Lserv:
			nm=uni_mark(a['title'])
			nml.append(nm)
		for id in CL:
				try:
					names = DBC[id]['names']
					enable=False
					for b in names:
						if b in nml: enable=True
					
					if enable:
						#name  = DBC[id]['title']
						#cover = get_picon(id)
						if id not in Lnm:
							Lnm.append(id)
				except:
					pass
		return Lnm


def select_gr(ind, gui=False):
	L=open_Groups()
	Lg=['Все каналы',]
	for i in L:
		if len(i)==2:Lg.append(i[0])
		elif len(i)==3: Lg.append('[COLOR 44FFFFFF]'+i[0]+'[/COLOR]')
	
	if gui: return Lg

def set_num_cn(id):
	L=open_Groups()
	try:SG=__settings__.getSetting("Sel_gr")
	except:SG=''
	if SG=='':SG='Все каналы'
	
	if SG!='Все каналы':
		CL=get_gr()
		CL.remove(id)
		#n=CL.index(id)
		CLn=[]
		for c in CL:
			try:CLn.append(DBC[c]['title'])
			except: pass
		CLn.append(' - В конец списка - ')
		sel = xbmcgui.Dialog()
		r = sel.select("Перед каналом:", CLn)
		if r>=0 :#and r<len(CL)
			#CL.remove(id)
			CL.insert(r, id)
			#k=0
			L2=[]
			for i in L:
				if i[0]==SG:
					if len(i)==2:igr=(SG,CL)
					elif len(i)==3:igr=(SG,CL,i[2])
					L2.append(igr)
				else:
					L2.append(i)
				#k+=1
			save_Groups(L2)



def add_to_gr(id, group=''):
	try:L=open_Groups()
	except:L=Ldf
	Lg=[]
	for i in L:
		Lg.append(i[0])
		
	if Lg!=[]:
		if group=='':
			sel = xbmcgui.Dialog()
			r = sel.select("Группа:", Lg)
		else:
			r=Lg.index(group)
		if r!=-1:
			if id not in L[r][1]:
					L[r][1].append(id)
					save_Groups(L)

def rem_from_gr(id):
	try:	SG=__settings__.getSetting("Sel_gr")
	except: SG=''
	try:L=open_Groups()
	except:L=Ldf
	L2=[]
	for i in L:
		if SG=='' or SG=='Все каналы':
				ng=i[1]
				if id in ng: i[1].remove(id)#ng.remove(id)
				#=ng
				#if len(i)==2:
				#L2.append([i[0],ng])
				L2.append(i)
		else:
			if SG == i[0]:
				ng=i[1]
				if id in ng: i[1].remove(id)#ng.remove(id)
				#L2.append([i[0],ng])
				#i[1]=ng
			#else:
			L2.append(i)
	save_Groups(L2)
	#xbmc.executebuiltin("Container.Refresh")

def update_cnl():
			#xbmcplugin.endOfDirectory(handle, False, False)
			pDialog = xbmcgui.DialogProgressBG()
			pDialog.create('Пазл ТВ', 'Обновление списка каналов ...')
			for i in Lserv:
				serv_id=str(int(i[1:3]))
				if __settings__.getSetting("serv"+serv_id)=='true' :
						pDialog.update(int(serv_id)*100/len(Lserv), message='Обновление списка каналов #'+serv_id+' ...')
						Ls=upd_canals_db(i)
			pDialog.close()
			xbmc.executebuiltin("Container.Refresh")

def add_gr(name=''):
	if name == '': name=inputbox('')
	try:L=open_Groups()
	except:L=Ldf
	st=(name,[])
	if st not in L:L.append(st)
	save_Groups(L)

def rem_gr(name=''):
	try:L=open_Groups()
	except:L=Ldf
	Lg=[]
	for i in L:
		Lg.append(i[0])
	
	if name=="":
		if Lg!=[]:
			sel = xbmcgui.Dialog()
			r = sel.select("Группа:", Lg)
		if r>=0:
			name=Lg[r]
	
	if name!="":
		L2=[]
		for i in L:
			if i[0]!=name: L2.append(i)
		save_Groups(L2)

def move_gr(name=''):
	if name!="":
		try:L=open_Groups()
		except:L=Ldf
		Lg=[]
		gi=None
		for i in L:
			if i[0]==name: gi=i
			else: Lg.append(i[0])
		Lg.append(' - В конец списка - ')
		
		sel = xbmcgui.Dialog()
		r = sel.select("Вставить перед группой:", Lg)
		if r>=0:
			L2=[]
			
			for i in L:
				if i[0]!=name: L2.append(i)
			L2.insert(r, gi)
			save_Groups(L2)

def set_pass_gr(name=''):
	if name!="":
		try:L=open_Groups()
		except:L=Ldf
		Lg=[]
		for i in L:
			if i[0]==name and len(i)==2: 
					pas=inputbox()
					i=[i[0],i[1], pas]
			Lg.append(i)
			save_Groups(Lg)


def rem_pass_gr(name=''):
	if name!="":
		try:L=open_Groups()
		except:L=Ldf
		Lg=[]
		for i in L:
			if i[0]==name and len(i)==3: 
				pas=inputbox()
				if pas==i[2]: i=[i[0],i[1]]
				else: showMessage('Отклонено!', 'Неверный пароль')
			Lg.append(i)
			save_Groups(Lg)

def get_access_gr(name=''):
	if name!="":
		true_name=name.replace('[COLOR 44FFFFFF]','').replace('[/COLOR]','')
		try:L=open_Groups()
		except:L=Ldf
		for i in L:
			if i[0]==true_name and len(i)==3:
				pas=inputbox()
				if pas==i[2]: return true_name
				else: showMessage('Отклонено!', 'Неверный пароль')
		return name

def rename_gr(name=''):
	ng=inputbox()
	if name!="" and ng!='':
		try:L=open_Groups()
		except:L=Ldf
		Lg=[]
		gi=None
		for i in L:
			if i[0]==name: i=[ng,i[1]]
			Lg.append(i)
			save_Groups(Lg)

def extend_gr(name=''):
	if name!="":
		try:L=open_Groups()
		except:L=Ldf
		Lg=[]
		gi=None
		for i in L:
			if i[0]==name: gi=i[1]
			else: Lg.append(i[0])
		
		sel = xbmcgui.Dialog()
		r = sel.select("Объединить с группой:", Lg)
		if r>=0:
			r_nm=Lg[r]
			gr=[]
			for i in L:
				if i[0]==r_nm:
					if len(i)==3: 
						showMessage('Недоступно', 'Группа заблокирована')
						return ""
					gr=i[1]
			
			for i in gi:
				if i not in gr: gr.append(i)
			
			L2=[]
			for i in L:
				if i[0]!=name:
					if i[0]==r_nm:   L2.append([r_nm, gr])
					else:            L2.append(i)
			save_Groups(L2)

def add_rec(name):
	for i in Larh:
		serv_id=str(int(i[1:3]))
		try: 
			exec ("import aid"+serv_id+"; dict=aid"+serv_id+".n2id")
			nm=lower(unmark(name))
			#print nm
			if nm in dict.keys():
				return name+" [COLOR 5FFF1010][R][/COLOR]"
		except: pass
	return name



def archive(name):#, sd='0'
	try:sd=__settings__.getSetting("Sel_sday")
	except: sd='0'
	if sd=="":sd='0'
	La=get_all_archive()
	ssec=int(sd)*24*60*60
	t=time.localtime(time.time() - ssec)
	add_item ('[COLOR FF10FF10][B]'+time.strftime('%d.%m.%Y',t)+" - "+unmark(name)+"[/B][/COLOR]", "select_date", 'url', '0' )
	da={}
	Lm=[]
	for n2id in La:
		serv_id=n2id['srv_id']
		#try: 
		exec ("import "+serv_id+"; arh="+serv_id+".ARH()")
		#n2id=arh.name2id()
		try:aid=n2id[lower(unmark(name))]
		except: aid=""
		#from aid3 import *
		#n2id
		if aid!="":
			L=arh.Archive(aid, t)
			for i in L:
				#url=i['url']
				#title=i['title']
				st=i['time']
				#add_item (st+" - "+title, "play2", [url,], 'archive' )
				try: 
					i2=da[st]
					urls=i2['url']
					url=i['url']
					urls.append(url)
					i2['url']=urls
					da[st]=i2
				except: 
					url=i['url']
					i['url']=[url,]
					da[st]=i
	for d in da.keys():
			urls=da[d]['url']
			title=da[d]['title']
			st=da[d]['time']
			add_item (st+" - "+title, "play2", urls, 'archive' )
			
	#xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	#xbmcplugin.endOfDirectory(handle)


def select_date():
		L=[]
		for i in range (0,10):
			ssec=i*24*60*60
			t=time.localtime(time.time() - ssec)
			st=time.strftime('%d.%m.%Y',t)
			L.append(st)
		sel = xbmcgui.Dialog()
		r = sel.select("Дата:", L)
		arhive.setSetting("Sel_sday",str(r))
		xbmc.executebuiltin("Container.Refresh")

def get_arhive_date():
	try:sd=arhive.getSetting("Sel_sday")
	except: sd='0'
	if sd=="":sd='0'
	ssec=int(sd)*24*60*60
	t=time.localtime(time.time() - ssec)
	return time.strftime('%d.%m.%Y',t)

def set_arhive_date(r):
	arhive.setSetting("Sel_sday",str(r))

# ------------------------------------ БД ------------------------------------------------
'''
import sqlite3 as db
db_name = os.path.join( addon.getAddonInfo('path'), "epg.db" )
c = db.connect(database=db_name)
cu = c.cursor()
def add_to_db(n, item):
		item=item.replace("'","XXCC").replace('"',"XXDD")
		err=0
		tor_id="n"+n
		litm=str(len(item))
		try:
			cu.execute("DROP TABLE "+tor_id+";")
			c.commit()
		except: pass
		try:
			cu.execute("CREATE TABLE "+tor_id+" (db_item VARCHAR("+litm+"), i VARCHAR(1));")
			c.commit()
		except: 
			err=1
			print "Ошибка БД"
		if err==0:
			cu.execute('INSERT INTO '+tor_id+' (db_item, i) VALUES ("'+item+'", "1");')
			c.commit()
			#c.close()

def get_inf_db(n):
		tor_id="n"+n
		cu.execute(str('SELECT db_item FROM '+tor_id+';'))
		c.commit()
		Linfo = cu.fetchall()
		info=Linfo[0][0].replace("XXCC","'").replace("XXDD",'"')
		return info
'''
# ----------------------------------- данные ----------------------------------------------------

def ungz(filename):
	import gzip
	with gzip.open(filename, 'rb') as f:
		file_content = f.read()
		return file_content

def unzip(filename):
	from zipfile import ZipFile
	fil = ZipFile(filename, 'r')
	for name in fil.namelist():
		f=fil.read(name)
		return f

def ASE_start():
	srv=__settings__.getSetting("p2p_serv")
	prt=__settings__.getSetting("p2p_port")
	lnk='http://'+srv+':'+prt+'/webui/api/service?method=get_version&format=jsonp&callback=mycallback'#getstream?id='+CID
	pDialog = xbmcgui.DialogProgressBG()
	resp=getURL(lnk)
	if resp != '':
		return False
	else:
		#showMessage('Пазл ТВ', 'Запуск Ace Stream')
		pDialog.create('Пазл ТВ', 'Запуск Ace Stream ...')
		pDialog.update(0, message='Запуск Ace Stream ...')
		start_linux()
		start_windows()
		for i in range (0,10):
			pDialog.update(i*10, message='Запуск Ace Stream ...')
			xbmc.sleep(1500)
			resp=getURL(lnk)
			if resp != '':
				pDialog.close()
				return True
		pDialog.close()
		return False

def start_linux():
        import subprocess
        try:
            subprocess.Popen(['acestreamengine', '--client-console'])
        except:
            try:
                subprocess.Popen('acestreamengine-client-console')
            except: 
                try:
                    xbmc.executebuiltin('XBMC.StartAndroidActivity("org.acestream.media")')
                    xbmc.sleep(2000)
                    xbmc.executebuiltin('XBMC.StartAndroidActivity("org.xbmc.kodi")')
                except:
                    return False
        return True
    
def start_windows():
        try:
            import _winreg
            try:
                t = _winreg.OpenKey(_winreg.HKEY_CURRENT_USER, r'Software\AceStream')
            except:
                t = _winreg.OpenKey(_winreg.HKEY_CURRENT_USER, r'Software\TorrentStream')
            path = _winreg.QueryValueEx(t, r'EnginePath')[0]
            os.startfile(path)
            return True
        except:
            return False

def get_arhive_directory():
	nm2id={}
	nml=[]
	for a in DBC.items():
		id=a[0]
		names=a[1]['names']
		for nm in names:
			nm2id[nm]=id
			nml.append(nm)
	
	response = eval(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Files.GetDirectory", "params": {"directory": "plugin://plugin.video.pazl.arhive"},"id": 1}'))
	files=response["result"]["files"]
	D={}
	for i in files:
		name=i["label"]
		if uni_mark(name) in nml:
			id = nm2id[uni_mark(name)]
			D[id]=i["file"]
	return D

def get_arhive_canale(dir):
	response = eval(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Files.GetDirectory", "params": {"directory": "'+dir+'"},"id": 1}'))
	files=response["result"]["files"]
	D={}
	for i in files:
		name=i["label"]
		curl=i["file"]
		if 'mode=play' in curl:
			D[name]=curl
	return D

def get_arhive_strm(dir):
	dir=dir.replace('mode=play2', 'mode=strm')
	#print dir
	response = eval(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Files.GetDirectory", "params": {"directory": "'+dir+'"},"id": 1}'))
	#print response
	files=response["result"]["files"]
	D={}
	for i in files:
		name=i["label"]
		curl=i["file"]
		D[name]=curl
	print D
	return D

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param


if __settings__.getSetting("xplay")=='true': 
	Player=pPlayer()
else:
	Player=xbmc.Player()

#Player=pPlayer()

'''
params = {}#get_params()
try:mode = urllib.unquote_plus(params["mode"])
except:mode =""
try:name = urllib.unquote_plus(params["name"])
except:name =""
try:url = eval(urllib.unquote_plus(params["url"]))
except:url =[]
try:cover = urllib.unquote_plus(params["cover"])
except:cover =""
try:ind = urllib.unquote_plus(params["ind"])
except:ind ="0000"
pDialog = xbmcgui.DialogProgressBG()

if mode=="off"         : #root
	if __settings__.getSetting("boost")=='true': root_b()
	else: root()

if mode=="context_gr"  :
		__settings__.setSetting("Sel_gr",name)
		xbmc.sleep(300)
		xbmc.executebuiltin("Container.Refresh")

if mode=="updateepg"   :
			add_to_db ("udata", str(0))
			#xbmcplugin.endOfDirectory(handle, False, False)

if mode=="grman"   :
	import GrBox
	GrBox.run("GrBox")

if mode=="tvgide"   : tvgide()
if mode=="add"      : add_to_gr(ind)
if mode=="rem"      : rem_from_gr(ind)
if mode=="addgr"    : add_gr()
if mode=="remgr"    : rem_gr()
if mode=="set_num"  : set_num_cn(id)
if mode=="update"   : update_cnl()

if mode=="select_gr": select_gr(ind)
if mode=="play"     : 
	if __settings__.getSetting("boost")=='true': play_b(ind, name, cover)
	else: play(url, name, cover)
if mode=="play2"    : play_archive(url, name, cover)
if mode=="next"     : 
	#video=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), '1.wmv'))
	xbmc.executebuiltin('Container.Update("plugin://plugin.video.pazl2.tv/?mode=next2")')

if mode=="next2"     :  next ('>')
if mode=="archive"   :  archive(name)#, ind
if mode=="select_date": select_date()
if mode=="append_cnl":   append_cnl(ind)
if mode=="rename_cnl":  rename_cnl(ind)
'''
#c.close()
#debug (str(time.time()-nt))
