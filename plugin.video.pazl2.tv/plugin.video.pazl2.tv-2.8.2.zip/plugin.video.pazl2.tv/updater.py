# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, time, sys

PLUGIN_NAME   = 'plugin.video.pazl2.tv'
addon = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
__settings__ = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
sys.path.append(os.path.join(addon.getAddonInfo('path'),"serv"))



try:
	if __settings__.getSetting("serv23")=='true':
		import Channels23  
		tm=Channels23.tm
		if time.time()-tm > 7200: 
			import p23_proxytv
			serv=p23_proxytv.PZL()
			serv.Canals()
except:
	pass


try:
	if __settings__.getSetting("serv1")=='true':
		import Channels1
		tm=Channels1.tm
		if time.time()-tm > 7200: 
			import p01_trash
			serv=p01_trash.PZL()
			serv.Canals()
except:
	pass
