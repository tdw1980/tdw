#!/usr/bin/python
# -*- coding: utf-8 -*-

import string, xbmc, xbmcgui, xbmcplugin, xbmcaddon
import os, cookielib, urllib, urllib2, time
addon = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
__settings__ = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
#-----------------------------------------

icon = ""
serv_id = '17'
siteUrl = 'ortus-global.com'
httpSiteUrl = 'https://' + siteUrl
#sid_file = os.path.join(xbmc.translatePath('special://temp/'), siteUrl+'.sid')

#cj = cookielib.FileCookieJar(sid_file) 
#hr  = urllib2.HTTPCookieProcessor(cj) 
#opener = urllib2.build_opener(hr) 
#urllib2.install_opener(opener) 

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))


def getURL(url, Referer = ''):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


def POST(target, post=None, referer='http://tvfeed.in'):
	#print target
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		req.add_header('X-Requested-With', 'XMLHttpRequest')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		print e
		return ''

def GET(url):
	post='url='+urllib.quote_plus(url)
	return POST('http://cameleo.xyz/r', post)


def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		#sn=http[s:]
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def save_channels(ns, L):
		fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'Channels'+ns+'.py'))
		fl = open(fp, "w")
		fl.write('# -*- coding: utf-8 -*-\n')
		fl.write('Channels=[\n')
		for i in L:
			fl.write(repr(i)+',\n')
		fl.write(']\n')
		fl.close()

def glaz(url):
					print url
					L=[]
					http=getURL(url, 'http://www.glaz.tv')
					#print http
					if 'rosshow' in http:
						id=http[http.find('//rosshow.ru/iframe/')+20:http.find("/' allowfullscreen>")]
						print id
						if 1<len(id)<100:
							uri='https://live-rmg.cdnvideo.ru/rmg/'+id+'_new.sdp/chunklist.m3u8?hls_proxy_host=pub1.rtmp.s01.l.rmg'
							print uri
							return [uri,]
						
					elif 'wmsAuthSign' in http:
						sig = http[http.find('var signature = "')+17:]
						signature = sig[:sig.find('";')]
						print signature
						ss='http://1'
						es='wmsAuthSign='
						L1=mfindal(http,ss,es)
						for i in L1:
							uri=i+'wmsAuthSign='+signature#+'|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:35.0) Gecko/20100101'
							if uri not in L and len(uri) < 500 : L.append(uri)

						return L

class PZL:
	def __init__(self):
		pass

	def Streams(self, url):
			#url='https://ortus-global.com/tv-online/1hd-music-television'
			print url
			hp=GET(url)#, Referer = 'https://ortus-global.com')
			if '/online-tv/' in hp:
				n_url= 'http://www.glaz.tv/online-tv/'+mfind(hp,'/online-tv/','">')
				return glaz(n_url)
			link = mfind(hp,'autoPlay=true&amp;src=','&amp;streamType')
			print link
			return [link,]

	def Canals(self):
		print 'ortus'
		LL=[]
		LU=[]
		url='http://ortus-global.com/tv-online'
		hp=GET(url)#, Referer = 'https://ortus-global.com')
		L=mfindal(hp,'<a title', ' /></a>')
		for i in L:
			if 'publikatsii' not in i:
				title = mfind(i,'title="', ' &ndash;')
				title = title.replace('&laquo;','').replace('&raquo;','')
				url = mfind(i,'href="', '"')
				url = 'https://ortus-global.com'+url[url.find('/tv-online/'):]
				img = 'https://ortus-global.com'+mfind(i,'src="', '"')#'http://0s.n5zhi5ltfvtwy33cmfwc4y3pnu.cmle.ru'+
				#http://0s.n5zhi5ltfvtwy33cmfwc4y3pnu.cmle.ru/files/253/rusong-tv.png
				
				LL.append({'url':url, 'img':img, 'title':title, 'group':""})
				LU.append(url)
		
		url='http://ortus-global.com/tv-online/russkoe-tv-ru'
		hp=GET(url)#, Referer = 'https://ortus-global.com')
		L=mfindal(hp,'<a title', ' /></a>')
		for i in L:
			if 'publikatsii' not in i:
				title = mfind(i,'title="', ' &ndash;')
				title = title.replace('&laquo;','').replace('&raquo;','')
				url = mfind(i,'href="', '"')
				url = 'https://ortus-global.com'+url[url.find('/tv-online/'):]
				img = 'https://ortus-global.com'+mfind(i,'src="', '"')#'http://0s.n5zhi5ltfvtwy33cmfwc4y3pnu.cmle.ru'+
				#http://0s.n5zhi5ltfvtwy33cmfwc4y3pnu.cmle.ru/files/253/rusong-tv.png
				
				if url not in LU: LL.append({'url':url, 'img':img, 'title':title, 'group':""})
		
		if LL!=[]: save_channels(serv_id, LL)
		else: showMessage('ortus', 'Не удалось загрузить каналы', times = 3000)

		return LL

