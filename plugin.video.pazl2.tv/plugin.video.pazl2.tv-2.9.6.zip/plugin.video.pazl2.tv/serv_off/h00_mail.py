#!/usr/bin/python
# -*- coding: utf-8 -*-

import string, xbmc, xbmcgui, xbmcplugin, xbmcaddon
import os, cookielib, urllib, urllib2, time
addon = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
__settings__ = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
#-----------------------------------------

icon = ""
serv_id = '13'
siteUrl = 'tv.mail.ru'
httpSiteUrl = 'https://' + siteUrl
sid_file = os.path.join(xbmc.translatePath('special://temp/'), siteUrl+'.sid')

cj = cookielib.FileCookieJar(sid_file) 
hr  = urllib2.HTTPCookieProcessor(cj) 
opener = urllib2.build_opener(hr) 
urllib2.install_opener(opener) 

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))


def CRC32(buf):
		import binascii
		buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		return str("%08X" % buf)


def GET(url, Referer = 'https://m.knigavuhe.ru/'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	req.add_header('x-requested-with', 'XMLHttpRequest')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def POST(target, post=None, referer='http://torrentino.net'):
	#print target
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		req.add_header('X-Requested-With', 'XMLHttpRequest')
		req.add_header('Content-Type', 'application/x-www-form-urlencoded')
		resp = urllib2.urlopen(req)
		#print resp.info()
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		print e
		return ''


def toutf(s):
	s=eval('u"'+s.replace('"',"''")+'"')
	return s.encode('utf-8')
	


def findall(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def get_stream(id):
	url='https://tv.mail.ru/voronezh/channel/'+id
	print url
	hp=GET(url)
	if 'rutube' in hp: return get_stream_rutube(hp)
	if 'vgtrk'  in hp: return get_stream_vgtrk(hp)


def get_stream_rutube(hp):
	rt_id=mfind(hp, '/play/embed/', '"')
	if '/' in rt_id: rt_id=rt_id[:rt_id.find('/')]
	rt_url='https://rutube.ru/api/play/options/'+rt_id+'/?format=json&no_404=true'
	print rt_url
	hp2=GET(rt_url)
	#print hp2
	true=True
	false=False
	null=None
	json=eval(hp2)
	#print json
	hls=json['live_streams']['hls'][0]['url']
	print hls
	return hls

def get_stream_vgtrk(hp):
	rt_id=mfind(hp, '//player.vgtrk.com', '"')
	rt_url='https://player.vgtrk.com'+rt_id
	print rt_url
	hp2=GET(rt_url)
	urlp = 'https:'+mfind(hp2, "window.pl.data.dataUrl = '", "';")
	print urlp
	#print hp2
	hp3=GET(urlp)
	true=True
	false=False
	null=None
	json=eval(hp3)
	#print json
	hls=json['data']['playlist']['medialist'][0]['sources']['m3u8']['auto']
	print hls
	return hls

#get_stream('1091')

def get_channels():
	print 'get_channels'
	import json, time
	target='https://tv.mail.ru/ajax/index/'
	
	prev='region_id=70&channel_type=all'
	ext='&appearance=list&period=all'
	dtm='&date='+time.strftime('%Y-%m-%d')
	Lr = []
	Lc=[[],
	[850,1271,1395,1389,1139,2060,1112,1158,751,1051,2068,1383,986,963,968,1671,1259,1049,717,1162,2097,2338,1670,1193],
	[1973,24,843,732,2360,2391,1959,2373,743,1173,2273,933,1334,1799,736,1362,800,868,975,1008,1092,2186,2025,1340],
	[1462,1519,1612,888,994,1063,1064,1229,1309,1968,1042,1433,2007,1727,1956,2355,2266,2396,1835,713,1234,1607,864,1405],
	[1810,1066,1143,2120,2122,2123,2384,742,905,980,1300,1721,1782,2301,2368,2294,2399,2263,2351,1851,775,1219,1894,2274],
	[1243,889,1944,919,924,1195,1244,1282,1296,1307,1353,1356,1396,1477,1567,1628,1122,2136,729,761,763,792,801,911],
	[1002,1003,1019,1094,896,2137,1050,2048,2167,2281,1266,1333,1343,1707,1993,2350,2324,2356,2425,2035,2195,2285,2363,2375],
	[2413,2173,2216,2153,2243,1027,1800,1566,1718,1926,2154,796,1144,773,787,833,1269,1651,769,1085,1097,1103,1134,1159],
	[1201,1241,808,1249,814,1258,838,1503,907,1669,929,1780,945,1991,1004,2090,1007,2277,1083,2135,2193,2268,2111,2166],
	[2276,974,921,1010,1262,1342,1367,1397,2246,2404,1653,2300,2269,2194,2306,2353,2209,2214,2215,2235,2288,2291,2295,2303],
	[2305,2259,2205,2210,2400,2401,2423,2161,2202,2237,2296,2339,2341,2398,1794,2192,2211,2258,2407,2411,2199,2200,2191,2234],
	[1641,1658,2044,2198,2249,2252,1126,1197,1352,1380,1499,1610,1622,835,900,944,1075,1115,1525,1827,781,996,1136,1141],
	[1204,1384,1623,1684,726,739,1420,2290,2420,1834,2386,1813,2010,1747,2311,1576,1603,745,766,806,1252,1324,1326,1354],
	[1381,1516,2006,2424,1825,2197,2224,2416,2426,2212,2155,2042,1970,1971,1972,715,1038,1716,1739,1185,1346,810,1449,822],
	[1570,834,853,901,942,953,1057,1104,1111,1127,1129,1182,2317,2367,1660,2304,2293,2325,1831,2026,2280,2264,2405,2415],
	[2217,2024,1787,782,946,1128,1302,1378,1759,2326,1778,1652,2262,2298,2320,2206,1666,1687,904,1579,981,1590,1070,1617],
	[1116,1618,1250,1619,1257,1657,1360,1683,1401,2124,1404,2204,1408,2227,1422,1521,1542,786,1557,832,1559,873,1832,1479],
	[1524,1598,2174,1470,1783,1818,2113,2116,2115,1700,2180,1781,1784,1817,1741,1786,1806,2160,2244,2309,2310,2321,2348,2349],
	[2383,1798,2168,1702,1830,2179,1744,1511,2207,2260,2261,2427,1836,1884,1821,2011,2175,1871,1854,2226,2229,2230,1723,2232],
	[2369,1385,1263,1366,1801,1561,1574,943,1382,1507,1528,714,744,1014,1023,1096,1174,1714,950,1255,1429,1624,927,1179]]
	
	cl=''
	for p in Lc:
		for j in p:
			cl+='&ex='+str(j)
		post=prev+cl+dtm+ext
		#print cl
		L=json.loads(POST(target, post))['schedule']
		for i in L:
			try:
				c = eval(repr(i['channel']).replace("u'","'"))
				print c
				try: life = c['has_live']
				except: life = 0
				if life == 1:
					try: name = toutf(c['name'])
					except: name = 'error'
					id = str(c['id'])
					print id+':'+name
					Lr.append({'id':id,'name':name})
			except:
				pass
				#print 'err'
	return Lr



def save_channels(ns, L):
		fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'Channels'+ns+'.py'))
		fl = open(fp, "w")
		fl.write('# -*- coding: utf-8 -*-\n')
		fl.write('Channels=[\n')
		for i in L:
			fl.write(repr(i)+',\n')
		fl.write(']\n')
		fl.close()


class PZL:
	def __init__(self):
		pass

	def Streams(self, url):
		print url
		id=url.replace('mail:', '')
		link=get_stream(id)
		return [link,]

	def Canals(self):
		L=get_channels()
		LL=[]
		for i in L:
			title = i['name']
			url = 'mail:'+i['id']
			LL.append({'url':url, 'title':title, 'img':'', 'group':''})

		if LL!=[]: save_channels(serv_id, LL)
		else: showMessage(siteUrl, 'Не удалось загрузить каналы', times = 3000)

		return LL

