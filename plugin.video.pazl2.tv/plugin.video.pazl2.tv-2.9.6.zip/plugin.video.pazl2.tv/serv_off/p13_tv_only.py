#!/usr/bin/python
# -*- coding: utf-8 -*-

import string, xbmc, xbmcgui, xbmcplugin, xbmcaddon
import os, cookielib, urllib, urllib2, time
addon = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
__settings__ = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
#-----------------------------------------

icon = ""
serv_id = '13'
siteUrl = 'tv-only.org'
httpSiteUrl = 'http://' + siteUrl
sid_file = os.path.join(xbmc.translatePath('special://temp/'), siteUrl+'.sid')

cj = cookielib.FileCookieJar(sid_file) 
hr  = urllib2.HTTPCookieProcessor(cj) 
opener = urllib2.build_opener(hr) 
urllib2.install_opener(opener) 

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def getURL(url, Referer = httpSiteUrl):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def GET(url, Referer = httpSiteUrl):
	req = urllib2.Request(url)
	#req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	#req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	#req.add_header('Accept-Language', 'ru,en;q=0.9')
	#req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def save_channels(n, L):
		ns=str(n)
		fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'Channels'+ns+'.py'))
		fl = open(fp, "w")
		fl.write('# -*- coding: utf-8 -*-\n')
		fl.write('Channels=[\n')
		for i in L:
			fl.write(repr(i)+',\n')
		fl.write(']\n')
		fl.close()

Android_User_Agent = 'Opera/6.10.2 Android/4.4.4 phone/Galaxy Tab E/arm64'
Apple_User_Agent = 'Mozilla/5.0 (iPad; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
Player_User_Agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:35.0) Gecko/20100101 Firefox/35.0'
class PZL:
	def __init__(self):
		pass

	def Streams(self, url):
					http=getURL(url)
					Lu=http.splitlines()
					for j in Lu:
						if 'file:"' in j:
							print j
							ss='file:"'
							es='"'
							u2=mfind(j, ss, es)+ '|User-Agent=%s' % Android_User_Agent
							return [u2,]
							
					return []
	
	
	def Canals(self):
		LL=[]
		urls='http://tv-only.org'
		http=getURL(urls)
		ss='<li class="item_tv">'
		es='</a></li>'
		L=mfindal(http, ss, es)
		for i in L:
			if '<a href="http' in i:
				print i
				try:
					ss='href="'
					es='.html'
					url=mfindal(i,ss,es)[0][len(ss):]+es
					
					ss='src="'
					es='" alt="'
					img=urls+mfindal(i,ss,es)[0][len(ss):]
					
					ss='alt="'
					es=' смотреть онлайн'
					title=mfindal(i,ss,es)[0][len(ss):]
					
					LL.append({'url':url, 'img':img, 'title':title})
				except:
					print i
		if LL!=[]:save_channels(serv_id, LL)
		else:showMessage('tv-only.org', 'Не удалось загрузить каналы', times = 3000)
				
		return LL
