#!/usr/bin/python
# -*- coding: utf-8 -*-

import string, xbmc, xbmcgui, xbmcplugin, xbmcaddon
import os, cookielib, urllib, urllib2, time
addon = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
__settings__ = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
#-----------------------------------------

icon = ""
serv_id = '7'
siteUrl = 'glaz.tv'
httpSiteUrl = 'http://' + siteUrl
sid_file = os.path.join(xbmc.translatePath('special://temp/'), siteUrl+'.sid')

cj = cookielib.FileCookieJar(sid_file) 
hr  = urllib2.HTTPCookieProcessor(cj) 
opener = urllib2.build_opener(hr) 
urllib2.install_opener(opener) 

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def getURL(url, Referer = httpSiteUrl):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def get_ttv(url):
		http=getURL(url)
		#print http
		ss1='this.loadPlayer("'
		ss2='this.loadTorrent("'
		es='",{autoplay: true})'
		srv=__settings__.getSetting("p2p_serv")
		prt=__settings__.getSetting("p2p_port")
		
		try:
			if ss1 in http:
				CID=mfindal(http,ss1,es)[0][len(ss1):]
				lnk='http://'+srv+':'+prt+'/ace/getstream?id='+CID
				if len(CID)<30:lnk=''
				return lnk
			elif ss2 in http:
				AL=mfindal(http,ss2,es)[0][len(ss2):]
				lnk='http://'+srv+':'+prt+'/ace/getstream?url='+AL
				if len(AL)<30:lnk=''
				return lnk
			else: return ""
		except:
			return ""

def save_channels(n, L):
		ns=str(n)
		fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'Channels'+ns+'.py'))
		fl = open(fp, "w")
		fl.write('# -*- coding: utf-8 -*-\n')
		fl.write('Channels=[\n')
		for i in L:
			fl.write(repr(i)+',\n')
		fl.write(']\n')
		fl.close()

def get_gr(t):
	gr=''
	if 'Обо всем'    in t : gr='ОБЩИЕ'
	if 'Развлечения' in t : gr='РАЗВЛЕКАТЕЛЬНЫЕ'
	if 'Авто'        in t : gr='МУЖСКИЕ'
	if 'Спорт'       in t : gr='СПОРТ'
	if 'Кино'        in t : gr='ФИЛЬМЫ'
	if 'Новости'     in t : gr='НОВОСТНЫЕ'
	if 'Мода'        in t : gr='ЖЕНСКИЕ'
	if 'Музыка'      in t : gr='МУЗЫКА'
	if 'Познавательное' in t : gr='ПОЗНАВАТЕЛЬНЫЕ'
	if 'Детям'       in t : gr='ДЕТСКИЕ'
	if 'Религия'     in t : gr='РЕЛИГИОЗНЫЕ'
	return gr

class PZL:
	def __init__(self):
		pass

	def Streams(self, url):
					print url
					L=[]
			#try:	
					http=getURL(url)
					#print http
					if 'rosshow' in http:
						id=http[http.find('//rosshow.ru/iframe/')+20:http.find("/' allowfullscreen>")]
						print id
						if 1<len(id)<100:
							uri='https://live-rmg.cdnvideo.ru/rmg/'+id+'_new.sdp/chunklist.m3u8?hls_proxy_host=pub1.rtmp.s01.l.rmg'
							print uri
							return [uri,]
						
					elif 'wmsAuthSign' in http:
						sig = http[http.find('var signature = "')+17:]
						signature = sig[:sig.find('";')]
						print signature
						ss='http://1'
						es='wmsAuthSign='
						L1=mfindal(http,ss,es)
						for i in L1:
							uri=i+'wmsAuthSign='+signature#+'|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:35.0) Gecko/20100101'
							if uri not in L and len(uri) < 500 : 
								print uri
								L.append(uri)
						
						return L #['rtmp://stream.smcloud.net/live2/eskatv/eskatv_360p/playlist.m3u8',]
			#except:
			#	return []

	def Canals(self):
		pDialog = xbmcgui.DialogProgressBG()
		pDialog.create('Пазл ТВ', 'glaz.tv')
		LL=[]
		b=0
		for n in range (1,18):
			url='http://www.glaz.tv/online-tv/'+str(n)+'/'
			http=getURL(url)
			ss='<a class="article"'
			es='article-under-text-country'
			ss='class="list-channel">'
			es='<div class="list-channel-info__program'

			L=mfindal(http,ss,es)
			for i in L:
				b+=1
				#print i
				if "/online-tv/" in i and 'Вещание с других сайтов' not in i:
					gr=get_gr(i)
					
					ss='/online-tv/'
					es='">'
					url='http://www.glaz.tv'+mfindal(i,ss,es)[0]
					
					ss='src="'
					es='" alt='
					img='http:'+mfindal(i,ss,es)[0][len(ss):]
					
					ss='alt="'
					es='">'
					title=mfindal(i[i.find('src='):],ss,es)[0][len(ss):]
					
					
					title=title.replace(' (ТНТ-Comedy, Comedy TV)','').replace(' (Вести 24)','').replace(' (ex. LifeNews)','').replace(' (Россия К)','').replace(' (Перец)','').replace('/Телеклуб','').replace(' (Мать и дитя)','')
					if "(+" not in title and " (" in title: title=title[:title.find(' (')]
					tmp=getURL(url)
					pDialog.update(b*100/(len(L)*18), message='glaz.tv')
					if 'wmsAuthSign' in tmp or 'rosshow' in tmp:
						LL.append({'url':url, 'img':img, 'title':title, 'group':gr})
		pDialog.close()
		if LL!=[]:save_channels(serv_id, LL)
		else:showMessage('glaz.tv', 'Не удалось загрузить каналы', times = 3000)
				
		return LL
