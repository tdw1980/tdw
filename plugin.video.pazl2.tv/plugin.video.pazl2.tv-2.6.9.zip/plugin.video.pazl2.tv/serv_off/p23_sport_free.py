#!/usr/bin/python
# -*- coding: utf-8 -*-

import string, xbmc, xbmcgui, xbmcplugin, xbmcaddon
import os, cookielib, urllib, urllib2, time
addon = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
__settings__ = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
#-----------------------------------------

icon = ""
serv_id = '23'
siteUrl = 'sport-free.net'
httpSiteUrl = 'http://' + siteUrl
sid_file = os.path.join(xbmc.translatePath('special://temp/'), siteUrl+'.sid')

cj = cookielib.FileCookieJar(sid_file) 
hr  = urllib2.HTTPCookieProcessor(cj) 
opener = urllib2.build_opener(hr) 
urllib2.install_opener(opener) 

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def getURL(url, Referer = httpSiteUrl, cooke=''):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	if cooke!='': req.add_header('Cookie', cooke)#'PHPSESSID=ajmf143pvcju7qqolpbpomvhj3'
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def get_cooke():
	import requests
	r = requests.get(httpSiteUrl,timeout=5)
	if r.status_code == 200:
		for cookie in r.cookies:
			return cookie

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def save_channels(n, L):
		ns=str(n)
		fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'Channels'+ns+'.py'))
		fl = open(fp, "w")
		fl.write('# -*- coding: utf-8 -*-\n')
		fl.write('Channels=[\n')
		for i in L:
			fl.write(repr(i)+',\n')
		fl.write(']\n')
		fl.close()

class PZL:
	def __init__(self):
		pass

	def Streams(self, url):
			#try:
				http=getURL(url)
				ss="'#player', '"
				es="' );"
				
				st=mfind(http,ss,es)#+'|Cookie=PHPSESSID=ajmf143pvcju7qqolpbpomvhj3;Referer='+httpSiteUrl
				print st
				#get_cooke()
				if len(st)>300: return []
				c=get_cooke()
				print getURL(st, httpSiteUrl, c)
				return [st,]
			#except:
			#	return []
			

	def Canals(self):
		LL=[]
		http=getURL('http://sport-free.net/channels/')
		
		ss='<td><a class="a-flex"'
		es='</div></a></td>'
		L=mfindal(http,ss,es)
		
		for i in L:
			ss='href="'
			es='">'
			url=httpSiteUrl+mfind(i,ss,es)
		
			ss='src="'
			es='" alt'
			img=httpSiteUrl+mfind(i,ss,es)

			ss='<span>'
			es='</span>'
			title=mfind(i,ss,es)
			
			try: title=title.encode('utf-8')
			except:pass
			
			#title=title.replace('Канал ','').strip()
			
			print title
			
			LL.append({'url':url, 'img':img, 'title':title, 'group': 'СПОРТ'})
			
		if LL!=[]:save_channels(serv_id, LL)
		else:showMessage('sport-free', 'Не удалось загрузить каналы', times = 3000)
		
		return LL
