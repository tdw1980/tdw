# -*- coding: utf-8 -*-
Channels=[
{'url': 'rutube:546602986e6a424d74d594876ddb3f04', 'group': '', 'img': '', 'title': '\xd0\xa2\xd0\x9d\xd0\xa2'},
{'url': 'rutube:9f87a9a0cecbe773be6fddcbd93585ac', 'group': '', 'img': '', 'title': '\xd0\x9f\xd1\x8f\xd1\x82\xd0\xbd\xd0\xb8\xd1\x86\xd0\xb0'},
{'url': 'rutube:dfbae35e461b25d827319d93ed5c1d76', 'group': '', 'img': '', 'title': '\xd0\xa1\xd0\xa3\xd0\x9f\xd0\x95\xd0\xa0'},
{'url': 'rutube:7bf12d9c050f9a7ef3728db5730432ae', 'group': '', 'img': '', 'title': '\xd0\xa2\xd0\x92-3'},
{'url': 'rutube:c801a7087e29a097192d74c270fbc6c1', 'group': '', 'img': '', 'title': '\xd0\xa2\xd0\x9d\xd0\xa2 4'},
{'url': 'rutube:ec27028741528445c21860576c21bb08', 'group': '', 'img': '', 'title': '\xd0\x9c\xd0\xa3\xd0\x97-\xd0\xa2\xd0\x92'},
{'url': 'rutube:11bbbec75a2ceb8cf446ad16813c6eec', 'group': '', 'img': '', 'title': '\xd0\x9c\xd0\xb0\xd1\x82\xd1\x87 \xd0\xa2\xd0\x92'},
{'url': 'rutube:42a58f895935bbf495089a2e1fe15e46', 'group': '', 'img': '', 'title': '\xd0\x9d\xd0\xa2\xd0\x92'},
{'url': 'rutube:c02663360b6a87df9a06e5a959cb6fa1', 'group': '', 'img': '', 'title': '\xd0\xbe2\xd1\x82\xd0\xb2'},
]
