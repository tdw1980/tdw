# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, sys, time, urllib
import pztv
PLUGIN_NAME   = 'plugin.video.pazl2.tv'
#handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id=PLUGIN_NAME)
__settings__ = xbmcaddon.Addon(id=PLUGIN_NAME)
pztv.__settings__=__settings__
icon = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'icon.png'))
background = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'fanart.png'))

#from DBcnl import *

def log(text, x3=''):
	print text

#Action Codes
# See guilib/Key.h
ACTION_CANCEL_DIALOG = (9,10,51,92,110)
ACTION_PLAYFULLSCREEN = (12,79,227)
ACTION_MOVEMENT_LEFT = (1,)
ACTION_MOVEMENT_RIGHT = (2,)
ACTION_MOVEMENT_UP = (3,)
ACTION_MOVEMENT_DOWN = (4,)
ACTION_MOVEMENT = (1, 2, 3, 4, 5, 6, 159, 160)
ACTION_INFO = (11,)
ACTION_CONTEXT = (117,)
ACTION_MOVEMENT_ALL = (1, 2, 3, 4, 5, 6, 159, 160, 104, 105, 106, 107)


#ControlIds
CONTROL_CONSOLES = 500
CONTROL_GENRE = 600
CONTROL_YEAR = 700
CONTROL_PUBLISHER = 800
CONTROL_CHARACTER = 900
FILTER_CONTROLS = (500, 600, 700, 800, 900,)
GAME_LISTS = (50, 51, 52,53, 54, 55, 56, 57, 58)
CONTROL_SCROLLBARS = (2200, 2201, 60, 61, 62)

CONTROL_GAMES_GROUP_START = 600
CONTROL_GAMES_GROUP_END = 59

#CONTROL_BUTTON_CHANGE_VIEW = 2
CONTROL_BUTTON_FAVORITE = 1000
CONTROL_BUTTON_SEARCH = 1100
CONTROL_BUTTON_VIDEOFULLSCREEN = (2900, 2901,)
NON_EXIT_RCB_CONTROLS = (500, 600, 700, 800, 900, 2, 1000, 1100)

CONTROL_LABEL_MSG = 4000
CONTROL_BUTTON_MISSINGINFODIALOG = 4001

try:
	epg_settings = xbmcaddon.Addon(id='plugin.program.pazl.epg')
	epg_port=epg_settings.getSetting("serv_port")
except:
	epg_port='8085'


def update_list_epg():
	update_current_epg()
	#try: Lepg=eval(pztv.getURL('http://127.0.0.1:'+epg_port+'/channels/all'))
	#except: Lepg=[]

Arhive={}
def update_Arhive():
	global Arhive
	try: Arhive=pztv.get_arhive_directory()
	except: Arhive={}

current_epg={}
def update_current_epg():
	global current_epg
	global Lepg
	if __settings__.getSetting("epgon")=='true':
		try:
			for p in range (1, 8):
				current_epg_p=eval(pztv.getURL('http://127.0.0.1:'+epg_port+'/current/p='+str(p)))
				if current_epg_p=={}: break
				for k in current_epg_p.keys():
					current_epg[k]=current_epg_p[k]
				
			Lepg=current_epg.keys()
		except:
			print '!except: current_epg'
			try:
				if current_epg == None: 
					current_epg={}
					Lepg=[]
			except:
				current_epg={}
				Lepg=[]
	else:
			current_epg={}
			Lepg=[]

#update_list_epg()
#update_current_epg()

def get_type(title):
	if   'Х/ф ' in title: return 'фильмы'
	elif 'Новости' in title: return 'новости'
	elif 'Т/с ' in title: return 'сериалы'
	elif 'М/с ' in title: return 'детям'
	elif 'Клипы' in title: return 'музыка'
	elif 'Clips' in title: return 'музыка'
	elif 'Playlist' in title: return 'музыка'
	else: return ''

def get_type_art(type):
	film = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'),'images', 'film.jpg'))
	info = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'),'images', 'info.jpg'))
	life = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'),'images', 'life.jpg'))
	mult = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'),'images', 'mult.jpg'))
	news = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'),'images', 'news.jpg'))
	show = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'),'images', 'show.jpg'))
	sport = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'),'images', 'sport.jpg'))
	science = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'),'images', 'science.jpg'))
	music = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'),'images', 'music.jpg'))
	
	if   type=='фильмы' or type=="movie":  return film
	elif type=='инфо'  or type=="info":    return info
	elif type=='досуг' or type=='live':    return life
	elif type=='детям':                    return mult
	elif type=='новости':                  return news
	elif type=='познавательное':           return science
	elif type=='сериалы' or type=='tvshow': return show
	elif type=='sport'   or type=='спорт' : return sport
	elif type=='музыка'                   : return music
	else: return background



class VFS_XML(xbmcgui.WindowXML):
	selectedControlId = 0
	def __init__(self,strXMLname, strFallbackPath, strDefaultName, forceFallback):
		#xbmcplugin.endOfDirectory(handle, False, False)
		self.uptime=0
		self.info_visible=True
		#self.time_visible=time.time()
		pass


	def onInit(self):
		print '-=-=-=-=-=-=- VFS_XML onInit =-=-=-=-=-=-=-'
		self.tugle_info_visible(True)
		self.setFocus(self.getControl(1))
		#self.setEPG()
		if xbmc.Player().isPlaying():
			last_id =__settings__.getSetting("cplayed")
			v_id =__settings__.getSetting("v_id")
			if last_id != v_id: 
				#__settings__.setSetting("lastplayed", v_id)
				#xbmc.sleep(300)
				pztv.play(v_id)
		else:
			v_id =__settings__.getSetting("v_id")
			#__settings__.setSetting("lastplayed", v_id)
			#xbmc.sleep(300)
			pztv.play(v_id)
		
		print '-=-=-=-=-=-=- VFS_XML onInit 2=-=-=-=-=-=-=-'
		#self.tugle_info_visible(True)
		#print '-=-=-=-=-=-=- VFS_XML onInit 2000=-=-=-=-=-=-=-'
		#xbmc.sleep(2000)
		#print '-=-=-=-=-=-=- VFS_XML onInit 2000 ok=-=-=-=-=-=-=-'
		self.tugle_info_visible(False)
		print '-=-=-=-=-=-=- VFS_XML onInit info_visible(False)=-=-=-=-=-=-=-'
		#while  xbmc.Player().isPlaying():
		#		xbmc.sleep(500)
		#		self.setEPG()
		print '-=-=-=-=-=-=- VFS_XML onInit 3=-=-=-=-=-=-=-'
		while  xbmc.Player().isPlaying():
				xbmc.sleep(500)
		print '-=-=-=-=-=-=- VFS_XML onInit 4=-=-=-=-=-=-=-'
		#if not xbmc.Player().isPlaying():
		__settings__.setSetting("lastplayed", '')
		print '-=-=-=-=-=-=- VFS_XML onInit 5=-=-=-=-=-=-=-'
		self.close()
	
	def onAction(self, action):
		#self.time_visible=time.time()
		log("onAction: "+ str(action.getId()))
		# Same as normal python Windows.
		if(action.getId() == 0):
			log("actionId == 0. Input ignored")
			return
		#try:
		if(action.getId() in ACTION_CANCEL_DIALOG):
				log("onAction: ACTION_CANCEL_DIALOG")
					
				#don't exit RCB here. Just close the filters
				if(self.selectedControlId in NON_EXIT_RCB_CONTROLS):
					#HACK: when list is empty, focus sits on other controls than game list
					if(self.getListSize() > 0):
						self.setFocus(self.getControl(CONTROL_GAMES_GROUP_START))
						return
					
					log("ListSize == 0 in onAction. Assume that we have to exit.", util.LOG_LEVEL_WARNING)
							
				#if(self.player.isPlayingVideo()):
				#	self.player.stop()
					#xbmc.sleep(util.WAITTIME_PLAYERSTOP)
				if self.selectedControlId in [8,9,10,11]: 
					self.setFocus(self.getControl(1))
					self.tugle_info_visible(False)
				elif self.info_visible==False: 
					self.close()
		
		if action.getId() == 13 :
			xbmc.Player().stop()
			self.close()
		
		if action.getId() == 11 :
			self.tugle_info_visible()
		
		#if action.getId() == 107 : self.setFocus(self.getControl(9))
		
		if action.getId() in ACTION_MOVEMENT_UP: self.Next()
			
		if action.getId() in ACTION_MOVEMENT_DOWN: self.Prev()
			
		self.setEPG()
			
			
	def onClick(self, controlID):
		print 'onClick ' +str(controlID)
		if controlID == 8: pztv.select_stream()
		if controlID == 11:
			xbmc.Player().stop()
			self.close()
		if controlID == 10 : self.Next()
		if controlID == 9 :  self.Prev()
		if controlID == 1 : 
			self.tugle_info_visible(True)
			self.setFocus(self.getControl(9))
		if controlID == 6 : 
			self.tugle_info_visible(False)
			self.setFocus(self.getControl(1))
	
	def onFocus(self, controlID):
		self.selectedControlId = controlID

	def tugle_info_visible(self, vis=' '):
		if vis==True:
			self.uptime=0
			self.setEPG()
		win = xbmcgui.Window (xbmcgui.getCurrentWindowId())
		#self.time_visible=time.time()
		if vis==False:
			self.info_visible=False
			win.setProperty('info_visible',  '')
		elif vis==True:
			self.info_visible=True
			win.setProperty('info_visible',  'true')
		else:
			if self.info_visible==True:
				self.info_visible=False
				win.setProperty('info_visible',  '')
			else: 
				self.info_visible=True
				win.setProperty('info_visible',  'true')
		
		if self.info_visible==False: self.setFocus(self.getControl(1))
	
	def Next(self):
			
			v_id =__settings__.getSetting("next_itm")
			__settings__.setSetting("v_id", v_id)
			self.tugle_info_visible(True)
			
			__settings__.setSetting("n_play","0")
			v_id=pztv.next ('>')
			
			v_id =__settings__.getSetting("cplayed")
			__settings__.setSetting("v_id", v_id)
			self.tugle_info_visible(True)
			
			if self.selectedControlId not in [9,10,11]:
				#xbmc.sleep(2000)
				self.tugle_info_visible(False)

	def Prev(self):
			__settings__.setSetting("n_play","0")
			v_id =__settings__.getSetting("prev_itm")
			__settings__.setSetting("v_id", v_id)
			self.tugle_info_visible(True)
			
			v_id=pztv.next ('<')
			
			v_id =__settings__.getSetting("cplayed")
			__settings__.setSetting("v_id", v_id)
			self.tugle_info_visible(True)
			if self.selectedControlId not in [9,10,11]:
				#xbmc.sleep(2000)
				self.tugle_info_visible(False)


	def setEPG(self):
			try:
				delta=time.time()-self.uptime
				if delta > 45: 
					print '============================ uptime '
					id =__settings__.getSetting("v_id")
					
					self.uptime=time.time()
					print '===== set_epg '+id+' ====='
					EPG=[]
					#if id in Lepg and __settings__.getSetting("epgon")=='true':
					if id in Lepg and __settings__.getSetting("epgon")=='true':
							print '===== set_epg ON'
							lnk='http://127.0.0.1:'+epg_port+'/channels/'+id
							try:EPG=eval(pztv.getURL(lnk))
							except:EPG=[]
					
					if EPG!=[]:
							try:EPG0_time=time.ctime(eval(EPG[0]['time']))[-13:-8]
							except: EPG0_time=''
							try:EPG0_title=EPG[0]['title']
							except: EPG0_title=''
							try:EPG0_img=EPG[0]['img']
							except: EPG0_img=''#background
							try:EPG0_plot=EPG[0]['plot']
							except: EPG0_plot=''

								
							try:EPG1_time=time.ctime(eval(EPG[1]['time']))[-13:-8]
							except: EPG1_time=''
							try:EPG1_title=EPG[1]['title']
							except: EPG1_title=''
							print '===== set_epg ok1'
					else:
							EPG0_time=''
							EPG0_title=''
							EPG0_img=''#background
							EPG0_plot=''
							EPG1_time=''
							EPG1_title=''
							print '===== set_epg None'
					
					if EPG0_time!='' and EPG1_time!='':
						t0=eval(EPG[0]['time'])
						t1=eval(EPG[1]['time'])
						tc=time.time()
						total=t1-t0
						back=tc-t0
						percent=int(back*100/total)
						print '===== set_epg bar ok'
					else:
						percent=0
						print '===== set_epg bar none'
					
					win = xbmcgui.Window (xbmcgui.getCurrentWindowId())
					
					win.setProperty('EPG1_time',  EPG1_time)
					win.setProperty('EPG1_title', EPG1_title)
					win.setProperty('EPG0_time',  EPG0_time)
					win.setProperty('EPG0_img',   EPG0_img)
					win.setProperty('EPG0_title', EPG0_title)
					win.setProperty('EPG0_plot',  EPG0_plot)
					win.setProperty('picon',   pztv.get_picon(id))
					win.setProperty('title',   pztv.DBC[id]['title'])
					
					bar=self.getControl(5)
					bar.setWidth(percent*5)
					print '=========== set_epg done =========='
			except:
				print '=========== set_epg ERRRRRRRRRRRRRRR =========='
				pass



class UI_XML(xbmcgui.WindowXML):#Dialog
	selectedControlId = 0
	def __init__(self,strXMLname, strFallbackPath, strDefaultName, forceFallback):
		# Changing the three varibles passed won't change, anything
		# Doing strXMLname = "bah.xml" will not change anything.
		# don't put GUI sensitive stuff here (as the xml hasn't been read yet
		# Idea to initialize your variables here
		#xbmcplugin.endOfDirectory(handle, False, False)
		self.CurrentListPosition=0
		self.uptime=0
		if __settings__.getSetting("arhon")=='true': update_Arhive()
		pass

	def onInit(self):
		try:
			# Put your List Populating code/ and GUI startup stuff here
			self.setFocus(self.getControl(CONTROL_GAMES_GROUP_START))
			#self.clearList()
			
			self.showList()
			
			abc=__settings__.getSetting("abc")
			btn=self.getControl(1)
			if abc == 'false':	btn.setLabel('Порядок: Свой')
			else:				btn.setLabel('Порядок: ABC')
			
			if __settings__.getSetting("cllogo")=='true':
				__settings__.setSetting("cllogo",'false')
				pztv.cllogo()
			
		except:
			pass


	def onAction(self, action):
		log("onAction: "+ str(action.getId()))
		# Same as normal python Windows.
		if(action.getId() == 0):
			log("actionId == 0. Input ignored")
			return
		
		#try:
		if(action.getId() in ACTION_CANCEL_DIALOG):
				log("onAction: ACTION_CANCEL_DIALOG")
				self.exit()
		#except:
		#	log("onAction: ERRR")
		elif (action.getId() in ACTION_CONTEXT):
				self.showContextMenu()
		
		if action.getId() in ACTION_MOVEMENT_ALL:
			self.CurrentListPosition=self.getCurrentListPosition()
			self.setINFO()
			#try:uptime=eval(__settings__.getSetting("uptime"))
			#except: uptime=0
			delta=time.time()-self.uptime
			if delta > 55: 
				self.updateEPG()
				#__settings__.setSetting("uptime", repr(time.time()))
		if(action.getId() == 13):# stop
			#self.showList()
			self.setPlayed()
		if(action.getId() == 11):# info
			if self.selectedControlId == 600:
				list1=self.getControl(600)
				listitem = list1.getSelectedItem()
				curl = listitem.getProperty('arhive')
				id   = listitem.getProperty('id')
				if curl!='': 
					__settings__.setSetting("arhive_cnl", curl)
					__settings__.setSetting("arhive_cnl_id", id)
					self.run_arhive()#xbmc.executebuiltin('ActivateWindow(10025,"'+curl+'", return)')


	def onClick(self, controlID):
		print 'onClick ' +str(controlID)
		if controlID == 600:
			#n = self.getCurrentListPosition()
			#listitem = self.getListItem(n)
			id = self.get_cnl_id() #id = listitem.getProperty('id')
			if id=='': self.exit()
			else: 
				__settings__.setSetting("v_id", id)
				if __settings__.getSetting("xplay")=='false':
					pztv.play(id)
				else:
					skin = "Default"
					vfs = VFS_XML("PTV-VideoFullScreen.xml", addon.getAddonInfo('path'), skin, "720p")
					vfs.doModal()
					del vfs
				
				#self.showList()
				self.setPlayed()
				
		if controlID == 800:
			list=self.getControl(controlID)
			clp=list.getSelectedPosition()
			listitem=list.getSelectedItem()
			SG=listitem.getLabel()
			if 'COLOR' in SG: SG=pztv.get_access_gr(SG)
			if 'COLOR' not in SG:__settings__.setSetting("Sel_gr",SG)
			self.CurrentListPosition=0
			self.showList()
			list.selectItem(clp)
		if controlID == 5:
			__settings__.openSettings()
			self.showList()
		if controlID == 1:
			abc=__settings__.getSetting("abc")
			btn=self.getControl(controlID)
			if abc == 'true':
				__settings__.setSetting("abc", 'false')
				btn.setLabel('Порядок: Свой')
			else:
				__settings__.setSetting("abc", 'true')
				btn.setLabel('Порядок: ABC')
			self.showList()

	def onFocus(self, controlID):
		self.setINFO()
		self.selectedControlId = controlID
		if controlID == 6: 
			list=self.getControl(800)
			self.setFocusId(800)
			list.selectItem(list.size()-1)
			
		#print controlID
		pass

	def exit(self):
		if pztv.get_autoexit_gr(): __settings__.setSetting("Sel_gr", 'Все каналы')
		log("PTV exit")
		self.close()
	
	def get_cnl_id(self):
			list1=self.getControl(600)
			#n = self.getCurrentListPosition()
			listitem = list1.getSelectedItem()#list1.getListItem(n)
			id = listitem.getProperty('id')
			return id
	
	def getCurrentListPosition(self):
		list1=self.getControl(600)
		n=list1.getSelectedPosition()
		return n
	
	def setCurrentListPosition(self, n):
		list1=self.getControl(600)
		list1.selectItem(n)
	
	def set_cnl_epg(self, cid1):
		D2=eval(pztv.getURL('http://127.0.0.1:'+epg_port+'/channels/dict'))
		D2['- НЕ СВЯЗАН']='000000'
		L=D2.keys()
		L.sort()
		sel = xbmcgui.Dialog()
		r = sel.select("Выберите программу передач:", L)
		if r>-1:
			nm=L[r]
			cid2=D2[nm]
			#print cid2+' to '+cid1
			pztv.getURL('http://127.0.0.1:'+epg_port+'/change/id='+cid2+'/to='+cid1)
		update_list_epg()
		self.updateEPG()

	def showContextMenu(self):
		clp=self.getCurrentListPosition()
		controlID=self.selectedControlId
		print 'showContextMenu '+ str(controlID)
		if controlID == 600:
			id = self.get_cnl_id()
			if __settings__.getSetting("abc")=='true': 
				  context=['Добавить в группу','Удалить из группы','Объеденить с каналом', 'Разделить канал','Переименовать канал', 'Установить EPG']
			else: context=['Добавить в группу','Удалить из группы','Переместить в группе','Объеденить с каналом', 'Разделить канал','Переименовать канал', 'Установить EPG']
			if id in Arhive.keys(): context.append('Архив')
			
			sel = xbmcgui.Dialog()
			r = sel.select("", context)
			if r>=0:
				func=context[r]
				if   func=='Добавить в группу':    pztv.add_to_gr(id)
				elif func=='Удалить из группы':    pztv.rem_from_gr(id)
				elif func=='Переместить в группе': pztv.set_num_cn(id)
				elif func=='Объеденить с каналом': pztv.append_cnl(id)
				elif func=='Разделить канал':      pztv.split_cnl(id)
				elif func=='Переименовать канал':  pztv.rename_cnl(id)
				elif func=='Установить EPG':       self.set_cnl_epg(id)
				elif func=='Архив':                self.context_arhive()
				
				if   func!='Добавить в группу': self.showList()
		if controlID == 800:
			context1=['Создать группу','Удалить группу','Переместить группу','Переименовать группу', 'Объединить с группой','Установить пароль','Редактор каналов','Обновить каналы','Обновить телепрограмму']
			context2=['Создать группу','Переместить группу','Снять пароль','Редактор каналов','Обновить каналы','Обновить телепрограмму']
			list2=self.getControl(800)
			listitem=list2.getSelectedItem()
			label=listitem.getLabel()
			if 'COLOR' in label:
				label=label.replace('[COLOR 44FFFFFF]','').replace('[/COLOR]','')
				context=context2
			else:
				context=context1
			sel = xbmcgui.Dialog()
			r = sel.select("", context)
			if r>=0:
				func=context[r]
				
				if   func=='Создать группу':       pztv.add_gr()
				elif func=='Удалить группу':       pztv.rem_gr(label)
				elif func=='Переместить группу':   pztv.move_gr(label)
				elif func=='Переименовать группу': pztv.rename_gr(label)
				elif func=='Объединить с группой': pztv.extend_gr(label)
				elif func=='Установить пароль':    pztv.set_pass_gr(label)
				elif func=='Снять пароль':         pztv.rem_pass_gr(label)
				elif func=='Редактор каналов':     self.run_editor()
				elif func=='Обновить каналы':      pztv.update_cnl()
				elif func=='Обновить телепрограмму': pztv.getURL('http://127.0.0.1:'+epg_port+'/update')

				if label == __settings__.getSetting("Sel_gr"): __settings__.setSetting("Sel_gr", 'Все каналы')
				self.showList()
		self.setCurrentListPosition(clp)

	def context_arhive(self):
				list1=self.getControl(600)
				listitem = list1.getSelectedItem()
				id = listitem.getProperty('id')
				curl = listitem.getProperty('arhive')
				if curl!='': 
					__settings__.setSetting("arhive_cnl", curl)
					__settings__.setSetting("arhive_cnl_id", id)
					self.run_arhive()

	def setINFO(self):
			list1=self.getControl(600)
			item=list1.getSelectedItem()
			win = xbmcgui.Window (xbmcgui.getCurrentWindowId())
			
			try:
					win.setProperty('EPG2_time',  item.getProperty('EPG2_time'))
					win.setProperty('EPG2_title', item.getProperty('EPG2_title'))
					win.setProperty('EPG1_time',  item.getProperty('EPG1_time'))
					win.setProperty('EPG1_title', item.getProperty('EPG1_title'))
					win.setProperty('EPG0_title', item.getProperty('EPG0_title'))
					win.setProperty('EPG0_time',  item.getProperty('EPG0_time'))
					win.setProperty('EPG0_img',   item.getProperty('EPG0_img'))
					win.setProperty('EPG0_plot',  item.getProperty('EPG0_plot'))
					for i in range(0,11):
						if item.getProperty('EPG_pr'+str(i*10)) == 'true': win.setProperty('EPG_pr'+str(i*10), 'true')
						else: win.setProperty('EPG_pr'+str(i*10), '')
			except:
				print '=========== set_info ERRRRRRRRRRRRRRR =========='


	def set_epg(self, item):
		self.uptime=time.time()
		id=item.getProperty('id')
		#print '===== set_epg '+id+' ====='
		#if id in Lepg:
					#lnk='http://127.0.0.1:'+epg_port+'/channels/'+id
					#print lnk
		EPG={}
		try:
			if id in current_epg.keys(): EPG=current_epg[id]#eval(pztv.getURL(lnk))
		except: 
			print 'err current_epg '+id
		
		if EPG!={}:
					try:EPG0_time=time.ctime(eval(EPG[0]['time']))[-13:-8]
					except: EPG0_time=''
					try:EPG0_title=EPG[0]['title']
					except: EPG0_title=''
					try:EPG0_img=EPG[0]['img']
					except: EPG0_img=background
					if EPG0_img=='':EPG0_img=background
					try:EPG0_plot=EPG[0]['plot']
					except: EPG0_plot=''
					try:EPG0_type=EPG[0]['type']
					except: EPG0_type=''
					
					try:EPG1_time=time.ctime(eval(EPG[1]['time']))[-13:-8]
					except: EPG1_time=''
					try:EPG1_title=EPG[1]['title']
					except: EPG1_title=''
					
					try:EPG2_time=time.ctime(eval(EPG[2]['time']))[-13:-8]
					except: EPG2_time=''
					try:EPG2_title=EPG[2]['title']
					except: EPG2_title=''
					
		else:
					EPG0_time=''
					EPG0_title=''
					EPG0_img=background
					EPG0_plot=''
					EPG0_type=''
					EPG1_time=''
					EPG1_title=''
					EPG2_time=''
					EPG2_title=''
		
		if EPG0_time!='' and EPG1_time!='':
				t0=eval(EPG[0]['time'])
				t1=eval(EPG[1]['time'])
				tc=time.time()
				total=t1-t0
				back=tc-t0
				percent=int(back*100/total)
				for i in range(0,11):
					if i*10 <= percent < i*10+10 :  item.setProperty('EPG_pr'+str(i*10), 'true')
					else:				item.setProperty('EPG_pr'+str(i*10), 'false')
		
		if __settings__.getSetting("fanart")=='false': EPG0_img=background
		
		if __settings__.getSetting("typeart")=='true': 
			if EPG0_type=='':EPG0_type=get_type(EPG0_title)
			if EPG0_type!='' and EPG0_img==background: EPG0_img=get_type_art(EPG0_type)
		item.setProperty('EPG0_time',  EPG0_time)
		item.setProperty('EPG0_title', EPG0_title)
		item.setProperty('EPG0_img',   EPG0_img)
		item.setProperty('EPG0_plot',  EPG0_plot)#EPG0_type+"\n"+
		
		item.setProperty('EPG1_time',  EPG1_time)
		item.setProperty('EPG1_title', EPG1_title)
		item.setProperty('EPG2_time',  EPG2_time)
		item.setProperty('EPG2_title', EPG2_title)
		self.setINFO()
		#return item
		
	def showList(self):
		
		#__settings__.setSetting("uptime", repr(time.time()))
		#Каналы
		L=pztv.root(__settings__.getSetting("Sel_gr"))
		list1=self.getControl(600)
		pos = self.getCurrentListPosition()
		#if __settings__.getSetting("dinamic")=='false':self.clearList()
		list1.reset()
		
		if xbmc.Player().isPlaying(): last_id =__settings__.getSetting("cplayed")
		else: last_id ='0'
		n=0
		pos_set=True
		for i in L:
				#if last_id == i['id']: title='[COLOR FFFFAA22]'+i['title']+'[/COLOR]'
				#else: 
				title=i['title']
				#if i['id'] in Arhive.keys(): arh=Arhive[i['id']]
				#else: arh=""
					
				item = xbmcgui.ListItem(title)
				item.setProperty('background', background)
				
				item.setProperty('id', i['id'])
				#item.setProperty('arhive', arh)
				if __settings__.getSetting("intlogo")=='true':
					item.setProperty('picon', i['picon'])
					try:item.setProperty('picon_background', os.path.join(os.path.split(i['picon'])[0], 'background.png'))
					except: pass
					
					
				#item = self.set_epg(item)
				
				list1.addItem(item)
				
				if n==self.CurrentListPosition and pos_set: self.setCurrentListPosition(self.CurrentListPosition)
				if last_id == i['id']: 
					pos_set=False
					self.setCurrentListPosition(n)
					self.CurrentListPosition=n
				n+=1
				
		
		self.setPlayed()
		self.setCurrentListPosition(self.CurrentListPosition)
		if __settings__.getSetting("arhon")=='true': self.setArhive()
		
		#Группы
		self.getControl(95).setLabel('Группа: '+__settings__.getSetting("Sel_gr"))
		list2=self.getControl(800)
		list2.reset()
		Lgr=pztv.select_gr('', True)
		n=0
		for i in Lgr:
				item = xbmcgui.ListItem(str(i))
				list2.addItem(item)
		
		if len(L)>0: self.setFocus(self.getControl(CONTROL_GAMES_GROUP_START))
		else:self.setFocus(self.getControl(800))
		
		self.updateEPG()
		
	
	def setPlayed(self):
			if xbmc.Player().isPlaying(): last_id =__settings__.getSetting("cplayed")
			else: last_id ='0'
			list1=self.getControl(600)
			try:n=list1.size()
			except: return
			for i in range(0, n):
				
				try:
					item = list1.getListItem(i)
					if last_id == item.getProperty('id'): item.setLabel2(item.getLabel())
					else: item.setLabel2('')
				except:
					pass
	
	def setArhive(self):
			list1=self.getControl(600)
			try:n=list1.size()
			except: return
			for i in range(0, n):
				item = list1.getListItem(i)
				id = item.getProperty('id')
				if id in Arhive.keys(): arh=Arhive[id]
				else: arh=""
				item.setProperty('arhive', arh)


	def updateEPG(self):
		list1=self.getControl(600)
		if __settings__.getSetting("epgon")=='true':
			for i in range(0, list1.size()):
				try:
					item = list1.getListItem(i)
					self.set_epg(item)
				except: pass
			
			update_current_epg()
			
			try:n=list1.size()
			except: return
			for i in range(0, n):
				try:
					item = list1.getListItem(i)
					self.set_epg(item)
				except: 
					#self.close()
					print 'ERR: Ошибка назначения EPG элементу '+str(i)
		else:
			try:n=list1.size()
			except: return
			for i in range(0, n):
				try:
					item = list1.getListItem(i)
					#item.setProperty('EPG0_title', item.getLabel())
					item.setProperty('EPG0_img',background)#item.getProperty('picon')
				except: 
					print 'ERR: Ошибка назначения EPG элементу '+str(i)
	
	def run_editor(self):
				skin = "Default"
				editor = EDITOR_XML("PTV-EDITOR.xml", addon.getAddonInfo('path'), skin, "720p")
				editor.doModal()
				del editor

	def run_arhive(self):
				skin = "Default"
				arhive = ARHIVE_XML("PTV-arhive.xml", addon.getAddonInfo('path'), skin, "720p")
				arhive.doModal()
				del arhive


class EDITOR_XML(xbmcgui.WindowXML):
	def __init__(self,strXMLname, strFallbackPath, strDefaultName, forceFallback):
		pass
	
	def onInit(self):
		self.showList()
		self.setFocus(self.getControl(500))


	def showList(self):
		#Группы
		
		SG=pztv.get_SG()
		list1=self.getControl(500)
		list1.reset()
		Lgr=pztv.select_gr('', True)
		for i in Lgr:
				item = xbmcgui.ListItem(str(i))
				if SG==str(i): item.setLabel2(str(i))
				else:item.setLabel2('')
				list1.addItem(item)

		# Все каналы
		CL=pztv.get_gr()
		list2=self.getControl(600)
		list2.reset()
		if pztv.get_autoexit_gr(): pas=False
		else: pas=True
		Lcn=pztv.get_gr('Все каналы', pas)
		for i in Lcn:
				title=pztv.DBC[i]['title']
				item = xbmcgui.ListItem(title)
				if i in CL: item.setLabel2(title)
				else:item.setLabel2('')
				item.setProperty('id', i)
				list2.addItem(item)

		list3=self.getControl(700)
		list3.reset()
		Lcn=pztv.get_gr()
		for i in Lcn:
			
				try:title=pztv.DBC[i]['title']
				except: title=i
				item = xbmcgui.ListItem(title)
				item.setProperty('id', i)
				list3.addItem(item)


	def color500(self):
		SG=pztv.get_SG()
		list1=self.getControl(500)
		Lgr=pztv.select_gr('', True)
		n=0
		for i in Lgr:
				item=list1.getListItem(n)
				if SG==str(i): item.setLabel2(str(i))
				else:item.setLabel2('')
				n+=1

	def color600(self):
		CL=pztv.get_gr()
		list2=self.getControl(600)
		if pztv.get_autoexit_gr(): pas=False
		else: pas=True
		Lcn=pztv.get_gr('Все каналы', pas)
		n=0
		for i in Lcn:
				title=pztv.DBC[i]['title']
				item=list2.getListItem(n)
				if i in CL: item.setLabel2(title)
				else:item.setLabel2('')
				n+=1

	def reset600(self):
		CL=pztv.get_gr()
		list2=self.getControl(600)
		list2.reset()
		if pztv.get_autoexit_gr(): pas=False
		else: pas=True
		Lcn=pztv.get_gr('Все каналы', pas)
		for i in Lcn:
				title=pztv.DBC[i]['title']
				item = xbmcgui.ListItem(title)
				if i in CL: item.setLabel2(title)
				else:item.setLabel2('')
				item.setProperty('id', i)
				list2.addItem(item)



	def reset700(self):
		list3=self.getControl(700)
		list3.reset()
		Lcn=pztv.get_gr()
		for i in Lcn:
				title=pztv.DBC[i]['title']
				item = xbmcgui.ListItem(title)
				item.setProperty('id', i)
				list3.addItem(item)


	def onClick(self, controlID):
		print 'onClick ' +str(controlID)
				
		if controlID == 500:
			list=self.getControl(controlID)
			listitem=list.getSelectedItem()
			SG=listitem.getLabel()
			if 'COLOR' in SG: SG=pztv.get_access_gr(SG)
			if 'COLOR' not in SG:
				__settings__.setSetting("Sel_gr",SG)
			self.color500()
			self.reset600()
			self.reset700()
		
		if controlID == 600:
			list=self.getControl(controlID)
			listitem=list.getSelectedItem()
			id=listitem.getProperty('id')
			if listitem.getLabel2()=='': pztv.add_to_gr(id, pztv.get_SG())
			else: pztv.rem_from_gr(id)
			self.color500()
			self.color600()
			self.reset700()
		
		if controlID == 700:
			list=self.getControl(controlID)
			listitem=list.getSelectedItem()
			id=listitem.getProperty('id')
			pztv.rem_from_gr(id)
			list.removeItem(list.getSelectedPosition())
			self.color600()

		if controlID == 5:
			__settings__.openSettings()
			self.showList()
			

class ARHIVE_XML(xbmcgui.WindowXML):
	def __init__(self,strXMLname, strFallbackPath, strDefaultName, forceFallback):
		self.dir=__settings__.getSetting("arhive_cnl")
		self.cid=__settings__.getSetting("arhive_cnl_id")
		try: self.epg=eval(pztv.getURL('http://127.0.0.1:'+epg_port+'/channel/full/id='+str(self.cid)))
		except: self.epg={}
		pztv.set_arhive_date(0)
	
	def onInit(self):
		self.showList()
		self.setFocus(self.getControl(600))
	
	def showList(self):
		win = xbmcgui.Window (xbmcgui.getCurrentWindowId())
		picon = pztv.get_picon(self.cid)
		ctitle = pztv.DBC[self.cid]['title']
		arhive_date = pztv.get_arhive_date()
		win.setProperty('update', 'update.gif')
		win.setProperty('picon',  picon)
		win.setProperty('picon_background', os.path.join(os.path.split(picon)[0], 'background.png'))
		win.setProperty('title',  ctitle)
		win.setProperty('date',  arhive_date)
		#даты
		list1=self.getControl(500)
		list1.reset()
		for i in range (0,10):
			ssec=i*24*60*60
			t=time.localtime(time.time() - ssec)
			st=time.strftime('%d.%m.%Y',t)
			item = xbmcgui.ListItem(st)
			if st == arhive_date: item.setLabel2(st)
			list1.addItem(item)
		
		# передачи
		list2=self.getControl(600)
		list2.reset()
		D=pztv.get_arhive_canale(self.dir)
		L=D.keys()
		L.sort()
		for title in L:
			item = xbmcgui.ListItem(title)
			item.setProperty('curl', D[title])
			
			if __settings__.getSetting("epgarhon") == 'true':
				try:
					st=arhive_date+'-'+title[:5]
					strptime=time.strptime(st , '%d.%m.%Y-%H:%M')
					tmt=str(time.mktime(strptime))
				except:
					tmt=''
				if tmt in self.epg.keys():
					item.setProperty('img', self.epg[tmt]['img'])
					plot=self.epg[tmt]['plot']
					item.setProperty('plot', plot[:151]+"\n"+plot[150:300])
			
			list2.addItem(item)
		
		if D!={}: self.setFocus(self.getControl(600))
		else: self.setFocus(self.getControl(500))
		win.setProperty('update', '')

	def onClick(self, controlID):
		print 'onClick ' +str(controlID)
		
		if controlID == 600:
			
			list=self.getControl(controlID)
			listitem=list.getSelectedItem()
			curl=listitem.getProperty('curl')
			#xbmc.executebuiltin('ActivateWindow(10025,"'+curl+'", return)')
			
			D=pztv.get_arhive_strm(curl)
			playlist = xbmc.PlayList (xbmc.PLAYLIST_VIDEO)
			playlist.clear()
			for title in D.keys():
				purl=D[title]
				item = xbmcgui.ListItem(title, path=purl)
				playlist.add(url=purl, listitem=item)
			player=xbmc.Player()
			player.play(playlist)
			
		if controlID == 500:
			list=self.getControl(controlID)
			r=list.getSelectedPosition()
			pztv.set_arhive_date(r)
			self.showList()



def main():
	#settings = util.getSettings()
	#skin = settings.getSetting(util.SETTING_RCB_SKIN)
	#if(skin == "Confluence"):
	skin = "Default"
	ui = UI_XML("PTV-main.xml", addon.getAddonInfo('path'), skin, "720p")
	ui.doModal()
	del ui

#xbmcplugin.endOfDirectory(handle, False, False)
main()
