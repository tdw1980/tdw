#!/usr/bin/python
# -*- coding: utf-8 -*-

import string, xbmc, xbmcgui, xbmcplugin, xbmcaddon
import os, cookielib, urllib, urllib2, time
addon = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
__settings__ = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
#-----------------------------------------

icon = ""
serv_id = '16'
siteUrl = 'player.vgtrk.com'
httpSiteUrl = 'http://' + siteUrl
sid_file = os.path.join(xbmc.translatePath('special://temp/'), siteUrl+'.sid')

cj = cookielib.FileCookieJar(sid_file) 
hr  = urllib2.HTTPCookieProcessor(cj) 
opener = urllib2.build_opener(hr) 
urllib2.install_opener(opener) 

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def unmark(nm):
	for i in range (0,20):
		nm=nm.replace(" #"+str(i),"")
	return nm

def lower_old(s):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.lower().encode('utf-8')
	return s

def lower(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in range (65,90):
		t=t.replace(chr(i),chr(i+32))
	for i in RUS.keys():
		t=t.replace(i,RUS[i])
	return t

def upper(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in RUS.keys():
		t=t.replace(RUS[i],i)
	for i in range (65,90):
		t=t.replace(chr(i+32),chr(i))
	return t

def get_HTML(url, post = None, ref = None, get_redirect = False):
    import urlparse
    if url.find('http')<0 :
        if CT=="0": url='http:'+url
        else: url='https:'+url
    #url="http://translate.googleusercontent.com/translate_c?u="+url
    request = urllib2.Request(url, post)

    host = urlparse.urlsplit(url).hostname
    if ref==None:
        try:
           ref='http://'+host
        except:
            ref='localhost'

    request.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
    request.add_header('Host',   host)
    request.add_header('Accept', 'text/html, application/xhtml+xml, */*')
    request.add_header('Accept-Language', 'ru-RU')
    request.add_header('Referer',             ref)
    request.add_header('Content-Type','application/x-www-form-urlencoded')

    try:
        f = urllib2.urlopen(request)
    except IOError, e:
        if hasattr(e, 'reason'):
           print('We failed to reach a server.')
        elif hasattr(e, 'code'):
           print('The server couldn\'t fulfill the request.')
        return 'We failed to reach a server.'

    if get_redirect == True:
        html = f.geturl()
    else:
        html = f.read()

    return html

def Login():
	url1 = 'http://torrent-tv.ru/auth.php'
	login = __settings__.getSetting("ttv_login")
	passw = __settings__.getSetting("ttv_password")
	if login == '' or passw == '': return False
	
	values = {
				'email'     : login,
				'password'  : passw,
				'remember'    : 'on',
				'enter'    : 'Войти'
		}
	post = urllib.urlencode(values)
	html = get_HTML(url1, post, 'http://torrent-tv.ru/')
	return True

def getURL(url, Referer = httpSiteUrl):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def save_channels(ns, L):
		fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'Channels'+ns+'.py'))
		fl = open(fp, "w")
		fl.write('# -*- coding: utf-8 -*-\n')
		fl.write('Channels=[\n')
		for i in L:
			fl.write(repr(i)+',\n')
		fl.write(']\n')
		fl.close()

Android_User_Agent = 'Opera/6.10.2 Android/4.4.4 phone/Galaxy Tab E/arm64'
class PZL:
	def __init__(self):
		pass

	def Streams(self, url):
			hp=getURL(url)
			L=hp.splitlines()
			link=mfind(hp,'{"mp4":"","m3u8":"','"},picture:')
			m3u8=getURL(link)
			Lm3u=m3u8.splitlines()
			L2=[]
			for i in Lm3u:
				if '#EXT' not in i and '.m3u' in i:
					steream = link.replace('playlist.m3u8?', i+'|cookie=').replace('&e=', '; e=')
					L2.append(steream)
			#steream2 = link.replace('playlist.m3u8?', 'chunklist_b400000.m3u8|cookie=').replace('&e=', '; e=')
			#cookie = link[link.find('md5'):]
			#cookie = cookie.replace('&', "; ")
			#link='https://livehlsvgtrk.cdnvideo.ru/live/smil:r24.smil/chunklist_b800000.m3u8|cookie='+cookie
			print L2
			return L2

	def Canals(self):
		list={'Россия 1':'1', 'Россия 24':'3', 'Культура':'4', 'Россия РТР':'82', 'Россия HD':'86', 'Москва 24':'76', 'Вести FM':'199'}
		LL=[]
		for cn in list.keys():
			title = cn
			hp=getURL('http://live.russia.tv/index/index/channel_id/'+list[cn])
			id=mfind(hp,'/iframe/live/id/', '/showZoomBtn/')
			url="https://player.vgtrk.com/iframe/live/id/"+id+"/showZoomBtn/false/isPlay/true/"
			img="http://live.russia.tv/i/small_logo/ch-logo-"+list[cn]+".png"
			LL.append({'url':url, 'img':img, 'title':title, 'group':""})

		if LL!=[]: save_channels(serv_id, LL)
		else: showMessage('yandex.ru', 'Не удалось загрузить каналы', times = 3000)

		return LL

