# -*- coding: utf-8 -*-
Channels=[
{'url': 'garant:http://151.249.213.188:81/udp/233.81.116.1:1234', 'group': '', 'img': '', 'title': '\xd0\x91\xd0\x95\xd0\x9b\xd0\x90\xd0\xa0\xd0\xa3\xd0\xa1\xd0\xac 1 HD'},
{'url': 'garant:http://151.249.213.188:81/udp/233.81.116.2:1234', 'group': '', 'img': '', 'title': '\xd0\x91\xd0\x95\xd0\x9b\xd0\x90\xd0\xa0\xd0\xa3\xd0\xa1\xd0\xac 2 HD'},
{'url': 'garant:http://151.249.213.188:81/udp/233.81.116.3:1234', 'group': '', 'img': '', 'title': '\xd0\x9e\xd0\x9d\xd0\xa2 HD'},
{'url': 'garant:http://151.249.213.188:81/udp/233.81.116.4:1234', 'group': '', 'img': '', 'title': '\xd0\xa1\xd0\xa2\xd0\x92 HD'},
{'url': 'garant:http://151.249.213.188:81/udp/233.81.116.5:1234', 'group': '', 'img': '', 'title': '\xd0\x9d\xd0\xa2\xd0\x92 \xd0\x91\xd0\x95\xd0\x9b\xd0\x90\xd0\xa0\xd0\xa3\xd0\xa1\xd0\xac'},
{'url': 'garant:http://151.249.213.188:81/udp/233.81.116.6:1234', 'group': '', 'img': '', 'title': '\xd0\x91\xd0\x95\xd0\x9b\xd0\x90\xd0\xa0\xd0\xa3\xd0\xa1\xd0\xac \xd0\xa0\xd0\xa2\xd0\xa0'},
{'url': 'garant:http://151.249.213.188:81/udp/233.81.116.7:1234', 'group': '', 'img': '', 'title': '\xd0\x91\xd0\x95\xd0\x9b\xd0\x90\xd0\xa0\xd0\xa3\xd0\xa1\xd0\xac 3 HD'},
{'url': 'garant:http://151.249.213.188:81/udp/233.81.116.8:1234', 'group': '', 'img': '', 'title': '\xd0\x9c\xd0\x98\xd0\xa0 HD'},
{'url': 'garant:http://151.249.213.188:81/udp/233.81.116.9:1234', 'group': '', 'img': '', 'title': '\xd0\x91\xd0\x95\xd0\x9b\xd0\x90\xd0\xa0\xd0\xa3\xd0\xa1\xd0\xac 5 HD'},
{'url': 'garant:http://151.249.213.188:81/udp/233.81.116.10:1234', 'group': '', 'img': '', 'title': '\xd0\x91\xd0\x95\xd0\x9b\xd0\x90\xd0\xa0\xd0\xa3\xd0\xa1\xd0\xac 5 HD'},
]
tm=1544176740.72
