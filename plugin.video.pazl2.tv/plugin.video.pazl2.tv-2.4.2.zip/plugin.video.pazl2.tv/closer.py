# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, time
print '-==-=-=-=- run closer =-=--=-===-=--='
for i in range(5):
	time.sleep(1)
	#win = xbmcgui.Window (xbmcgui.getCurrentWindowId())
	print 'DialogId: ' + str(xbmcgui.getCurrentWindowDialogId())
	if xbmcgui.getCurrentWindowDialogId() == 12002: xbmc.executebuiltin("Action(Back)")