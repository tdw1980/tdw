# coding: utf-8
# Module: server
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys, os
import xbmc, xbmcgui, xbmcaddon
import time
import urllib2
__settings__ = xbmcaddon.Addon(id='plugin.program.pazl.epg')
port = int(__settings__.getSetting("serv_port"))

addon = xbmcaddon.Addon(id='plugin.program.pazl.epg')
pazl = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
sys.path.append(pazl.getAddonInfo('path'))

import cookielib
sid_file = os.path.join(xbmc.translatePath('special://temp/'), 'vsetv.sid')
cj = cookielib.FileCookieJar(sid_file) 
hr  = urllib2.HTTPCookieProcessor(cj) 
opener = urllib2.build_opener(hr) 
urllib2.install_opener(opener) 


from DBcnl import *

try: 
	from EPGdb import *
	if EPG == "": EPG = {}
except:
	EPG = {}

icon=None
pDialog = xbmcgui.DialogProgressBG()

PlotCashe={}
ImgCashe={}

#time.sleep(10)
xbmc.sleep(5000)
print('----- Starting P_EPG -----')
start_trigger = True
#n=0
# =========================== Базовые функции ================================

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		#sn=http[s:]
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def getURL2(url, dt=3):
		import requests
		try:
			s = requests.session()
			r=s.get(url, timeout=(0.5, dt), verify=False).text#0.00001
		except:
			print 'requests: timeout'
			r=''
		#r=r.encode('windows-1251')
		return r

def getURL(url, Referer = 'http://viks.tv/'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


def get_HTML(url, post = None, ref = None, get_redirect = False):
    import urlparse
    if url.find('http')<0 :url='http:'+url
    request = urllib2.Request(url, post)

    host = urlparse.urlsplit(url).hostname
    if ref==None:
        try:
           ref='http://'+host
        except:
            ref='localhost'

    request.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
    request.add_header('Host',   host)
    request.add_header('Accept', 'text/html, application/xhtml+xml, */*')
    request.add_header('Accept-Language', 'ru-RU')
    request.add_header('Referer',             ref)
    request.add_header('Content-Type','application/x-www-form-urlencoded')

    try:
        f = urllib2.urlopen(request)
    except IOError, e:
        if hasattr(e, 'reason'):
           print('We failed to reach a server.')
        elif hasattr(e, 'code'):
           print('The server couldn\'t fulfill the request.')
        return 'We failed to reach a server.'

    if get_redirect == True:
        html = f.geturl()
    else:
        html = f.read()

    return html




def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def rt(x):
	try:
		L=[('&#133;','…'),('&#34;','&'), ('&#39;','’'), ('&#145;','‘'), ('&#146;','’'), ('&#147;','“'), ('&#148;','”'), ('&#149;','•'), ('&#150;','–'), ('&#151;','—'), ('&#152;','?'), ('&#153;','™'), ('&#154;','s'), ('&#155;','›'), ('&#156;','?'), ('&#157;',''), ('&#158;','z'), ('&#159;','Y'), ('&#160;',''), ('&#161;','?'), ('&#162;','?'), ('&#163;','?'), ('&#164;','¤'), ('&#165;','?'), ('&#166;','¦'), ('&#167;','§'), ('&#168;','?'), ('&#169;','©'), ('&#170;','?'), ('&#171;','«'), ('&#172;','¬'), ('&#173;',''), ('&#174;','®'), ('&#175;','?'), ('&#176;','°'), ('&#177;','±'), ('&#178;','?'), ('&#179;','?'), ('&#180;','?'), ('&#181;','µ'), ('&#182;','¶'), ('&#183;','·'), ('&#184;','?'), ('&#185;','?'), ('&#186;','?'), ('&#187;','»'), ('&#188;','?'), ('&#189;','?'), ('&#190;','?'), ('&#191;','?'), ('&#192;','A'), ('&#193;','A'), ('&#194;','A'), ('&#195;','A'), ('&#196;','A'), ('&#197;','A'), ('&#198;','?'), ('&#199;','C'), ('&#200;','E'), ('&#201;','E'), ('&#202;','E'), ('&#203;','E'), ('&#204;','I'), ('&#205;','I'), ('&#206;','I'), ('&#207;','I'), ('&#208;','?'), ('&#209;','N'), ('&#210;','O'), ('&#211;','O'), ('&#212;','O'), ('&#213;','O'), ('&#214;','O'), ('&#215;','?'), ('&#216;','O'), ('&#217;','U'), ('&#218;','U'), ('&#219;','U'), ('&#220;','U'), ('&#221;','Y'), ('&#222;','?'), ('&#223;','?'), ('&#224;','a'), ('&#225;','a'), ('&#226;','a'), ('&#227;','a'), ('&#228;','a'), ('&#229;','a'), ('&#230;','?'), ('&#231;','c'), ('&#232;','e'), ('&#233;','e'), ('&#234;','e'), ('&#235;','e'), ('&#236;','i'), ('&#237;','i'), ('&#238;','i'), ('&#239;','i'), ('&#240;','?'), ('&#241;','n'), ('&#242;','o'), ('&#243;','o'), ('&#244;','o'), ('&#245;','o'), ('&#246;','o'), ('&#247;','?'), ('&#248;','o'), ('&#249;','u'), ('&#250;','u'), ('&#251;','u'), ('&#252;','u'), ('&#253;','y'), ('&#254;','?'), ('&#255;','y'), ('&laquo;','"'), ('&raquo;','"'), ('&nbsp;',' '), ('&amp;quot;','"')]
		for i in L:
			x=x.replace(i[0], i[1])
		return x
	except:
		return x

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def fs_enc(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode('utf-8').encode(sys_enc)

def fs_dec(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode(sys_enc).encode('utf-8')

def lower_old(s):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.lower().encode('utf-8')
	return s

def lower(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in range (65,90):
		t=t.replace(chr(i),chr(i+32))
	for i in RUS.keys():
		t=t.replace(i,RUS[i])
	return t

def upper(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in RUS.keys():
		t=t.replace(RUS[i],i)
	for i in range (65,90):
		t=t.replace(chr(i+32),chr(i))
	return t

def CRC32(buf):
		import binascii
		buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		return str("%08X" % buf)

def mfind_old(t,s,e):
	r=t[t.find(s)+len(s):t.find(e)]
	return r

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2
	
def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "w")
	fl.write(s)
	fl.close()


# ================================ БД =======================================
#import sqlite3 as db
#db_name = os.path.join( addon.getAddonInfo('path'), "epg.db" )
#c = db.connect(database=db_name)
#cu = c.cursor()
'''
def add_to_db(n, item):
	if len(item)>4:
		c = db.connect(database=db_name)
		cu = c.cursor()
		item=item.replace("'","XXCC").replace('"',"XXDD")
		err=0
		tor_id="n"+n
		litm=str(len(item))
		try:
			cu.execute("DROP TABLE "+tor_id+";")
			c.commit()
		except: pass
		try:
			cu.execute("CREATE TABLE "+tor_id+" (db_item VARCHAR("+litm+"), i VARCHAR(1));")
			c.commit()
		except: 
			err=1
			print "Ошибка БД"
		if err==0:
			cu.execute('INSERT INTO '+tor_id+' (db_item, i) VALUES ("'+item+'", "1");')
			c.commit()
		c.close()
		xbmc.sleep(30)

def get_inf_db_old(n):
		c = db.connect(database=db_name)
		cu = c.cursor()
		tor_id="n"+n
		cu.execute(str('SELECT db_item FROM '+tor_id+';'))
		c.commit()
		Linfo = cu.fetchall()
		info=Linfo[0][0].replace("XXCC","'").replace("XXDD",'"')
		return info
		c.close()
'''

def get_inf_db(n):
	try: return EPG[n]
	except: return {}

# ================================ EPG =======================================

def upepg():
			
			pDialog.create('Пазл EPG', 'Обновление EPG ...')
			clear_EPG()
			if __settings__.getSetting('ttv')=='true':  
				pDialog.update(10, message='Обновление EPG TorrentTV')
				try: upd_EPG_xmltv()
				except: pDialog.update(10, message='TorrentTV: Ошибка')
			if __settings__.getSetting('vsetv_ua')=='true': 
				pDialog.update(20, message='Обновление EPG VseTV UA')
				try:upd_EPG_vsetv("uabase")
				except: pDialog.update(20, message='VseTV: Ошибка')
			if __settings__.getSetting('vsetv_by')=='true': 
				pDialog.update(30, message='Обновление EPG VseTV BY')
				try:upd_EPG_vsetv("bybase")
				except: pDialog.update(30, message='VseTV: Ошибка')
			if __settings__.getSetting('vsetv_ru')=='true': 
				pDialog.update(40, message='Обновление EPG VseTV RU')
				try:upd_EPG_vsetv("tricolor")#rubase
				except: pDialog.update(40, message='VseTV: Ошибка')
			if __settings__.getSetting('stv')=='true':  
				pDialog.update(60, message='Обновление EPG S-TV')
				try:upd_stv()
				except: pDialog.update(60, message='S-TV: Ошибка')
			if __settings__.getSetting('yatv')=='true': 
				pDialog.update(80, message='Обновление EPG Yandex')
				try: yatv()
				except: pDialog.update(80, message='S-TV: Ошибка Yandex')
			save_EPG()
			pDialog.close()


def get_nm_dict():
	nm_dict={}
	for i in EPG.keys():
		try:nm_dict[EPG[i]['title']]=i
		except:pass
	return nm_dict

def get_id(name):
	nm2id={}
	nm2id_ext={}
	nml=[]
	for a in DBC.items():
		id=a[0]
		names=a[1]['names']
		for nm in names:
			nm2id[nm]=id
			nml.append(nm)
			nm2id_ext[nm.replace('.','').replace('-','').replace(' ','').replace('канал','').replace('channel','')]=id
	
	name_ext=lower(name).replace('.','').replace('-','').replace(' ','').replace('канал','').replace('channel','')
	
	if lower(name) in nml:
		id = nm2id[lower(name)]
	elif name_ext in nm2id_ext.keys():
		id = nm2id_ext[name_ext]
	else:
		Did=get_nm_dict()
		if name in Did.keys(): id=Did[name]
		else: id = CRC32(lower(name))
	return id
#==============================   Старое ======================================

def yatv():
	ncrd=str(long(time.time())*1000+1080)
	dtm=time.strftime('%Y-%m-%d')
	Lcnl=[1335,100,928,664,626,442,16,173,1372,747,1021,1395,1674,1377,1699,987,127,911,1680,531,1329,934,217,1588,723,608,799,1753,681,25,455,315,730,1011,615,516,382,576,113,715,927,15,1570,141,1716,1436,789,924,477,1725,1043,180,250,921,797,1703,663,481,920,1721,783,328,1562,406,637,502,494,1585,912,521,463,552,1713,415,431,1723,757,1700,412,807,349,248,659,454,247,1397,737,1657,1376,595,367,311,518,917,831,741,1727,1744,685,990,1038,1760,1030,686,1034,680,35,996,675,1734,278,648,1620,267,123,1371,1672,499,23,1764,1772,1026,121,1729,509,257,153,925,1662,614,273,916,1013,810,425,1765,277,1039,1757,1667,1425,410,613,834,520,1394,1737,1746,308,555,82,560,1719,1031,589,929,409,1660,1586,1731,1670,994,669,376,124,6,312,1722,389,384,165,919,777,930,223,575,21,1681,1578,1726,102,765,1754,1763,66,59,393,1571,1676,1702,485,821,1033,138,828,1738,1012,644,850,618,284,1714,355,331,1663,462,22,1668,495,923,591,933,542,798,533,423,1042,319,794,31,801,617,935,1669,1732,1035,1332,779,563,1612,125,401,352,322,1331,1773,1330,1698,505,1767,1762,333,601,642,37,661,1755,769,151,756,288,163,1365,804,662,434,567,12,1037,983,1736,1679,464,156,1766,1322,1666,1730,491,1036,705,91,731,11,638,774,309,145,566,1584,53,1683,150,211,79,162,427,187,405,146,279,743,740,325,365,323,689,597,529,633,898,1003,690,1593,1598,1000,447,726,897,1649,275,214,1561,1720,547,931,984,1046,1032,1396,132,313,55,1759,1739,258,776,631,1761,1728,363,1743,461,932,346,918]
	channelIds=''#'channelIds%22%3A%22'
	for i in Lcnl:
		channelIds+=str(i)+'%2C'
	channelIds=channelIds[:-3]#+'%22'
	
	for n in range(0,31):
		url='https://m.tv.yandex.ru/ajax/i-tv-region/get?params=%7B"channelLimit"%3A10%2C"channelOffset"%3A'+str(n*10)+'%2C"fields"%3A"channel%2Ctitle%2Cchannel%2Cid%2Ctitle%2Clogo%2Csizes%2Cwidth%2Cheight%2Csrc%2Ccopyright%2Cschedules%2Cchannels%2Cchannel%2Cid%2Ctitle%2CavailableProgramTypes%2Celement%2Cid%2Cname%2Cevents%2Cid%2CchannelId%2Cepisode%2Cdescription%2CseasonName%2CseasonNumber%2Cid%2CprogramId%2Ctitle%2Cstart%2Cfinish%2Cprogram%2Cid%2Ctype%2Cid%2Cname%2Ctitle"%2C"channelIds"%3A"'+channelIds+'"%2C"start"%3A"'+dtm+'T03%3A00%3A00%2B03%3A00"%2C"duration"%3A96400%2C"channelProgramsLimit"%3A500%2C"lang"%3A"ru"%7D&userRegion=193&resource=schedule&ncrd='+ncrd
		#url='https://m.tv.yandex.ru/ajax/i-tv-region/get?params=%7B%22channelLimit%22%3A'+str(10)+'%2C%22channelOffset%22%3A'+str(n*10)+'%2C%22fields%22%3A%22channel%2Ctitle%2Cchannel%2Cid%2Ctitle%2Clogo%2Csizes%2Cwidth%2Cheight%2Csrc%2Ccopyright%2Cschedules%2Cchannels%2Cchannel%2Cid%2Ctitle%2CavailableProgramTypes%2Celement%2Cid%2Cname%2Cevents%2Cid%2CchannelId%2Cepisode%2Cdescription%2CseasonName%2CseasonNumber%2Cid%2CprogramId%2Ctitle%2Cstart%2Cfinish%2Cprogram%2Cid%2Ctype%2Cid%2Cname%2Ctitle%22%2C%22'+dtm+'T05%3A00%3A00%2B03%3A00%22%2C%22duration%22%3A86400%2C%22channelProgramsLimit%22%3A500%2C%22genresIds%22%3A%5B%5D%2C%22lang%22%3A%22ru%22%7D&userRegion=193&resource=schedule&ncrd='+ncrd
		print url
		#1469175651563
		try:E=getURL(url)
		except:
			try:E=getURL(url)
			except:
				print 'yatv сервер недоступен'
				return False
		e=E.replace('\\/','/').replace('false','False').replace('true','True').replace('\\"',"'")
		#debug (e)
		try:
			D=eval(e)
			L=D['schedules']
		except:
			L=[]
		#DCnl={}
		
		for i in L:
			title=i['channel']['title']
			print title
			channel_id=str(i['channel']['id'])
			idx=get_id(title)
			
			Le=[]
			De={}
			L2=i['events']
			for j in L2:
				start      =    j['start']
				program_id =str(j['program']['id'])
				ptitle     =    j['program']['title']
				try: etitle   = j['episode']['title']
				except: etitle = ''
				try:plot   =    j['program']['description']
				except: plot = ''
				try: type=j['program']['type']['name']
				except: type=''
				if etitle == ptitle: etitle = ''
				if etitle != '': ptitle=ptitle+' '+etitle
				
				cdata = time.strftime('%Y%m%d')
				pdata = start[:10].replace('-','')
				if True:#pdata==cdata:
					start_at=start.replace('+03:00','').replace('T',' ')#2016-07-22T04:20:00+03:00
					#print "-==-=-=-=-=-=-=-=-=-=-"
					try:strptime=time.strptime(start_at , '%Y-%m-%d %H:%M:%S')
					except:
						xbmc.sleep(1000)
						try:strptime=time.strptime(start_at , '%Y-%m-%d %H:%M:%S')
						except: strptime=0
					if strptime!=0:
						tms=str(time.mktime(strptime))
						img='http://127.0.0.1:'+str(port)+'/977/program/'+program_id#+"/cid"+idx+'/tms'+tms
						#print tms
						#Le.append({"title":rt(ptitle), "start_at":start_at, 'img': img})
						De[tms]={"title":rt(ptitle), 'img': img, 'plot': plot[:300], 'type':type}
			#E2=repr(Le)
			#Ed=repr(De)
			De['title']=title
			pDialog.update(int(n*100/31), message=title)
			if idx!="": 
				#add_to_db(idx, Ed)
				EPG[idx]=De
				#Dr[idx]=title

def upd_stv():
	opener = urllib2.build_opener()
	#opener.addheaders.append(('Cookie', 'favorites=1TV%3BRTR%3BNTV%3BMIR%3BTVC%3BKUL%3BMatchTV%3BTNT%3BDOMASHNIY%3BRenTV%3BSTS%3BPiter5_RUS%3BZVEZDA%3BChe%3BKarusel%3B2X2%3BDisney%3BU%3BTV3%3BOTR%3BFriday%3BVesti%3BTNT_4%3BEhoFilm%3B360d%3B360dHD%3BVKT%3BMOSCOW-24%3BDOVERIE%3BPingLolo%3BFAMILY%3Bntv%2B41%3BAMEDIA%3BAmediaHit%3BAmedia1%3BBollywood%3BDrama%3BFOX%20CRIME%3BFOX%20LIFE%3BHDKino%3BPARAMAUNT%3BParamounHD%3BParaComedy%3BSET_RUSSIA%3BAXNSciFi%3BSonyTurbo%3BTV1000%3BTV1000_Act%3BTV1000_RK%3BTV21%3BZee-TV%3BDomKino%3BDomKinoP%3BEuroKINO%3BILLUSION%2B%3BIndia%3Bntv%2B34%3BKinoTV%3Bntv%2B4%3BKinipokaz%3BKinop_HD-1%3BKinop_HD-2%3BKinoPrHD%3Bntv%2B40%3BKomedia1%3BKomedia%3BMir_serial%3BmnogoTV%3BMenKino%3BNSTV%3Bntv%2B3%3Bntv%2B7%3BNacheHD%3BOstroHD%3Bntv%2B10%3BRTVi-LK%3BRTVi-NK%3BRus-Bestst%3BRuDetektiv%3BRU_ILLusio%3BRusRoman%3BSemeynoeHD%3BStrahnoeHD%3BSTSLove%3Bntv%2B39%3BFeniks%3BMatchTV%3BABMotors%3Bntv%2B13%3BEuro-2%3BEurospNews%3Bntv%2B23%3BVia_Sport%3BBoxingTV%3Bntv%2B9%3BKHL_HD%3BMatcharena%3Bboets%3BMatchigra%3BMatchsport%3Bntv%2B11%3Bntv%2B44%3BSporthit%3BNautical%3Bntv%2B1%3BRU_Extrem%3BFootBallTV%3BArirang%3Bntv%2B25%3BBBC_Entert%3BBBC-World%3Bntv%2B33%3BCCTVNews%3BCNBC%3Bntv%2B30%3BCNN_ENG%3BDW%3BDW_DEU%3Bntv%2B19%3BFrance24%3BFrance_FR%3BJSTV%3BNewsOne%3BNHK_World%3BRus_Today%3BRT_Doc%3BRTEspanol%3BRTDrus%3BRAIN%3BKommers_TV%3BLDPR%3BMir24%3BRBK%3B4P.INFO%3B24_DOC%3B365_day%3Bntv%2B17%3BDa%20Vinci%3Bntv%2B16%3Bntv%2B28%3BDiscov_VE%3BGalaxy_TV%3BHistor%20%3BHistoryENG%3Bntv%2B18%3BOCEAN-TV%3BENCYCLO%3BExplorer%3BHistory%3BNature_CEE%3BZooTV%3BZoopark%3BViM%3BVopr-Otvet%3BEGE%3BGivPlaneta%3BJivPriroda%3BIstoria%3BWho_is_who%3BMy_Planet%3BNANO_TV%3BNauka_2.0%3B1Obrazovat%3BProsvejeni%3BTop_secret%3BSTRANA%3BTNV_PL%3B1HD%3BA-OnHipHop%3BBizTV%3BBridge-TV%3BC_Music_TV%3BDangeTV%3BEuropaPlus%3BHardLifeTV%3BiConcerts%3BJuCeTV%3BMCMPOP%3BMCMTOP%3Bntv%2B26%3BMTV_Dance%3BMTVDI%3BMTV_Europ%3BMTV_Hits%3BMTVHI%3BMTV_Music%3BMTV_ROCKS%3BMTVRI%3BMTVRus%3BMTV_AM%3BMusicBox-R%3BMusicBox-T%3BRAP%3BRU-TV%3BRusong_TV%3BTOPSONG_T%3BTRACE_URBA%3BTVMChannel%3BVH1_Class%3BVH1_EURO%3BW_Music_Ch%3BLa-minor%3BMUZ_TVnew%3BMuZ-One%3BO2TV%3BA-ONE%3BSHANSON%3BAmazing%3BAngelTV%3BReality%3BCCTV%3BDTXEMEA%3BEnglishClu%3BFash_One%3BFashion_TV%3BFLN%3BFoodNet%3BFuel_TV_HD%3BGame_Show%3BGlobalStar%3BInsiUlHD%3BLuxe_TV%3BMAN_TV%3BMotors_TV%3BMuseum_HD%3BmyZen.tv%3Bntv%2B20%3BOutdoor%3Bprodengi%3BRTGInt%3BRTG_TV%3BStyle%26moda%3BTTS%3BShoppingLi%3BBulvar%3BStyle_TV%3BTDK%3BTLC%3BTop%20Shop%20T%3BTrChenel%3BTravel%2BAdv%3BTVclub%3BTV_Mail%3BTV_SALE%3Bntv%2B32%3BVintage_%3BWBC%3BW_Fashion%3Bautoplus%3BAGRO-TV%3BBalansTV%3BBober%3BVremya%3BD_Jivotnie%3BDrive_MTU%3BEDA%3BJiVi%3BZagorod_zh%3Bzagorodny%3BZdorov_MTU%3BKuhna%3BMirUvlech%3BMuzhskoj%3BNedvigim%3BNostalgi%3BWeapons%3BHa%26Fi_MTU%3BOhot%26Ribal%3BPark_Razvl%3B1InternetK%3BPsihology%3BRaz-TV%3BRetro_MTU%3Bsarafan-tv%3BSojuz%3BSPAS%3BTeatr%3BTeledom%3BTelekafe%3BTeletravel%3BTehno24%3BTONUS-TV%3B3Angela%3BTurInfo%3BUsadba_MTU%3BUspeh%3BEgoist-TV%3BHUMOUR-TV%3BAni%3BBaby_TV%3BBoomerang%3Bntv%2B29%3BGingerHD%3BGulli%3BJIMJAM%3BNick_Jr%3Bntv%2B15%3BNickelodHD%3BTiJi%3BDetskiy%3Bntv%2B8%3BMother%26Chi%3BMult%3BMultimania%3BRadost_moj%3BUlibkaRebe%3BAmediaPRHD%3BAnFamilHD%3BAnimalPlHD%3BArteHD%3BEurekaHD%3BEuroSporHD%3BFashiOneHD%3BFashion_HD%3BFOXLIFE_HD%3BHD-Life%3BHD_Media%3BHD_Media3D%3BLuxe_TV_HD%3BMezzoLive%3BMGM_HD%3BMTV_LiveHD%3BNatGeoW_HD%3BNat_Geo_HD%3BOutdoor%20HD%3BRTDrushd%3BSET_HD%3BTeleTravHD%3BTrace_SpHD%3BTr_Chan_HD%3BTravAdHD%3BTV1000Come%3BTV1000Mega%3BTV1000Prem%3BRAIN_HD%3BEDA_HD%3BMatchareHD%3BMirHD%3BOhotRybHD%3B1TVHD%3BIQHD%3BRTRHD%3BBlueHust%3BBrazzEuro%3BCandy3D%3BCandy%3BDaring!TV%3BFrench_Lov%3BHustle3DHD%3BHustler%3BPlayboy_TV%3BXXL%3BIskushenie%3BNightClub%3BRusnight%3B8_KANAL%3BHistor2%3BBelarus-TV%3BDomMagazin%3BInva_Media%3BKaleidosco%3BKVNTV%3BMatchKmir%3BKrasLin%3BLiderTV%3BNadegda%3BNasheTV%3B1_Meteo%3BProdvigeni%3BRGD%3BRigiy%3BTBN%3BTvoy%3BTNV%3BToshkaTV%3BTRO%3BUvelir'))
	
	opener.addheaders.append(('Cookie', 'favorites=1TV%3BRTR%3BNTV%3BMIR%3BTVC%3BKUL%3BMatchTV%3BTNT%3BDOMASHNIY%3BRenTV%3BSTS%3BPiter5_RUS%3BZVEZDA%3BChe%3BKarusel%3B2X2%3BDisney%3BU%3BTV3%3BOTR%3BFriday%3BVesti%3BSuper%3BTNT_4%3BMOSCOW-24%3BDOVERIE%3BProdvige%3BFAMILY%3BAmedia1%3BAMEDIA%3Bntv%2B41%3BAmediaHit%3BBollywood%3BDetektive%3BEurochanne%3BFilmBoxArh%3BFOX%20CRIME%3BFOX%20LIFE%3BPARAMAUNT%3BParaComedy%3BSET_RUSSIA%3BAXNSciFi%3BSonyTurbo%3BSpike%3BTV1000%3BTV1000_Act%3BTV1000_RK%3BTV21%3BZee-TV%3BDomKino%3BDomKinoP%3BDorama%3BEuroKINO%3BILLUSION%2B%3BIndia%3BKaleidosco%3BKinoUHD%3BKinoTV%3BKomedia%3Bntv%2B34%3BKinipokaz%3BKinop_HD-1%3BKinop_HD-2%3BKinoPrHD%3Bntv%2B10%3Bntv%2B4%3BHDKino%3BmnogoTV%3Bntv%2B40%3BClassKino%3BKomedia1%3BMir_serial%3BMenKino%3BNSTV%3Bnashdetekt%3Bnashkinor%3BNasheLubim%3Bntv%2B7%3BNTVserial%3BNTVHit%3BOstroHD%3Bntv%2B3%3BRTVi-LK%3BRTVi-NK%3BRus-Bestst%3BRuDetektiv%3BRU_ILLusio%3BRusRoman%3BSerialUHD%3BStrahnoeHD%3BSTSLove%3BTelenovell%3BFeniks%3Bntv%2B13%3BEuro-2%3BEurospGold%3BEurospNews%3Bntv%2B23%3BFightBox%3BM-1GLOBAL%3BRu_ExtUHD%3BViasatGolf%3BViaGolfHD%3BVia_Sport%3BBoxingTV%3BMatchKmir%3BMatcharena%3Bboets%3BMatchigra%3BMatchsport%3Bntv%2B11%3Bntv%2B44%3BSporthit%3BNautical%3Bntv%2B1%3BRU_Extrem%3BStart%3Bntv%2B9%3BKHL_HD%3BFootBallTV%3BArirang%3Bntv%2B25%3BBBC_Entert%3BBBC-World%3Bntv%2B33%3BCCTVNews%3BCNBC%3Bntv%2B30%3BCNN_ENG%3BDW%3BDW_DEU%3Bntv%2B19%3BFrance24%3BFrance_FR%3BJSTV%3BNewsOne%3BNHK_World%3BRus_Today%3BRTArabic%3BRT_Doc%3BRTEspanol%3BRTDrus%3BBelarus-TV%3BRAIN%3BIzvestiy%3BKommers_TV%3BLDPR%3BMir24%3BRBK%3B4P.INFO%3BEhoFilm%3B365_day%3Bntv%2B17%3BDa%20Vinci%3Bntv%2B16%3BDiscov_VE%3Bntv%2B28%3BHistor2%3BHHD2%3BHistor%20%3BHistoryENG%3Bntv%2B18%3BOCEAN-TV%3BExplorer%3BHistory%3BViaHistHD%3BNature_CEE%3BZooTV%3BZoopark%3BVopr-Otvet%3BDoctor%3BEGE%3BGivPlaneta%3BJivPriroda%3BJivPriHD%3BIstoria%3BWho_is_who%3BMosObrazov%3BMy_Planet%3BNANO_TV%3BNauka_2.0%3B1Obrazovat%3BProsvejeni%3BSinergiaTV%3BTop_secret%3BGalaxy_TV%3B1HD%3B360TuneBox%3BBridgeHD%3BBridge-TV%3BTOPSONG_T%3BDangeTV%3BRusong_TV%3BC_Music_TV%3BClubbingTV%3BEuropaPlus%3BFestival4K%3BFreshtv%3BHardLifeTV%3BHitv%3BJuCeTV%3BMCMTOP%3Bntv%2B26%3BMTVDI%3BMTVHI%3BMTVRI%3BMTVRus%3BMTV_AM%3BMusicBox-T%3BRAP%3BRU-TV%3BMusicBox-R%3BiConcerts%3BTMBRU%3BVH1_Class%3BVH1_EURO%3BLa-minor%3BMUZ_TVnew%3BMuZ-One%3BMultmuzika%3BO2TV%3BA-ONE%3BSHANSON%3BTV7%3BC4K360%3BReality%3BCCTV4%3BCCTV%3BPark_Razvl%3BDTXEMEA%3BGame_Show%3BEnglishClu%3BFash_One%3BFashion_4K%3BFashion_TV%3BFLN%3BFoodNet%3BFoodmanClu%3BFuel_TV_HD%3BGlobalStar%3BHome4K%3BInsiUlHD%3BLuxe_TV%3BMotors_TV%3BMuseum_HD%3Bntv%2B20%3BNoise_%3BOutdoor%3Bprodengi%3BRTGInt%3BRusHualiTV%3BRTG_TV%3BStyle%26moda%3BShoppingLi%3BSlow%3BTDK%3BTLC%3BTop%20Shop%20T%3BTrChenel%3BTravel%2BAdv%3BTrick%3BTVclub%3BTV_SALE%3Bntv%2B32%3BTVMChannel%3BTvRus%3BWBC%3BW_Fashion%3Bautoplus%3BAvto24%3BAnekdotTV%3BBalansTV%3BBober%3BBolshAziy%3BBUMTV%3BSovetFeder%3BVremya%3BDaivingTV%3BdialogiRib%3BDikayOhHD%3BDikayRybHD%3BDikiy%3BD_Jivotnie%3BDomMagazin%3BDrive_MTU%3BEDA%3BBulvar%3BJiVi%3BZagorod_zh%3Bzagorodny%3BZagorodInt%3BZdorov_MTU%3BTONUS-TV%3BKVNTV%3BKuhna%3BMirUvlech%3BMuzhskoj%3BNadegda%3BNeizPlanet%3BNostalgi%3BNTVpravo%3BNTVstil%3BWeapons%3BHa%26Fi_MTU%3BOhot%26Ribal%3BOhotRibInt%3BPervVegeta%3BPesiKo%3BPoehali%3BPsihology%3BRaz-TV%3BRetro_MTU%3Bsarafan-tv%3BSojuz%3BSPAS%3BTvoiDom%3BTvTur%3BTeatr%3BTeledom%3BTelekafe%3BTeletravel%3BTehno24%3B3Angela%3BUsadba_MTU%3BUspeh%3BCentralTV%3BEgoist-TV%3BUvelir%3BHUMOUR-TV%3BAni%3BBaby_TV%3BBoomerang%3Bntv%2B29%3BGingerHD%3BGulli%3BJIMJAM%3BNick_Jr%3Bntv%2B15%3BNickelodHD%3BTiJi%3BVgostskaz%3BDetskiy%3Bntv%2B39%2B8%3BDetskoeRad%3BLubimoetv%3BMalysh%3BMother%26Chi%3BMult%3BMyltikHD%3BMultimania%3BO%3BPingLolo%3BRadost_moj%3BRigiy%3BTlumHD%3B360dHD%3BAmediaPRHD%3BAnimalPlHD%3BArteHD%3BDocuBoxHD%3BEuroSporHD%3BEurospGHD%3BFashBoxHD%3BFashiOneHD%3BFashion_HD%3BFaFuBoxHD%3BFilmBoxHD%3BFoodNetHD%3BFOXLIFE_HD%3BHD-Life%3BHD_Media%3BHD_Media3D%3BLuxe_TV_HD%3BMezzoLive%3BMGM_HD%3BMTV_LiveHD%3BNatGeoW_HD%3BNat_Geo_HD%3BOutdoor%20HD%3BParamounHD%3BRTDrushd%3BRussiaMBHD%3BSETHD%3BSET_HD%3BTr_Chan_HD%3BTravAdHD%3BTV1000Come%3BTV1000Mega%3BTV1000Prem%3BAnFamilHD%3BRAIN_HD%3BDomKinoPHD%3BEDA_HD%3BKinoTVHD%3BMatchareHD%3BMirHD%3BOhotRybHD%3B1TVHD%3BIQHD%3BTeleTravHD%3BRTRHD%3BRRomanHD%3BTNTHD%3BEurekaHD%3BBabesTV%3BBarely%3BBlueHust24%3BBlueHust%3BCandy3D%3BCandy%3BDaring!TV%3BErox%3BHustle3DHD%3BHustler%3BPlayboy_TV%3BIskushenie%3BNightClub%3BRusnight%3BShalun%3BShalunHD%3B360d%3B8_KANAL%3BShantPrem%3BTRO%3BVesnaFM%3BKBSrus%3BKrasLin%3BLiderTV%3BMarusyFM%3BNasheTV%3BNovoeradio%3BNewworld%3BOpenworld%3B1_Meteo%3BRatnik%3BRGD%3BTBN%3BTNV%3BTNV_PL%3BTnomer%3BTochkaOtr%3BToshkaTV'))

	
	
	urllib2.install_opener(opener)
	url = 'http://new.s-tv.ru/tv/'
	http = getURL(url)
	ss='<td class="channel">'
	es='<table class="item_table">'
	L=mfindal(http,ss,es)
	epg={}
	n=0
	tt=len(L)
	for i in L:
		n+=1
		#try:
		if i!="":
			ss='width="45px" title="'
			es='" />'
			cnl_nm=mfindal(i,ss,es)[0][len(ss):]
			idx=get_id(cnl_nm)
			if idx!="":
				ss='<div class="prg_item">'
				es='</div>'
				L2=mfindal(i,ss,es)
				Le=[]
				De={}
				nday=False
				tms_prev=0
				for j in L2:
					
					#print j
					type=''
					if 'class="live"' in j:  type='live'
					if 'class="info"' in j:  type='info'
					if 'class="new"' in j:   type='new'
					if 'class="movie"' in j: type='movie'
					if 'сезон.' in j:        type='tvshow'
					if 'Футбол.' in j:       type='sport'
					if 'Хоккей.' in j:       type='sport'
					if 'Ралли.' in j:       type='sport'
					if 'спорт.' in j:       type='sport'
						
					j=j.replace('span', 'span\n')
					Ls=j.splitlines()
					title=''
					st=''
					img_id=''
					for t in Ls:
						if 'prg_item_no' in t: title=mfind(t,'item_no">','</span')
						if 'item_time'  in t: st=mfind(t, 'time">','</span')
						if 'href'  in t: 
							img_id=mfind(t, 'href="#ab','">')
							title=mfind(t,'">','</a>')
					
					title=title.replace('<spa','')
					#print cnl_nm+" "+st+" "+title+" "+img_id
			
					start_at=time.strftime('%Y-%m-%d')+" "+st#+":00"
					strptime=time.strptime(start_at , '%Y-%m-%d %H.%M')
					tmt=time.mktime(strptime)
					
					if tms_prev>tmt: nday=True
					tms_prev=tmt
					if nday: tmt+=86400
					tms=str(tmt)
					
					if img_id!='':img='http://127.0.0.1:'+str(port)+"/cid"+idx+'/tms'+tms+'/program/new.s-tv.ru/tv/ajaxinfo/'+img_id+"/0"
					else: img=''
					De[tms]={"title":rt(title), 'img': img, 'plot': '', 'type':type}
					
				De['title']=cnl_nm
				EPG[idx]=De
				pDialog.update(int(n*100/tt), message=cnl_nm)

def upd_EPG_vsetv_old(pack):
	url = 'http://www.vsetv.com/schedule_package_'+pack+'_day.html'
	#url = 'http://www.vsetv.com/schedule_package_bybase_day.html'
	#url = 'http://www.vsetv.com/schedule_package_rubase_day.html'
	#url = 'http://www.vsetv.com/schedule_package_uabase_day.html'
	http = getURL(url)
	ss='<div class=chlogo>'
	es='></div><div class="clear'
	L=mfindal(http,ss,es)
	epg={}
	n=0
	t=len(L)
	for i in L:
		#print i
		try:
			i=i.decode('windows-1251')
			i=i.encode('utf-8')
		except: pass
		i=i.replace(chr(10),"").replace(chr(13),"").replace("\t","")
		#debug (i)
		n+=1
		if i!="":
			
			ss='class="channeltitle">'
			es='</td><td width="99%"'
			cnl_nm=mfindal(i,ss,es)[0][len(ss):]
			#print cnl_nm
			idx=get_idx(cnl_nm)
			if idx=="": idx=get_idx(cnl_nm.replace(" Россия","").replace(" (Россия)","").replace(" (Международный)",""))
			
			if idx!="":
				tmp=i.replace('class="past','class="').replace('class="onair"','class="time"')
				tmp=tmp.replace('</div><div class="prname2">','<:--:>').replace('align="absmiddle">&nbsp;','-:>').replace('.html>','-:>').replace('.html class=b>','-:>')
				tmp=tmp.replace('-:><','')
				sdn=tmp.find('chnum')
				tmp=tmp[sdn:]
				ss='class="time"'
				es='div><div'
				#print tmp
				L2=mfindal(tmp,ss,es)
				Le=[]
				for j in L2:
					try:
						ss='"time">'
						es='<:'
						stm=mfindal(j,ss,es)[0][len(ss):]
						
						ss=':>'
						es='</'
						pr_nm=mfindal(j,ss,es)[0][len(ss):]
						if pr_nm=="": print j
						
						start_at=time.strftime('%Y-%m-%d')+" "+stm+":00"
						#print start_at +" - "+pr_nm
						Le.append({"name":rt(pr_nm), "start_at":start_at})
					except: 
						print j
						pass
				try:pDialog.update(int(n*100/t), message=cnl_nm)
				except: pass
				if len(Le)>0:add_to_db(idx, repr(Le))

			else:
				print "NO_ID: "+cnl_nm

def upd_EPG_vsetv(pack):
	#url = 'http://www.vsetv.com/schedule_package_'+pack+'_day.html'
	#post='submit.x=109&submit.y=16&dset11=2&dset12=1&dset21=2&dset22=1'
	#ht = get_HTML(url, post)
	
	url1='http://www.vsetv.com/rewrite_url.php'
	url2 = 'http://www.vsetv.com/schedule_printversion_withdesc.html'
	post='timezone=14&selected_channel=package_'+pack+'&submit.x=109&submit.y=16&dset11=2&dset12=1&dset21=2&dset22=1'
	ht = get_HTML(url1, post, url2)
	ht = get_HTML(url2)
	
	main=mfind(ht, '<td class="main">', 'class="bottomline">')
	if main!='':
		#print "main"
		#print main
		L=mfindal(main, 'class="chname"', 'class="clearshed"')
		for i in L:
			try:
				i=i.decode('windows-1251')
				i=i.encode('utf-8')
				i=i.replace('class="past','class="').replace('class="onair"','class="time"').replace('<div class="time">','\n<div class="time">')
				#i=i.replace('<a class=f0></a>','0').replace('<a class=d9></a>','0').replace('<a class=z0></a>','0')
			except: pass

			#print i
			name=mfind(i,'class="channeltitle">','</td>')
			
			Lrepl=[' (русский)', ' (Русский)', ' (Россия)', ' Россия', ' (Europe)']
			for j in Lrepl:
				name=name.replace(j,'')
			
			idx=get_id(name)
			#print "-==-=-=-=-"+name+'=-=-=-=-=-'
			L2=i.splitlines()
			nday=False
			tms_prev=0
			De={}
			for sl in L2:
				if 'class="time"' in sl:
					
					#print sl
					st=mfind(sl,'class="time">','</div><div')
					
					
					ptitle=mfind(sl,'prname2">','</div>')
					if 'absmiddle">&nbsp;' in ptitle: ptitle=mfind(ptitle,'absmiddle">&nbsp;','</div>')
					
					ptitle=ptitle.replace('<b>','').replace('</b>','').replace('</b','')
					
					#if '<img src' in sl: img='http://www.vsetv.com'+mfind(sl,'<img src="','" border=0 hspace=5')
					#else: img=""
					#print img
					if 'class="desc">' in sl and '<br><br>' in sl: 
						if '...' in sl: se='...'
						else: se='<div'
						plot=mfind(sl,'<br><br>',se)+"..."
					else: plot=''
					
					if len(ptitle)>80 and '", ' in ptitle:
						plot2=ptitle[ptitle.find('", ')+3:]
						ptitle=ptitle[:ptitle.find('", ')]
						plot=plot2+'\n'+plot
					elif len(ptitle)>80 and '. ' in ptitle:
						plot2=ptitle[ptitle.find('. ')+2:]
						ptitle=ptitle[:ptitle.find('. ')]
						plot=plot2+'\n'+plot
					elif len(ptitle)>80 and ': ' in ptitle:
						plot2=ptitle[ptitle.find(': ')+2:]
						ptitle=ptitle[:ptitle.find(': ')]
						plot=plot2+'\n'+plot
					
					#print '...............................'
					#print st
					#print ptitle
					#print plot
					
					
					HM=time.strptime(st, '%H:%M')
					H=HM[3]
					M=HM[4]
					ctime=time.gmtime(time.time()+3*60*60)
					ntime=(ctime[0],ctime[1],ctime[2],H,M,0,ctime[6],ctime[7],ctime[8])
					tmt=time.mktime(ntime)
					#print tmt
					'''
					start_at=time.strftime('%Y-%m-%d')+" "+st#+":00"
					strptime=time.strptime(start_at , '%Y-%m-%d %H:%M')
					tmt=time.mktime(strptime)
					print ' '
					print tmt
					'''
					if tms_prev>tmt: nday=True
					tms_prev=tmt
					if nday: tmt+=86400
					tms=str(tmt)
					#print time.ctime(tmt)
					De[tms]={"title":rt(ptitle), 'img': '', 'plot': plot}
					
			De['title']=name
			EPG[idx]=De

def upd_EPG_xmltv():
	xml=dload_epg_xml()
	if xml=="": xml=dload_epg_xml()
	if xml!="":
		d=pars_xmltv(xml)
'''		j=0
		dk=d.keys()
		for id in dk:
			j+=1
			#print d[id]
			add_to_db("x"+id, repr(d[id]))
			pDialog.update(j/4, message='xmltv '+id)
	else:
		pDialog.update(0, message='Не удалось загрузить xml.')
'''

def dload_epg_xml():
	try:
			#target='http://programtv.ru/xmltv.xml.gz'
			target='http://api.torrent-tv.ru/ttv.xmltv.xml.gz'
			#print "-==-=-=-=-=-=-=- download =-=-=-=-=-=-=-=-=-=-"
			fp = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'tmp.zip'))
			
			req = urllib2.Request(url = target, data = None)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			fl = open(fp, "wb")
			fl.write(resp.read())
			fl.close()
			
			#time.sleep(1)
			xbmc.sleep(1000)
			#print "-==-=-=-=-=-=-=- unpak =-=-=-=-=-=-=-=-=-=-"
			xml=ungz(fp)
			#print "-==-=-=-=-=-=-=- unpak ok =-=-=-=-=-=-=-=-=-=-"
			#os.remove(fp)
			return xml
	except Exception, e:
			print 'HTTP ERROR ' + str(e)
			return ''


def ungz(filename):
	import gzip
	with gzip.open(filename, 'rb') as f:
		file_content = f.read()
		return file_content


def pars_xmltv_old(xml):
	#print "-==-=-=-=-=-=-=- parsing =-=-=-=-=-=-=-=-=-=-"
	#debug (xml)
	xml=xml.replace(chr(10),"").replace(chr(13),"").replace("<programme ", "\n<programme ")
	ss="<programme "
	es="</programme>"
	L=xml.splitlines()
	#L=mfindal(xml,ss,es)
	epg={}
	n=0
	t=len(L)
	cdata = time.strftime('%Y%m%d')
	for i in L:
		n+=1
		if "<programme " in i:
			#print "-==-=-=-=-=-=-=- parsing i =-=-=-=-=-=-=-=-=-=-"
			#debug i
			ss='start="'
			es=' +0300" stop="'
			st=mfindal(i,ss,es)[0][len(ss):]
			
			pdata=st[:8]
			#print pdata+' '+cdata
			if pdata==cdata:
				#ss='stop="'
				#es=' +0300" channel'
				#et=mfindal(i,ss,es)[0][len(ss):]
				
				ss=' channel="'
				es='">'
				id=mfindal(i,ss,es)[0][len(ss):]
				
				ss='<title'
				es='</title>'
				title=mfindal(i,ss,es)[0][len(ss):].replace(' lang="ru">',"")#.replace('&amp;quot;','*')
				
				try:Le=epg[id]
				except: Le=[]
			
				n=len(Le)
				start_at=xt(st[0:4]+"-"+st[4:6]+"-"+st[6:8]+" "+st[8:10]+":"+st[10:12]+":00")
			
				#print start_at+" "+title
				try:
					Le.append({"name":rt(title), "start_at":start_at})
					epg[id]=Le
					#pDialog.update(int(n*100/t), message=title)
					#print id
				except:
					pass
				#print id+"  :  "+start_at+"  :  "+title
	return epg


def get_ttv_epg_id():
	E=getURL('http://torrent-tv.ru/news.php')
	L=mfindal(E,'<li ','</li>')
	D={}
	for i in L:
		if 'data-epg-id' in i:
			epg_id=i[i.find('epg-id="')+8:i.find('">')]
			ttv_id='ttv'+i[i.find('translation=')+12:i.rfind('">')]
			print epg_id+" > "+ttv_id
			D[ttv_id]=epg_id
	return D

def pars_xmltv(xml):
	xml=xml.replace(chr(10),"").replace(chr(13),"").replace("<programme ", "\n<programme ").replace("<channel ", "\n<channel ")
	L=xml.splitlines()
	cdata = time.strftime('%Y%m%d')
	epg={}
	channel={}
	#epg_id=get_ttv_epg_id()
	n=0
	for i in L:
		if "<channel " in i:
			channel_id=i[i.find('id="')+4:i.find('"><display')]
			name=i[i.find('"ru">')+5:i.find('</display-name>')]
			cid=get_id(name)
			#if cid not in EPG.keys(): EPG
			channel[channel_id]={'id':cid, 'name':name}
		if "<programme " in i:
			n+=1
			title=i[i.find('<title lang="ru">')+17:i.find('</title>')]
			if 'desc' in i: desc=i[i.find('<desc lang="ru">')+16:i.find('</desc>')]
			else: desc=''
			if '<category' in i: cat=i[i.find('<category lang="ru">')+20:i.find('</category>')]
			else: cat=''

			start_at=i[i.find('start="')+7:i.find(' +0300')]
			ttv_id=i[i.find('channel="')+9:i.find('">')]
			cid=channel[ttv_id]['id']
			cnm=channel[ttv_id]['name']
			
			strptime=time.strptime(start_at , '%Y%m%d%H%M%S')
			tms=str(time.mktime(strptime))
			
			img=''
			
			if cid not in EPG.keys(): EPG[cid] = {'title':cnm}
			EPG[cid][tms]={"title":rt(title), 'img': img, 'plot': desc, 'type': cat}
			




# --------------------------------------------------

def clear_EPG():
	print 'clear_EPG'
	for cid in EPG.keys():
		cnl=EPG[cid]
		try:CL=cnl.keys()
		except:CL=[]
		for tm in CL:
			if tm!='title':
				if time.time()-eval(tm) > 4*60*60:
					#print cid+' '+tm
					EPG[cid].pop(tm, '')

def debug_epg(cid):
	info=get_inf_db(cid)
	L=info.keys()
	print "debug_epg " + info['title']
	try:L.remove('title')
	except: pass
	L.sort()
	s=''
	for tm in L:
		t=time.ctime(eval(tm))
		ttl=info[tm]['title']
		si=t+" "+ttl
		print si
		s=s+si+'\n'
	return s


def change_id(cid1, cid2):
	print cid1+' change_id_to '+cid2
	info=get_inf_db(cid1)
	#print info
	EPG[cid2]=info
	EPG.pop(cid1, '') 
	save_EPG()


def get_channels_info(cid):
	info=get_inf_db(cid)
	
	try:L=info.keys()
	except:
		print 'info err:'
		print info
		return []
		
	try:L.remove('title')
	except: pass
	L.sort()
	if __settings__.getSetting('autoshift')=='true':
		dts=time.timezone
	else:
		dts=(int(__settings__.getSetting('shift'))-11)*3600
	#print dts
	ct=time.time()
	m_ct=ct+dts
	#print ct
	for i in L:
		#print i
		try:ei=eval(i)-3*60*60
		except:
			print '!except eval(i)!'
			ei=0
		if ei > m_ct:
			#print 'ok'
			n1=L.index(i)
			n0=n1-1
			n2=n1+1
			e1=info[L[n1]]
			e1['time']=str(eval(L[n1])-3*60*60-dts)
			if n0>=0: 
				e0=info[L[n0]]
				e0['time']=str(eval(L[n0])-3*60*60-dts)
			else:e0={}
			if n2<len(L): 
				e2=info[L[n2]]
				e2['time']=str(eval(L[n2])-3*60*60-dts)
			else:e2={}
			Lr=[e0,e1,e2]
			#print Lr
			return Lr
	
	#if 'title' in info.keys():title=info['title']
	#else:title='Неизвестный канал'
	#print "NoEPG " +cid+' '+title
	return []

#get_channels_info('F79F4A92')
#print 'debug'
#debug_epg('7944E7D0')
#upepg()

def get_current_epg(ps='0'):
	print ps
	try:p=int(ps)
	except: p=0
	print 'run get_current_epg()'
	D={}
	n=0
	for cid in get_channels_list():
		if n>=(p-1)*100: 
			#print cid
			if cid!='udata':
				nfo=get_channels_info(cid)
				D[cid]=nfo
			if n > 0 and n >= 100*p: return D
		n+=1
	return D

def get_channels_list():
	try:
		return EPG.keys()
	except: 
		print 'except: get_channels_list()'
		return []

def save_EPG():
		EPG['udata']=time.strftime('%Y%m%d')
		fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'EPGdb.py'))
		fl = open(fp, "w")
		fl.write('# -*- coding: utf-8 -*-\n')
		fl.write('EPG={\n')
		for i in EPG.items():
			fl.write("'"+i[0]+"':"+repr(i[1])+',\n')
		fl.write('}\n')
		fl.close()

#print get_current_epg()

import os
import socket
import time
import sys

def load_img(target):
	try:
			req = urllib2.Request(url = target, data = None)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			return resp.read()
	except:
			print "err:  "+target
			return None

def get_img(addres):
	try:
		if 's-tv.ru' in addres:
			#print 'stv img'
			if 'cid' in addres:
				cid=addres[addres.find('/cid')+4:addres.find('/tms')]
				tms=addres[addres.find('/tms')+4:addres.find('/program')]
				addres=addres[addres.find('/program'):]
			else:
				cid=''
			#print 'cid:'+cid
			url=addres.replace('/program/','http://')
			#print url
			http=getURL2(url, 5)
			if http=='': return ''
			img=mfind(http,'<img src="','" style=')
			#print img
			if cid!='':
				#print 'DESC'
				try:
					if '<h4>' in http: tmp1=xt(mfind(http,'<h4>','</h4>'))
					else:  tmp1=''
				except:
					print 'err tmp1'
					tmp1=''
				try:
					if 'ajax-info-desc' in http: tmp2=xt(mfind(mfind(http,'ajax-info-desc','<script type'),'<p>','</p>'))
					else: tmp2=''
				except:
					print 'err tmp2'
					tmp2=''
				
				if tmp1!='': desc=tmp1+"\n"+tmp2
				else: desc=tmp2
				#print xt(desc)
				if desc!="":
					EPG[cid][tms]['plot']=desc
		else:
			url='https://m.tv.yandex.ru'+addres.replace('/977/', '/146/')
			http=getURL2(url)
			if http=='': return ''
			img='https:'+mfindal(http,'//avatars.mds.yandex.net/get-tv-shows','/small&quot;')[0]+'/normal'
		return img
	except:
		return ''


def send_answer(conn, status="200 OK", typ="text/plain; charset=utf-8", data="", Location=""):
		#print 'send_answer '+status
		#data = data.encode("utf-8")
		
		conn.send(b"HTTP/1.1 " + status + b"\r\n")#.encode("utf-8")
		
		if Location !="":
			conn.send(b"Location: "+ Location + b"\r\n")#.encode("utf-8")
			#print 'Location ОК'
		conn.send(b"Server: simplehttp\r\n")
		conn.send(b"Connection: close\r\n")
		conn.send(b"Content-Type: " + typ + b"\r\n")#.encode("utf-8")
		conn.send(b"Content-Length: " + bytes(len(data)) + b"\r\n")
		conn.send(b"\r\n")
		conn.send(data)
		#print Location
		#print 'Connection close'


def get_on(conn, addr):
	try:
		data = b""
	
		while not b"\r\n" in data:
			tmp = conn.recv(1024)
			if not tmp:
				break
			else:
				data += tmp
	
		if not data:
			return
	
		udata = data.decode("utf-8")
		udata = udata.split("\r\n", 1)[0]
		method, addres, protocol = udata.split(" ", 2)
		#print addres
		if 'current' in addres:
			if '/p=' in addres: p=addres[addres.find('/p=')+3:]
			else: p=0
			send_answer(conn, data=repr(get_current_epg(p)))
			
		if 'debug' in addres:
			cid=addres[addres.rfind('/')+1:]
			send_answer(conn, data=debug_epg(cid))

		if  'update' in addres:
			send_answer(conn, data="update")
			upepg()
		
		if  'change/id' in addres:
			cid1=addres[addres.find('/id=')+4:addres.find('/to=')]
			cid2=addres[addres.find('/to=')+4:]
			send_answer(conn, data="change id")
			change_id(cid1, cid2)

		if  'channels' in addres:
			try:
				cid=addres[addres.rfind('/')+1:]
				#print cid
				if   cid == 'all':	send_answer(conn, data=repr(get_channels_list()))
				elif cid =='dict':	send_answer(conn, data=repr(get_nm_dict()))
				elif len(cid)>4:	send_answer(conn, data=repr(get_channels_info(cid)))
				else: 				send_answer(conn, data="id:"+'None')
			except:
				print "ERR EPG "+addres
				send_answer(conn, "404 Not Found", data="Error")
		
		if  'channel/full/id' in addres:
			cid=addres[addres.find('/id=')+4:]
			send_answer(conn, data=repr(get_inf_db(cid)))
			
		elif 'program' in addres:
			
			redir=get_img(addres)
			if redir=='': redir='http://kolomiets.by/wp-content/uploads/2016/03/error-768x432.jpg'
			#if cid!='' and redir!='':
			#	EPG[cid][tms]['img']=redir
			
			#print redir
			#img=load_img(redir)
			if redir=='': send_answer(conn, "404 Not Found", data="")
			else:         send_answer(conn, "302 Moved Temporarily", typ="image/jpeg", Location=redir)
					#   application/vnd.apple.mpegurl 
					#send_answer(conn, "200 OK", typ="image/jpeg", data=img)
					#print "302 Moved Temporarily"
			return True
		else:
			return False
		
	except:
				print "ERR EPG "+addres
				send_answer(conn, "404 Not Found", data="ERR EPG")


if True:
	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.bind(("", port))
	s.listen(10)
#--------------------------------------------

# ================================ server =====================================

while not xbmc.abortRequested:
		if start_trigger:
			#time.sleep(10)
			print('----- P_EPG Запущен -----')
			#xbmcgui.Dialog().notification('PTV', 'Запущен', icon, 1000, False)
			start_trigger = False
		# ---------------------------------
		try:udata = int(get_inf_db('udata'))
		except: udata = 0
		cdata = int(time.strftime('%Y%m%d'))
		#print('----- PTV ud:'+str(udata))
		#print('----- PTV сd:'+str(cdata))
		
		if cdata>udata and __settings__.getSetting("epgon")=='true':
			#add_to_db ("udata", str(cdata))
			print('----- P_EPG обновление -----')
			upepg()
			#xbmc.executebuiltin("Container.Refresh")
		
		for i in range(0, 10):
			if __settings__.getSetting("epgon")=='true':
				try:s.settimeout(8.0)
				except: xbmc.sleep(2000)
					
				try:
					conn, addr = s.accept()
					get_on(conn, addr)
				except:pass
					

				#xbmc.sleep(3000)
				if xbmc.abortRequested:
					print ('----- P_EPG break -----')
					break
			else:
				xbmc.sleep(5000)

try:s.close()
except:pass

print('----- P_EPG stopped -----')

