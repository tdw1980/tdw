# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, urllib, sys, urllib2, time
#nt=time.time()
PLUGIN_NAME   = 'plugin.program.pazl.epg'
handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.program.pazl.epg')
__settings__ = xbmcaddon.Addon(id='plugin.program.pazl.epg')

pazl = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
sys.path.append(pazl.getAddonInfo('path'))
from DBcnl import *
try: 
	from EPGdb import *
	if EPG == "": EPG = {}
except:
	EPG = {}


# ================================ БД =======================================
import sqlite3 as db
db_name = os.path.join( addon.getAddonInfo('path'), "epg.db" )
#c = db.connect(database=db_name)
#cu = c.cursor()

def add_to_db(n, item):
	if len(item)>4:
		c = db.connect(database=db_name)
		cu = c.cursor()
		item=item.replace("'","XXCC").replace('"',"XXDD")
		err=0
		tor_id="n"+n
		litm=str(len(item))
		try:
			cu.execute("DROP TABLE "+tor_id+";")
			c.commit()
		except: pass
		try:
			cu.execute("CREATE TABLE "+tor_id+" (db_item VARCHAR("+litm+"), i VARCHAR(1));")
			c.commit()
		except: 
			err=1
			print "Ошибка БД"
		if err==0:
			cu.execute('INSERT INTO '+tor_id+' (db_item, i) VALUES ("'+item+'", "1");')
			c.commit()
		c.close()
		xbmc.sleep(30)

def list_to_db(L):
	c = db.connect(database=db_name)
	cu = c.cursor()
	for i in L:
		n=i[0]
		item=i[1]
		if len(item)>4:
			item=item.replace("'","XXCC").replace('"',"XXDD")
			err=0
			tor_id="n"+n
			litm=str(len(item))
			try:
				cu.execute("DROP TABLE "+tor_id+";")
				c.commit()
			except: pass
			try:
				cu.execute("CREATE TABLE "+tor_id+" (db_item VARCHAR("+litm+"), i VARCHAR(1));")
				c.commit()
			except: 
				err=1
				print "Ошибка БД"
			if err==0:
				cu.execute('INSERT INTO '+tor_id+' (db_item, i) VALUES ("'+item+'", "1");')
				c.commit()
	c.close()
	xbmc.sleep(30)

def get_inf_db(n):
		c = db.connect(database=db_name)
		cu = c.cursor()
		tor_id="n"+n
		cu.execute(str('SELECT db_item FROM '+tor_id+';'))
		c.commit()
		Linfo = cu.fetchall()
		info=Linfo[0][0].replace("XXCC","'").replace("XXDD",'"')
		return info
		c.close()

def rem_inf_db(n):
	if len(n)>0:
		c = db.connect(database=db_name)
		cu = c.cursor()
		tor_id="n"+n
		try:
			cu.execute("DROP TABLE "+tor_id+";")
			c.commit()
		except: pass
		c.close()

#==================================================================================================

def getURL(url, Referer = 'http://viks.tv/'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		#sn=http[s:]
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2






def add_item (name, mode="", ind="0", cover=None, funart=None):

	listitem = xbmcgui.ListItem(name, iconImage=cover)
	uri = sys.argv[0] + '?mode='+mode
	uri += '&name='  + urllib.quote_plus(name)
	uri += '&ind='  + urllib.quote_plus(str(ind))
	
	Context=[('[COLOR FF55FF55][B]Связать с каналом...[/B][/COLOR]', 'Container.Update("plugin://plugin.program.pazl.epg/?mode=set_id&ind='+ind+'")'),]
	listitem.addContextMenuItems(Context)
	
	xbmcplugin.addDirectoryItem(handle, uri, listitem, True)#False

def get_nm_dict():
	nm_dict={}
	for i in EPG.keys():
		try:nm_dict[EPG[i]['title']]=i
		except:pass
	return nm_dict

def root():
	D=get_nm_dict()
	for i in D.keys():
			pid=D[i]
			if pid in DBC.keys(): title='[COLOR FF55ff55]'+i+'[/COLOR] ['+DBC[pid]['title']+']'
			else: title='[COLOR FFFF5555]'+i+'[/COLOR] [НЕ СВЯЗАН]'
			add_item(title, "all", pid)#set_id
		
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(handle)

def all(ind):
	port=__settings__.getSetting("serv_port")
	url='http://127.0.0.1:'+port+'/debug/'+ind
	ht=getURL(url)
	L=ht.splitlines()
	for i in L:
		add_item(i)
	xbmcplugin.endOfDirectory(handle)

def set_id(ind):
	#D=get_nm_dict()
	#title=D[ind]
	CL=sort_abc(DBC.keys())
	L2=[]
	for i in CL:
		L2.append(DBC[i]['title'])
	
	sel = xbmcgui.Dialog()
	r = sel.select("Связать телепрограмму с каналом:", L2)
	if r>-1:
		id=CL[r]
		#D[id]=title
		#D.pop(ind)
		#__settings__.setSetting('idlist', repr(D))
		port=__settings__.getSetting("serv_port")
		url='http://127.0.0.1:'+port+'/change/id='+ind+'/to='+id
		getURL(url)
		#if info != None:
		#	rem_inf_db(ind)
		#	add_to_db(id, info)
		xbmc.sleep(2000)
		xbmc.executebuiltin("Container.Refresh")

def sort_abc(L):
	L2=[]
	for id in L:
		try: L2.append((DBC[id]['title'],id))
		except: pass
	L2.sort()
	L=[]
	for i in L2:
		L.append(i[1])
	return L

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

params = get_params()

try:mode = urllib.unquote_plus(params["mode"])
except:mode =""
try:name = urllib.unquote_plus(params["name"])
except:name =""
try:url = eval(urllib.unquote_plus(params["url"]))
except:url =[]
try:cover = urllib.unquote_plus(params["cover"])
except:cover =""
try:ind = urllib.unquote_plus(params["ind"])
except:ind ="0"
	
if mode==""         : root()
if mode=="set_id"   : set_id(ind)
if mode=="all"      : all(ind)