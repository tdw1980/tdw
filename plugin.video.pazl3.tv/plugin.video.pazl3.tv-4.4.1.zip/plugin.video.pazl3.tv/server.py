# coding: utf-8
# Module: server
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import threading
import sys, os
#
import time
#import base64
try:
	import xbmc, xbmcgui, xbmcaddon, xbmcvfs
except:
	pass

if sys.version_info.major > 2:  # Python 3 or later
	import socketserver as SocketServer
	import http.server as BaseHTTPServer
	
	import urllib.request
	#from urllib.parse import quote
	#from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import BaseHTTPServer, SocketServer
	import urllib, urlparse
	#from urllib import quote
	#from urllib import unquote
	import urllib2
'''
import ssl
try:
	ctx = ssl.create_default_context()
	ctx.check_hostname = False
	ctx.verify_mode = ssl.CERT_NONE
except: pass
'''
def abortRequested():
	#return False
	try:
		import xbmc
		if sys.version_info.major > 2: return xbmc.Monitor().abortRequested()
		else: return xbmc.abortRequested
	except:
		return False

#__settings__ = xbmcaddon.Addon(id='plugin.video.pazl3.tv')
port = 18089 #int(__settings__.getSetting("serv_port"))
trigger = True

#addon = xbmcaddon.Addon(id='plugin.video.pazl3.tv')

#if __settings__.getSetting("Debug")=='true':
#	deb = True
#else:
#	deb = False

deb = True
#cache_dict = {}
#gtm=time.time()

#import socket
#socket.setdefaulttimeout(None)

# - ====================================== antizapret ====================================================
#import cookielib
#sid_file = os.path.join(xbmc.translatePath('special://temp/'), 'servtam.sid')
#cj = cookielib.FileCookieJar(sid_file) 
#hr  = urllib2.HTTPCookieProcessor(cj) 
'''
def b2s(s):
	if err_torrent(s)==False: return s
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		return s
	else:
		return s

def err_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False
'''

LOG=[]
def LOG_append(t):
	try:
		if '/log/' not in t:
			tm=str(time.time())+' '
			LOG.append(tm+t)
			if len(LOG)>1000: LOG.pop(0)
	except: pass

def deb_print(s):
	if deb: print(s)
	LOG_append(s)
'''
def CRC32(buf):
		import binascii
		if sys.version_info.major > 2: buf = (binascii.crc32(buf.encode('utf-8')) & 0xFFFFFFFF)
		else: buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		r=str("%08X" % buf)
		return r
'''
# =========================== Базовые функции ================================


def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2
	

#=================================BS=================================
'''
if sys.version_info.major > 2:  # Python 3 or later
	import urllib.request
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2
'''

block_sz = 1024#81920

stack = []
mdstack = {}
tSTOP = False

from threading import Thread
class MyThread(Thread):
	def __init__(self, url):
		self.mdstack = {}
		self.tSTOP = False
		self.buf_max = 6000
		self.comp = 0
		Thread.__init__(self)
		self.url=url
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 OPR/77.0.4054.203')
		self.resp = urllib2.urlopen(req, timeout=5)
		print ('connection ok')
		#self.n = n
	
	def run(self):
		print ('run download loop')
		if self.mdstack != {}:return
		
		while not self.tSTOP:
			if len(self.mdstack) < self.buf_max:
				try: buf=self.resp.read(block_sz)
				except: buf=''
				if len(buf)>1000:
					self.mdstack[self.comp] = buf
					self.comp += 1
					time.sleep(0.001)
				else:
					self.resp.close()
					req = urllib2.Request(self.url)
					req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 OPR/77.0.4054.203')
					self.resp = urllib2.urlopen(req, timeout=10)
					#self.buf_max += 100
					#time.sleep(1)
					print ('-RE-')
		
		self.mdstack = {}
		self.resp.close()
	
	def mdstack(self):
		return self.mdstack

	def stop(self, s=True):
			self.tSTOP=s

def save(val):
	key=str(int(time.time()/60))
	try:
		db_dir = os.path.join(os.getcwd(), "record" )
		fp=os.path.join(db_dir, key)
		with open(fp,'ab') as fl:
		#fl = open(fp, "w")
			fl.write(val)
		#fl.close()
		return ('ok')
	except:
		return ('error set '+key)

class BSc():
	def __init__(self, url):
		#req = urllib2.Request(url)
		#self.resp = urllib2.urlopen(req, timeout=3)
		#buf = self.resp.read(block_sz)
		self.last = None#buf
		self.url = url
		self.list = []
		self.run = 0
		self.complit = 0
		self.n = 0
		self.t1 = ''
		self.t2 = ''
		#self.stack = [None,None,None,None,None,None,None,None,None,None]
		
		self.my_thread = self.create_thread()
		#self.stop(False)

	def get_head(self, url):
		return url[:url.rfind('/')+1]

	def get_data(self):
		mdstack=self.my_thread.mdstack()
		for i in range(10):
			if self.n not in mdstack.keys(): time.sleep(0.1)
		
		try: 
			data=mdstack[self.n]#self.GET()
			del mdstack[self.n]
			self.n+=1
		except: 
			data=None
		if len(mdstack)<2:
			time.sleep(0.5)
			print ('stack<2')
		elif len(mdstack)<3:
			time.sleep(0.1)
		#print 'ok'
		#save(data)
		return data
	
	def get_status(self):
		return len(mdstack)
	
	def create_thread(self):
		print ('--- create_strim_thread ---')
		my_thread = MyThread(self.url)
		my_thread.start()
		time.sleep(1)
		return my_thread
	
	def stop(self, s=True):
		self.my_thread.mdstack(s)


#===================================================================

def get_on(addres):
		data='ERR 404'
		if len(addres)>10: pref = addres[:10]
		else:              pref = addres
		
		if '/log/' in pref:
			data = ''
			for i in LOG:
				data +=i+'\n'
		elif 'restream/' in pref:
			data='BS:'+addres[addres.find('restream/')+9:]
		
		return data

headers_db={}

# ================================ server =====================================
#import bitstream
cbs=''
class HttpProcessor(BaseHTTPServer.BaseHTTPRequestHandler):
	def do_HEAD(self):
		LOG_append('> HEAD')
		self.send_response(200)
		self.send_header('Content-type','video/octet-stream')
		self.end_headers()


	def do_POST(self):
		deb_print('> POST')
		deb_print(self.path)
		self.data_string = self.rfile.read(int(self.headers['Content-Length']))
		deb_print(self.data_string)
		LOG_append('> POST: '+self.path+' '+repr(self.data_string))
		set_headers(self.headers, self.path)
		
		addres = self.path
		data = ''
		post = None
		if 'proxy/' in addres:
			url=addres[addres.find('proxy/')+6:]
			post = self.data_string
			data = POST(url, post)
		elif 'http' in addres:
			post = self.data_string
			data = POST(addres, post)
		self.send_response(200)
		self.end_headers()
		LOG_append('< POST: '+str(len(data)))
		try: data = data.encode('utf-8')
		except: pass
		self.wfile.write(data)
	
	def do_GET(self):
		#try:
			try: xbmc.sleep(100)
			except: pass

			if 'Range:' in self.headers: 
				self.send_response(404)
				data = '404 Not Found'
				self.end_headers()
			deb_print('> GET: '+self.path)
			#deb_print('==============')
			#deb_print('\n'+str(self.headers))
			#deb_print('==============')
			
			data=get_on(self.path)
			#LOG_append(data[:4])
			if data == 'ERR 404':
				self.send_response(404)
				self.end_headers()
			
			elif data[:3]=='BS:': 
				#if 'bytes=0-' not in str(self.headers) : #'Kodi' in self.headers and 
				#	self.send_response(403)
				#	self.end_headers()
				#	self.wfile.write(b'')
				#	deb_print('Renturn 403')
				#	return None
				
				global cbs
				deb_print('== BS ==')
				curl=data[3:]
				deb_print(curl)
				
				if cbs==curl: 
					self.send_response(403)
					self.end_headers()
					self.wfile.close()
					#self.wfile.write(b'')
					deb_print('Renturn 403')
					return None
				
				cbs=curl
				#BS=BSc(curl)
				
				import bitstream
				BS=bitstream.BS(curl)
				for i in range(8):
					status = BS.get_status()
					print ('buffer: '+str(status))
					if status>1000: break
					time.sleep(1)
				
				if status<1000:
					self.send_response(404)
					self.end_headers()
					self.wfile.write(b'')
					deb_print('Renturn 404')
					cbs=''
					return None
				
				self.send_response(200)
				self.send_header('Content-type','video/octet-stream')
				self.send_header('Content-Type', 'video/mpeg')
				self.send_header('Accept-Ranges', 'bytes')
				self.send_header('Content-Ranges', 'bytes 0-')
				self.end_headers()
				
				deb_print('Renturn 200')
				
				bsn = 0
				bst = 0
				rs = 0
				while trigger:
					try: xbmc.sleep(1)
					except: time.sleep(0.0001)
					try:
						try: part=BS.get_data()
						except: part=None
						#if rs==0: 
						#	part = b'G'#part[752:]
						#	rs=1
						#	rs=0
						if part == 'error': break
						if part !=None: 
							try: self.wfile.write(part)
							except: 
								try: xbmc.sleep(100)
								except: pass
								break
							#print len(self.wfile)
							bsn = 0
						
						else: 
							print (bsn)
							if bsn > 1: break
							if bst > 15: break
							deb_print('== RECONNECT ==')
							try:BS.stop()
							except:pass
							time.sleep(0.01)
							BS=bitstream.BS(curl)
							rs=1
							bsn+=1
							bst+=1
						
					except:
						break
				try: xbmc.sleep(100)
				except: pass
				
				BS.stop()
				try: xbmc.sleep(100)
				except: pass

				deb_print('== BS END ==')
				try: xbmc.sleep(500)
				except: time.sleep(0.5)
				cbs=''
				deb_print('== CBS END ==')
				return
			else:
				self.send_response(200)
				self.end_headers()
			if '/log/' not in self.path: LOG_append('< GET: '+str(len(data))+" "+ repr(data)[:6])
			
			try: data = data.encode('utf-8')
			except: pass
			self.wfile.write(data)
		#except:
		#	pass

class MyThreadingHTTPServer(SocketServer.ThreadingMixIn, BaseHTTPServer.HTTPServer):
	pass

errors = False
try:
	serv = MyThreadingHTTPServer(("127.0.0.1", port), HttpProcessor)
	threading.Thread(target=serv.serve_forever).start()
	#target=serv.serve_forever()
except:
	errors = True

if errors:
	deb_print('----- Restream_serv ERROR -----')
else:
	deb_print('----- Restream_serv OK -----')
	n=0
	while not abortRequested():
				try: xbmc.sleep(1000)
				except: time.sleep(1)
				
				
trigger = False
deb_print('----- Restream_serv shutdown -----')
try:serv.shutdown()
except:pass

deb_print('----- Restream_serv stopped -----')

