# coding: utf-8
# Module: server
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys, os
import xbmc, xbmcgui, xbmcaddon
import time
import urllib2
__settings__ = xbmcaddon.Addon(id='plugin.program.pazl.server')
port = int(__settings__.getSetting("serv_port"))

addon = xbmcaddon.Addon(id='plugin.program.pazl.server')
pazl = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
sys.path.append(pazl.getAddonInfo('path'))

import cookielib
sid_file = os.path.join(xbmc.translatePath('special://temp/'), 'servpazl.sid')
cj = cookielib.FileCookieJar(sid_file) 
hr  = urllib2.HTTPCookieProcessor(cj) 
opener = urllib2.build_opener(hr) 
urllib2.install_opener(opener) 


#from DBcnl import *
import pztv
DBC = pztv.DBC

EPG = {}

icon=None
pDialog = xbmcgui.DialogProgressBG()

PlotCashe={}
ImgCashe={}

#time.sleep(10)
#xbmc.sleep(5000)
print('----- Starting P_serv -----')
start_trigger = True
#n=0
# =========================== Базовые функции ================================

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		#sn=http[s:]
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def getURL2(url, dt=3):
		import requests
		try:
			s = requests.session()
			r=s.get(url, timeout=(0.5, dt), verify=False).text#0.00001
		except:
			print 'requests: timeout'
			r=''
		#r=r.encode('windows-1251')
		return r

def getURL(url, Referer = 'http://viks.tv/'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


def get_HTML(url, post = None, ref = None, get_redirect = False):
    import urlparse
    if url.find('http')<0 :url='http:'+url
    request = urllib2.Request(url, post)

    host = urlparse.urlsplit(url).hostname
    if ref==None:
        try:
           ref='http://'+host
        except:
            ref='localhost'

    request.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
    request.add_header('Host',   host)
    request.add_header('Accept', 'text/html, application/xhtml+xml, */*')
    request.add_header('Accept-Language', 'ru-RU')
    request.add_header('Referer',             ref)
    request.add_header('Content-Type','application/x-www-form-urlencoded')

    try:
        f = urllib2.urlopen(request)
    except IOError, e:
        if hasattr(e, 'reason'):
           print('We failed to reach a server.')
        elif hasattr(e, 'code'):
           print('The server couldn\'t fulfill the request.')
        return 'We failed to reach a server.'

    if get_redirect == True:
        html = f.geturl()
    else:
        html = f.read()

    return html




def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def rt(x):
	try:
		L=[('&#133;','…'),('&#34;','&'), ('&#39;','’'), ('&#145;','‘'), ('&#146;','’'), ('&#147;','“'), ('&#148;','”'), ('&#149;','•'), ('&#150;','–'), ('&#151;','—'), ('&#152;','?'), ('&#153;','™'), ('&#154;','s'), ('&#155;','›'), ('&#156;','?'), ('&#157;',''), ('&#158;','z'), ('&#159;','Y'), ('&#160;',''), ('&#161;','?'), ('&#162;','?'), ('&#163;','?'), ('&#164;','¤'), ('&#165;','?'), ('&#166;','¦'), ('&#167;','§'), ('&#168;','?'), ('&#169;','©'), ('&#170;','?'), ('&#171;','«'), ('&#172;','¬'), ('&#173;',''), ('&#174;','®'), ('&#175;','?'), ('&#176;','°'), ('&#177;','±'), ('&#178;','?'), ('&#179;','?'), ('&#180;','?'), ('&#181;','µ'), ('&#182;','¶'), ('&#183;','·'), ('&#184;','?'), ('&#185;','?'), ('&#186;','?'), ('&#187;','»'), ('&#188;','?'), ('&#189;','?'), ('&#190;','?'), ('&#191;','?'), ('&#192;','A'), ('&#193;','A'), ('&#194;','A'), ('&#195;','A'), ('&#196;','A'), ('&#197;','A'), ('&#198;','?'), ('&#199;','C'), ('&#200;','E'), ('&#201;','E'), ('&#202;','E'), ('&#203;','E'), ('&#204;','I'), ('&#205;','I'), ('&#206;','I'), ('&#207;','I'), ('&#208;','?'), ('&#209;','N'), ('&#210;','O'), ('&#211;','O'), ('&#212;','O'), ('&#213;','O'), ('&#214;','O'), ('&#215;','?'), ('&#216;','O'), ('&#217;','U'), ('&#218;','U'), ('&#219;','U'), ('&#220;','U'), ('&#221;','Y'), ('&#222;','?'), ('&#223;','?'), ('&#224;','a'), ('&#225;','a'), ('&#226;','a'), ('&#227;','a'), ('&#228;','a'), ('&#229;','a'), ('&#230;','?'), ('&#231;','c'), ('&#232;','e'), ('&#233;','e'), ('&#234;','e'), ('&#235;','e'), ('&#236;','i'), ('&#237;','i'), ('&#238;','i'), ('&#239;','i'), ('&#240;','?'), ('&#241;','n'), ('&#242;','o'), ('&#243;','o'), ('&#244;','o'), ('&#245;','o'), ('&#246;','o'), ('&#247;','?'), ('&#248;','o'), ('&#249;','u'), ('&#250;','u'), ('&#251;','u'), ('&#252;','u'), ('&#253;','y'), ('&#254;','?'), ('&#255;','y'), ('&laquo;','"'), ('&raquo;','"'), ('&nbsp;',' '), ('&amp;quot;','"')]
		for i in L:
			x=x.replace(i[0], i[1])
		return x
	except:
		return x

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def fs_enc(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode('utf-8').encode(sys_enc)

def fs_dec(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode(sys_enc).encode('utf-8')

def lower_old(s):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.lower().encode('utf-8')
	return s

def lower(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in range (65,90):
		t=t.replace(chr(i),chr(i+32))
	for i in RUS.keys():
		t=t.replace(i,RUS[i])
	return t

def upper(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in RUS.keys():
		t=t.replace(RUS[i],i)
	for i in range (65,90):
		t=t.replace(chr(i+32),chr(i))
	return t

def CRC32(buf):
		import binascii
		buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		return str("%08X" % buf)

def mfind_old(t,s,e):
	r=t[t.find(s)+len(s):t.find(e)]
	return r

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2
	
def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "w")
	fl.write(s)
	fl.close()


def get_inf_db(n):
	try: return EPG[n]
	except: return {}

#==================================================================

def root_list():
		Lret=[]
		Lnm=[]
		nml=[]
		Lserv=pztv.get_all_channeles()
		L=pztv.DBC.keys()
		for a in Lserv:
			nm=pztv.uni_mark(a['title'])
			nml.append(nm)
		CL=pztv.get_gr('Все каналы')
		for id in CL:
				try:
					names = DBC[id]['names']
					enable=False
					for b in names:
						if b in nml: enable=True
					
					if enable:
						name  = pztv.DBC[id]['title']
						cover = pztv.get_picon(id)
						Lret.append({'title':name, 'id': id, 'picon': cover})
				except: pass
		return Lret



def get_playlist():
		try:ip = socket.gethostbyname_ex(socket.gethostname())[2][0]
		except: ip = '127.0.0.1'
		Dgr={}
		try:Lgr=pztv.open_Groups()
		except:Lgr=[]
		for i in Lgr:
			for idc in i[1]:
				Dgr[idc]=i[0]

		list='#EXTM3U\n'
		L=root_list()#pztv.root('Все каналы')
		for i in L:
			name  = i['title']
			id    = i['id']
			cover = i['picon']
			if id in Dgr.keys(): gr=Dgr[id]
			else: gr='ДРУГИЕ'
			EXTINF='#EXTINF:-1 group-title="'+gr+'" tvg-name="'+name+'" tvg-id="'+id+'" tvg-logo="'+cover+'",'+name
			PREF='http://'+ip+':'+__settings__.getSetting("serv_port")+'/get/stream/'
			list+=EXTINF+'\n'
			list+=PREF+id+'\n'
		return list

def get_jsonlist():
		Dgr={}
		json={}
		try:Lgr=pztv.open_Groups()
		except:Lgr=[]
		for i in Lgr:
			for idc in i[1]:
				Dgr[idc]=i[0]

		L=root_list()
		Lc=[]
		for i in L:
			name  = i['title']
			id    = i['id']
			cover = i['picon']
			if id in Dgr.keys(): gr=Dgr[id]
			else: gr='ДРУГИЕ'
			PREF='http://127.0.0.1:'+__settings__.getSetting("serv_port")+'/get/stream/'
			curl=PREF+id
			Lc.append({"id":id, "name":name.decode('utf-8'), "icon":cover.decode('utf-8'), "group":gr.decode('utf-8'), "url":curl.decode('utf-8')})
		json["channels"]=Lc
		return repr(json).replace("'", '"').replace('u"','"')

def get_stream(id):
	if id=='': return ''
	L = pztv.get_all_channeles()
	urls=pztv.get_allurls(id, L)
	
	for url in urls:
		try: L2=pztv.get_stream(url)
		except:L2=[]
		if len(L2)>0: return L2[0]
	return ''

def get_streams(id):
	if id=='': return '[]'
	L = pztv.get_all_channeles()
	urls=pztv.get_allurls(id, L)
	Lstr=[]
	for url in urls:
		try: L2=pztv.get_stream(url)
		except:L2=[]
		for st in L2:
			Lstr.append(st)
	return repr(Lstr)

#===================================================================

import os
import socket
import time
import sys



def send_answer(conn, status="200 OK", typ="text/plain; charset=utf-8", data="", Location=""):
		#print 'send_answer '+status
		#data = data.encode("utf-8")
		
		conn.send(b"HTTP/1.1 " + status + b"\r\n")#.encode("utf-8")
		
		if Location !="":
			conn.send(b"Location: "+ Location + b"\r\n")#.encode("utf-8")
			#print 'Location ОК'
		conn.send(b"Server: simplehttp\r\n")
		conn.send(b"Connection: close\r\n")
		conn.send(b"Content-Type: " + typ + b"\r\n")#.encode("utf-8")
		conn.send(b"Content-Length: " + bytes(len(data)) + b"\r\n")
		conn.send(b"\r\n")
		conn.send(data)
		#print Location
		#print 'Connection close'


def get_on(conn, addr):
	#try:
		data = b""
		while not b"\r\n" in data:
			print 'while not'
			tmp = conn.recv(1024)
			print 'tmp'
			if not tmp:
				print  'not tmp'
				break
			else:
				print 'data += tmp'
				data += tmp
	
		if not data: 
			print  'not data'
			return
			
		
		udata = data.decode("utf-8")
		udata = udata.split("\r\n", 1)[0]
		method, addres, protocol = udata.split(" ", 2)
		
		print addres
		
		if 'get/playlist' in addres:
			send_answer(conn, data=get_playlist())
			
		elif 'get/json' in addres:
			send_answer(conn, data=get_jsonlist())
			
		elif 'get/streams/' in addres:
			id=addres[addres.find('streams/')+8:]
			send_answer(conn, data=get_streams(id))
			
		elif 'get/stream/' in addres:
			id=addres[addres.find('stream/')+7:]
			redir=get_stream(id)
			if redir=='': send_answer(conn, "404 Not Found", data="")
			else:
				#send_answer(conn, data=id)
				send_answer(conn, "302 Moved Temporarily", typ="application/octet-stream", Location=redir)
		
	#except:
	#		print "ERR EPG "+addres
	#		send_answer(conn, "404 Not Found", data="ERR EPG")


soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
soc.bind(("", port))
soc.listen(5)

# ================================ server =====================================
#xbmc.executebuiltin('RunPlugin("plugin://plugin.program.pazl.server/?mode=watchdog")')
while not xbmc.abortRequested:
			if __settings__.getSetting("epgon")=='true':
				#try:soc.settimeout(10.0)
				#except: xbmc.sleep(2000)
				
				try:
					conn, addr = soc.accept()
					get_on(conn, addr)
				except:
					pass
			else:
				xbmc.sleep(5000)

try:soc.close()
except:pass

print('----- P_serv stopped -----')

