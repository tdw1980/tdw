# coding: utf-8
# Module: server
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer
import threading, SocketServer, BaseHTTPServer
quit_event = threading.Event()


import sys, os
import xbmc, xbmcgui, xbmcaddon
import time
import urllib2
import base64
import socket

__settings__ = xbmcaddon.Addon(id='plugin.program.pazl.server')
port = int(__settings__.getSetting("serv_port"))

addon = xbmcaddon.Addon(id='plugin.program.pazl.server')
pazl = xbmcaddon.Addon(id='plugin.video.pazl2.tv')
sys.path.append(pazl.getAddonInfo('path'))

import cookielib
sid_file = os.path.join(xbmc.translatePath('special://temp/'), 'servpazl.sid')
cj = cookielib.FileCookieJar(sid_file) 
hr  = urllib2.HTTPCookieProcessor(cj) 
opener = urllib2.build_opener(hr) 
urllib2.install_opener(opener) 


import pztv
DBC = pztv.DBC
pztv.Player=xbmc.Player()

EPG = {}

icon=None
pDialog = xbmcgui.DialogProgressBG()

PlotCashe={}
ImgCashe={}

print('----- Starting P_serv -----')
start_trigger = True

# =========================== Базовые функции ================================
def getURL(url, Referer = 'http://viks.tv/'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

def rt(x):
	try:
		L=[('&#133;','…'),('&#34;','&'), ('&#39;','’'), ('&#145;','‘'), ('&#146;','’'), ('&#147;','“'), ('&#148;','”'), ('&#149;','•'), ('&#150;','–'), ('&#151;','—'), ('&#152;','?'), ('&#153;','™'), ('&#154;','s'), ('&#155;','›'), ('&#156;','?'), ('&#157;',''), ('&#158;','z'), ('&#159;','Y'), ('&#160;',''), ('&#161;','?'), ('&#162;','?'), ('&#163;','?'), ('&#164;','¤'), ('&#165;','?'), ('&#166;','¦'), ('&#167;','§'), ('&#168;','?'), ('&#169;','©'), ('&#170;','?'), ('&#171;','«'), ('&#172;','¬'), ('&#173;',''), ('&#174;','®'), ('&#175;','?'), ('&#176;','°'), ('&#177;','±'), ('&#178;','?'), ('&#179;','?'), ('&#180;','?'), ('&#181;','µ'), ('&#182;','¶'), ('&#183;','·'), ('&#184;','?'), ('&#185;','?'), ('&#186;','?'), ('&#187;','»'), ('&#188;','?'), ('&#189;','?'), ('&#190;','?'), ('&#191;','?'), ('&#192;','A'), ('&#193;','A'), ('&#194;','A'), ('&#195;','A'), ('&#196;','A'), ('&#197;','A'), ('&#198;','?'), ('&#199;','C'), ('&#200;','E'), ('&#201;','E'), ('&#202;','E'), ('&#203;','E'), ('&#204;','I'), ('&#205;','I'), ('&#206;','I'), ('&#207;','I'), ('&#208;','?'), ('&#209;','N'), ('&#210;','O'), ('&#211;','O'), ('&#212;','O'), ('&#213;','O'), ('&#214;','O'), ('&#215;','?'), ('&#216;','O'), ('&#217;','U'), ('&#218;','U'), ('&#219;','U'), ('&#220;','U'), ('&#221;','Y'), ('&#222;','?'), ('&#223;','?'), ('&#224;','a'), ('&#225;','a'), ('&#226;','a'), ('&#227;','a'), ('&#228;','a'), ('&#229;','a'), ('&#230;','?'), ('&#231;','c'), ('&#232;','e'), ('&#233;','e'), ('&#234;','e'), ('&#235;','e'), ('&#236;','i'), ('&#237;','i'), ('&#238;','i'), ('&#239;','i'), ('&#240;','?'), ('&#241;','n'), ('&#242;','o'), ('&#243;','o'), ('&#244;','o'), ('&#245;','o'), ('&#246;','o'), ('&#247;','?'), ('&#248;','o'), ('&#249;','u'), ('&#250;','u'), ('&#251;','u'), ('&#252;','u'), ('&#253;','y'), ('&#254;','?'), ('&#255;','y'), ('&laquo;','"'), ('&raquo;','"'), ('&nbsp;',' '), ('&amp;quot;','"')]
		for i in L:
			x=x.replace(i[0], i[1])
		return x
	except:
		return x

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def fs_enc(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode('utf-8').encode(sys_enc)

def fs_dec(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode(sys_enc).encode('utf-8')


def lower(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in range (65,90):
		t=t.replace(chr(i),chr(i+32))
	for i in RUS.keys():
		t=t.replace(i,RUS[i])
	return t

def upper(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in RUS.keys():
		t=t.replace(RUS[i],i)
	for i in range (65,90):
		t=t.replace(chr(i+32),chr(i))
	return t

def CRC32(buf):
		import binascii
		buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		return str("%08X" % buf)

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2
	
def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "w")
	fl.write(s)
	fl.close()


#==================================================================

def root_list():
		Lret=[]
		Lnm=[]
		nml=[]
		Lserv=pztv.get_all_channeles()
		L=pztv.DBC.keys()
		for a in Lserv:
			nm=pztv.uni_mark(a['title'])
			nml.append(nm)
		CL=pztv.get_gr('Все каналы')
		for id in CL:
				try:
					names = DBC[id]['names']
					enable=False
					for b in names:
						if b in nml: enable=True
					
					if enable:
						name  = pztv.DBC[id]['title']
						cover = pztv.get_picon(id)
						Lret.append({'title':name, 'id': id, 'picon': cover})
				except: pass
		return Lret



def get_playlist():
		try:ip = socket.gethostbyname_ex(socket.gethostname())[2][0]
		except: ip = '127.0.0.1'
		Dgr={}
		try:Lgr=pztv.open_Groups()
		except:Lgr=[]
		for i in Lgr:
			for idc in i[1]:
				Dgr[idc]=i[0]

		list='#EXTM3U\n'
		L=root_list()#pztv.root('Все каналы')
		for i in L:
			name  = i['title']
			id    = i['id']
			cover = i['picon']
			if id in Dgr.keys(): gr=Dgr[id]
			else: gr='ДРУГИЕ'
			EXTINF='#EXTINF:-1 group-title="'+gr+'" tvg-name="'+name+'" tvg-id="'+id+'" tvg-logo="'+cover+'",'+name
			PREF='http://'+ip+':'+__settings__.getSetting("serv_port")+'/get/stream/'
			list+=EXTINF+'\n'
			list+=PREF+id+'\n'
		return list

def get_jsonlist():
		Dgr={}
		json={}
		try:Lgr=pztv.open_Groups()
		except:Lgr=[]
		for i in Lgr:
			for idc in i[1]:
				Dgr[idc]=i[0]

		L=root_list()
		Lc=[]
		for i in L:
			name  = i['title']
			id    = i['id']
			cover = i['picon']
			if id in Dgr.keys(): gr=Dgr[id]
			else: gr='ДРУГИЕ'
			PREF='http://127.0.0.1:'+__settings__.getSetting("serv_port")+'/get/stream/'
			curl=PREF+id
			Lc.append({"id":id, "name":name.decode('utf-8'), "icon":cover.decode('utf-8'), "group":gr.decode('utf-8'), "url":curl.decode('utf-8')})
		json["channels"]=Lc
		return repr(json).replace("'", '"').replace('u"','"')

def get_stream(id):
	if id=='': return ''
	L = pztv.get_all_channeles()
	urls=pztv.get_allurls(id, L)
	
	for url in urls:
		try: L2=pztv.get_stream(url)
		except:L2=[]
		if len(L2)>0: return L2[0]
	return ''

def get_streams_old(id):
	if id=='': return '[]'
	L = pztv.get_all_channeles()
	urls=pztv.get_allurls(id, L)
	Lstr=[]
	for url in urls:
		try: L2=pztv.get_stream(url)
		except:L2=[]
		for st in L2:
			Lstr.append(st)
	return repr(Lstr).replace("'", '"').replace('u"','"')



def update_Lt(d):
	global Lthread
	if d == 'reset':	Lthread=[]
	else:				Lthread.append(d)

from threading import Thread
class MyThread(Thread):
	def __init__(self, param):
		Thread.__init__(self)
		self.param = param
	
	def run(self):
		update_Lt(pztv.get_stream(self.param))

def create_thread(param):
		my_thread = MyThread(param)
		my_thread.start()


def get_streams(id):
		if id=='': return '[]'
		L = pztv.get_all_channeles()
		urls=pztv.get_allurls(id, L)
		Lpurl=[]
		update_Lt('reset')
		for url in urls:
			create_thread(url)
		
		for t in range(20):
			if len(Lthread) == len(urls): break
			xbmc.sleep(100)
		
		for Lst in Lthread:
			for st in Lst:
				Lpurl.append(st)
		
		return repr(Lpurl).replace("'", '"').replace('u"','"')


def arh_jsonlist():
		nm2id={}
		nml=[]
		for a in pztv.DBC.items():
			id=a[0]
			names=a[1]['names']
			for nm in names:
				nm2id[nm]=id
				nml.append(nm)
		
		Lc=[]
		json={}
		response = eval(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Files.GetDirectory", "params": {"directory": "plugin://plugin.video.pazl.arhive"},"id": 1}'))
		#print response
		files=response["result"]["files"]
		
		for i in files:
			name=i["label"]
			url = i["file"]
			if pztv.uni_mark(name) in nml:
				id = nm2id[pztv.uni_mark(name)]
				Lc.append({"name":name.decode('utf-8'), "id": id.decode('utf-8')})#, "url":url.decode('utf-8')
			else:
				Lc.append({"name":name.decode('utf-8'), "id": u'0'})#, "url":url.decode('utf-8')
		json["channels"]=Lc
		return repr(json).replace("'", '"').replace('u"','"')

def arh_items(id, day='0'):
	pztv.arhive.setSetting("Sel_sday", day)
	D=pztv.get_arhive_directory()
	L=[]
	try:
		dir = D[id]
		json={}
		response = eval(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Files.GetDirectory", "params": {"directory": "'+dir+'"},"id": 1}'))
		files=response["result"]["files"]
		for i in files:
			name=i["label"]
			curl=i["file"]
			if 'mode=play' in curl:
				purl = curl.replace('mode=play2', 'mode=strm')
				sign=base64.b64encode(purl)[:-1]
				L.append({"name":name.decode('utf-8'), "id":sign.decode('utf-8')})
	except: pass
		
	json["channels"]=L
	return repr(json).replace("'", '"').replace('u"','"')

#print arh_items('CC6D4CDC')

def arh_streams(sign):
	dir=base64.b64decode(sign+'=')
	response = eval(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Files.GetDirectory", "params": {"directory": "'+dir+'"},"id": 1}'))
	files=response["result"]["files"]
	L=[]
	for i in files:
		name=i["label"]
		curl=i["file"]
		if curl not in L:
			L.append(curl)
	return repr(L).replace("'", '"').replace('u"','"')

#===================================================================

def get_on(addres):
		
		print addres
		data='ERR 404'
		if 'get/playlist' in addres:
			data=get_playlist()
			
		elif 'get/json' in addres:
			data=get_jsonlist()
			
		elif 'get/streams/' in addres:
			id=addres[addres.find('streams/')+8:]
			data=get_streams(id)
			
		elif 'get/stream/' in addres:
			id=addres[addres.find('stream/')+7:]
			redir=get_stream(id)
			if redir=='': data="ERR 404"
			else:         data=redir
		
		elif 'arh/json' in addres:
			data=arh_jsonlist()
		
		elif 'arh/channel/' in addres:
			if '/day/' in addres:
				day=addres[addres.find('/day/')+5:]
				id=addres[addres.find('channel/')+8:addres.find('/day/')]
			else:
				day='0'
				id=addres[addres.find('channel/')+8:]
			data=arh_items(id, day)

		elif 'arh/streams/' in addres:
			id=addres[addres.find('streams/')+8:]
			data=arh_streams(id)
		return data



#soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#soc.bind(("", port))
#soc.listen(5)

# ================================ server =====================================



class HttpProcessor(BaseHTTPRequestHandler):
	
	def do_GET(self):
		data=get_on(self.path)
		
		if data == 'ERR 404':
			self.send_response(404)
		elif data[:4]=='http': 
			self.send_response(302)
			self.send_header('Location', data)
			self.send_header('content-type','image/jpeg')
		else:
			self.send_response(200)
			self.send_header('content-type','text/html')
		
		self.end_headers()
		
		self.wfile.write(data)
		if data == 'update': upepg()
		#quit_event.set()

class MyThreadingHTTPServer(SocketServer.ThreadingMixIn, BaseHTTPServer.HTTPServer):
	pass

#if __settings__.getSetting("epgon")=='true':
serv = MyThreadingHTTPServer(("0.0.0.0",port), HttpProcessor)
threading.Thread(target=serv.serve_forever).start()

print('----- P_serv OK -----')
while not xbmc.abortRequested:
				xbmc.sleep(5000)

try:serv.shutdown()
#try:soc.close()
except:pass

print('----- P_serv stopped -----')

