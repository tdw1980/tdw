import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, urllib, sys, urllib2, time
__settings__ = xbmcaddon.Addon(id='plugin.program.pazl.server')


def getURL(url):
	req = urllib2.Request(url)
	#req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	#req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	#req.add_header('Accept-Language', 'ru,en;q=0.9')
	#req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	#link=response.read()
	response.close()
	#return link

def watchdog():
	port = __settings__.getSetting("serv_port")
	while not xbmc.abortRequested:
		xbmc.sleep(1000)
	url='http://127.0.0.1:'+port+'/stop'
	try: 
		print 'watchdog send stop'
		getURL(url)
	except: pass

watchdog()
