# -*- coding: utf-8 -*-
print ('-=-=- mp3bob -=-=-')
import sys, os, time
import uscode
import ssl
try: # Игнорирование SSl сертификата
	ctx = ssl.create_default_context()
	ctx.check_hostname = False
	ctx.verify_mode = ssl.CERT_NONE
except: pass

httpurl='https://mp3bob.ru'


# =========================функции для совместимости с коди 19 ===============================
if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2

def b2s(s):
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		return s
	else:
		return s
# ============================== текстовые функции ====================================
def rt(s): return uscode.decode(s)
def ru(x):return unicode(x,'utf8', 'ignore')

def find_all(http, ss, es): # Ищет все элементы начинающиеся с ss и заканчивающиеся на es
	L=[]
	while http.find(es)>0:
		s=http.find(ss)+len(ss)
		http=http[s:]
		e=http.find(es)
		i=http[:e]
		L.append(i)
		http=http[e+1:]
	return L

def mfind(t,s,e): # Ищет первый встреченый текст с ss и заканчивающиеся на es
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

# ============================== функции загрузки данных с сайта ====================================
def POST(target, post=None, referer=httpurl):
	#print target
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
		req.add_header('Accept', 'application/json, text/javascript, */*; q=0.01')
		req.add_header('Accept-Language', 'ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4')
		req.add_header('Referer', referer)
		resp = urllib2.urlopen(req)
		http = b2s(resp.read())
		resp.close()
		return http
	except:
		return ''

def GET(url, Referer = ''):
	print (url)
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	try:    response = urllib2.urlopen(req)
	except: response = urllib2.urlopen(req, context=ctx)
	link=b2s(response.read())
	response.close()
	return link


# ============================== функции запросов к сайту и их парсингу ====================================

def get_tracks(hp): # Ищет строки с треками и парсит из них ссылку, автора и название трека
	L1=find_all(hp, '<div class="song-item">', '/div></a></div></div></div>')
	L=[]
	for i in L1:
		#print (i)
		info={
		'artist':		mfind(i,'adv_artist">','<'),
		'title':		mfind(i,'adv_name">','<'),
		'url':			httpurl+mfind(i,'<a data-url="','"'),
		'type':			'track'
		}
		print (info)
		L.append(info)
		
	return L


def get_list(cat): # Составляет запрос к каталогам сайту и загружает стриницу
	url=httpurl+'/'+cat+'/'
	hp=rt(GET(url))
	L = get_tracks(hp)
	return L


def serch(s):# Составляет поисковый запрос к сайту и загружает стриницу
	url=httpurl+'/?do=search&subaction=search&story='+quote(s)
	hp=rt(GET(url))
	L = get_tracks(hp)
	return L
	

#serch('машина')
#time.sleep(10)
