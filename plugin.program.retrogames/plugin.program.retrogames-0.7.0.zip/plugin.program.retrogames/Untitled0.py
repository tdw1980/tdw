'https://api.cloudconvert.com/conversiontypeinfo?inputformat=7z&outputformat=zip'
'https://api.cloudconvert.com/conversiontypeinfo?inputformat=7z&outputformat=zip&mode=convert'
'https://api.cloudconvert.com/process' post '{"inputformat":null,"outputformat":null,"mode":"check"}'
   '{"url":"\/\/host123d1qw.cloudconvert.com\/process\/p1XztMLNRGWxs4cQJ0om","id":"p1XztMLNRGWxs4cQJ0om","host":"host123d1qw.cloudconvert.com","expires":"2017-09-21 18:35:27","maxsize":100,"maxtime":540,"concurrent":2,"minutes":9}'

'https://host123d1qs.cloudconvert.com/process/yh9kMESPBAuVNHe1nXJ3' post '{"mode":"check","input":"url","file":"http://emu-russia.net/ru/dl_roms/nes/18164a2363aa3aeab806d443788d6515/Bigfoot.7z"}'
   '{"id":"yh9kMESPBAuVNHe1nXJ3","url":"//host123d1qs.cloudconvert.com/process/yh9kMESPBAuVNHe1nXJ3","expire":1506006742,"percent":0,"message":"Preparing process","step":"input","starttime":1506006262,"output":{"url":"//host123d1qs.cloudconvert.com/download/~4shPxTKIRx49LqVtrpxpqQI6mQ4"},"input":{"type":"url"}}'
