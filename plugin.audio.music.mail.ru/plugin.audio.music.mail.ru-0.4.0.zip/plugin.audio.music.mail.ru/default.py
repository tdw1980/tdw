#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,urllib2,re,sys,os,random
import xbmcplugin,xbmcgui,xbmcaddon
import time
import mmusic
from tagger import *

addon = xbmcaddon.Addon(id='plugin.audio.music.mail.ru')
pluginhandle = int(sys.argv[1])
thumb = os.path.join( addon.getAddonInfo('path'), 'icon.png')
xbmcplugin.setContent(int(sys.argv[1]), 'songs')
__settings__ = xbmcaddon.Addon(id='plugin.audio.music.mail.ru')

httpurl='https://my.mail.ru'

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)
def rt(x):
	L=[('&#39;','’'), ('&#145;','‘'), ('&#146;','’'), ('&#147;','“'), ('&#148;','”'), ('&#149;','•'), ('&#150;','–'), ('&#151;','—'), ('&#152;','?'), ('&#153;','™'), ('&#154;','s'), ('&#155;','›'), ('&#156;','?'), ('&#157;',''), ('&#158;','z'), ('&#159;','Y'), ('&#160;',''), ('&#161;','?'), ('&#162;','?'), ('&#163;','?'), ('&#164;','¤'), ('&#165;','?'), ('&#166;','¦'), ('&#167;','§'), ('&#168;','?'), ('&#169;','©'), ('&#170;','?'), ('&#171;','«'), ('&#172;','¬'), ('&#173;',''), ('&#174;','®'), ('&#175;','?'), ('&#176;','°'), ('&#177;','±'), ('&#178;','?'), ('&#179;','?'), ('&#180;','?'), ('&#181;','µ'), ('&#182;','¶'), ('&#183;','·'), ('&#184;','?'), ('&#185;','?'), ('&#186;','?'), ('&#187;','»'), ('&#188;','?'), ('&#189;','?'), ('&#190;','?'), ('&#191;','?'), ('&#192;','A'), ('&#193;','A'), ('&#194;','A'), ('&#195;','A'), ('&#196;','A'), ('&#197;','A'), ('&#198;','?'), ('&#199;','C'), ('&#200;','E'), ('&#201;','E'), ('&#202;','E'), ('&#203;','E'), ('&#204;','I'), ('&#205;','I'), ('&#206;','I'), ('&#207;','I'), ('&#208;','?'), ('&#209;','N'), ('&#210;','O'), ('&#211;','O'), ('&#212;','O'), ('&#213;','O'), ('&#214;','O'), ('&#215;','?'), ('&#216;','O'), ('&#217;','U'), ('&#218;','U'), ('&#219;','U'), ('&#220;','U'), ('&#221;','Y'), ('&#222;','?'), ('&#223;','?'), ('&#224;','a'), ('&#225;','a'), ('&#226;','a'), ('&#227;','a'), ('&#228;','a'), ('&#229;','a'), ('&#230;','?'), ('&#231;','c'), ('&#232;','e'), ('&#233;','e'), ('&#234;','e'), ('&#235;','e'), ('&#236;','i'), ('&#237;','i'), ('&#238;','i'), ('&#239;','i'), ('&#240;','?'), ('&#241;','n'), ('&#242;','o'), ('&#243;','o'), ('&#244;','o'), ('&#245;','o'), ('&#246;','o'), ('&#247;','?'), ('&#248;','o'), ('&#249;','u'), ('&#250;','u'), ('&#251;','u'), ('&#252;','u'), ('&#253;','y'), ('&#254;','?'), ('&#255;','y'), ('&amp;','&')]
	for i in L:
		x=x.replace(i[0], i[1])
	return x

AZ=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
az=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
AR=['А','Б','В','Г','Д','Е','Ж','З','И','Й','К','Л','М','Н','О','П','Р','С','Т','У','Ф','Х','Ц','Ч','Ш','Щ','Ъ','Ы','Ь','Э','Ю','Я']
ar=['а','б','в','г','д','е','ж','з','и','й','к','л','м','н','о','п','р','с','т','у','ф','х','ц','ч','ш','щ','ъ','ы','ь','э','ю','я']


def retag(pt, info={}):
	#print "-=-=-= retag -=-=-=-=-"
	import mutagen
	from mutagen.mp3 import MP3
	from mutagen.id3 import ID3
	from mutagen.easyid3 import EasyID3

	try: ID3(pt).delete(delete_v1=True, delete_v2=False)
	except: pass

	mp3_tag = ID3v2(pt)
	title_frame = mp3_tag.new_frame('TIT2')
	title_frame.set_text(ru(info["title"].replace("? ","х ")))
	try:
		old_title_frame = [frame for frame in mp3_tag.frames if frame.fid == 'TIT2'][0]
		mp3_tag.frames.remove(old_title_frame)
	except: pass
	mp3_tag.frames.append(title_frame)
	
	a_frame = mp3_tag.new_frame('TPE1')
	a_frame.set_text(ru(info["artist"].replace("? ","х ")))
	try:
		old_a_frame = [frame for frame in mp3_tag.frames if frame.fid == 'TPE1'][0]
		mp3_tag.frames.remove(old_a_frame)
	except: pass
	mp3_tag.frames.append(a_frame)

	al_frame = mp3_tag.new_frame('TALB')
	al_frame.set_text(ru(info["album"].replace("? ","х ")))
	try:
		old_al_frame = [frame for frame in mp3_tag.frames if frame.fid == 'TALB'][0]
		mp3_tag.frames.remove(old_al_frame)
	except: pass
	mp3_tag.frames.append(al_frame)
	mp3_tag.commit()



def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "wb")
	fl.write(s)
	fl.close()

def inputbox():
	skbd = xbmc.Keyboard()
	skbd.setHeading('Поиск:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return ""

def showMessage(heading, message, times = 3000):
	heading = heading.encode('utf-8')
	message = message.encode('utf-8')
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, thumb))

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def GET(url, Referer = ''):
	if Referer == '': Referer = httpurl
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link
#============================================================================


def Root():
		AddItem("[COLOR F0E0E067][B][ Поиск ][/B][/COLOR]", "serch")
		AddItem("[COLOR F0E0E067][B][ Жанры ][/B][/COLOR]", "genres")
		#AddItem("[COLOR F0E0E067][B][ Исполнители ][/B][/COLOR]", "artists")
		AddItem("[COLOR F0E0E067][B][ Новинки ][/B][/COLOR]", "hits")
		xbmcplugin.endOfDirectory(pluginhandle)


def AddItem(title = "", mode = "", info={}, purl="", total=100):
			folder=False
			
			try:    img=info['cover']
			except: img=thumb
			
			try:tracknumber=info['tracknumber']
			except:tracknumber=''
			
			try:year=info['year']
			except:year=''
			
			try:stitle=info['title']
			except:stitle=''
			#	try:#info['album']
			#	except:stitle=title
			
			try:artist=info['artist']
			except:artist=''
			
			try:album=info['album']
			except:album=''
			
			try:genre=info['genre']
			except:genre=''
			
			
			try:ArtistID=info['ArtistID']
			except:ArtistID=''
			
			try:AlbumID=info['AlbumID']
			except:AlbumID=''
			
			try:GenreID=info['GenreID']
			except:GenreID=''
			
			try:SongID=info['SongID']
			except:SongID=''
			
			try:dict={'title':stitle, 'artist':artist, 'album':album, 'genre':genre, 'year':year, 'tracknumber':tracknumber}
			except:dict={}
			
			item = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
			item.setInfo(type="Music", infoLabels=dict)
			
			context=[]
			if AlbumID!='':
				uri=sys.argv[0] + '?mode=album&id='+AlbumID
				context.append(('[COLOR F050F050] Альбом [/COLOR]', 'Container.Update("'+uri+'")'))
				
			
			if ArtistID!='':
				uri=sys.argv[0] + '?mode=artist&id='+ArtistID
				uri2=sys.argv[0] + '?mode=similar_artist&id='+ArtistID
				context.append(('[COLOR F050F050] Исполнитель [/COLOR]', 'Container.Update("'+uri+'")'))
				context.append(('[COLOR F050F050] Похожие Исполнители [/COLOR]', 'Container.Update("'+uri2+'")'))
				
			if mode=='play':
				uri=sys.argv[0] + '?mode=save&info='+urllib.quote_plus(repr(info))
				context.append(('[COLOR F050F050] Сохранить трек [/COLOR]', 'Container.Update("'+uri+'")'))
				
			if AlbumID!='':
				uri=sys.argv[0] + '?mode=saveall&id='+AlbumID
				context.append(('[COLOR F050F050] Сохранить альбом [/COLOR]', 'Container.Update("'+uri+'")'))
			
			if purl=="":
				purl = sys.argv[0] + '?mode='+mode
				purl = purl+'&info='+urllib.quote_plus(repr(info))
				if mode=='opengenre': purl = purl+'&id='+GenreID
				if mode=='album':     purl = purl+'&id='+AlbumID
				if mode=='artist':    purl = purl+'&id='+ArtistID
				folder=True
			else:
				item.setProperty('IsPlayable', 'true')
				
			item.addContextMenuItems(context)
			xbmcplugin.addDirectoryItem(pluginhandle, purl, item, folder, total)


def Album(AlbumID):
	L = mmusic.get_album_tracks(AlbumID)
	for info in L:
			title = info['title']
			url   = info['url']
			artist= info['artist']
			AddItem(TR+artist+" - [B]"+title+"[/B]", "play", info, url, len(L))
	xbmcplugin.endOfDirectory(pluginhandle)

def Artist(ArtistID):#ok
	L=mmusic.get_albums(ArtistID)
	L2=mmusic.get_artist_top_music(ArtistID)
	L.extend(L2)
	
	for a in L:
		try:
			album=a['album']
			album['AlbumID']=album['id']
			AddItem("[B][COLOR FF55FF55]"+album['title']+"[/COLOR][/B]  [COLOR 66FFFFFF]("+str(album['year'])+")[/COLOR]", "album", album)#AL+
		except: pass
			
		for t in a['tracks']:
				AddItem(TR+"  "+t['title'], "play", t, t['url'])#artist
	xbmcplugin.endOfDirectory(pluginhandle)

def Similar_Artist(ArtistID):
	try:L=mmusic.get_similar_artists(ArtistID)
	except: L=[]
	for info in L:
		title=info['title']
		artist=info['artist']
		AddItem (title, 'artist', info)
	xbmcplugin.addSortMethod(pluginhandle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(pluginhandle)

def Serch(t=''):#ok
		if t=='': t=inputbox()
		Lst=mmusic.serch(t)
		uri=sys.argv[0] + '?mode=serch2&Lst='+urllib.quote_plus(repr(Lst))
		xbmc.executebuiltin('Container.Update("'+uri+'")')
		#xbmcplugin.endOfDirectory(pluginhandle)

def Serch2(L):#ok
	for info in L:
		if info['type']=='artist':
			AddItem ("[B][COLOR FFFFFFFF]"+info['title']+"[/COLOR][/B]", 'artist', info)
		else:
			title = 	info['title']
			artist = 	info['artist']
			url = 		info['url']
			AddItem(TR+artist+" - [B]"+title+"[/B]", "play", info, url, len(L))
	xbmcplugin.endOfDirectory(pluginhandle)
	#xbmc.sleep(300)
	#xbmc.executebuiltin("Container.SetViewMode(506)")
	#postinfo(Lid)


def Artists_off():
	xbmcplugin.setContent(int(sys.argv[1]), 'artists')
	xbmcplugin.setContent(int(sys.argv[1]), 'albums')
	for p in range(1,11):#2,3
		url=httpurl+'/Artist/Page'+str(p)
		http=GET(url)
		L=mfindal(http,'<tr>','</tr>')
		for i in L:
			if '/Artist/' in i: 
				title = rt(i[i.find('<img alt="')+10:i.find('" style="')])
				cover = i[i.find('src=')+5:i.find('.jpg')+4]
				tID = i[i.find('Artist/')+7:i.find('</a>')]
				ArtistID = tID[:tID.find('">')]
				info={"cover":cover, "ArtistID":ArtistID, 'artist':title}
				AddItem (title, 'artist', info)
				#Artist(ArtistID)
	xbmcplugin.addSortMethod(pluginhandle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(pluginhandle)


def Genres():#ok
	g=mmusic.genres
	L=g.keys()
	L.sort()
	for k in L:
		GenreID=g[k].replace(' ', '%20')
		AddItem(k, 'opengenre', {'GenreID':GenreID})
	xbmcplugin.endOfDirectory(pluginhandle)

def OpenGenre(GenreID):#ok
	xbmcplugin.setContent(int(sys.argv[1]), 'artists')
	xbmcplugin.setContent(int(sys.argv[1]), 'albums')
	L=mmusic.get_artists(GenreID)
	for info in L:
		title=info['title']
		artist=info['artist']
		AddItem (title, 'artist', info)
	xbmcplugin.addSortMethod(pluginhandle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(pluginhandle)

def Hits():
	Album('22583916704')


def SaveAlbum(AlbumID):
	xbmcplugin.endOfDirectory(pluginhandle, False, False)
	L = mmusic.get_album_tracks(AlbumID)
	for info in L:
			uri=sys.argv[0] + '?mode=save&info='+urllib.quote_plus(repr(info))
			xbmc.executebuiltin('Container.Update("'+uri+'")')
			xbmc.sleep(2000)
	xbmc.sleep(30000)
	xbmc.executebuiltin('UpdateLibrary("music")')


def Save(dict, update=False):
	xbmcplugin.endOfDirectory(pluginhandle, False, False)
	target	=dict["url"]
	artist	=dict["artist"]
	title	=dict["title"]
	img		=dict["cover"]
	album	=dict["album"]
	
	try:
		pDialog = xbmcgui.DialogProgressBG()
		pDialog.create('Сохранение:', artist+" - "+title)
	except: pass
	
	
	Dldir = __settings__.getSetting("DownloadDirectory")
	if Dldir == "":Dldir = os.path.join( addon.getAddonInfo('path'), "mp3" )
	
	fp = os.path.join(ru(Dldir), ru(artist.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"")))
	fp = os.path.join(fp, ru(album.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"")))
	if os.path.exists(fp)== False: os.makedirs(fp)
	cp=os.path.join(fp, "cover.jpg")
	fp = os.path.join(fp, ru(title.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"")+".mp3"))
	try:
	#if 1==1:
			req = urllib2.Request(url = target, data = None)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			fl = open(fp, "wb")
			fl.write(resp.read())
			fl.close()
			if os.path.exists(cp)== False and img !="":
				req = urllib2.Request(url = img, data = None)
				req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
				resp = urllib2.urlopen(req)
				fl = open(cp, "wb")
				fl.write(resp.read())
				fl.close()
			
			if __settings__.getSetting("Retag") == 'true': retag(fp, dict)
			#print "Update"
			try:pDialog.close()
			except: pass
			
			if update: 
				xbmc.sleep(3000)
				xbmc.executebuiltin('UpdateLibrary("music")')
			return fp
	except Exception, e:
			try:pDialog.close()
			except: pass
			print 'HTTP ERROR ' + str(e)
			return target


# -------------------------------------------------------------------

params = get_params()
url  =	'https://my.mail.ru'
mode =	None
name =	''
img =	' '
info =	{}
Lst=[]
id = ''
AL="[COLOR 663333DD][B][ A ][/B][/COLOR] "
TR=''#"[COLOR F055FF55][B][ T ][/B][/COLOR] "

try: id = urllib.unquote_plus(params["id"])
except: pass
try: url = urllib.unquote_plus(params["url"])
except: pass
try: mode = urllib.unquote_plus(params["mode"])
except: pass
try: name = urllib.unquote_plus(params["name"])
except: pass
try: img = urllib.unquote_plus(params["img"])
except: pass
try: info = eval(urllib.unquote_plus(params["info"]))
except: pass
try: Lst = eval(urllib.unquote_plus(params["Lst"]))
except: pass



if   mode == None:				Root()
elif mode == 'serch':			Serch()
elif mode == 'serch2':			Serch2(Lst)
elif mode == 'genres':			Genres()
elif mode == 'artists':			Artists()
elif mode == 'opengenre':		OpenGenre(id)
elif mode == 'album':			Album(id)
elif mode == 'artist':			
							try: Artist(id)
							except: Serch(id)
elif mode == 'similar_artist':	Similar_Artist(id)
elif mode == 'save':			Save(info)
elif mode == 'saveall':			SaveAlbum(id)
elif mode == 'hits':			Hits()
#elif mode == 'decade':		Decade()
#elif mode == 'decade2':		Decade2(Lst)

xbmc.sleep(300)
xbmc.executebuiltin("Container.SetViewMode(506)")

