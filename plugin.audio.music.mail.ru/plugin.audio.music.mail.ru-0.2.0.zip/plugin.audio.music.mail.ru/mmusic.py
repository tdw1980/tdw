# -*- coding: utf-8 -*-
import sys, os, time
import urllib, urllib2
import uscode
temp_dir = "d:\\"
print '-=-=- mmm -=-=-'

genres={
	'80s':'80s',
	'Alternative rock':'alternative rock',
	'Alternative':'alternative',
	'Alternative':'alternative',
	'Australian':'australian',
	'Austrian':'austrian',
	'Belarusian':'belarusian',
	'Blues':'blues',
	'British':'british',
	'Cabaret':'cabaret',
	'Catalan':'catalan',
	'Chanson':'chanson',
	'Dark cabaret':'dark cabaret',
	'Discorock':'discorock',
	'Dubstep':'dubstep',
	'Electronic':'electronic',
	'Experimental':'experimental',
	'Folk punk':'folk punk',
	'Folk rock':'folk rock',
	'Folk':'folk',
	'French':'french',
	'Funk':'funk',
	'Fusion':'fusion',
	'German':'german',
	'Gypsy':'gypsy',
	'Hiphop':'hiphop',
	'House':'house',
	'Indie':'indie',
	'Italian':'italian',
	'Jamaica':'jamaica',
	'Japanese':'japanese',
	'Jazz':'jazz',
	'Jazz':'jazz',
	'J-ska':'j-ska',
	'Latin':'latin',
	'Lofi':'lofi',
	'Metal':'metal',
	'New wave':'new wave',
	'Oi':'oi',
	'Polish':'polish',
	'Pop punk':'pop punk',
	'Pop rock':'pop rock',
	'Pop':'pop',
	'Pop':'pop',
	'Post-punk':'post-punk',
	'Punk rock':'punk rock',
	'Punk':'punk',
	'Punk':'punk',
	'Rap':'rap',
	'Reggae':'reggae',
	'Rock':'rock',
	'Rock':'rock',
	'Rocksteady':'rocksteady',
	'Romantic':'romantic',
	'Roots reggae':'roots reggae',
	'Russian rock':'russian rock',
	'Russian ska':'russian ska',
	'Russian':'russian',
	'Ska punk':'ska punk',
	'Ska rock':'ska rock',
	'Ska':'ska',
	'Ska-jazz':'ska-jazz',
	'Slovak':'slovak',
	'Soul':'soul',
	'Spanish':'spanish',
	'Swedish':'swedish',
	'Trance':'trance',
	'Trap':'trap',
	'Turkish':'turkish',
	'Ukrainian':'ukrainian',
	'Аудиокнига':'audiobook',
	'Детская':'kinder',
	'Диско':'disco',
	'Инструментальная':'instrumental',
	'Классика':'classic',
	'Лёгкая музыка':'easy listening',
	'Ностальгия':'nostalgy',
	'Праздничная':'holiday',
	'Путешествие':'trip-hop',
	'Релакс':'relax',
	'Романтика':'oldies',
	'Саундтрек':'soundtrack',
	'Шансон':'chanson',
}


def ru(x):return unicode(x,'utf8', 'ignore')

def POST(target, post=None, referer='https://my.mail.ru/music'):
	#print target
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36 OPR/46.0.2597.39')
		req.add_header('Accept', 'application/json, text/javascript, */*; q=0.01')
		req.add_header('Accept-Language', 'ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4')
		req.add_header('Referer', referer)
		req.add_header('x-requested-with', 'XMLHttpRequest')
		req.add_header('X-Secret-Key', '%D9%A2%D0%A9%D2%DF%DB%E2%9C%A4%E0p%D6%9F%EC%CA%99%EE%C8%DD%97%DA')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		print e
		return ''

def getURL(url,Referer = 'https://my.mail.ru/music'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	link=uscode.decode(link)
	return link

def GETjson(url,Referer = 'https://my.mail.ru/music'):
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36 OPR/46.0.2597.39')
		#req.add_header('Accept', 'application/xml, application/xhtml+xml, ')
		req.add_header('Accept', 'application/json, text/javascript, */*; q=0.01')
		req.add_header('Accept-Language', 'ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4')
		req.add_header('Referer', Referer)
		req.add_header('x-requested-with', 'XMLHttpRequest')
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		link=uscode.decode(link)
		return link

def find_all(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)+len(ss)
		http=http[s:]
		e=http.find(es)
		i=http[:e]
		L.append(i)
		http=http[e+1:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def save_inf(s):
	p = os.path.join(ru(temp_dir),"temp.txt")
	f = open(p, "w")
	f.write(s)
	f.close()
	return p


def get_tracks(hp):
	L=find_all(hp, '{"file":', '}')
	LL=[]
	n=0
	for i in L:
		if 'userTrackId' in i:
			n+=1
			d=eval('{"file":'+i+'}')
			info={
			'tracknumber' : n,
			'duration':		d["durationInSeconds"],
			'artist':		d["author"],
			'title':		d["name"],
			'cover':		d["albumCoverURL"],
			'url':			'https:'+d["url"],
			'type':			'track'
			}
			LL.append(info)
			#print str(n)+': '+d["name"].decode('utf-8')
			#print info
	return LL

def get_album_tracks(id):
	#id='34356037529'
	url='https://my.mail.ru/cgi-bin/my/ajax?ajax_call=1&func_name=music.playlist&arg_ref_user=&arg_limit=100&arg_ret_json=1&arg_offset=0&arg_playlist_id='+id
	print url
	null=''
	true=True
	false=False
	json=eval(GETjson(url).replace('\\"',"“"))[3]#["Data"][0]#["Collection"]
	try:year=json["Collection"]["AlbumYear"]
	except:year=''
	try:genre=json["Collection"]["TagList"][0]["TagName"]
	except:genre=''
	print json["Data"][0].keys()
	L=[]
	for i in json["Data"]:
		#print i["HasText"]
		#print i["File"].decode('utf-8')
		info={
		'tracknumber' : i["OrderNum"],
		'duration':		i["DurationInSeconds"],
		'year':			year,
		'genre':		genre,
		'album':		i["Album"],
		'artist':		i["Author"],
		'title':		i["Name"],
		'cover':		i["AlbumCoverURL"],
		'url':			'https:'+i["URL"],
		'type':			'track'
		}
		L.append(info)
	return L

def get_albums_old(artist_id):
	artist_id=artist_id.replace(' ', '%20')
	url='https://my.mail.ru/music/artists/'+artist_id+'/albums'
	print url
	hp=getURL(url)
	L=find_all(hp, '<div class="b-music__album-header">', '<script class="list-options" type="text/plain">')
	La=[]
	for i in L:
		alb={}
		r=mfind(i,'{"Added":','}')
		album=eval('{"Added":'+r+'}')
		#print '=================================='
		#print album["Name"].decode('utf-8')
		#print '=================================='
		#print album
		tracks=get_tracks(i)
		a_info={
		'title':		album["Name"],
		'artist':		tracks[0]["artist"],
		'cover':		album["CoverURLRaw"],
		'id':			album["ID"],
		'url':			'https://my.mail.ru/music/albums/'+album["URLID"],
		'year':			album["CreateTime"],
		'type':			'album'
		}
		alb['album']=a_info
		#print a_info
		
		trk=[]
		for t in tracks:
			t['album']=album["Name"]
			t['year']=album["CreateTime"]
			trk.append(t)
		alb['tracks']=trk
		La.append(alb)
	return La

def get_albums(artist_id):
	artist_id=artist_id.replace(' ', '%20')
	url='https://my.mail.ru/cgi-bin/my/ajax?ajax_call=1&func_name=music.artist_albums&arg_offset=0&arg_limit=20&arg_name='+artist_id
	null=''
	true=True
	false=False
	json=eval(GETjson(url).replace('\\"',"“"))[3]#["Data"][0]#["Collection"]
	artist=json["Artist"]["Name"]
	try:genre=json["Artist"]["TagList"][0]["TagName"]
	except:genre=''
	
	La=[]
	for album in json["Data"]:
		alb={}
		try:album_cover=album["CoverURLRaw"]
		except:
			try:album_cover=album['AlbumTracks'][0]["AlbumCoverURL"]
			except:album_cover=''
		try:album_year=album["AlbumYear"]
		except:album_year=''
		a_info={
		'title':		album["Name"],
		'artist':		artist,
		'genre':		genre,
		'cover':		album_cover,
		'id':			album["ID"],
		'url':			'https://my.mail.ru/music/albums/'+album["AlbumURLID"],
		'year':			album_year,
		'type':			'album'
		}
		alb['album']=a_info
		tracks=album['AlbumTracks']
		
		trk=[]
		for t in tracks:
			t_info={
			'tracknumber' : t["OrderNum"],
			'duration':		t["Duration"],
			'year':			album["AlbumYear"],
			'genre':		genre,
			'album':		t["Album"],
			'artist':		t["Author"],
			'title':		t["Name"],
			'cover':		t["AlbumCoverURL"],
			'url':			'https:'+t["URL"],
			'type':			'track'
			}
			trk.append(t_info)
		alb['tracks']=trk
		La.append(alb)
	return La




def get_artists(tag):
	null=''
	url='https://my.mail.ru/+/music/tag/'+tag+'/artists/?limit=300&offset=0&ajax_call=1'
	print url
	L=eval(getURL(url))["data"]
	L2=[]
	for i in L:
		#print i
		info={
			'title': i["name"],
			'artist':i["name"],
			'cover': i["urls"]["avatar180"],
			'ArtistID': i["url"].replace(' ', '%20')
			}
		L2.append(info)
	return L2


def get_genres():
	null=''
	true=True
	false=False
	genres={}
	Lg=[]
	url='https://my.mail.ru/music/genre/ska/artists?ajax_call=1&func_name='#&mna=1149978229&mnb=3760101813&_=1510908339017
	#url='https://my.mail.ru/music?ajax_call=1&func_name='
	#save_inf(GETjson(url).replace('\\"',"“"))
	
	json=eval(GETjson(url).replace('\\"',"“"))
	for a in json["artists"]:
		for t in a["tags"]:
			if t["title"] not in Lg:
				Lg.append(t["title"])
				#print "{'"+t["title"].decode('utf-8')+"':'"+t["url"]+"'},"
				genres[t["title"]]=t["title"]
	
	for i in json["tags"]:
		print "{'"+i["title"].decode('utf-8')+"':'"+i["url"]+"'},"

def get_catalogue():
	url='https://my.mail.ru/cgi-bin/my/ajax?ajax_call=1&func_name=music.catalogue&arg_tags=&arg_limit=50&arg_ret_json=1&arg_offset=0'#&mna=1959249162&mnb=3939620678
	null=''
	json=eval(GETjson(url).replace('\\"',"“"))[3]
	for i in json["Data"]:
		print i
	
def serch(s):
	url='https://my.mail.ru/cgi-bin/my/ajax?ajax_call=1&func_name=music.search&arg_search_params=%7B%22music%22%3A%7B%22limit%22%3A100%7D%2C%22playlist%22%3A%7B%22limit%22%3A20%7D%2C%22album%22%3A%7B%22limit%22%3A10%7D%2C%22artist%22%3A%7B%22limit%22%3A10%7D%7D&arg_extended=1&arg_offset=0&arg_limit=100&arg_query='+s.replace(' ', '%20')
	
	null=''
	#Lk=['MusicData', 'ArtistData', 'AlbumData', 'PlaylistData']# 'Results'
	json=eval(GETjson(url).replace('\\"',"“"))[3]#["PlaylistData"]
	
	try:artist=json["ArtistData"]
	except: 
		time.sleep(1)
		json=eval(GETjson(url).replace('\\"',"“"))[3]
	'''
	for k in Lk:
		print k
		d=json[k][0]
		for c in d.keys():
			print ' -- '+c+" : "+str(d[c]).decode('utf-8')
	artists=[]
	'''
	L=[]
	for a in json["ArtistData"]:
		info={
		'artist' : 	a["Name"],
		'title' : 	a["Name"],
		'cover' : 	a["RawAvatar180URL"],
		'ArtistID':	a["AuthorURL_Text_HTML"].replace(' ', '%20'),
		'plot' : 	a["ShortDescription_Text_HTML"],
		'type' :	'artist'
		}
		print info
		L.append(info)
	
	for a in json["MusicData"]:
		print a
		info={
		'artist' : 	a["Author"],
		'title' : 	a["Name"],
		'duration' : a["DurationInSeconds"],
		'album' : 	a["Album"],
		'url' : 	'https:'+a["URL"],
		'cover' : 	a["AlbumCoverURL"],
		'ArtistID': a["Author_Text_HTML"].replace(' ', '%20'),
		'type':		'track'
		}
		print info
		L.append(info)
	
	return L

def preserch(s):
	url='https://my.mail.ru/cgi-bin/my/ajax?func_name=perl_musearch_suggest'
	post='&ajax_call=1&data=%5B%22guns+n%E2%80%99+roses%22%5D'
	print POST(url, post, 'https://my.mail.ru/music/search/guns%20n%E2%80%99%20roses')


#url='https://my.mail.ru/music/artists/Ария/albums'
#url='https://my.mail.ru/+/music/tag/russian/artists/?limit=150&offset=0&ajax_call=1'
#hp=getURL(url)
#save_inf(hp)
#get_tracks(hp)
#get_albums('Ария')
#get_artists('russian')
#serch('морчиба')
#get_catalogue()
#get_genres()
#get_album_tracks('34356037529')
#time.sleep(105)
