#!/usr/bin/python
# -*- coding: utf-8 -*-

# *  Copyright (C) 2016 TDW

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, urllib, urllib2, time, codecs, httplib

PLUGIN_NAME   = 'World-Art.ru'
siteUrl = 'www.world-art.ru'
httpSiteUrl = 'http://' + siteUrl
handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.world-art.ru')
__settings__ = xbmcaddon.Addon(id='plugin.video.world-art.ru')
xbmcplugin.setContent(int(sys.argv[1]), 'movies')

icon  = os.path.join( addon.getAddonInfo('path'), 'icon.png')
dbDir = addon.getAddonInfo('path')
LstDir = addon.getAddonInfo('path')


#======================== стандартные функции ==========================
def fs_enc(path):
	sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
	return path.decode('utf-8').encode(sys_enc)

def fs_dec(path):
	sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
	return path.decode(sys_enc).encode('utf-8')
	
def uw(s):return s.decode('utf-8').encode('windows-1251')
def fs(s):return s.decode('windows-1251').encode('utf-8')
def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)
def rt(x):#('&#39;','’'), ('&#145;','‘')&#40;
	import uscode
	x=uscode.decode(x)
	L=[('&amp;',"&"),('&#133;','…'),('&#58;',':'),('&#40;','('),('&#41;',')'),('&#43;','+'),('&#44;',','),('&#45;','-'),('&#46;','.'),('&#47;','/'),('&#27;','’'),('&#38;','&'),('&#34;','"'),('&#33;','!'), ('&#39;','"'), ('&#145;','"'), ('&#146;','"'), ('&#147;','“'), ('&#148;','”'), ('&#149;','•'), ('&#150;','–'), ('&#151;','—'), ('&#152;','?'), ('&#153;','™'), ('&#154;','s'), ('&#155;','›'), ('&#156;','?'), ('&#157;',''), ('&#158;','z'), ('&#159;','Y'), ('&#160;',''), ('&#161;','?'), ('&#162;','?'), ('&#163;','?'), ('&#164;','¤'), ('&#165;','?'), ('&#166;','¦'), ('&#167;','§'), ('&#168;','?'), ('&#169;','©'), ('&#170;','?'), ('&#171;','«'), ('&#172;','¬'), ('&#173;',''), ('&#174;','®'), ('&#175;','?'), ('&#176;','°'), ('&#177;','±'), ('&#178;','?'), ('&#179;','?'), ('&#180;','?'), ('&#181;','µ'), ('&#182;','¶'), ('&#183;','·'), ('&#184;','?'), ('&#185;','?'), ('&#186;','?'), ('&#187;','»'), ('&#188;','?'), ('&#189;','?'), ('&#190;','?'), ('&#191;','?'), ('&#192;','A'), ('&#193;','A'), ('&#194;','A'), ('&#195;','A'), ('&#196;','A'), ('&#197;','A'), ('&#198;','?'), ('&#199;','C'), ('&#200;','E'), ('&#201;','E'), ('&#202;','E'), ('&#203;','E'), ('&#204;','I'), ('&#205;','I'), ('&#206;','I'), ('&#207;','I'), ('&#208;','?'), ('&#209;','N'), ('&#210;','O'), ('&#211;','O'), ('&#212;','O'), ('&#213;','O'), ('&#214;','O'), ('&#215;','?'), ('&#216;','O'), ('&#217;','U'), ('&#218;','U'), ('&#219;','U'), ('&#220;','U'), ('&#221;','Y'), ('&#222;','?'), ('&#223;','?'), ('&#224;','a'), ('&#225;','a'), ('&#226;','a'), ('&#227;','a'), ('&#228;','a'), ('&#229;','a'), ('&#230;','?'), ('&#231;','c'), ('&#232;','e'), ('&#233;','e'), ('&#234;','e'), ('&#235;','e'), ('&#236;','i'), ('&#237;','i'), ('&#238;','i'), ('&#239;','i'), ('&#240;','?'), ('&#241;','n'), ('&#242;','o'), ('&#243;','o'), ('&#244;','o'), ('&#245;','o'), ('&#246;','o'), ('&#247;','?'), ('&#248;','o'), ('&#249;','u'), ('&#250;','u'), ('&#251;','u'), ('&#252;','u'), ('&#253;','y'), ('&#254;','?'), ('&#255;','y'), ('&laquo;','"'), ('&raquo;','"'), ('&nbsp;',' ')]
	for i in L:
		x=x.replace(i[0], i[1])
	return x

def lower(s):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.lower().encode('utf-8')
	return s

def mid(s, n):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.center(n)
	try:s=s.encode('utf-8')
	except: pass
	return s

def mids(s, n):
	l="                                              "
	s=l[:n-len(s)]+s+l[:n-len(s)]
	return s

def FC(s, color="FFFFFF00"):
	s="[COLOR "+color+"]"+s+"[/COLOR]"
	return s

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	if s in t:
		r=t[t.find(s)+len(s):]
		r2=r[:r.find(e)]
		return r2
	else:
		return ''

def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "wb")
	fl.write(s)
	fl.close()

def deb_print(s):
	if __settings__.getSetting("DebMod")=='true': print s

def inputbox():
	skbd = xbmc.Keyboard()
	skbd.setHeading('Поиск:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return ""

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

#====================== подготовка данных для интерфейса ================




#============================== основная часть ============================

def save_strm(url, ind=0, id='0'):
		info=get_info(str(id))
		SaveDirectory = __settings__.getSetting("SaveDirectory")
		if SaveDirectory=="":SaveDirectory=LstDir
		originaltitle=get_orig_title(id)
		name = originaltitle.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"")+" ("+str(info['year'])+")"
		
		uri = sys.argv[0] + '?mode=PlayTorrent'
		uri = uri+ '&url='+urllib.quote_plus(url)
		uri = uri+ '&ind='+str(ind)
		uri = uri+ '&id='+str(id)
		
		fl = open(os.path.join(fs_enc(SaveDirectory),fs_enc(name+".strm")), "w")
		fl.write(uri)
		fl.close()
		
		xbmc.executebuiltin('UpdateLibrary("video", "", "false")')

def save_film_nfo(id):
		#get_posters(id)
		info=get_info(str(id))
		title=info['title']
		fanart=info['fanart']
		cover=info['cover']
		#try: fanarts=info["fanarts"]
		#except: 
		fanarts=[fanart,cover]
		#posters=get_posters(id)
		#fanarts.extend(posters)
		
		year=info['year']
		plot=info['plot']
		rating=info['rating']
		#originaltitle=info['originaltitle']
		originaltitle=get_orig_title(id)
		#duration=info["duration"]
		genre=info["genre"].replace(', ', '</genre><genre>')
		studio=info["studio"]
		#director=info["director"]
		cast=info["cast"]
		#try: actors=info["actors"]
		#except: 
		actors={}
		
		name = originaltitle.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"")+" ("+str(info['year'])+")"
		cn=name.find(" (")
		#if cn>0:
		#	name=name[:cn]
		#	rus=1
		#else: rus=0
		
		#trailer=get_trailer(id)
		
		SaveDirectory = __settings__.getSetting("SaveDirectory")
		if SaveDirectory=="":SaveDirectory=LstDir
		
		nfo='<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>'+chr(10)
		nfo+='<movie>'+chr(10)
		
		nfo+="	<title>"+title+"</title>"+chr(10)
		nfo+="	<originaltitle>"+originaltitle+"</originaltitle>"+chr(10)
		nfo+="	<genre>"+genre+"</genre>"+chr(10)
		nfo+="	<studio>"+studio+"</studio>"+chr(10)#nfo+="	<director>"+director+"</director>"+chr(10)
		nfo+="	<year>"+str(year)+"</year>"+chr(10)
		nfo+="	<plot>"+plot+"</plot>"+chr(10)
		nfo+='	<rating>'+str(rating)+'</rating>'+chr(10)#nfo+='	<runtime>'+duration+' min.</runtime>'+chr(10)
		
		nfo+="	<fanart>"+chr(10)
		for fan in fanarts:
			nfo+="		<thumb>"+fan+"</thumb>"+chr(10)
		nfo+="		<thumb>"+cover+"</thumb>"+chr(10)
		nfo+="	</fanart>"+chr(10)
		
		nfo+="	<thumb>"+cover+"</thumb>"+chr(10)
		
		for actor in cast:
			nfo+="	<actor>"+chr(10)
			nfo+="		<name>"+actor+"</name>"+chr(10)
			#try:
			#	aid=actors[actor]
			#	actor_img="http://st.kp.yandex.net/images/actor_iphone/iphone360_"+aid+".jpg"
			#	nfo+="		<thumb>"+actor_img+"</thumb>"+chr(10)
			#except: pass
			nfo+="	</actor>"+chr(10)
		
		nfo+="</movie>"+chr(10)
		
		fl = open(os.path.join(fs_enc(SaveDirectory),fs_enc(name+".nfo")), "w")
		fl.write(nfo)
		fl.close()

def get_orig_title(id):
	url='http://www.world-art.ru/cinema/cinema.php?id='+id
	
	hp=fs(rt(GET(url)))
	title=mfind(hp, "<b>Названия</b></td><td width=15></td><td class='review' Valign=top>", '/').replace("<","").strip()
	if '------------' in title: title=""
	return title


def play(url, ind=0, id='0'):
	#print url
	if 'magnet' in url: play_t2h (url, ind, __settings__.getSetting("DownloadDirectory"))
	else:
		engine=__settings__.getSetting("Engine")
		if engine=="0": 
			if play_ace (url, ind) != 'Ok':
				if ind == 0: 
					if play_ace (alter (id, url), 0) != 'Ok': xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.world-art.ru/?mode=Torrents&id='+id+'", return)')
				else: xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.world-art.ru/?mode=Torrents&id='+id+'", return)')
		if engine=="1": play_t2h (url, ind, __settings__.getSetting("DownloadDirectory"))
		if engine=="2": play_yatp(url, ind)
		if engine=="3": play_torrenter(url, ind)

def play_ace(torr_link, ind=0):
	try:
		title=get_item_name(torr_link, ind)
		from TSCore import TSengine as tsengine
		TSplayer=tsengine()
		out=TSplayer.load_torrent(torr_link,'TORRENT')
		#print out
		if out=='Ok': TSplayer.play_url_ind(int(ind),title, icon, icon, True)
		TSplayer.end()
		return out
	except: 
		return '0'

def play_t2h(uri, file_id=0, DDir=""):
	try:
		sys.path.append(os.path.join(xbmc.translatePath("special://home/"),"addons","script.module.torrent2http","lib"))
		from torrent2http import State, Engine, MediaType
		progressBar = xbmcgui.DialogProgress()
		from contextlib import closing
		if DDir=="": DDir=os.path.join(xbmc.translatePath("special://home/"),"userdata")
		progressBar.create('Torrent2Http', 'Запуск')
		# XBMC addon handle
		# handle = ...
		# Playable list item
		# listitem = ...
		# We can know file_id of needed video file on this step, if no, we'll try to detect one.
		# file_id = None
		# Flag will set to True when engine is ready to resolve URL to XBMC
		ready = False
		# Set pre-buffer size to 15Mb. This is a size of file that need to be downloaded before we resolve URL to XMBC 
		pre_buffer_bytes = 15*1024*1024
		
		engine = Engine(uri, download_path=DDir, enable_dht=True, dht_routers=["router.bittorrent.com:6881","router.utorrent.com:6881"], user_agent = 'uTorrent/2200(24683)')
		with closing(engine):
			# Start engine and instruct torrent2http to begin download first file, 
			# so it can start searching and connecting to peers  
			engine.start(file_id)
			progressBar.update(0, 'Torrent2Http', 'Загрузка торрента', "")
			while not xbmc.abortRequested and not ready:
				xbmc.sleep(500)
				status = engine.status()
				# Check if there is loading torrent error and raise exception 
				engine.check_torrent_error(status)
				# Trying to detect file_id
				if file_id is None:
					# Get torrent files list, filtered by video file type only
					files = engine.list(media_types=[MediaType.VIDEO])
					# If torrent metadata is not loaded yet then continue
					if files is None:
						continue
					# Torrent has no video files
					if not files:
						break
						progressBar.close()
					# Select first matching file                    
					file_id = files[0].index
					file_status = files[0]
				else:
					# If we've got file_id already, get file status
					file_status = engine.file_status(file_id)
					# If torrent metadata is not loaded yet then continue
					if not file_status:
						continue
				if status.state == State.DOWNLOADING:
					# Wait until minimum pre_buffer_bytes downloaded before we resolve URL to XBMC
					if file_status.download >= pre_buffer_bytes:
						ready = True
						break
					#print file_status
					#downloadedSize = status.total_download / 1024 / 1024
					getDownloadRate = status.download_rate / 1024 * 8
					#getUploadRate = status.upload_rate / 1024 * 8
					getSeeds = status.num_seeds
					
					progressBar.update(100*file_status.download/pre_buffer_bytes, xt('Предварительная буферизация: '+str(file_status.download/1024/1024)+" MB"), "Сиды: "+str(getSeeds), "Скорость: "+str(getDownloadRate)[:4]+' Mbit/s')#
					
				elif status.state in [State.FINISHED, State.SEEDING]:
					#progressBar.update(0, 'T2Http', 'We have already downloaded file', "")
					# We have already downloaded file
					ready = True
					break
				
				if progressBar.iscanceled():
					progressBar.update(0)
					progressBar.close()
					break
				# Here you can update pre-buffer progress dialog, for example.
				# Note that State.CHECKING also need waiting until fully finished, so it better to use resume_file option
				# for engine to avoid CHECKING state if possible.
				# ...
			progressBar.update(0)
			progressBar.close()
			if ready:
				# Resolve URL to XBMC
				item = xbmcgui.ListItem(path=file_status.url)
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
				xbmc.sleep(3000)
				xbmc.sleep(3000)
				# Wait until playing finished or abort requested
				while not xbmc.abortRequested and xbmc.Player().isPlaying():
					xbmc.sleep(500)
	except: pass


def play_yatp(url, ind):
	purl ="plugin://plugin.video.yatp/?action=play&torrent="+ urllib.quote_plus(url)+"&file_index="+str(ind)
	item = xbmcgui.ListItem(path=purl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def play_torrenter(url, ind):
	purl ="plugin://plugin.video.torrenter/?action=playSTRM&url="+ urllib.quote_plus(url)+"&file_index="+str(ind)
	item = xbmcgui.ListItem(path=purl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def GET(url,Referer = 'http://www.world-art.ru/'):
	deb_print ('KP GET '+url)
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
		req.add_header('Accept', '*/*')
		req.add_header('Accept-Language', 'ru,en;q=0.9')
		req.add_header('Referer', Referer)
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
	except:
		import requests
		s = requests.session()
		r=s.get(url).text
		rd=r.encode('windows-1251')
		return rd

def GETjson(url,Referer = 'https://world-art.ru'):
		deb_print ('KP GETjson '+url)
		
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36 OPR/46.0.2597.39')
		req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
		req.add_header('Accept-Language', 'ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4')
		req.add_header('Referer', Referer)
		req.add_header('X-Requested-With', 'XMLHttpRequest')
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link

def GET2(url, Referer= 'https://world-art.ru'):
	try:
		import requests
		try:
			s = requests.session()
			r=s.get(url, timeout=(0.5, 3), verify=False).text#0.00001
		except:
			print 'requests: timeout'
			r=''
		#r=r.encode('windows-1251')
		return r
	except:
		return ''

def GETtorr(target):
	try:
			req = urllib2.Request(url = target)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			return resp.read()
	except Exception, e:
			print 'HTTP ERROR ' + str(e)
			return None

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param



import sqlite3 as db
db_name = os.path.join( dbDir, "info.db" )
c = db.connect(database=db_name)
cu = c.cursor()
def add_to_db(n, item):
		deb_print ('KP add_to_db '+n)
		item=item.replace("'","XXCC").replace('"',"XXDD")
		err=0
		tor_id="n"+n
		litm=str(len(item))
		try:
			cu.execute("CREATE TABLE "+tor_id+" (db_item VARCHAR("+litm+"), i VARCHAR(1));")
			c.commit()
			deb_print ('KP add_to_db CREATE TABLE '+tor_id)
		except: 
			err=1
			print "Ошибка БД"+ n
		if err==0:
			cu.execute('INSERT INTO '+tor_id+' (db_item, i) VALUES ("'+item+'", "1");')
			c.commit()
			deb_print ('KP add_to_db INSERT INTO '+tor_id)
			#c.close()

def get_inf_db(n):
		deb_print ('KP get_inf_db '+n)
		tor_id="n"+n
		cu.execute(str('SELECT db_item FROM '+tor_id+';'))
		c.commit()
		deb_print ('KP get_inf_db SELECT '+tor_id)
		Linfo = cu.fetchall()
		info=Linfo[0][0].replace("XXCC","'").replace("XXDD",'"')
		deb_print ('KP get_inf_db return_info OK')
		return info

def rem_inf_db(n):
		deb_print ('KP rem_inf_db '+n)
		tor_id="n"+n
		try:
			cu.execute("DROP TABLE "+tor_id+";")
			c.commit()
			deb_print ('KP rem_inf_db DROP TABLE '+n)
		except: pass

def get_labels(info):
	Linf=['genre', 'year', 'rating', 'cast', 'director', 'plot', 'title', 'originaltitle', 'studio']
	Labels={}
	for inf in Linf:
		try:Labels[inf] = info[inf]
		except: pass
	try:Labels['duration'] = str(int(info['duration'])*60)
	except: pass
	return Labels


def AddItem(Title = "", mode = "", id='0', url='', total=50):
			if id=='0': info={'cover': icon}
			else: 		info=get_info(id)
			
			if Title == "": 
					try: Title = info['title']
					except: Title = id
			
			cover=info['cover']
			listitem = xbmcgui.ListItem(Title, iconImage=cover, thumbnailImage=cover)
			listitem.setInfo(type = "Video", infoLabels = info)
			#try: listitem.setArt({ 'poster': cover, 'fanart' : fanart, 'thumb': cover, 'icon': cover})
			#except: pass
			try:listitem.setProperty('fanart_image', info['fanart'])
			except: pass
			
			purl = sys.argv[0] + '?mode='+mode+'&id='+id
			if url !="": purl = purl +'&url='+urllib.quote_plus(url)
			
			if mode=="OpenTorrent":
				try:type=info["type"]
				except:type='1'
				if type != '1': listitem.addContextMenuItems([('[B]Сохранить сериал[/B]', 'Container.Update("plugin://plugin.video.torrent.checker/?mode=save_episodes_api&url='+urllib.quote_plus(url)+'&name='+urllib.quote_plus(info['originaltitle'])+ '&info=' + urllib.quote_plus(repr(info))+'")'),])
				else: listitem.addContextMenuItems([('[B]Сохранить фильм(STRM)[/B]', 'Container.Update("plugin://plugin.video.world-art.ru/?mode=Save_strm&id='+id+'&url='+urllib.quote_plus(url)+'")'),])

			#xbmcplugin.addDirectoryItem(handle, purl, listitem, True, total)
			try:type=info["type"]
			except:type=''
			if __settings__.getSetting("Autoplay") == 'true' and mode=="Torrents" and type=="1":
				listitem.setProperty('IsPlayable', 'true')
				purl = sys.argv[0] + '?mode=Autoplay&id='+id
				xbmcplugin.addDirectoryItem(handle, purl, listitem, False, total)
			else:
				xbmcplugin.addDirectoryItem(handle, purl, listitem, True, total)


def update_info(id):
	rem_inf_db(id)
	xbmc.executebuiltin('Container.Refresh')


def get_info(ID):
	
	try:
			#if __settings__.getSetting('UpdLib')=='true': rem_inf_db(ID)
			info=eval(xt(get_inf_db(ID)))
			deb_print ('KP get_info ОК')
			return info
	except:
			if __settings__.getSetting("LocalMod")=='true': return {"title": ID, "originaltitle":ID, "rating":0, "cover":icon, "type":'', "id":ID}
			info = get_info_wa(ID)
			
			try:
				add_to_db(ID, repr(info))
				#print "ADD: " + FilmID
			except:
				print "ERR: " + ID
				#print repr(info)
			deb_print ('KP return info')
			return info

def get_info_wa(id):
	print '=-=-=-=-=-=-=-=-=-'
	url='http://www.world-art.ru/cinema/cinema.php?id='+id
	print url
	
	hp=fs(rt(GET(url)))
	title=mfind(hp,'<font size=5>','</font>')
	print title
	
	originaltitle=mfind(hp, "<b>Названия</b></td><td width=15></td><td class='review' Valign=top>", '/').replace("<","").strip()
	if '------------' in originaltitle: originaltitle=title
	
	tmp=mfind(hp,'<b>Жанр</b>','Valign=top>')
	Lg=mfindal(tmp, "class='review'>", '</a>')
	genre = ''
	for g in Lg:
		if 2<len(g)<30: genre += g.replace("class='review'>","")+", "
	genre = genre[:-2]
	print genre
	
	if "<p align=justify" in hp:
		plot=mfind(hp,"<p align=justify class='review'>", "</p></td></tr>")
		if '</' in plot: plot=plot[:plot.find('</')]
	else:
		plot=''
	print plot
	
	if 'нет постера' in hp:
		cover=''
		fanart=''
	else:
		cover_id=mfind(hp,"<img src='img/","/")
		cover='http://www.world-art.ru/cinema/img/'+cover_id+'/'+id+'/1.jpg'
		fanart='http://www.world-art.ru/cinema/img/'+cover_id+'/'+id+'/2.jpg'
	print cover
	
	if "<b>Первый показ</b>" in hp:
		year=mfind(hp,"<b>Первый показ</b></td><td width=15></td><td class='review'>", ".")
	else:
		year=""
	print year
	
	try: year=int(year)
	except: year=0
	
	country=mfind(hp,"public_online=2&sort=2' class='review'>", "</a>")
	print country
	type=mfind(hp,"cinema/list.php?public_type=","&sort")
	print type
	
	tmp=mfind(hp, "<b>В ролях</b>","cinema_full_cast.php")
	Lc=mfindal(tmp,"' class='review'>","</a>,")
	cast=[]
	for c in Lc:
		if "class='" in c: c=c[c.find("class='")+7:]
		if 2<len(c)<100: cast.append(c.replace("' class='review'>",""))
	print cast
	
	try: rating=float(mfind(hp, "<b>Средний балл</b></td><td width=15></td><td class='review'>", "&nbsp;"))
	except: rating=0
	print rating
	
	info = {"title": title,
			"originaltitle": originaltitle,
			"year": year,
			"genre": genre,
			"studio": country,
			"cast": cast,
			"rating": rating,
			"cover": cover,
			"fanart": fanart,
			"plot": plot,
			"type": type,
			"id": id
			}
	return info


#==============  Menu  ====================
def Root():
	try:L=eval(__settings__.getSetting("W_list"))
	except: L=[]
	AddItem("Поиск", "Search")
	AddItem("Навигатор", "Navigator")
	AddItem("Популярные", "Popular")
	AddItem("Новые", "New")
	#AddItem("Самые ожидаемые", "Future")
	AddItem("Списки", "TopLists")
	#AddItem("Персоны", "PersonList")
	#if len(L)>0: AddItem("Буду смотреть", "Wish_list")
	#if __settings__.getSetting("DebMod")=='true': AddItem("Проверить список", "check")
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

def get_option(s):
	L1=[]
	L2=[]
	s=s.replace('<OPTION','<option')
	for i in mfindal(s,'<option','</'):
		if 'value=' in i:
			v=mfind(i,"value='","'>")
			o=i[i.find("'>")+2:]
		else:
			v=i[i.find(">")+1:]
			o=v
		if o!='':
			L1.append(o)
			L2.append(v)
	return [L1, L2]


def set_menu():
	hp=fs(GET('http://www.world-art.ru/cinema/list.php?public_action=1'))
	
	type=mfind(hp,"NAME='public_type'","NAME='lit'")
	lit=mfind(hp,"NAME='lit'","NAME='public_year'")
	year=mfind(hp,"NAME='public_year'","NAME='public_country'")
	country=mfind(hp,"NAME='public_country'","NAME='status'")
	status=mfind(hp,"NAME='status'","NAME='public_genre'")
	genre=mfind(hp,"NAME='public_genre'","NAME='public_keyword'")
	keyword=mfind(hp,"NAME='public_keyword'","NAME='sort'")
	sort=mfind(hp,"NAME='sort'","</SELECT>")
	
	Ltype=get_option(type)
	Llit=get_option(lit)
	Lyear=get_option(year)
	Lcountry=get_option(country)
	Lstatus=get_option(status)
	Lgenre=get_option(genre)
	Lkeyword=get_option(keyword)
	Lsort=get_option(sort)
	
	add_to_db('type', repr(Ltype))
	add_to_db('lit', repr(Llit))
	add_to_db('year', repr(Lyear))
	add_to_db('country', repr(Lcountry))
	add_to_db('status', repr(Lstatus))
	add_to_db('genre', repr(Lgenre))
	add_to_db('keyword', repr(Lkeyword))
	add_to_db('sort', repr(Lsort))

try:
	Ltype=eval(get_inf_db('type'))
	Llit=eval(get_inf_db('lit'))
	Lyear=eval(get_inf_db('year'))
	Lcountry=eval(get_inf_db('country'))
	Lstatus=eval(get_inf_db('status'))
	Lgenre=eval(get_inf_db('genre'))
	Lkeyword=eval(get_inf_db('keyword'))
	Lsort=eval(get_inf_db('sort'))
except:
	set_menu()
	
	Ltype=eval(get_inf_db('type'))
	Llit=eval(get_inf_db('lit'))
	Lyear=eval(get_inf_db('year'))
	Lcountry=eval(get_inf_db('country'))
	Lstatus=eval(get_inf_db('status'))
	Lgenre=eval(get_inf_db('genre'))
	Lkeyword=eval(get_inf_db('keyword'))
	Lsort=eval(get_inf_db('sort'))

def Navigator():
	AddItem("Тип: "+__settings__.getSetting("type_t"), "SetType")
	AddItem("Алфавит: "+__settings__.getSetting("lit_t"), "SetABC")
	AddItem("Год: "+__settings__.getSetting("year_t"), "SetYear")
	AddItem("Страна: "+__settings__.getSetting("country_t"), "SetCountry")
	AddItem("Статус: "+__settings__.getSetting("status_t"), "SetStatus")
	AddItem("Жанр: "+__settings__.getSetting("genre_t"), "SetGenre")
	AddItem("Теги: "+__settings__.getSetting("keyword_t"), "SetKeyword")
	AddItem("Сортировка: "+__settings__.getSetting("sort_t"), "SetSort")
	AddItem("[B][ ИСКАТЬ ][/B]", "RunNavigator")


def Navigate(md, nst='0'):
	if nst==None: nst='0'
	try:	ns=int(nst)
	except: ns=0
	if ns>0: limit='&limit_1='+str(ns*50)
	else:	 limit=''
	
	if md=='Popular':url='http://www.world-art.ru/cinema/list.php?public_type=1&lit=&public_year=&public_country=&status=1&public_genre=&public_keyword=&sort=1'+limit
	if md=='New'    :url='http://www.world-art.ru/cinema/list.php?public_type=1&lit=&public_year=&public_country=&status=1&public_genre=&public_keyword=&sort=3'+limit
	if 'http://' in md: url=md
	
	ss='<table cellpadding=0 cellspacing=0 width=100%>'
	es='</tr></table><br><br>'

	
	ht=fs(rt(GET(url)))
	L=mfindal(ht, ss, es)
	print L[1]
	
	for i in L:
			print '-==-=-=-=-=-=-=-=-'
			if ', сериал)' in i: 
				type='2'
				i=i.replace(', сериал)',')')
			else:
				type='1'
			
			title=mfind(i, 'h3 style=undeground:none>', "</a> <font size=3")
			print title
			print type
			
			id=mfind(i, 'php?id=', "'")
			print id
			
			if 'нет постера' in i:
				cover=''
				fanart=''
			else:
				cover_id=mfind(i, 'converted_images_', "/optimize")
				cover_num=mfind(i, 'optimize_a/'+id+'-', "-optimize_a")
				cover='http://www.world-art.ru/cinema/img/'+cover_id+'/'+id+'/'+cover_num+'.jpg'
				fanart='http://www.world-art.ru/cinema/img/'+cover_id+'/'+id+'/2.jpg'
			print cover
			
			year=mfind(i, '<font size=3>(', " г.)</font>")
			try: year=int(year)
			except: year=0
			print year
			
			
			if '<font size=14>' in i:
				rating=float(mfind(i, '<font size=14><b>', "</b></font></a>"))
			else:
				rating=0
			print rating
			
			genre=mfind(i, 'Жанры: ', "<br>")
			print genre
			
			if 'описания ещё нет' in i: plot=''
			else: 
				plot=mfind(i, "</font></label><div class='hide'>", "</div><br><br><")
				if '<br><br><a href' in plot: plot=plot[:plot.find('<br><br><a href')]
			print plot
			
			country=mfind(i, 'Производство: ', "<br>")
			print country
			
			tmp=mfind(i, "class='review'>", "cinema_full_cast")
			Lc=mfindal(tmp,"review'>","</a>")
			cast=[]
			for c in Lc:
				if 1<len(c)<100: 
					if 'font color' not in c: cast.append(c.replace("review'>",''))
			#"director": du(director),
			
			info = {"title": title,
					"originaltitle": '',
					"year": year,
					"genre": genre,
					"studio": country,
					"cast": cast,
					"rating": rating,
					"cover": cover,
					"fanart": fanart,
					"plot": plot,
					"type": type,
					"id": id
					}
			
			try:
					add_to_db(id, repr(info))
			except:
					print "ERR: " + id
			
			if title!='': 
				if __settings__.getSetting("Rating")=='true': 
					if rating>0:r='[ '+str(rating)+' ] '
					else:r='[  - -  ] '
				else: r=''
				if __settings__.getSetting("TypeVid")=='true': 
					if type=='2': tv='[COLOR 55FFFFFF] (сериал)[/COLOR]'
					else: tv=''
				else:
					tv=''
				AddItem(r+'[B]'+title+'[/B]'+tv, "Torrents", id)
	if 'http://' not in md: AddItem("ЕЩЕ >", md, url=str(ns+1))
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

def Search():
	t=inputbox()
	url='http://www.world-art.ru/search.php?global_sector=all&public_search='+urllib.quote_plus(uw(t))
	#url='http://www.world-art.ru/search.php?public_search=%F2%E5%F0%EC%E8%ED%E0%F2%EE%F0&global_sector=all'
	print url
	hp=fs(rt(GET(url)))
	L=mfindal(hp,"<tr><td Valign=top width=40 align=center>","</table><br></td></tr>")
	for i in L:
		id=mfind(i,"php?id=","'>")
		if id!="": AddItem('', "Torrents", id)
	
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

def get_top_list():
	url='http://www.world-art.ru/cinema/list.php?public_action=1'
	hp=fs(rt(GET(url)))
	L=mfindal(hp,"<a href='http", ")</td><")
	LL=[]
	for i in L:
		t=mfind(i,"review'>","</a>")
		u=mfind(i,"<a href='","' class=")
		if 'анимация' in t: 
			t='анимация'
			u='http://www.world-art.ru/cinema/list.php?public_genre=22'
		LL.append([u,t])
	return LL

def TopLists():
	for i in get_top_list():
		url=i[0]
		title=i[1]
		AddItem(title, "OpenTopList", url=url)

def Torrents(id, additm=True):
	offlist=[]
	if __settings__.getSetting("Serv1")=='false': offlist.append('rutor')
	if __settings__.getSetting("Serv2")=='false': offlist.append('fasttor')
	if __settings__.getSetting("Serv3")=='false': offlist.append('freebfg')
	if __settings__.getSetting("Serv5")=='false':  offlist.append('fileek')
	if __settings__.getSetting("Serv6")=='false':  offlist.append('hdreactor')
	if __settings__.getSetting("Serv7")=='false':  offlist.append('picktorrent')
	if __settings__.getSetting("Serv8")=='false':  offlist.append('torrentby')
	if __settings__.getSetting("Serv9")=='false':  offlist.append('megapeer')
	if __settings__.getSetting("Serv10")=='false': offlist.append('krasfs')
	if __settings__.getSetting("Serv11")=='false': offlist.append('findmagnet')
	offlist.append('torrentino')

	info=get_info(id)
	sys.path.append(os.path.join(addon.getAddonInfo('path'),"src"))
	ld=os.listdir(os.path.join(addon.getAddonInfo('path'),"src"))
	L2=[]
	Lz=[]
	for i in ld:
		off = True
		for sr in offlist:
			if sr in i: off = False
		if i[-3:]=='.py' and off: 
			exec ("import "+i[:-3]+"; skp="+i[:-3]+".Tracker()")
			try:
				exec ("import "+i[:-3]+"; skp="+i[:-3]+".Tracker()")
				L = skp.Search(info)
			except: L=[]
			for D in L:
				url = D['url']
				try:    tor_title=D['title'].encode('utf-8').replace("«",'').replace("»",'').replace('"', '')
				except: tor_title=D['title'].replace("«",'').replace("»",'').replace('"', '')
				deb_print (lower(tor_title))
				ru_title=xt(info['title']).replace("«",'').replace("»",'').replace('"', '')
				deb_print (lower(ru_title))
				en_title=info['originaltitle'].replace("«",'').replace("»",'').replace('"', '')
				year=str(info['year'])
				year2=str(int(info['year'])+1)
				
				if (lower(ru_title) in lower(tor_title) or ru_title in tor_title) and (year in tor_title or year2 in tor_title or info['type']!='1'):
					deb_print ('Название соответствует')
					size = D['size']
					if 'MB' in size and '.' in size: size=size[:size.find('.')]
					size = size.replace('GB','').replace('MB','').strip()
					if size not in Lz or __settings__.getSetting("CutSize") == 'false':
						Lz.append(size)
						Z=D['size']
						if 'GB' in Z and Z.find('.') == 2: Z=Z[:3]+Z[4:]
						title=xt(mid(Z, 10))+" | "+xt(mids(D['sids'], 6))+" | "+xt(D['title'])
						title=get_label(xt(D['title']))+" "+title
						if additm:
							if __settings__.getSetting("SortLst") == 'true' and info['type']=='1':
								pr=fnd(D)
								#ratio=str(get_rang(D))+" "
								if pr: title=FC(title, 'FEFFFFFF')
								else:  title=FC(title.replace("[COLOR F", "[COLOR 7"), 'FF777777')
							AddItem(title, "OpenTorrent", id, url)
						L2.append(D)
				#print D
	return L2
def get_label(text):
	text=lower(text)#.lower()
	#print text
	if 'трейлер'  in text: return FC('[ Трейл.]',    'FF999999')
	if ' кпк'     in text: return FC('[   КПК  ]',   'FFF8888F')
	if 'telesyn'  in text: return FC('[    TS    ]', 'FFFF2222')
	if 'telecin'  in text: return FC('[    TS    ]', 'FFFF2222')
	if 'camrip'   in text: return FC('[    TS    ]', 'FFFF2222')
	if ' ts'      in text: return FC('[    TS    ]', 'FFFF2222')
	if 'dvdscr'   in text: return FC('[    Scr   ]', 'FFFF2222')
	if ' 3d'      in text: return FC('[    3D    ]', 'FC45FF45')
	if '720'      in text: return FC('[  720p  ]',   'FBFFFF55')
	if '1080'     in text: return FC('[ 1080p ]',    'FAFF9535')
	if 'blu-ray'  in text: return FC('[  BRay  ]',   'FF5555FF')
	if 'bdremux'  in text: return FC('[    BD    ]', 'FF5555FF')
	if ' 4k'      in text: return FC('[    4K    ]', 'FF5555FF')
	if 'bdrip'    in text: return FC('[ BDRip ]',    'FE98FF98')
	if 'drip'     in text: return FC('[ BDRip ]',    'FE98FF98')
	if 'hdrip'    in text: return FC('[ HDRip ]',    'FE98FF98')
	if 'webrip'   in text: return FC('[  WEB   ]',   'FEFF88FF')
	if 'WEB'      in text: return FC('[  WEB   ]',   'FEFF88FF')
	if 'web-dl'   in text: return FC('[  WEB   ]',   'FEFF88FF')
	if 'hdtv'     in text: return FC('[ HDTV ]',     'FEFFFF88')
	if 'tvrip'    in text: return FC('[    TV    ]', 'FEFFFF88')
	if 'satrip'   in text: return FC('[    TV    ]', 'FEFFFF88')
	if 'dvb '     in text: return FC('[    TV    ]', 'FEFFFF88')
	if 'dvdrip'   in text: return FC('[DVDRip]',     'FE88FFFF')
	if 'dvd5'     in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'xdvd'     in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'dvd-5'    in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'dvd-9'    in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'dvd9'     in text: return FC('[  DVD   ]',   'FE88FFFF')
	return FC('[   ????  ]', 'FFFFFFFF')

def OpenTorrent(url, id):
	#print url
	if 'magnet' in url: 
		OpenMagnet(url, id)
		return
	
	torrent_data = GETtorr(url)
	if torrent_data != None:
		import bencode
		torrent = bencode.bdecode(torrent_data)
		cover = get_info(id)['cover']
		try:
			L = torrent['info']['files']
			ind=0
			for i in L:
				name=ru(i['path'][-1])
				#size=i['length']
				listitem = xbmcgui.ListItem(name, iconImage=cover, thumbnailImage=cover)
				listitem.setProperty('IsPlayable', 'true')
				uri = sys.argv[0]+'?mode=PlayTorrent2&id='+id+'&ind='+str(ind)+'&url='+urllib.quote_plus(url)
				xbmcplugin.addDirectoryItem(handle, uri, listitem)
				ind+=1
		except:
				ind=0
				name=torrent['info']['name']
				listitem = xbmcgui.ListItem(name, iconImage=cover, thumbnailImage=cover)
				listitem.setProperty('IsPlayable', 'true')
				listitem.addContextMenuItems([('[B]Сохранить фильм(STRM)[/B]', 'Container.Update("plugin://plugin.video.world-art.ru/?mode=Save_strm&id='+id+'&url='+urllib.quote_plus(url)+'")'),])
				uri =sys.argv[0]+'?mode=PlayTorrent2&id='+id+'&ind='+str(ind)+'&url='+urllib.quote_plus(url)
				xbmcplugin.addDirectoryItem(handle, uri, listitem)


def OpenMagnet(url, id):
			cover = icon
			L=list_magnet(url)
			if L==None: return
			ind=0
			for i in L:
				name=i[0]
				listitem = xbmcgui.ListItem(name, iconImage=cover, thumbnailImage=cover)
				listitem.setProperty('IsPlayable', 'true')
				#listitem.addContextMenuItems([('[B]Сохранить фильм(STRM)[/B]', 'Container.Update("plugin://plugin.video.KinoPoisk.ru/?mode=Save_strm&id='+id+'&url='+urllib.quote_plus(url)+'")'),])
				uri =sys.argv[0]+'?mode=PlayTorrent2&id='+id+'&ind='+str(ind)+'&url='+urllib.quote_plus(url)
				xbmcplugin.addDirectoryItem(handle, uri, listitem)
				ind+=1

def list_magnet(uri):
	from contextlib import closing
	sys.path.append(os.path.join(xbmc.translatePath("special://home/"),"addons","script.module.torrent2http","lib"))
	# Create instance of Engine 
	from torrent2http import State, Engine, MediaType
	engine = Engine(uri)
	files = []
	# Ensure we'll close engine on exception 
	progressBar = xbmcgui.DialogProgress()
	progressBar.create('Torrent2Http', 'Запуск')
	with closing(engine):
	# Start engine 
		engine.start()
		# Wait until files received 
		while not files and not xbmc.abortRequested:
			progressBar.update(0, 'Torrent2Http', 'Примагничиваемся', "")
			
			# Will list only video files in torrent
			files = engine.list(media_types=[MediaType.VIDEO])
			# Check if there is loading torrent error and raise exception 
			engine.check_torrent_error()
			xbmc.sleep(200)
			if progressBar.iscanceled():
						progressBar.update(0)
						progressBar.close()
						return []
			
	progressBar.close()
	return files

def get_item_name(url, ind):
	torrent_data = GETtorr(url)
	if torrent_data != None:
		import bencode
		torrent = bencode.bdecode(torrent_data)
		try:
			L = torrent['info']['files']
			name=L[ind]['path'][-1]
		except:
			name=torrent['info']['name']
		return name
	else:
		return ' '

def check():
	deb_print ("check")
	SaveDirectory = __settings__.getSetting("SaveDirectory")
	if SaveDirectory=="":SaveDirectory=LstDir
	
	try:L=eval(__settings__.getSetting("W_list"))
	except: L=[]
	for id in L:
		info=get_info(id)
		year=info["year"]
		name = info['originaltitle'].replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"")+" ("+str(info['year'])+")"
		if os.path.isfile(os.path.join(fs_enc(SaveDirectory),fs_enc(name+".strm")))==False:
			L=Torrents(id, False)
			url=''
			rang=0
			for i in L:
				if fnd(i):
					rang_i=get_rang(i)
					if rang_i>rang:
						rang=rang_i
						deb_print (str(rang)+": "+i['title']+" "+i['size'])
						deb_print (i['url'])
						url=i['url']
			
			if url != "":
					if __settings__.getSetting("NFO2")=='true': save_film_nfo(id)
					save_strm (url, 0, id)
		else:
			if __settings__.getSetting("AREM")=='true': # автоудаление из желаний
					try:Lt=eval(__settings__.getSetting("W_list"))
					except: Lt=[]
					Lt.remove(id)
					__settings__.setSetting("W_list", repr(Lt))


def alter(id, url=''):
		SaveDirectory = __settings__.getSetting("SaveDirectory")
		if SaveDirectory=="":SaveDirectory=LstDir
		info=get_info(id)
		year=info["year"]
		name = info['originaltitle'].replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"")+" ("+str(info['year'])+")"
		L=Torrents(id, False)
		try:W_list=eval(__settings__.getSetting("W_list"))
		except: W_list=[]
		for i in L:
			newurl=i['url'].replace('new-ru.org','').replace('open-tor.org','')
			oldurl=url.replace('new-ru.org','').replace('open-tor.org','')
			if fnd(i) and newurl!=oldurl:
				if id in W_list:
					if __settings__.getSetting("NFO2")=='true': save_film_nfo(id)
					save_strm (i['url'], 0, id)
				return i['url']

def autoplay(id):
		L=Torrents(id, False)
		url=''
		for i in L:
			if fnd(i): 
				url=i['url']
				break
		if url !='': play(url,0,id)
		else: 
			if len(L)== 0: showMessage("World-Art", "Фильм не найден")
			else: showMessage("World-Art", "Нет нужного качества")

def review(id):
	url='https://m.kinopoisk.ru/reviews/'+id
	url='https://www.kinopoisk.ru/rss/comment-'+id+'.rss'
	http=GET(url)
	#debug(http)
	ss='<item>'
	es='</item>'
	L=mfindal(http,ss,es)
	#debug(L[0])
	Lt=[]
	Lu=[]
	for i in L:
		#if "hand_good.gif" in i: rating = FC('+', 'FF33FF33')
		#elif "hand_bad.gif" in i: rating = FC(' - ', 'FFFF3333')
		#else: rating = FC(' - ', '01003333')
		rating =''
		
		ss='<pubDate>'
		es='</pubDate>'
		date=mfindal(i,ss,es)[0][len(ss):]
		
		ss='&lt;i&gt;'
		es='&lt;/i&gt;&lt;'
		try:head=mfindal(i,ss,es)[0][len(ss):]
		except: head=''
		
		ss='<guid>'
		es='</guid>'
		url=mfindal(i,ss,es)[0][len(ss):]
		if head!='':
			Lt.append(rt(fs(head)))
			Lu.append(url)
	sel = xbmcgui.Dialog()
	r = sel.select("Рецензии:", Lt)
	if r >=0:
		http2=GET(Lu[r])
		#debug (http2)
		n=http2.find('itemprop="reviewBody">')
		k=http2.find('</span></p>')
		text=http2[n+22:k].replace('<b>','').replace('</b>','').replace('<i>','').replace('</i>','').replace('<p>','').replace('</p>','').replace('<br>','').replace('<br />','').replace('&nbsp;',' ')
		text=rt(fs(text))
		heading=Lt[r]
		showText(heading, text)

def showText(heading, text):
	id = 10147
	xbmc.executebuiltin('ActivateWindow(%d)' % id)
	xbmc.sleep(500)
	win = xbmcgui.Window(id)
	retry = 50
	while (retry > 0):
		try:
			xbmc.sleep(10)
			retry -= 1
			win.getControl(1).setLabel(heading)
			win.getControl(5).setText(text)
			return
		except:
			pass

def fnd(D):
	BL=['Трейлер', "Тизер", 'трейлер', "тизер", 'ТРЕЙЛЕР', "ТИЗЕР"]
	if __settings__.getSetting("F_Qual") != "0":BL.extend([' TS','TeleSyn','TeleCin','TELECIN',' CAM',' CamRip','screen','Screen', 'звук из кинотеатра'])
	WL=[]
	if __settings__.getSetting("F_Qual1") == 'true': WL.append("dvdrip")
	if __settings__.getSetting("F_Qual2") == 'true': WL.append("webrip")
	if __settings__.getSetting("F_Qual3") == 'true': WL.append("web-dl")
	if __settings__.getSetting("F_Qual4") == 'true': WL.append("bdrip")
	if __settings__.getSetting("F_Qual5") == 'true': WL.append("hdrip")
	if __settings__.getSetting("F_Qual6") == 'true': WL.append("tvrip")
	if __settings__.getSetting("F_Qual7") == 'true': WL.append("hdtv")
	if __settings__.getSetting("F_Qual8") == 'true': WL.append("blu-ray")
	if __settings__.getSetting("F_Qual9") == 'true': WL.append("720p")
	if __settings__.getSetting("F_Qual10")== 'true': WL.append("1080p")
	if __settings__.getSetting("F_Qual") == '0': WL=[]

	size1 = int(__settings__.getSetting("F_Size1"))
	size2 = int(__settings__.getSetting("F_Size2"))
	if size2 == 0: size2 = 999
	
	b=0
	q=0
	z=0
	Title = D['title']
	try:Title=Title+' '+D['quality']
	except:pass
	
	try:Title=Title.encode('utf-8')
	except: Title=xt(Title)
	
	for i in BL:
		if Title.find(i)>0:b+=1
	
	if __settings__.getSetting("F_Qual") == "0":
		q=1
	else:
		for i in WL:
			if Title.lower().find(i)>0:q+=1
		
	if 'ГБ' in xt(D['size']) or 'GB' in xt(D['size']):
			szs=xt(D['size']).replace('ГБ','').replace('GB','').replace('|','').strip()
			sz=float(szs)
			if sz>size1 and sz<size2 : z=1
	else: z=0
	
	#print Title
	#if b <> 0: print 'Попал в Черный список'
	#if q == 0: print 'Низкое Качество'
	#if z == 0: print 'Не тот Размер'
	
	if b == 0 and q > 0 and z > 0:
		#print 'Файл найден'
		return True
	else: 
		return False

def get_rang(D):
	Title = D['title']
	try:Title=Title+' '+D['quality']
	except:pass
	try:Title=Title.encode('utf-8')
	except: Title=xt(Title)
	Title=Title.lower()
	ratio=0
	WL=[]
	if __settings__.getSetting("F_Qual1") == 'true' and "dvdrip"  in Title:   ratio+=40
	if __settings__.getSetting("F_Qual2") == 'true' and "webrip"  in Title:   ratio+=30
	if __settings__.getSetting("F_Qual3") == 'true' and "web-dl"  in Title:   ratio+=30
	if __settings__.getSetting("F_Qual4") == 'true' and "bdrip"   in Title:   ratio+=80
	if __settings__.getSetting("F_Qual5") == 'true' and "hdrip"   in Title:   ratio+=80
	if __settings__.getSetting("F_Qual6") == 'true' and "tvrip"   in Title:   ratio+=20
	if __settings__.getSetting("F_Qual7") == 'true' and "hdtv"    in Title:   ratio+=70
	if __settings__.getSetting("F_Qual8") == 'true' and "blu-ray" in Title:   ratio+=20
	
	if __settings__.getSetting("F_Qual9") == 'true' and '720p'    in Title:   ratio+=1000
	if __settings__.getSetting("F_Qual10")== 'true' and "1080p"   in Title:   ratio+=2000
	
	size1 = int(__settings__.getSetting("F_Size1"))
	size2 = int(__settings__.getSetting("F_Size2"))
	if size2 == 0: size2 = 10
	size=(size2-size1)/2+size1
	
	if 'ГБ' in xt(D['size']) or 'GB' in xt(D['size']):
			szs=xt(D['size']).replace('ГБ','').replace('GB','').replace('|','').strip()
			sz=float(szs)
			#print size
			#print sz
			#print abs(sz-size)
			#print '----'
			if   abs(sz-size)<1 : ratio+=900
			elif abs(sz-size)<2 : ratio+=800
			elif abs(sz-size)<3 : ratio+=700
			elif abs(sz-size)<4 : ratio+=600
			elif abs(sz-size)<5 : ratio+=500
			elif abs(sz-size)<6 : ratio+=400
			elif abs(sz-size)<7 : ratio+=300
			elif abs(sz-size)<8 : ratio+=200
			elif abs(sz-size)<9 : ratio+=100
	
	sids=D['sids']
	if len(sids)==1: ratio+=11
	if len(sids)==2: ratio+=44
	if len(sids)==3: ratio+=66
	if len(sids)==4: ratio+=88
	if len(sids)==5: ratio+=99
	if sids =='0': ratio-=500
	if sids =='1': ratio-=100
	if sids =='2': ratio-=50
	return ratio

def SetViewMode():
	n = int(__settings__.getSetting("ListView"))
	if n>0:
		xbmc.executebuiltin("Container.SetViewMode(0)")
		for i in range(1,n):
			xbmc.executebuiltin("Container.NextViewMode")



try:    mode = urllib.unquote_plus(get_params()["mode"])
except: mode = None
try:    url = urllib.unquote_plus(get_params()["url"])
except: url = None
try:    info = eval(urllib.unquote_plus(get_params()["info"]))
except: info = {}
try:    id = str(get_params()["id"])
except: id = '0'
try:    ind = int(get_params()["ind"])
except: ind = 0


if mode == None:
	__settings__.setSetting("type", '')
	__settings__.setSetting("type_t", '--')
	__settings__.setSetting("lit", '')
	__settings__.setSetting("lit_t", '--')
	__settings__.setSetting("year", '')
	__settings__.setSetting("year_t", '--')
	__settings__.setSetting("country", '')
	__settings__.setSetting("country_t", '--')
	__settings__.setSetting("status", '')
	__settings__.setSetting("status_t", '--')
	__settings__.setSetting("genre", '')
	__settings__.setSetting("genre_t", '--')
	__settings__.setSetting("keyword", '')
	__settings__.setSetting("keyword_t", '--')
	__settings__.setSetting("sort", '1')
	__settings__.setSetting("sort_t", 'по рейтингу')
	
	Root()

if mode == "Search":
	Search()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Navigator":
	Navigator()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Popular":
	Navigate("Popular", url)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "New":
	Navigate("New", url)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Future":
	SrcNavi("Future")
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Recomend":
	SrcNavi("Recomend")
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "PersonFilm":
	SrcNavi("PersonFilm")#+PeID
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Person":
	Person()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "PersonList":
	AddItem("[ Поиск ]", "PersonSearch")
	PersonList()
	xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "PersonSearch": 
	PersonSearch()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "AddPerson": 
	AddPerson(info)

if mode == "RemovePerson": 
	RemovePerson(info)
	xbmc.executebuiltin("Container.Refresh()")
	
if mode == "RunNavigator":
	type =__settings__.getSetting("type")
	lit =__settings__.getSetting("lit")
	year =__settings__.getSetting("year")
	country =__settings__.getSetting("country")
	status =__settings__.getSetting("status")
	genre =__settings__.getSetting("genre")
	keyword =__settings__.getSetting("keyword")
	sort =__settings__.getSetting("sort")

	param='http://www.world-art.ru/cinema/list.php?public_type='+type+'&lit='+lit+'&public_year='+year+'&public_country='+country+'&status='+status+'&public_genre='+genre+'&public_keyword='+keyword+'&sort='+sort
	Navigate(param, url)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "SetType":
	sel = xbmcgui.Dialog()
	r = sel.select("Тип:", Ltype[0])
	__settings__.setSetting(id="type", value=Ltype[1][r])
	__settings__.setSetting(id="type_t", value=Ltype[0][r])

if mode == "SetABC":
	sel = xbmcgui.Dialog()
	r = sel.select("ABC:", Llit[0])
	__settings__.setSetting(id="lit", value=Llit[1][r])
	__settings__.setSetting(id="lit_t", value=Llit[0][r])

if mode == "SetYear":
	sel = xbmcgui.Dialog()
	r = sel.select("Год:", Lyear[0])
	__settings__.setSetting(id="year", value=Lyear[1][r])
	__settings__.setSetting(id="year_t", value=Lyear[0][r])

if mode == "SetCountry":
	sel = xbmcgui.Dialog()
	r = sel.select("Год:", Lcountry[0])
	__settings__.setSetting(id="country", value=Lcountry[1][r])
	__settings__.setSetting(id="country_t", value=Lcountry[0][r])

if mode == "SetStatus":
	sel = xbmcgui.Dialog()
	r = sel.select("Статус:", Lstatus[0])
	__settings__.setSetting(id="status", value=Lstatus[1][r])
	__settings__.setSetting(id="status_t", value=Lstatus[0][r])

if mode == "SetGenre":
	sel = xbmcgui.Dialog()
	r = sel.select("Жанр:", Lgenre[0])
	__settings__.setSetting(id="genre", value=Lgenre[1][r])
	__settings__.setSetting(id="genre_t", value=Lgenre[0][r])

if mode == "SetKeyword":
	sel = xbmcgui.Dialog()
	r = sel.select("Теги:", Lkeyword[0])
	__settings__.setSetting(id="keyword", value=Lkeyword[1][r])
	__settings__.setSetting(id="keyword_t", value=Lkeyword[0][r])

if mode == "SetSort":
	sel = xbmcgui.Dialog()
	r = sel.select("Сортировка:", Lsort[0])
	__settings__.setSetting(id="sort", value=Lsort[1][r])
	__settings__.setSetting(id="sort_t", value=Lsort[0][r])


if mode == "Torrents" or mode == "Torrents2":
	Torrents(id)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(handle)
	xbmc.sleep(300)
	SetViewMode()
	#xbmc.executebuiltin("Container.SetViewMode(51)")

if mode == "OpenTorrent":
	OpenTorrent(url, id)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(handle)


if mode == "PlayTorrent":
	progressBar = xbmcgui.DialogProgress()
	progressBar.create('Кинопоиск', 'Запуск сохраненного файла')
	cancel=False
	for i in range (0,5):
		progressBar.update(20*i, '', '[B]Нажмите "Отмена" для выбора качества[/B]')
		xbmc.sleep(600)
		if progressBar.iscanceled():
					progressBar.update(0)
					cancel=True
					break
	progressBar.close()
	if cancel: 
		xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.world-art.ru/?mode=Torrents&id='+id+'", return)')
		xbmc.executebuiltin("Container.Refresh()")
	else: play(url, ind, id)

if mode == "PlayTorrent2":
	play(url, ind, id)

if mode == "Add2List":
	try:L=eval(__settings__.getSetting("W_list"))
	except: L=[]
	if id not in L:
		L.append(id)
		__settings__.setSetting("W_list", repr(L))

if mode == "RemItem":
	try:L=eval(__settings__.getSetting("W_list"))
	except: L=[]
	L.remove(id)
	__settings__.setSetting("W_list", repr(L))
	xbmc.executebuiltin("Container.Refresh()")

if mode == "Wish_list":
	try:L=eval(__settings__.getSetting("W_list"))
	except: L=[]
	for id in L:
		info=get_info(str(id))
		rus=info["title"]
		AddItem(rus, 'Wish', id)
	xbmcplugin.endOfDirectory(handle)

if mode == "Wish":
	Torrents(id)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(handle)
	xbmc.sleep(300)
	SetViewMode()
	#xbmc.executebuiltin("Container.SetViewMode(51)")

if mode == "update_info":
	update_info(id)

if mode == "TopLists":
	TopLists()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "OpenTopList":
	Navigate(url)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "PlayTrailer":
	trailer=get_trailer(id)
	if trailer!='':
		info=get_info(str(id))
		cover=info['cover']
		title=info['title']
		listitem = xbmcgui.ListItem("trailer", path=trailer,iconImage=cover, thumbnailImage=cover)
		listitem.setInfo(type = "Video", infoLabels = get_labels(info))
		xbmc.Player().play(trailer, listitem)
		xbmcplugin.endOfDirectory(handle, False, False)

if mode == "Save_strm":
	if __settings__.getSetting("NFO2")=='true': save_film_nfo(id)
	save_strm (url, 0, id)

if mode == "check":
	check()

if mode == "Review":
	review(id)

if mode == "Autoplay":
	autoplay(id)

c.close()