﻿# -*- coding: utf-8 -*-

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, sys

if sys.version_info.major > 2:  # Python 3 or later
	import urllib.request
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
	from urllib.parse import urlencode
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote_plus as unquote
	import urllib2
	from urllib import urlencode


PLUGIN_NAME   = 'shortcuts'
handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.tdw.shortcuts')


L=[
('Movies', 'videodb://movies/'),
('MovieGenres', 'videodb://movies/genres/'),
('MovieTitles', 'videodb://movies/titles/'),
('MovieYears', 'videodb://movies/years/'),
('MovieActors', 'videodb://movies/actors/'),
('MovieDirectors', 'videodb://movies/directors/'),
('MovieStudios', 'videodb://movies/studios/'),
('MovieSets', 'videodb://movies/sets/'),
('MovieCountries', 'videodb://movies/countries/'),
('MovieTags', 'videodb://movies/tags/'),
('RecentlyAddedMovies', 'videodb://recentlyaddedmovies/'),
('TvShows', 'videodb://tvshows/'),
('TvShowGenres', 'videodb://tvshows/genres/'),
('TvShowTitles', 'videodb://tvshows/titles/'),
('TvShowYears', 'videodb://tvshows/years/'),
('TvShowActors', 'videodb://tvshows/actors/'),
('TvShowStudios', 'videodb://tvshows/studios/'),
('RecentlyAddedEpisodes', 'videodb://recentlyaddedepisodes/'),
('InProgressTvShows', 'videodb://inprogresstvshows'),
('Addons', 'addons://sources/executable/'),
('Playlists', 'special://videoplaylists/'),
]

def dir():
	
	for i in L:
		
		context = xbmcgui.ListItem(i[0])
		xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=i[1], listitem=context, isFolder=True)
		
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

dir()
