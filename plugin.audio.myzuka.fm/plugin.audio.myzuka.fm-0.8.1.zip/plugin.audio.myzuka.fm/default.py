#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,urllib2,re,sys,os,random, cookielib
import xbmcplugin,xbmcgui,xbmcaddon
import time

addon = xbmcaddon.Addon(id='plugin.audio.myzuka.fm')
pluginhandle = int(sys.argv[1])
thumb = os.path.join( addon.getAddonInfo('path'), 'icon.png')
xbmcplugin.setContent(int(sys.argv[1]), 'songs')
__settings__ = xbmcaddon.Addon(id='plugin.audio.myzuka.fm')

#httpurl='http://imyz.me'
httpurl='https://myzuka.club/'

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)
def rt(x):
	L=[('&#39;','’'), ('&#145;','‘'), ('&#146;','’'), ('&#147;','“'), ('&#148;','”'), ('&#149;','•'), ('&#150;','–'), ('&#151;','—'), ('&#152;','?'), ('&#153;','™'), ('&#154;','s'), ('&#155;','›'), ('&#156;','?'), ('&#157;',''), ('&#158;','z'), ('&#159;','Y'), ('&#160;',''), ('&#161;','?'), ('&#162;','?'), ('&#163;','?'), ('&#164;','¤'), ('&#165;','?'), ('&#166;','¦'), ('&#167;','§'), ('&#168;','?'), ('&#169;','©'), ('&#170;','?'), ('&#171;','«'), ('&#172;','¬'), ('&#173;',''), ('&#174;','®'), ('&#175;','?'), ('&#176;','°'), ('&#177;','±'), ('&#178;','?'), ('&#179;','?'), ('&#180;','?'), ('&#181;','µ'), ('&#182;','¶'), ('&#183;','·'), ('&#184;','?'), ('&#185;','?'), ('&#186;','?'), ('&#187;','»'), ('&#188;','?'), ('&#189;','?'), ('&#190;','?'), ('&#191;','?'), ('&#192;','A'), ('&#193;','A'), ('&#194;','A'), ('&#195;','A'), ('&#196;','A'), ('&#197;','A'), ('&#198;','?'), ('&#199;','C'), ('&#200;','E'), ('&#201;','E'), ('&#202;','E'), ('&#203;','E'), ('&#204;','I'), ('&#205;','I'), ('&#206;','I'), ('&#207;','I'), ('&#208;','?'), ('&#209;','N'), ('&#210;','O'), ('&#211;','O'), ('&#212;','O'), ('&#213;','O'), ('&#214;','O'), ('&#215;','?'), ('&#216;','O'), ('&#217;','U'), ('&#218;','U'), ('&#219;','U'), ('&#220;','U'), ('&#221;','Y'), ('&#222;','?'), ('&#223;','?'), ('&#224;','a'), ('&#225;','a'), ('&#226;','a'), ('&#227;','a'), ('&#228;','a'), ('&#229;','a'), ('&#230;','?'), ('&#231;','c'), ('&#232;','e'), ('&#233;','e'), ('&#234;','e'), ('&#235;','e'), ('&#236;','i'), ('&#237;','i'), ('&#238;','i'), ('&#239;','i'), ('&#240;','?'), ('&#241;','n'), ('&#242;','o'), ('&#243;','o'), ('&#244;','o'), ('&#245;','o'), ('&#246;','o'), ('&#247;','?'), ('&#248;','o'), ('&#249;','u'), ('&#250;','u'), ('&#251;','u'), ('&#252;','u'), ('&#253;','y'), ('&#254;','?'), ('&#255;','y'), ('&amp;','&')]
	for i in L:
		x=x.replace(i[0], i[1])
	return x

AZ=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
az=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
AR=['А','Б','В','Г','Д','Е','Ж','З','И','Й','К','Л','М','Н','О','П','Р','С','Т','У','Ф','Х','Ц','Ч','Ш','Щ','Ъ','Ы','Ь','Э','Ю','Я']
ar=['а','б','в','г','д','е','ж','з','и','й','к','л','м','н','о','п','р','с','т','у','ф','х','ц','ч','ш','щ','ъ','ы','ь','э','ю','я']

from tagger import *
def retag(pt, info={}):
	#print "-=-=-= retag -=-=-=-=-"
	import mutagen
	from mutagen.mp3 import MP3
	from mutagen.id3 import ID3
	from mutagen.easyid3 import EasyID3

	try: ID3(pt).delete(delete_v1=True, delete_v2=False)
	except: pass

	mp3_tag = ID3v2(pt)
	title_frame = mp3_tag.new_frame('TIT2')
	title_frame.set_text(ru(info["title"].replace("? ","х ")))
	try:
		old_title_frame = [frame for frame in mp3_tag.frames if frame.fid == 'TIT2'][0]
		mp3_tag.frames.remove(old_title_frame)
	except: pass
	mp3_tag.frames.append(title_frame)
	
	a_frame = mp3_tag.new_frame('TPE1')
	a_frame.set_text(ru(info["artist"].replace("? ","х ")))
	try:
		old_a_frame = [frame for frame in mp3_tag.frames if frame.fid == 'TPE1'][0]
		mp3_tag.frames.remove(old_a_frame)
	except: pass
	mp3_tag.frames.append(a_frame)

	al_frame = mp3_tag.new_frame('TALB')
	al_frame.set_text(ru(info["album"].replace("? ","х ")))
	try:
		old_al_frame = [frame for frame in mp3_tag.frames if frame.fid == 'TALB'][0]
		mp3_tag.frames.remove(old_al_frame)
	except: pass
	mp3_tag.frames.append(al_frame)
	mp3_tag.commit()

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		#sn=http[s:]
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L


def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "wb")
	fl.write(s)
	fl.close()

def inputbox():
	skbd = xbmc.Keyboard()
	skbd.setHeading('Поиск:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return ""

def showMessage(heading, message, times = 3000):
	heading = heading.encode('utf-8')
	message = message.encode('utf-8')
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, thumb))

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

#============================================================

def POST(target, post=None, referer='http://tvfeed.in'):
	#print target
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		req.add_header('X-Requested-With', 'XMLHttpRequest')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		print e
		return ''

def GET(url, Referer = ''):
	post='url='+urllib.quote_plus(url)
	if __settings__.getSetting("unlock")=='true': return POST('http://cameleo.xyz/r', post)
	if Referer == '': Referer = httpurl
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

#============================================================

import sqlite3 as db
db_name = os.path.join( addon.getAddonInfo('path'), "info.db" )
c = db.connect(database=db_name)
cu = c.cursor()
def add_to_db(n, item):
		rem_inf_db(n)
		item=item.replace("'","XXCC").replace('"',"XXDD")
		err=0
		tor_id="n"+n
		litm=str(len(item))
		try:
			cu.execute("CREATE TABLE "+tor_id+" (db_item VARCHAR("+litm+"), i VARCHAR(1));")
			c.commit()
		except: 
			err=1
			print "Ошибка БД"
		if err==0:
			cu.execute('INSERT INTO '+tor_id+' (db_item, i) VALUES ("'+item+'", "1");')
			c.commit()
			#c.close()

def get_inf_db(n):
		tor_id="n"+n
		cu.execute(str('SELECT db_item FROM '+tor_id+';'))
		c.commit()
		Linfo = cu.fetchall()
		info=Linfo[0][0].replace("XXCC","'").replace("XXDD",'"')
		return info

def rem_inf_db(n):
		tor_id="n"+n
		try:
			cu.execute("DROP TABLE "+tor_id+";")
			c.commit()
		except: pass

def Root():
		AddItem("[COLOR F0E0E067][B][ Поиск ][/B][/COLOR]", "serch")
		AddItem("[COLOR F0E0E067][B][ ТОП-100 ][/B][/COLOR]", "top")
		AddItem("[COLOR F0E0E067][B][ Жанры ][/B][/COLOR]", "genres")
		AddItem("[COLOR F0E0E067][B][ Исполнители ][/B][/COLOR]", "artists")
		AddItem("[COLOR F0E0E067][B][ Хиты ][/B][/COLOR]", "hits")
		#Top100()
		xbmcplugin.endOfDirectory(pluginhandle)


def fast_track_info(SongID):
	ID = 'S'+SongID
	try:
			info=eval(xt(get_inf_db(ID)))
			info['SongID']=SongID
			return info
	except:
			return {}

def get_track_info(SongID):
	ID = 'S'+SongID
	try:
			info=eval(xt(get_inf_db(ID)))
			info['SongID']=SongID
			return info
	except:
		url=httpurl+'/Song/'+SongID
		http=GET(url)
		t=http[http.find('<div itemprop="tracks"'):http.find('class="save-to-pl big-song glyphicon glyphicon-chevron-down"')]
		cover=t[t.find('<img src="')+10:t.find('.jpg')+4]
		url=httpurl+t[t.find('/Song/Play/'):t.find('" data-position')].replace('amp;','')
		title=t[t.find(' - ')+3:t.find('</h1>')]
		if " (" in title: title = title[:title.find(" (")]
		
		L=mfindal(t,'<tr>','</tr>')
		
		Genre=''
		Artist=''
		Album=''
		Duration=''
		AlbumID=''
		ArtistID=''
		Type='Song'
		rating=''
		
		for i in L:
			if 'Genre' in i: Genre=i[i.find('">')+2:i.find('</a>')]
			if 'Artist' in i: 
				la=i.splitlines()
				for j in la:
					if Artist=='' or ArtistID=='':
						if 'itemprop="name"' in j: Artist=j[j.find('="')+2:j.find('" itemprop')]
						if 'itemprop="url"' in j: ArtistID=j[j.find('Artist/')+7:j.find('" itemprop')]
			if 'Album' in i: 
				la=i.splitlines()
				for j in la:
					if 'itemprop="name"' in j: Album=j[j.find('="')+2:j.find('" itemprop')]
					if 'itemprop="url"' in j: AlbumID=j[j.find('Album/')+6:j.find('" itemprop')]
			if 'duration' in i: Duration=i[i.find('"/>')+3:i.find('"/>')+8]
			if 'UserPlays' in i: rating=i[i.find('"/>')+3:i.find('</td>')]
		
		info={
			'duration' : Duration,
			'genre'    : rt(Genre),
			'album'    : rt(Album),
			'AlbumID'  : AlbumID,
			'artist'   : rt(Artist),
			'ArtistID' : ArtistID,
			'title'    : rt(title),
			'cover'    : cover,
			'type'     : Type,
			'rating'   : rating,
			'url'      : url
			}
		
		try:
			add_to_db(ID, repr(info))
		except:
			print "ERR: " + ID
		
		info['SongID']=SongID
		return info


def fast_album_info(AlbumID):
	if '/' in AlbumID: AlbumID=AlbumID[:AlbumID.find('/')]
	ID = 'A'+AlbumID
	try:
			info=eval(xt(get_inf_db(ID)))
			return info
	except:
			return {}

def get_album_info(AlbumID):
	if '/' in AlbumID: AlbumID=AlbumID[:AlbumID.find('/')]
	ID = 'A'+AlbumID
	try:
			info=eval(xt(get_inf_db(ID)))
			return info
	except:
		#rem_inf_db(ID)
		url=httpurl+'/Album/'+AlbumID
		http=GET(url)
		if 'Альбом удален по просьбе правообладателя' in http: return {'year':'','genre': '','album': '','AlbumID' : '','artist': '','ArtistID' : '', 'type': '', 'cover' : ''}
		t=http[http.find('<meta content="/Album/')+6:http.find('<a id="tracks">')]
		Album = t[t.find('<meta content="')+15:t.find('" itemprop="name"')]
		cover=t[t.find('image" src="')+12:t.find('.jpg')+4]
		L=mfindal(t,'<tr>','</tr>')
		
		Genre=''
		Artist=''
		Year=''
		Duration=''
		ArtistID=''
		Type=''
		
		for i in L:
			if 'Genre' in i: Genre=i[i.find('">')+2:i.find('</a>')]
			if 'datetime' in i: Year=i[i.find('datetime="')+10:i.find('-01-01"')]
			if 'duration' in i: Duration=i[i.find('"/>')+3:i.find('"/>')+8]
			
			if 'Студийный альбом' in i: Type='Альбом'
			if 'Сингл' in i:            Type='Сингл'
			#if 'Сборник' in i:          Type='Сборник'
			
			if 'Artist' in i: 
				la=i.splitlines()
				for j in la:
					if Artist=='' or ArtistID=='':
						if 'itemprop="name"' in j: Artist=j[j.find('="')+2:j.find('" itemprop')]
						if 'itemprop="url"' in j: ArtistID=j[j.find('Artist/')+7:j.find('" itemprop')]
		
		info={
			'year'     : Year,
			'genre'    : rt(Genre),
			'album'    : rt(Album),
			'AlbumID'  : AlbumID,
			'artist'   : rt(Artist),
			'ArtistID' : ArtistID,
			'type'     : Type,
			'cover'    : cover
			}
		
		t2=http[http.find('<a id="tracks">'):http.find('<div id="rating"')]
		L2=mfindal(t2,'data-url="/Song/Play/','?t=')
		n=0
		tracks={}
		for k in L2:
			n+=1
			SongID = k.replace('data-url="/Song/Play/','')
			tracks[SongID] = n
		
		info['tracks'] = tracks
		
		try:
			if Album!="": add_to_db(ID, repr(info))
		except:
			print "ERR: " + ID

		return info


def get_tracks(url):
	#print url
	http=GET(url)
	#print http
	#debug (http)
	ss='/Song/Play/'
	es='" data-position'
	es='" title="Слушать'
	L=mfindal(http, ss,es)
	L2=[]
	L3=[]
	if __settings__.getSetting("unlock")=='true': httpurl=mfindal(http, 'og:url" content="', '.cmle.ru')[0][17:]+".cmle.ru"
	for i in L:
		url = httpurl+i[:i.find('" data-position')].replace('amp;','')
		SongID = i[i.find('Play/')+5:i.find('?t=')]
		title = rt(i[i.rfind(' - ')+3:])
		artist = rt(i[i.find('data-title="')+12:i.find(' - ')])
		if " (" in title: title = title[:title.find(" (")]
		if SongID not in L3:
			L2.append({'id':SongID, 'url':url, 'title':title, 'artist':artist})
			L3.append(SongID)
	return L2

def get_albums(url):
	http=GET(url)
	http=http[:http.find("button-a register no-ajaxy")]
	L2=[]
	if '<div data-type="' in http:
		L=mfindal(http,'</div><div data','Год релиза')
		type='0'
	else:
		L=http.splitlines()
		type='2'
		
	for i in L:
			if '/Album/' in i:
				if 'data-type' in i: type=i[i.find('-type="')+7:i.find('" class="item')]
				t=i[i.find('Album/')+6:]
				AlbumID=t[:t.find('/')]
				if AlbumID not in L2 and (type=='2' or type=='4'): L2.append(AlbumID)
	return L2


def AddItem(title = "", mode = "", info={}, purl="", total=100):
			folder=False
			
			try:    img=info['cover']
			except: img=thumb
			
			try:tracknumber=info['tracknumber']
			except:tracknumber=''
			
			try:year=info['year']
			except:year=''
			
			try:stitle=info['title']
			except:
				try:stitle=''#info['album']
				except:stitle=title
			
			try:artist=info['artist']
			except:artist=''
			
			try:album=info['album']
			except:album=''
			
			try:genre=info['genre']
			except:genre=''
			
			
			try:ArtistID=info['ArtistID']
			except:ArtistID=''
			
			try:AlbumID=info['AlbumID']
			except:AlbumID=''
			
			try:GenreID=info['GenreID']
			except:GenreID=''
			
			try:SongID=info['SongID']
			except:SongID=''
			
			try:
				dict={'title':stitle, 'artist':artist, 'album':album, 'genre':genre, 'year':year, 'tracknumber':tracknumber}
			except:dict={}
			
			item = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
			item.setInfo(type="Music", infoLabels=dict)
			
			context=[]
			if AlbumID!='':
				uri=sys.argv[0] + '?mode=album&id='+AlbumID
				context.append(('[COLOR F050F050] Альбом [/COLOR]', 'Container.Update("'+uri+'")'))
				
			
			if ArtistID!='':
				uri=sys.argv[0] + '?mode=artist&id='+ArtistID
				context.append(('[COLOR F050F050] Исполнитель [/COLOR]', 'Container.Update("'+uri+'")'))
				
			if SongID!='':
				uri=sys.argv[0] + '?mode=save&id='+SongID
				context.append(('[COLOR F050F050] Сохранить трек [/COLOR]', 'Container.Update("'+uri+'")'))
				
			if AlbumID!='':
				uri=sys.argv[0] + '?mode=saveall&id='+AlbumID
				context.append(('[COLOR F050F050] Сохранить альбом [/COLOR]', 'Container.Update("'+uri+'")'))
			
			if purl=="":
				purl = sys.argv[0] + '?mode='+mode
				if mode=='opengenre': purl = purl+'&id='+GenreID
				if mode=='album':     purl = purl+'&id='+AlbumID
				if mode=='artist':    purl = purl+'&id='+ArtistID
				folder=True
			else:
				item.setProperty('IsPlayable', 'true')
				
			item.addContextMenuItems(context)
			xbmcplugin.addDirectoryItem(pluginhandle, purl, item, folder, total)

def Top100():
	url=httpurl+"/Hits/Top100Monthly?_pjax=%23bodyContent"
	L = get_tracks(url)
	Lid=[]
	for i in L:
		url = i['url']
		SongID = i['id']
		#info=get_track_info(SongID)
		info=fast_track_info(SongID)
		try:title=info['title']
		except:title=i['title']
		try:artist=info['artist']
		except:artist=i['artist']
		try:AlbumID=info['AlbumID']
		except:AlbumID=''
		
		if AlbumID!='':
			try:
				info2=get_album_info(AlbumID)
				info2['SongID']=SongID
				ntr = info2['tracks']
				info2['title']=title
				try:info2['tracknumber']=ntr[i['id']]
				except: pass
				info=info2
			except: pass
		if info=={}:
			Lid.append(SongID)
			info={'artist':artist, 'title':title, 'SongID':SongID}
		if title!='': 
			purl = sys.argv[0] + '?mode=play&id='+SongID
			AddItem(TR+artist+" - [B]"+title+"[/B]", "play", info, purl, len(L))
	xbmcplugin.endOfDirectory(pluginhandle)
	
	for SongID in Lid:
		info=get_track_info(SongID)
		AlbumID=info['AlbumID']
		try:info2=get_album_info(AlbumID)
		except: pass
	if len (Lid)>0:
		xbmc.executebuiltin("Container.Refresh")


def Decade():
	L1=[]
	L2=[]
	for i in range (0,11):
		year=str(2017-i)
		L1.append(year)
		L2.append(year+" г.")
	
	for i in range (0,7):
		year=str(200-i)
		L1.append(year)
		L2.append(year+"0-x")
	
	#L2.reverse()
	#L1.reverse()
	sel = xbmcgui.Dialog()
	r = sel.select("Хиты:", L2)
	if r>0:
		L=[]
		if r>10:
				for i in range (0,10):
					url=httpurl+'/Hits/'+L1[r]+str(i)+'?_pjax=%23bodyContent'
					print url
					Lt = get_tracks(url)
					if len(Lt)>10:
						for t in range(0,11):
							L.append(Lt[t])
					else:
						L.extend(Lt)
		else:
				for i in range (1,3):
					url=httpurl+'/Hits/'+L1[r]+'/Page'+str(i)+'?_pjax=%23bodyContent'
					print url
					Lt = get_tracks(url)
					L.extend(Lt)
	else: return
	uri=sys.argv[0] + '?mode=decade2&Lst='+urllib.quote_plus(repr(L))
	xbmc.executebuiltin('Container.Update("'+uri+'")')

def Decade2(L):
		#L = get_tracks(url)
		Lid=[]
		for i in L:
			url = i['url']
			SongID = i['id']
			title=i['title']
			artist=i['artist']
			#info=get_track_info(SongID)
			info=fast_track_info(SongID)
			#title=info['title']
			if info != {}:
				AlbumID=info['AlbumID']
				if AlbumID!='':
					try:
						info2=get_album_info(AlbumID)
						info2['SongID']=SongID
						ntr = info2['tracks']
						info2['title']=title
						try:info2['tracknumber']=ntr[i['id']]
						except: pass
						info=info2
					except: pass
				#if title!='': AddItem(TR+artist+" - [B]"+title+"[/B]", "play", info, url, len(L))
			else:
				Lid.append(SongID)
				info={'artist':artist, 'title':title, 'SongID':SongID}
			if title!='': AddItem(TR+artist+" - [B]"+title+"[/B]", "play", info, url, len(L))
		xbmcplugin.endOfDirectory(pluginhandle)
		xbmc.sleep(300)
		xbmc.executebuiltin("Container.SetViewMode(506)")
	
		postinfo(Lid)


def Hits():
	AddItem("[COLOR F0E0E067][B][ По годам ][/B][/COLOR]", "decade")
	
	url=httpurl+'/Hits/'
	L = get_tracks(url)
	Lid=[]
	for i in L:
			url = i['url']
			SongID = i['id']
			title=i['title']
			artist=i['artist']
			#info=get_track_info(SongID)
			#title=info['title']
			info=fast_track_info(SongID)
			if info != {}:
				AlbumID=info['AlbumID']
				if AlbumID!='':
					try:
						info2=get_album_info(AlbumID)
						info2['SongID']=SongID
						ntr = info2['tracks']
						info2['title']=title
						try:info2['tracknumber']=ntr[i['id']]
						except: pass
						info=info2
					except: pass
				#if title!='': AddItem(TR+artist+" - [B]"+title+"[/B]", "play", info, url, len(L))
			else:
				Lid.append(SongID)
				info={'artist':artist, 'title':title, 'SongID':SongID}
			if title!='': AddItem(TR+artist+" - [B]"+title+"[/B]", "play", info, url, len(L))
	xbmcplugin.endOfDirectory(pluginhandle)
	xbmc.sleep(300)
	xbmc.executebuiltin("Container.SetViewMode(506)")
	
	postinfo(Lid)

def Album(AlbumID):
	url=httpurl+"/Album/"+AlbumID
	info = get_album_info(AlbumID)
	ntr = info['tracks']
	L = get_tracks(url)
	for i in L:
		title = i['title']
		if title!='':
			url = i['url']
			SongID=i['id']
			artist=info['artist']
			info['title']=title
			info['SongID']=SongID
			try:info['tracknumber']=ntr[SongID]
			except: pass
			AddItem(TR+artist+" - [B]"+title+"[/B]", "play", info, url, len(L))
	xbmcplugin.endOfDirectory(pluginhandle)

def Artist(ArtistID):
	xbmcplugin.setContent(int(sys.argv[1]), 'albums')
	url=httpurl+"/Artist/"+ArtistID+'/Albums'
	L=get_albums(url)
	for AlbumID in L:
		info = get_album_info(AlbumID)
		title  = info['album']
		artist = info['artist']
		type   = info['type']
		year   = info['year']
		if type!='': AddItem(AL+artist+" - [B]"+title+"[/B]  [COLOR 66FFFFFF]("+year+")[/COLOR]", "album", info)
	xbmcplugin.endOfDirectory(pluginhandle)

def Serch():
		q=inputbox().replace(" ","%20")
		url=httpurl+'/Search?searchText='+q#+'#songs'
		
		http=GET(url)
		n=http.find("<h1>Поиск по композициям</h1>")
		http=http[n:]
		try:
			ss='ght="30">'
			es='<td hei'
			L=mfindal(http, ss, es)
		except:
			L=[]
		Lst=[]
		for i in L:
			print i
			Lt=i.splitlines()
			artist =''
			title = ''
			SongID= ''
			for j in Lt:
				if 'Artist' in j:
					artist = rt(j[j.find('">')+2:j.find('</a>')])
					
				if 'Song' in j: 
					title = rt(j[j.find('">')+2:j.find('</a>')])
					j2 = j[j.find('Song/')+5:]
					SongID = j2[:j2.find('/')]
			if SongID!='': Lst.append({'SongID':SongID, 'title':title, 'artist':artist})
		uri=sys.argv[0] + '?mode=serch2&Lst='+urllib.quote_plus(repr(Lst))
		xbmc.executebuiltin('Container.Update("'+uri+'")')

		#xbmcplugin.endOfDirectory(pluginhandle)

def Serch2(L):
	Lid=[]
	for i in L:
					SongID=i['SongID']
					info=fast_track_info(SongID)
					if info!={}:
						title=info['title']
						artist=info['artist']
					else:
						Lid.append(SongID)
						title=i['title']
						artist=i['artist']
						info={'artist':artist, 'title':title, 'SongID':SongID}
					purl = sys.argv[0] + '?mode=play&id='+SongID
					if title!='': AddItem(TR+artist+" - [B]"+title+"[/B]", "play", info, purl, len(L))
	xbmcplugin.endOfDirectory(pluginhandle)
	xbmc.sleep(300)
	xbmc.executebuiltin("Container.SetViewMode(506)")
	postinfo(Lid)


def postinfo(Lid):
	if len (Lid)>0:
		try:
			pDialog = xbmcgui.DialogProgressBG()
			pDialog.create('Musica.fm', '')
		except: pass
		
		n=0
		for SongID in Lid:
			n+=1
			xbmc.sleep(300)
			try:pDialog.update(n*100/len(Lid), message='Загрузка описаний')
			except: pass
			info=get_track_info(SongID)
			print info
			AlbumID=info['AlbumID']
			try:info2=get_album_info(AlbumID)
			except: pass
		
		xbmc.executebuiltin("Container.Refresh")
		try:pDialog.close()
		except: pass





def Artists():
	xbmcplugin.setContent(int(sys.argv[1]), 'artists')
	xbmcplugin.setContent(int(sys.argv[1]), 'albums')
	for p in range(1,11):#2,3
		url=httpurl+'/Artist/Page'+str(p)
		http=GET(url)
		L=mfindal(http,'<tr>','</tr>')
		for i in L:
			if '/Artist/' in i: 
				title = rt(i[i.find('<img alt="')+10:i.find('" style="')])
				cover = i[i.find('src=')+5:i.find('.jpg')+4]
				tID = i[i.find('Artist/')+7:i.find('</a>')]
				ArtistID = tID[:tID.find('">')]
				info={"cover":cover, "ArtistID":ArtistID, 'artist':title}
				AddItem (title, 'artist', info)
				#Artist(ArtistID)
	xbmcplugin.addSortMethod(pluginhandle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(pluginhandle)
	

def Play(SongID):
	#print httpurl+'/Song/'+SongID
	url=get_tracks(httpurl+'/Song/'+SongID)[0]['url']
	item = xbmcgui.ListItem(path=url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)



def Genres(pop=True): 
	if pop: AddItem('[COLOR F0E0E067][B][ Все жанры ][/B][/COLOR]','allgenres')
	rez=[]
	for p in ['1', '2', '3', '4']:
		purl=httpurl+'/Genre/Page'+p+'?_pjax=%23bodyContent'
		http=GET(purl).replace(chr(13),'').replace('td>\n','td>').replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ')
		L=mfindal(http,'<td height="50">','</td> </tr>')
		for i in L:
			L2=i.splitlines()
			n=int(L2[4].replace('</td> <td>','').replace(' ',''))
			title=rt(L2[2][L2[2].find('">')+2:L2[2].find('</a>')])
			tid=L2[2][L2[2].find('Genre/')+6:]
			GenreID=tid[:tid.find('">')]
			if n>800000 or pop==False:
				rez.append({'title':title, 'id':id, 'rating': n})
				AddItem(title, 'opengenre', {'GenreID':GenreID} )
	xbmcplugin.endOfDirectory(pluginhandle)
	return rez

def OpenGenre(GenreID, p=1):
	url=httpurl+'/Genre/'+GenreID+'/Page'+str(p)+'?_pjax=%23bodyContent'
	L=get_albums(url)
	for i in L:
		info=get_album_info(i)
		title=info['album']
		artist=info['artist']
		AddItem (artist+' - '+title, 'album', info)
	xbmcplugin.endOfDirectory(pluginhandle)


def SaveAlbum(AlbumID):
	xbmcplugin.endOfDirectory(pluginhandle, False, False)
	url=httpurl+"/Album/"+AlbumID
	info = get_album_info(AlbumID)
	L = info['tracks']
	for SongID in L:
			uri=sys.argv[0] + '?mode=save&id='+SongID
			xbmc.executebuiltin('Container.Update("'+uri+'")')
			xbmc.sleep(2000)
	xbmc.sleep(100000)
	xbmc.executebuiltin('UpdateLibrary("music")')


def Save(SongID, update=False):
	xbmcplugin.endOfDirectory(pluginhandle, False, False)
	target=get_tracks(httpurl+'/Song/'+SongID)[0]['url']
	dict=get_track_info(SongID)
	artist	=dict["artist"]
	title	=dict["title"]
	img		=dict["cover"]
	album	=dict["album"]
	
	try:
		pDialog = xbmcgui.DialogProgressBG()
		pDialog.create('Сохранение:', artist+" - "+title)
	except: pass
	
	
	Dldir = __settings__.getSetting("DownloadDirectory")
	if Dldir == "":Dldir = os.path.join( addon.getAddonInfo('path'), "mp3" )
	
	fp = os.path.join(ru(Dldir), ru(artist))
	fp = os.path.join(fp, ru(album))
	if os.path.exists(fp)== False: os.makedirs(fp)
	cp=os.path.join(fp, "cover.jpg")
	fp = os.path.join(fp, ru(title+".mp3"))
	try:
	#if 1==1:
			req = urllib2.Request(url = target, data = None)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			fl = open(fp, "wb")
			fl.write(resp.read())
			fl.close()
			if os.path.exists(cp)== False and img !="":
				req = urllib2.Request(url = img, data = None)
				req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
				resp = urllib2.urlopen(req)
				fl = open(cp, "wb")
				fl.write(resp.read())
				fl.close()
			
			retag(fp, dict)
			#print "Update"
			try:pDialog.close()
			except: pass
			
			if update: 
				xbmc.sleep(3000)
				xbmc.executebuiltin('UpdateLibrary("music")')
			
			return fp
	except Exception, e:
			pDialog.close()
	#		#xbmc.log( '[%s]: GET EXCEPT [%s]' % (addon_id, e), 4 )
	#		return target
	#		print 'HTTP ERROR ' + str(e)


# -------------------------------------------------------------------

params = get_params()
url  =	httpurl
mode =	None
name =	''
img =	' '
info =	{}
Lst=[]
id = ''
AL="[COLOR 663333DD][B][ A ][/B][/COLOR] "
TR=''#"[COLOR F055FF55][B][ T ][/B][/COLOR] "

try: id = urllib.unquote_plus(params["id"])
except: pass
try: url = urllib.unquote_plus(params["url"])
except: pass
try: mode = urllib.unquote_plus(params["mode"])
except: pass
try: name = urllib.unquote_plus(params["name"])
except: pass
try: img = urllib.unquote_plus(params["img"])
except: pass
try: info = eval(urllib.unquote_plus(params["info"]))
except: pass
try: Lst = eval(urllib.unquote_plus(params["Lst"]))
except: pass



if   mode == None:			Root()
elif mode == 'serch':		Serch()
elif mode == 'serch2':		Serch2(Lst)
elif mode == 'genres':		Genres()
elif mode == 'allgenres':	Genres(False)
elif mode == 'artists':		Artists()
elif mode == 'opengenre':	OpenGenre(id)
elif mode == 'album':		Album(id)
elif mode == 'play':		Play(id)
elif mode == 'artist':		Artist(id)
elif mode == 'save':		Save(id)
elif mode == 'saveall':		SaveAlbum(id)
elif mode == 'hits':		Hits()
elif mode == 'decade':		Decade()
elif mode == 'decade2':		Decade2(Lst)
elif mode == 'top':			Top100()

xbmc.sleep(300)
xbmc.executebuiltin("Container.SetViewMode(506)")

