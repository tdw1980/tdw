# -*- coding: utf-8 -*-
import sys, os, time
import urllib, urllib2
temp_dir = "d:\\"
print '-=-=- myzcloud -=-=-'
import uscode
httpurl='http://myzcloud.me'

#-------------------------------------------------------------------------------
import xbmcaddon#, cookielib
addon = xbmcaddon.Addon(id='plugin.audio.myzcloud')
if addon.getSetting("antizapret") == "true": httpurl='http://127.0.0.1:8095/proxy/'+httpurl
'''
fcookies = os.path.join(addon.getAddonInfo('path'), 'cookies.txt')
cj = cookielib.FileCookieJar(fcookies)
hr  = urllib2.HTTPCookieProcessor(cj)

if addon.getSetting("antizapret") == "true":
	prx='http://proxy.antizapret.prostovpn.org:3128'
	proxy_support = urllib2.ProxyHandler({"http" : prx})#, "https": prx
	opener = urllib2.build_opener(proxy_support, hr)
	print "Proxy antizapret"
else:
	opener = urllib2.build_opener(hr)
	print "NO Proxy"

urllib2.install_opener(opener)
#-------------------------------------------------------------------------------
'''

def rt(s): return uscode.decode(s)
def ru(x):return unicode(x,'utf8', 'ignore')

def POST(target, post=None, referer=''):
	#print target
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36 OPR/46.0.2597.39')
		req.add_header('Accept', 'application/json, text/javascript, */*; q=0.01')
		req.add_header('Accept-Language', 'ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4')
		req.add_header('Referer', referer)
		req.add_header('x-requested-with', 'XMLHttpRequest')
		#req.add_header('X-Secret-Key', '%D9%A2%D0%A9%D2%DF%DB%E2%9C%A4%E0p%D6%9F%EC%CA%99%EE%C8%DD%97%DA')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		print e
		return ''

def GET(url, Referer = ''):
	print url
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def GETjson(url,Referer = ''):
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36 OPR/46.0.2597.39')
		#req.add_header('Accept', 'application/xml, application/xhtml+xml, ')
		req.add_header('Accept', 'application/json, text/javascript, */*; q=0.01')
		req.add_header('Accept-Language', 'ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4')
		req.add_header('Referer', Referer)
		req.add_header('x-requested-with', 'XMLHttpRequest')
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link

def find_all(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)+len(ss)
		http=http[s:]
		e=http.find(es)
		i=http[:e]
		L.append(i)
		http=http[e+1:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def get_tracks(hp):
	L1=find_all(hp, 'class="playlist__item"', 'class="playlist__actions"')
	L=[]
	for i in L1:
		print i
		info={
		'artist':		mfind(mfind(i,'/artist/','<span'), '">', '<'),
		'title':		mfind(mfind(i,'href="/song/','<p>'), '">', '<'),
		'url':			httpurl+mfind(i,'data-url="','"'),
		'type':			'track'
		}
		if info['artist']=='\n': info['artist']=mfind(i,'data-artist="','"')
		print info
		L.append(info)
		
	return L

def get_top_tracks(artist_id):# OK
	url=httpurl+'/artist/'+artist_id
	hp=GET(url)
	return get_tracks(hp)


def get_album_tracks(id):# OK
	#id='34356037529'
	url=httpurl+'/album/'+id+'?_pjax=%23bodyContent'
	hp=rt(GETjson(url))
	L1=find_all(hp, 'class="playlist__item"', 'class="playlist__actions"')
	#print hp
	tmp = mfind(hp,'<img alt=','class')
	album = mfind(tmp,'"','" src')
	cover = mfind(tmp,'src="','"')
	year =  mfind(hp,'time datetime="','-')
	genre=  ""#mfind(tmp,'time datetime="','-')
	L=[]
	for i in L1:
		#print i
		info={
		'tracknumber' : mfind(i,'data-position="','"'),
		#'duration':		mfind(i,'',''),
		'year':			year,
		'genre':		genre,
		'album':		album,
		'artist':		mfind(i,'rel="nofollow">','<'),
		'title':		mfind(mfind(i,'href="/song/','<p>'), '">', '<'),
		'cover':		cover,
		'url':			httpurl+mfind(i,'data-url="','"'),
		'type':			'track'
		}
		print info
		L.append(info)
		
	return L
#get_album_tracks('1637717')

def get_albums(artist_id):# OK
	url=httpurl+'/artist/'+artist_id+'/albums'
	print url
	hp=GET(url)
	L=find_all(hp, 'div data-type', 'zmdi zmdi-calendar')
	artist=mfind(hp,'<h1>','</h1>').replace('Альбомы ','')
	La=[]
	for i in L:
		if '"2" class="card"' in i:
			print '=================================='
			info={
			'title':		mfind(i,'alt="','"'),
			'artist':		artist,
			'cover':		mfind(i,'src="','"'),
			'AlbumID':		mfind(i,'/album/','/'),
			'year':			mfind(i,'/albums/','"'),
			'type':			'album'
			}
			print info
			La.append(info)
	return La

#get_albums('160261/nautilus-pompilius')

def get_artists(p='1'):# OK
	url=httpurl+'/artist/page'+p
	if p=='1': url=httpurl+'/artist'
	hp=rt(GET(url))
	hp=hp[hp.find('</nav>'):]
	L=find_all(hp, '<img alt', '</a>')
	L2=[]
	for i in L:
		if 'height: 50px' in i:
			i+='</a>'
			info={
			'title':		mfind(i,'="','"'),
			'artist':		mfind(i,'="','"'),
			'cover':		mfind(i,'src="','"'),
			'ArtistID':		mfind(i,'/artist/','"'),
			'type':			'artist'
			}
			L2.append(info)
			print info
	return L2

#get_artists()

def get_genre_artists(id):
	url=httpurl+'/genre/'+id
	print url
	pid=id.replace('/','&NameForUrl=')
	L2=[]
	for p in range(1,10):
		post='ID='+pid+'&Page='+str(p)+'&SortOrder.Property=myzRating&SortOrder.IsAscending=false&X-Requested-With=XMLHttpRequest'
		hp=POST(httpurl+'/genre/FilterAlbums', post, url)
		#hp=GET(url)
		#hp=hp[hp.find('table-responsive'):]
		#L=find_all(hp, '<img alt', '</b>')
		L=hp.splitlines()
		for i in L:
			if '/artist/' in i:
				info={
				'title':		mfind(i,'">','<'),
				'artist':		mfind(i,'">','<'),
				'cover':		'',#mfind(i,'src="','"')
				'ArtistID':		mfind(i,'/artist/','"'),
				'type':			'artist'
				}
				if info not in L2: L2.append(info)
				#print info
	return L2


def get_genres():
	L2=[]
	for p in range (1, 6):
		url=httpurl+'/genre/page'+str(p)
		hp=GET(url)
		hp=hp[hp.find('table-responsive'):]
		L=hp.splitlines()
		for i in L:
			if '<a href="/genre/' in i:
				info={
				'title':		rt(mfind(i,'">','<')),
				'id':			mfind(i,'/genre/','"'),
				'type':			'genre'
				}
				L2.append(info)
				print info
	return L2

def get_top():
	url=httpurl+'/hits/top100week'
	hp=rt(GET(url))
	return get_tracks(hp)

def get_catalogue():
	url='https://my.mail.ru/cgi-bin/my/ajax?ajax_call=1&func_name=music.catalogue&arg_tags=&arg_limit=50&arg_ret_json=1&arg_offset=0'#&mna=1959249162&mnb=3939620678
	null=''
	#json=eval(GETjson(url).replace('\\"',"“"))
	save_inf(GETjson(url).replace('\\"',"“"))
	
def serch(s):# OK
	url=httpurl+'/search?searchText='+s.replace(' ', '%20')
	hp=GET(url)
	hp=hp[hp.find('<nav class="toolbar__nav">'):]
	hp=hp.replace("'",'"')
	L=find_all(hp, '<td height="30">', 'style="width:100px')
	L2=[]
	for i in L:
			cover=mfind(i,'src="','"')
			if 'http' not in cover: cover=""
			info={
			'title':		mfind(i,'alt="','"'),
			'artist':		mfind(i,'alt="','"'),
			'cover':		cover,
			'ArtistID':			mfind(i,'/artist/','"'),
			'type':			'artist'
			}
			L2.append(info)
			#print info
	#print '========='
	
	L=find_all(hp, 'class="playlist__item"', 'class="playlist__actions"')
	for i in L:
		#print i
		info={
		'artist':		mfind(i,'fw"></i></span>','<').replace('\n',''),
		'title':		mfind(i,'class="strong">','<'),
		'url':			httpurl+mfind(i,'data-url="','"'),
		'type':			'track'
		}
		#print info
		L2.append(info)
	return L2
#serch('машина')


#time.sleep(10)
