# -*- coding: utf-8 -*-


siteUrl = 'www.fast-torrent.ru'
httpSiteUrl = 'http://' + siteUrl
import os, urllib, urllib2
import uscode

#import xbmc, xbmcgui, xbmcplugin, xbmcaddon
#__settings__ = xbmcaddon.Addon(id='plugin.video.RuTor')
#siteUrl = __settings__.getSetting('Url')
#if siteUrl == "": siteUrl = 'open-tor.org'
#httpSiteUrl = 'http://' + siteUrl

def win(t):
	return t.decode('utf-8').encode('windows-1251')

def lower(s):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.lower().encode('utf-8')
	return s

def CRC32(buf):
		import binascii
		buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		return str("%08X" % buf)

def GET(target, referer='', post=None):
	#try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	#except Exception, e:
	#	print e
	#	return e

def GETtorr(target):
	try:
			req = urllib2.Request(url = target)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			#req.add_header('Accept', 'application/octet-stream')
			#req.add_header('Referer', 'http://hdpicture.ru')
			#req.add_header('Content-Transfer-Encoding', 'binary')
			resp = urllib2.urlopen(req)
			#resp = urllib2.urlopen(target)
			#debug (resp.read())
			return resp.read()
	except Exception, e:
			print 'HTTP ERROR ' + str(e)
			return None

def POST(target, post=None, referer=''):
	#print target
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		req.add_header('X-Requested-With', 'XMLHttpRequest')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		print e
		return ''

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def rt(x):
	x = uscode.decode(x)
	L=[('&#39;','’'), ('&#145;','‘'), ('&#146;','’'), ('&#147;','“'), ('&#148;','”'), ('&#149;','•'), ('&#150;','–'), ('&#151;','—'), ('&#152;','?'), ('&#153;','™'), ('&#154;','s'), ('&#155;','›'), ('&#156;','?'), ('&#157;',''), ('&#158;','z'), ('&#159;','Y'), ('&#160;',''), ('&#161;','?'), ('&#162;','?'), ('&#163;','?'), ('&#164;','¤'), ('&#165;','?'), ('&#166;','¦'), ('&#167;','§'), ('&#168;','?'), ('&#169;','©'), ('&#170;','?'), ('&#171;','«'), ('&#172;','¬'), ('&#173;',''), ('&#174;','®'), ('&#175;','?'), ('&#176;','°'), ('&#177;','±'), ('&#178;','?'), ('&#179;','?'), ('&#180;','?'), ('&#181;','µ'), ('&#182;','¶'), ('&#183;','·'), ('&#184;','?'), ('&#185;','?'), ('&#186;','?'), ('&#187;','»'), ('&#188;','?'), ('&#189;','?'), ('&#190;','?'), ('&#191;','?'), ('&#192;','A'), ('&#193;','A'), ('&#194;','A'), ('&#195;','A'), ('&#196;','A'), ('&#197;','A'), ('&#198;','?'), ('&#199;','C'), ('&#200;','E'), ('&#201;','E'), ('&#202;','E'), ('&#203;','E'), ('&#204;','I'), ('&#205;','I'), ('&#206;','I'), ('&#207;','I'), ('&#208;','?'), ('&#209;','N'), ('&#210;','O'), ('&#211;','O'), ('&#212;','O'), ('&#213;','O'), ('&#214;','O'), ('&#215;','?'), ('&#216;','O'), ('&#217;','U'), ('&#218;','U'), ('&#219;','U'), ('&#220;','U'), ('&#221;','Y'), ('&#222;','?'), ('&#223;','?'), ('&#224;','a'), ('&#225;','a'), ('&#226;','a'), ('&#227;','a'), ('&#228;','a'), ('&#229;','a'), ('&#230;','?'), ('&#231;','c'), ('&#232;','e'), ('&#233;','e'), ('&#234;','e'), ('&#235;','e'), ('&#236;','i'), ('&#237;','i'), ('&#238;','i'), ('&#239;','i'), ('&#240;','?'), ('&#241;','n'), ('&#242;','o'), ('&#243;','o'), ('&#244;','o'), ('&#245;','o'), ('&#246;','o'), ('&#247;','?'), ('&#248;','o'), ('&#249;','u'), ('&#250;','u'), ('&#251;','u'), ('&#252;','u'), ('&#253;','y'), ('&#254;','?'), ('&#255;','y')]
	for i in L:
		x=x.replace(i[0], i[1])
	return x


def untag(html):
	import re
	p = re.compile(r'<.*?>')
	return p.sub('', html)

def get_list(url):
	print 'get_list: '+url
	hp=GET(url)
	L=mfindal(hp, '<div itemscope itemtype', '</em></div></div></div>')
	L2=[]
	for i in L:
		id = mfind(i,"id='","'")
		curl = mfind(i,'itemprop="url" content="','"').strip()
		ru = rt(mfind(i,'itemprop="name">','<')).strip()
		if 'alternativeHeadline' in i: en = rt(mfind(i,'alternativeHeadline">','<')).strip()
		else: en = ru
		year = mfind(i,'</span>  (',')')
		plot=rt(mfind(i,'film-announce">','<')).strip()
		cover=mfind(i,'<meta itemprop="image" content="','"')
		#http://media7.fast-torrent.ru/media/files/s4/nu/zg/yarkost-scene.jpg
		#http://media7.fast-torrent.ru/media/files/s3/ge/jl/cache/yarkost_video_list.jpg
		ft=''
		print '----'
		print id
		print ru
		print en
		print year
		print curl
		print cover
		print plot
		
		L2.append ({'id':id, 'url':curl, 'title': ru, 'originaltitle':en, 'year':year, 'fulltitle':ft})
	return L2

def gettorlist(url):
	http = GET(httpSiteUrl+url.replace(".html", "/torrents.html"))
	ss='upload1'
	es='torrent-info hidden'
	L=mfindal(http, ss, es)
	L3=[]
	for i in L:
		qa  = i[i.find("title='")+7:i.find(" :: ")]
		#qa=""
		sez =''
		lng1 =''
		lng2 =''
		sz  ='0'
		dt  = '0'
		dl  = '0'
		tor = ''
		sl  = '--/--'
		
		ss="<div class='c"
		es='</div>'
		L2=mfindal(i, ss, es)
		for j in L2:
			j=j.replace("&nbsp;"," ")
			#if "class='c1'" in j: qa  = j[j.find('">')+2:j.find("</em>")]
			if "class='c9'" in j: sez = j[j.find("'>")+2:].replace('</b>','').replace('<b>','').replace('    ',' ').replace('  ',' ').replace('  ',' ').replace('\t','').replace(chr(13),"").replace(chr(10),"")#+" / "
			if "class='c10" in j: lng1 =j[j.find("<b>")+3:j.find("</b>")]
			if "class='c10" in j: lng2 =j[j.find('blank">')+7:j.find("</a>")]
			if "class='c3'" in j: sz  = j[j.find("'>")+2:]
			if "class='c4'" in j: dt  = j[j.find("'>")+2:]
			if "class='c5'" in j: dl  = j[j.find("'>")+2:]
			if "class='c7'" in j: tor = 'http://www.fast-torrent.ru'+j[j.find("/download"):j.find('" class=')]
			if "class='c6'" in j: 
								  sid = j[j.find("▲ ")+4:j.find("</font>")]
								  lich= j[j.find("▼ ")+4:j.rfind("</font>")]
								  if 'c6' in sid: sid= '0'
								  if 'c6' in lich: lich= '0'
								  sl  = sid+' / '+lich
			if "class='c2" in j: lng1 =j[j.find("<b>")+3:j.find("</b>")]
			if "class='c2" in j and 'blank">' in j : lng2 =j[j.find('blank">')+7:j.find("</a>")]
		#print " | "+qa+" | "+sez+" | "+lng1+" | "+lng2+" | "+sz+" | "+dt+" | "+dl+" | "+tor+" | "+sl
		#L3.append([sez+lng1+" "+lng2,sz,dt,dl,sid,lich,tor,qa])
		L3.append({'season':sez,'lng1':lng1,'lng2':lng2,'size':sz,'data':dt,'down':dl,'sid':sid,'lich':lich,'url':tor,'quality':qa})
	return L3

def get_kpid(t):
	if 'kinopoisk.ru/rating/' in t: return mfind(t,'kinopoisk.ru/rating/','.')
	elif 'rating.kinopoisk.ru/' in t: return mfind(t,'rating.kinopoisk.ru/','.')
	else: return ''

def get_kp_info(kp_id):
	import kpdb
	try: info = kpdb.get_info(kp_id)
	except: info = {}
	return info

def get_info(info = {}):
	id = info['id']
	url=httpSiteUrl+'/torrent/'+id
	hp=GET(url)
	
	kp_id = get_kpid(hp)
	#if kp_id =='': kp_id = serch_kpid(hp)
	
	if kp_id !='': 
		kp_info = get_kp_info(kp_id)
		if kp_info != {}:
			info = kp_info
			info['id'] = id
			info['kp_id'] = kp_id
			try:
				st=info['studio']
				if '&' in st: 
					st=st[:st.find('&')]
					info['studio'] = st
			except: pass
			return info
	
	info['cover'] = get_cover(hp)
	
	utt=untag(hp)
	utt=utt.replace(chr(13),'')
	utt=utt.replace('О фильме:','Описание:')
	utt=utt.replace('Описание:\n','Описание: ')
	#utt=utt.replace('','')
	#utt=utt.replace('','')
	#utt=utt.replace('','')
	#utt=utt.replace('','')
	L=utt.splitlines()
	for i in L:
		if ': ' in i:
			#try: print win(i)
			#except: print i
			if 'Год' in i: 		info['year'] = i[i.find(': ')+2:]
			if 'Описание' in i: info['plot'] = i[i.find(': ')+2:]
			if 'Жанр' in i: 	info['genre'] = i[i.find(': ')+2:]
			if 'Страна' in i: 	info['studio'] = i[i.find(': ')+2:]
			
	return info

def get_cover(hp):
	hp=hp.replace(chr(13),'')
	hp=hp.replace(chr(10),'')
	hp=hp.replace('<img src="',chr(10)+'<img src="')
	hp=hp.replace('">','">'+chr(10))
	L=hp.splitlines()
	BL = ['banner', 'blacklist']
	for i in L:
		if '.jpg' in i and 'http' in i: 
			n=0
			for b in BL:
				if b in i: n+=1
			
			if n==0: return 'http'+mfind(i, 'http', '.jpg')+'.jpg'


def get_db_id(info):
	sid = lower(info['originaltitle']).replace('.','').replace(',','').replace(':','').replace('-','')+str(info['year'])
	return CRC32(sid)

def torrents(info):
	id = info['id']
	url=httpSiteUrl+'/torrent/'+id
	hp=GET(url)
	if 'margin-bottom: -5px;"><a href="' in hp:
		url2=httpSiteUrl+mfind(hp,'margin-bottom: -5px;"><a href="', '"').replace(' ', '%20')
		#print url2
		return get_list(url2)
	else:
		return [info,]

def serch(t):
	category = '0'
	t=t.replace("%", "%20").replace(" ", "%20").replace("?", "%20").replace("#", "%20")
	url = 'http://www.fast-torrent.ru/search/'+t+'/1.html'
	return get_list(url)



#get_list('http://www.fast-torrent.ru/most-films/')

#get_info('612444')
#get_info('608076')
#get_info('612451')

#torrents('612444')

#serch('матрица')
















