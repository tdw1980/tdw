# -*- coding: utf-8 -*-
import sys, os
import urllib, urllib2

temp_dir = "c:\\"

def ru(x):return unicode(x,'utf8', 'ignore')

def CRC32(buf):
		import binascii
		buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		return str("%08X" % buf)


def GET(url, Referer = 'https://m.knigavuhe.org/', XML=False):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	if XML: req.add_header('x-requested-with', 'XMLHttpRequest')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


def findall(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def get_info(id):
	print id
	try:
		url='https://www.anilibria.tv/release/'+id+'.html'
		i=GET(url)
		
		ogt            = mfind(i,'og:title" content="','" />')
		title          = ogt[ogt.find(' / ')+3:]
		originaltitle  = ogt[:ogt.find(' / ')]
		
		year           = mfind(i,'?date=','">')
		if ' ' in year: year=year[year.find(' ')+1:]
		
		cover          = 'https://www.anilibria.tv'+mfind(i,"detail_torrent_pic' border='0' src='","'")
		fanart         = cover
		plot           = mfind(i,'og:description" content="','"')
		gt             = mfind(i,'<b>Жанры:</b>','<br/>')
		#print gt
		Lg = findall(gt,"'>",'</')
		genre = ""
		for g in Lg:
			genre=genre+g.replace("'>", '')+", "
		genre=genre[:-2]
		info = {
			'title':title,
			'originaltitle':originaltitle,
			'year':year,
			'fanart':fanart,
			'cover':cover,
			'plot':plot,
			'genre':genre,
			'id':id,
			}
		#print info
		return info
	except:
			info = {
			'title':id,
			'originaltitle':id,
			'year':'1999',
			'fanart':'',
			'cover':'',
			'plot':'plot',
			'genre':'genre',
			'id':id,
			}
			return info

#get_info('paranormalnoe-byuro-rassledovanij-muhyo-i-rodzhi')


def get_chapters(id):
	print '====get_chapters===='
	url='https://m.knigavuhe.org/book/'+id
	print url
	hp=GET(url)
	if 'book_blocked_info' in hp: return [{'title': 'Доступ к книге ограничен по просьбе правообладателя.', 'author': 'author', 'duration': 0, 'cover':'', 'url':''}]
	try:cover=mfind(hp,'<img src="','" alt=')
	except: cover=''
	data='[{'+mfind(hp,', [{','],')+']'
	L=eval(data.replace('\\/','/'))
	LL=[]
	for i in L:
		i['cover']=cover
		LL.append(i)
	return LL

#get_chapters('peremeshhennoe-lico')

def get_books(url):
	print '===get_books==='
	print url
	hp=GET(url, XML=True)
	#print hp
	L=findall(hp, 'bookitem\\', '\\n\\n  \\n')
	LL=[]
	for i in L:
		i=i.replace('\\/','/').replace('\\"','"')
		print '=========================================='
		print i
		book_id=mfind(i,'/book/', '/')
		print book_id
		cover=mfind(i,'src="', '"')
		print cover
		title=mfind(i,'" class="bookitem_name">', '<').strip()
		print title
		duration=mfind(i,'meta_time\">', '<')
		print duration
		gbl=mfind(i,'<a href="/genre/', '<')
		print gbl
		genre_id=gbl[:gbl.find('/">')]
		genre   =gbl[gbl.find('/">')+3:]
		abl=mfind(i,'<a href="/author/', '<')
		print abl
		author_id=abl[:abl.find('/">')]
		author   =abl[abl.find('/">')+3:]
		rbl=mfind(i,'<a href="/reader/', '<')
		print rbl
		reader_id=rbl[:rbl.find('/">')]
		reader   =rbl[rbl.find('/">')+3:]
		LL.append({'book_id':book_id, 'cover': cover, 'title': title, 'duration': duration, 'genre_id': genre_id, 'genre': genre, 'author_id': author_id, 'author': author, 'reader_id': reader_id, 'reader': reader})
	return LL

#url='https://m.knigavuhe.org/genre/detektivy-trillery/2/?pn=1'
#get_books(url)

def get_autors(p):
	url='https://m.knigavuhe.org/authors/'+str(p)+'/?pn=1'
	hp=GET(url, XML=True)
	L=findall(hp, '<a href=', '<\\/div>\\n')
	LL=[]
	for i in L:
		i=i.replace('\\/','/').replace('\\"','"')
		print '=========================================='
		#print i
		author_id=mfind(i,'author/', '/')
		print author_id
		author=mfind(i,'item_name">', '<')
		print author
		book_count=mfind(i,'item_count">', '<')
		print book_count
		LL.append({'author_id': author_id, 'author': author, 'book_count': book_count})
	return LL

#get_autors(1)

def get_genres():
	url='https://m.knigavuhe.org/genres/'
	hp=GET(url).replace('\n','').replace('\t','')
	L=findall(hp, '<a href=" /genre/', '</div>')
	LL=[]
	for i in L:
		if 'genre_item_name' in i:
			print '=========================================='
			#print i
			genre_id  =mfind(i,'/genre/', '/')
			genre     =mfind(i,'item_name">', '<')
			
			book_count=mfind(i,'item_count">', '<')
			print book_count
			print genre_id
			print genre

			LL.append({'genre_id': genre_id, 'genre': genre, 'book_count': book_count})
	return LL

#get_genres()

def seach_books(q):
	url='https://m.knigavuhe.org/search/?q='+q.replace(' ','+')
	hp=GET(url)
	L=findall(hp, 'class="bookitem"', 'bookitem_meta_bottom_block')
	LL=[]
	for i in L:
		if 'bookitem_name' in i:
			print '=========================================='
			print i
			i2=i.replace('<span class="highlight_keyword">','').replace('</span>','')
			book_id=mfind(i,'/book/', '/')
			print book_id
			cover=mfind(i,'src="', '"')
			print cover
			title=mfind(i2,'" class="bookitem_name">', '<').strip()
			print title
			duration=mfind(i,'meta_time">', '<')
			print duration
			gbl=mfind(i,'<a href="/genre/', '<')
			print gbl
			genre_id=gbl[:gbl.find('/">')]
			genre   =gbl[gbl.find('/">')+3:]
			abl=mfind(i,'<a href="/author/', '<')
			print abl
			author_id=abl[:abl.find('/">')]
			author   =abl[abl.find('/">')+3:]
			rbl=mfind(i,'<a href="/reader/', '<')
			print rbl
			reader_id=rbl[:rbl.find('/">')]
			reader   =rbl[rbl.find('/">')+3:]
			LL.append({'book_id':book_id, 'cover': cover, 'title': title, 'duration': duration, 'genre_id': genre_id, 'genre': genre, 'author_id': author_id, 'author': author, 'reader_id': reader_id, 'reader': reader})
	return LL

#seach_books('маг')

def seach_authors(q):
	url='https://m.knigavuhe.org/search/authors/?any_word=1&q='+q.replace(' ','+')
	hp=GET(url)
	L=findall(hp, '<a href="/author', '</a>')
	LL=[]
	for i in L:
		if 'item_name' in i:
			i=i.replace('<span class="highlight_keyword">','').replace('</span>','')
			print '=========================================='
			#print i
			author_id=mfind(i,'author/', '/')
			print author_id
			author=mfind(i,'item_name">', '<').strip()
			print author
			book_count=mfind(i,'item_count">', '<').strip()
			print book_count
			LL.append({'author_id': author_id, 'author': author, 'book_count': book_count})
	return LL

#seach_authors('маг')