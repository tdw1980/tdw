# -*- coding: utf-8 -*-
import sys, os, time
#import  urllib2, urllib
domen = 'http://filmpotok.com'#www.

if sys.version_info.major > 2:  # Python 3 or later
	import urllib.request
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote_plus as unquote
	import urllib2

def b2s(s):
	if err_torrent(s)==False: return s
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def err_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False

def ru(x):return unicode(x,'utf8', 'ignore')

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def findall(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L


def POST(target, post=None, referer=domen, XML=False):
	try:
		if sys.version_info.major > 2: post = post.encode()
		req = urllib2.Request(url = target, data = post)
#		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36 OPR/55.0.2994.61')
#		req.add_header('Accept', '*/*')
#		req.add_header('Accept-Encoding', 'gzip, deflate')
		req.add_header('Referer', referer)
		if XML: req.add_header('X-Requested-With', 'XMLHttpRequest')
		resp = urllib2.urlopen(req)
		http = b2s(resp.read())
		resp.close()
		return http
	except:
		print ('POST err')
		return ''

def GET(url, referer=domen):
	req = urllib2.Request(url)
	req.add_header('Referer', referer)
#	req.add_header('X-Requested-With', 'XMLHttpRequest')
#	req.add_header('Content-Type', 'application/x-www-form-urlencoded')
	response = urllib2.urlopen(req)
	link=b2s(response.read())
	response.close()
	return link

def get_link(cat='film', sort='pop', cantry='en'):
	
	if   sort=='pop':  sr='sort=2'
	elif sort=='best': sr='sort=8'
	else:              sr='sort=' #('new')
	
	if cat   =='film': 
		if cantry=='ru':   category = 'russian'
		else:              category = 'zarubezhnyj-film'
	elif cat =='series':
		if cantry=='ru':   category = 'russian-tv/tv'
		else:              category = 'foreign-tv/tv'
	elif cat == 'mult':
		if   cantry=='ru': category = 'russkie-multfilmy/multfilm'
		elif cantry=='jp': category = 'anime/multfilm/'
		elif cantry=='su': category = 'sovetskie-multfilmy/multfilm'
		else:              category = 'zarubezhnye-multfilmy/multfilm'
	elif cat == 'mult_sr':
		if   cantry=='ru': category = 'russkie-multfilmy/multfilm/ru/multserialy'
		elif cantry=='jp': category = 'anime-serialy/multfilm'
		else:              category = 'multserialy/multfilm/'
	elif cat == 'doc':
		if   cantry=='ru': category = 'new/documentary/ru/'
		else:              category = 'last/documentary/'
		
	elif cat == 'music':   category = 'latest/music/'

	url=domen+'/'+category+'/?'+sr+'&pages=50'
	return url

def get_most_link(cat='film', sort='pop', cantry='en'):
	c_year = str(time.gmtime()[0])
	
	if   sort=='pop':  sr='sort=2'
	elif sort=='best': sr='sort=8'
	else:              sr='sort=' #('new')
	
	if cat   =='film': 
		if cantry=='ru':   category = 'most-films/ru/-/-'
		else:              category = 'zarubezhnyj-film/-'
	elif cat =='series':
		if cantry=='ru':   category = 'russian-tv/tv/-'
		else:              category = 'foreign-tv/tv/-'
	elif cat == 'mult':
		if   cantry=='ru': category = 'russkie-multfilmy/multfilm/-'
		elif cantry=='jp': category = 'anime/multfilm/'
		elif cantry=='su': category = 'sovetskie-multfilmy/multfilm/-'
		else:              category = 'zarubezhnye-multfilmy/multfilm/-'
	elif cat == 'mult_sr':
		if   cantry=='ru': category = 'russkie-multfilmy/multfilm/ru/multserialy/-'
		elif cantry=='jp': category = 'anime-serialy/multfilm/-'
		else:              category = 'multserialy/multfilm/'
	elif cat == 'doc':
		if   cantry=='ru': category = 'new/documentary/ru/'
		else:              category = 'last/documentary/'
		
	elif cat == 'music':   category = 'latest/music/'
	
	url=domen+'/'+category+'/'+c_year+'/?'+sr+'&pages=50'
	return url

def get_items(html):
	L=findall(html, '<div itemscope itemtype=', '</em></div></div></div>')
	LL=[]
	for i in L:
		info=get_info(i)
		LL.append(info)
	return LL

def get_info(t):
	url     = domen+mfind(t, '><a href="', '"').replace(".html", "/torrents.html")
	cover   = mfind(t, 'background: url(', ')"')
	title   = mfind(t, 'itemprop="name">', '<')
	year    = mfind(mfind(t, 'itemprop="name">'+title, '<br/>'), '(', ')')
	plot    = mfind(t, 'class="film-announce">', '<').replace('<p>','')
	director= mfind (t[t.find('<strong>Режиссер</strong>'):], 'itemprop="actor">', '<')
	try:   rating  = float(mfind(t, "average='", "'"))
	except:rating = 0
	
	if 'alternativeHeadline' in t: 
		ortitle = mfind(t, 'alternativeHeadline">', '<')
	else:
		ortitle = title

	cast=[]
	Lcast    = findall(t[t.find('<strong>В ролях</strong>'):], 'itemprop="actor">', '</a>')
	for c in Lcast:
		cast.append(c[17:])
	
	genre=''
	Lg   = findall(t, 'itemprop="genre" >', '</a>, <')
	for g in Lg:
		if '<' in g: g=g[:g.find('<')]
		if len(g)>18: genre+=g[18:]+"; "
	
	
	country = mfind(mfind(t, '<em class="cn-icon', '<'), "title='", "'")
	
	if 'fo-icon copyright-problem' in t: url ='http://127.0.0.1:8095/proxy/'+url
	
	info = {"title": title,
			"originaltitle": ortitle,
			"director": director,
			"studio": country,
			"rating": rating,
			"genre": genre,
			"cover": cover,
			"cast":  cast,
			"year": year, 
			"plot": plot,
			"url": url
			}
	return info


def torrents(url):
	http=GET(url)
	#L=findall(http,'torrent-row open','class="box"')
	L=findall(http,'upload1','torrent-info hidden')
	L3=[]
	for i in L:
		qa  = i[i.find("title='")+7:i.find(" :: ")]
		sez =''
		lng1 =''
		lng2 =''
		sz  ='0'
		dt  = '0'
		dl  = '0'
		tor = ''
		lich= '0'
		sl  = '--/--'

		ss="<div class='c"
		es='</div>'
		L2=findall(i, ss, es)
		sid=mfind(i,"<em class='upload-icon l","'><")
		if len(sid) > 5: sids = '?'
		for j in L2:
			j=j.replace("&nbsp;"," ")
			if "class='c9'" in j: sez = j[j.find("'>")+2:].replace('</b>','').replace('<b>','').replace('    ',' ').replace('  ',' ').replace('  ',' ').replace('\t','').replace(chr(13),"").replace(chr(10),"").replace("<br/>",", ")
			if "class='c10" in j: lng1 =j[j.find("<b>")+3:j.find("</b>")]
			if "class='c10" in j: lng2 =j[j.find('blank">')+7:j.find("</a>")]
			if "class='c3'" in j: sz  = j[j.find("'>")+2:]
			if "class='c4'" in j: dt  = j[j.find("'>")+2:]
			if "class='c5'" in j: dl  = j[j.find("'>")+2:]
			if "class='c7'" in j: tor = domen+j[j.find("/download"):j.find('" class=')]
			#if "class='c6'" in j: 
			#					  sid = j[j.find("▲ ")+4:j.find("</font>")]
			#					  lich= j[j.find("▼ ")+4:j.rfind("</font>")]
			#					  if 'c6' in sid: sid= '0'
			#					  if 'c6' in lich: lich= '0'
			#					  sl  = sid+' / '+lich
			if "class='c2" in j: lng1 =j[j.find("<b>")+3:j.find("</b>")]
			if "class='c2" in j and 'blank">' in j : lng2 =j[j.find('blank">')+7:j.find("</a>")]
			if "убтитры" in lng1: lng1 = 'Субтитры'
			if "убтитры" in lng2: lng2 = ''
			if "усский"  in lng1: lng1 = 'Русский'
			if "усский"  in lng2: lng2 = ''
			if "<b>"  in lng1: lng1 = mfind(lng1,"<b>","<")
			if "<b>"  in lng2: lng2 = mfind(lng2,"<b>","<")
			if lng1 == lng2: lng2=''
			if 'МБ' in sz: sz=sz[:sz.find('.')]+' MB'
		#print (" | "+qa+" | "+sez+" | "+lng1+" | "+lng2+" | "+sz+" | "+dt+" | "+dl+" | "+tor+" | "+sl)
		L3.append({'season':sez,'lng1':lng1,'lng2':lng2,'size':sz,'data':dt,'down':dl,'sid':sid,'lich':lich,'url':tor,'quality':qa})
	return L3

#torrents('http://filmpotok.ru/film/novaya-politsejskaya-istoriya/torrents.html')

def seach(t):
	url=domen+'/search/'+quote(t)+'/1.html'#urllib.urlencode(t)
	html=GET(url)
	return get_items(html)


def filtr(type='1', rating='1', year='', country='', genre='', sort='2'):
	url=domen+'/search/-/50/1.html'
	post='search_page=1&search_pages=50&keyword=&captcha_0=&captcha_1=&captcha_2=&up_celebrity=0'
	if type!='':
		post+='&type='+type
	if country!='':
		post+='&countries='+country
	if genre!='':
		post+='&genre='+genre
	post+='&from_rating='+rating
	post+='&to_rating=10'
	post+='&sort='+sort
	post+='&search_pages_set=15'
	if year!='':
		post+='&from_date='+year
		post+='&to_date='+year
	
	rez = POST(url, post, domen+'/search.html', True)
	html=eval(rez)['content']
	return get_items(html)
	
	'''
	L=eval(POST(url, post))['content']#['results']['matches']
	L2=[]
	for i in L:
		L2.append(str(i['id']))
	return L2
	'''