# coding: utf-8
# Module: server
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer
import threading, SocketServer, BaseHTTPServer
quit_event = threading.Event()


import sys, os, json
import time
import urllib, urllib2, socket
#import base64

import settings
import core
import hls

try:
	import xbmcaddon
	addon = xbmcaddon.Addon(id='ptv3')
	root_dir = addon.getAddonInfo('path')
except:
	root_dir = os.getcwd()

#settings.set('port', 8185)
try: port = int(settings.get('port'))
except: 
	port = 8185
	settings.set('port', 8185)
if port=='': 
	port = 8185
	settings.set('port', 8185)

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def get_ip():
	IP = settings.get('ip')
	if IP == '' or settings.get('ip_chek')!='false':
		if 'win' in sys.platform:
			try:IP = socket.gethostbyname_ex(socket.gethostname())[2][0]
			except: IP = '127.0.0.1'
		else:
			try:
				Ln = []
				for n in range(5):
					Ln.append('enp'+str(n)+'s0')
					Ln.append('wlp'+str(n)+'s0')
				for f in Ln:
					r = os.popen('ip addr show '+f).read()
					if 'inet ' in r:
						ip = mfind(r,'inet ','/')
						if '192.168.' in ip: 
							IP = ip
							break
			except: IP = '127.0.0.1'
		settings.set('ip', IP)
	return IP


ip = get_ip()


print('----- Starting PTV3 -----')
print('HELP:     http://'+ip+':'+str(port))
print('PLAYLIST: http://'+ip+':'+str(port)+'/playlist')
trigger = True


# =========================== Базовые функции ================================
def fs_enc(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode('utf-8').encode(sys_enc)

def fs_dec(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode(sys_enc).encode('utf-8')

def lower(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in range (65,90):
		t=t.replace(chr(i),chr(i+32))
	for i in RUS.keys():
		t=t.replace(i,RUS[i])
	return t

def utf(t):
	try:t=t.decode('windows-1251')
	except: pass
	try:t=t.decode(sys.getfilesystemencoding())
	except: pass
	try:t=t.encode('utf-8')
	except: pass
	return t

def win(t):
	try:t=t.decode('utf-8')
	except: pass
	try:t=t.decode(sys.getfilesystemencoding())
	except: pass
	try:t=t.encode('windows-1251')
	except: pass
	return t

def upper(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in RUS.keys():
		t=t.replace(RUS[i],i)
	for i in range (65,90):
		t=t.replace(chr(i+32),chr(i))
	return t

def CRC32(buf):
		import binascii
		buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		return str("%08X" % buf)

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2
	
def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "w")
	fl.write(s)
	fl.close()









# ================================ server =====================================
set_list=[
	'Id_port',
	'Id_ip',
	'Id_unlock',
	'Id_split_1',
	'Id_split_2',
	'Id_split_3',
	'Id_serv21',
	'Id_serv31',
	'Id_serv37',
	'Id_serv52',
	'Id_serv53',
	'Id_serv12',
	'Id_serv15',
	'Id_serv10',
	'Id_serv5']

tr_list=[
	'tr_unlock',
	'tr_p2p_start',
	'tr_ip_chek',
	'tr_addcnl',
	'tr_upd21',
	'tr_upd31',
	'tr_upd37',
	'tr_upd52',
	'tr_upd53',
	'tr_split_1',
	'tr_split_2',
	'tr_split_3',
	'tr_serv21',
	'tr_serv31',
	'tr_serv37',
	'tr_serv52',
	'tr_serv53',
	'tr_serv12',
	'tr_serv15',
	'tr_serv10',
	'tr_serv5']

upt_list=[
	'Id_upt21',
	'Id_upt31',
	'Id_upt37',
	'Id_upt52',
	'Id_upt53',
	'Id_upt12',
	'Id_upt15',
	'Id_upt10',
	'Id_upt5']

btn_list=['btn_upd53',]

ib_list=[
	'ib_port',
	'ib_ip',
	'ib_p2p_serv',
	]

for pid in range(99):
	sid=str(99-pid)
	#upt_list.append('Id_upt'+sid)
	tr_list.append ('tr_serv'+sid)
	tr_list.append ('tr_upd'+sid)
	set_list.append('Id_serv'+sid)
	btn_list.append('btn_upd'+sid)

fl = open(os.path.join(root_dir,"webui.htm"), "r")
temp_ui=fl.read()
fl.close()

def splitter(ui):
	Ls=['split_1','split_2','split_3']
	for id in Ls:
		if settings.get(id) == 'false':
			ui=ui.replace('<!--s_'+id+'-->', '<!--')
			ui=ui.replace('<!--e_'+id+'-->', '-->')
	return ui

import controls
def WebUI():
		
		ui=temp_ui
		if settings.get('ip_chek')!='false': 
			get_ip()
			ui=ui.replace('ib_ip', 'Id_ip')
		for i in set_list:
			id = i[3:]
			s = str(settings.get(id))
			if s=='true':  s = "<span style='color:green'>V</span>"
			if s=='false': s = "<span style='color:red'>X</span>"
			ui=ui.replace(i, s)
	
		for i in tr_list:
			id = i[3:]
			val = str(settings.get(id))
			s = controls.trigger('/settings/set/'+id+'/val/'+val)
			ui=ui.replace(i, s)
		
		for i in ib_list:
			id = i[3:]
			val = str(settings.get(id))
			s = controls.input('/settings/set/'+id+'/val/', val)
			ui=ui.replace(i, s)
		
		for i in btn_list:
			id = i[7:]
			s = controls.buton('/update/'+id)
			ui=ui.replace(i, s)
		
		for i in upt_list:
			id = i[6:]
			tm = core.get_cahe_time(id)
			tm = time.strftime('%H:%M %d.%m.%y',time.localtime(core.get_cahe_time(id)))
			#tm=
			ui=ui.replace(i, tm)
			
			s = str(settings.get('upd'+i[6:]))
			if s=='true': s = "<span style='color:green'>V</span>"
			if s=='false': s = "<span style='color:red'>X</span>"
			ui=ui.replace(i.replace('upt','up'), s)

		total=str(len(core.channels('all')))
		try:total=str(len(core.channels('all')))
		except: total='err'
		ui=ui.replace('Id_total', total)
		ui = splitter(ui)
		return ui

def editor():
		fl = open(os.path.join(root_dir,"webui.files", "cnl.htm"), "r")
		data = fl.read()
		fl.close()
		L = core.get_base()#get_DBC()#channels('all')
		items=''
		for i in L:
			gr=''
			for g in i['group']:
				gr+=" | "+g
			gr=gr[3:]
			if i['enable']: option="[V]"
			else:           option="[X]"
			option+=" [U]"
			if i['split']: option+=" [S]"
			else:          option+=" [Sp]"
			if i['enable']:option+=" [I]"
			itm = controls.item({'name':i['title'],'cid':i['id'],'group':gr,'option':option, 'enable':i['enable']})
			try:
				items+=itm
			except:
				print 'err item'
		
		return data.replace('<!--items-->',items) 

def info(id):
		fl = open(os.path.join(root_dir,"webui.files", "info.htm"), "r")
		data = fl.read()
		fl.close()
		inf=""
		inf = core.DBC[id]
		data=data.replace('[ID]', id)
		data=data.replace('[NAME]', win(inf['title']))
		gr=''
		for g in core.get_cn_groups(id):
				gr+=" | "+g
		gr=gr[3:]
		data=data.replace('[GROUP]', win(gr))
		img = "<img border=0 width=120 height=120 src='http://td-soft.narod.ru/logo/picon/"+id+".png'>"
		data=data.replace('[IMG]', img)
		
		LL=[]
		D=core.get_serv_dict()
		for s in D.keys():
			L=D[s]
			for i in L:
				if core.get_ID(i['title']) == id: LL.append({'serv': s, 'url': i['url']})
		
		items=''
		for j in LL:
			itm = controls.item4(j)
			items+=itm
		
		data=data.replace('<!--items-->', items)
		return data

def unite_gr(id1):
		fl = open(os.path.join(root_dir,"webui.files", "unite_gr.htm"), "r")
		data = fl.read()
		fl.close()
		
		items=''
		L=core.open_Groups()
		id2=0
		for i in L:
			if id2 == id1:
				data=data.replace('[TITLE]', i[0])
			else:
				img = '/webui.files/space.jpg'
				itm = controls.item2("/group/"+str(id1)+"/unite/"+str(id2), i[0], img)
				try:
					items+=itm
				except:
					print 'err item'
			id2+=1
		
		data=data.replace('<!--items-->', items)
		
		return data

def unite(id1):
		fl = open(os.path.join(root_dir,"webui.files", "unite.htm"), "r")
		data = fl.read()
		fl.close()
		
		items=''
		L=core.get_DBC()
		for i in L:
			if i['id'] == id1:
				data=data.replace('[TITLE]', i['title'])
			else:
				img = 'http://td-soft.narod.ru/logo/picon/'+i['id']+'.png'
				itm = controls.item2("/channel/"+id1+"/unite/"+i['id'], i['title'], img)
				try:
					items+=itm
				except:
					print 'err item'
		
		data=data.replace('<!--items-->', items)
		
		return data

def split(id1):
		fl = open(os.path.join(root_dir,"webui.files", "split.htm"), "r")
		data = fl.read()
		fl.close()
		
		items=''
		i=core.DBC[id1]
		data=data.replace('[TITLE]', i['title'])
		L=i['names']
		for nm in L:
				img = '/webui.files/spl.jpg'
				itm = controls.item2("/channel/"+id1+"/split/"+nm, nm, img)
				try:
					items+=itm
				except:
					print 'err item'
		
		data=data.replace('<!--items-->', items)
		
		return data

def groups():
		fl = open(os.path.join(root_dir,"webui.files", "gr.htm"), "r")
		data = fl.read()
		fl.close()
		L=core.open_Groups()
		
		data=data.replace('[NEW]', controls.input('/group/add/', '', 250))
		items=''
		id=0
		for i in L:
			try: lock = i[2]
			except: lock = 'false'
			itm = controls.item3({'name':i[0], 'list':i[1], 'id': id, 'lock':lock})
			items+=itm
			id+=1
		return data.replace('<!--items-->',items) 



from threading import Thread
class MyThread(Thread):
	def __init__(self, param):
		Thread.__init__(self)
		self.param = param
	
	#def run(self):
	#	update_Lt(pztv.get_stream(self.param))

def create_thread(param):
		my_thread = MyThread(param)
		my_thread.start()


class HttpProcessor(BaseHTTPRequestHandler):
	
	def do_GET(self):
		data=get_on(self.path)
		try: head = data[:4]
		except: head = '    '
		
		if data == 'ERR 404':
			self.send_response(404)
		else:
			if head =='http' or head[0] =='/':
				self.send_response(302)
				self.send_header('Location', data)
				self.send_header('content-type','image/jpeg')
			elif 'JFIF' in data:
				self.send_response(200)
				self.send_header('content-type','image/jpeg')
			else:
				self.send_response(200)
				self.send_header('content-type','text/html')
		
		self.end_headers()
		
		if head[:3]=='BS:': 
			import bitstream
			curl=data[3:]
			BS=bitstream.BS(curl)
			for i in range(1000):
					part=BS.get_data()
					if part !=None: 
						self.wfile.write(part)
		
		elif head[:3]=='HLS': 
			import hls
			curl=data[4:]
			print curl
			HLS=hls.HLS(curl)#'https://strm.yandex.ru/kal/fashiontv/fashiontv0_169_1080p.json/index-v1-a1.m3u8?partner_id=270171&target_ref=https%3A%2F%2Fyastatic.net&uuid=42ee5f579c38ea04a6d92ccefdbeed99&vsid=ojhxcxb2wxf48pv&redundant=5'
			for i in range(1000):
					part=HLS.get_data()
					if part !=None: self.wfile.write(part)
		else:
			self.wfile.write(data)
		#quit_event.set()

class MyThreadingHTTPServer(SocketServer.ThreadingMixIn, BaseHTTPServer.HTTPServer):
	pass

serv = MyThreadingHTTPServer(("0.0.0.0",port), HttpProcessor)
threading.Thread(target=serv.serve_forever).start()



#===================================================================
fch={}

def get_on(addres):
		print addres
		global trigger
		addres=utf(addres)
		data='ERR 404'
		if addres == "/":
			data = WebUI()#help
		if "/webui.files/" in addres:
			nmf=addres[13:]
			if nmf in fch.keys():
				data = fch[nmf]
			else:
				fl = open(os.path.join(root_dir,"webui.files", nmf), "rb")#
				data = fl.read()
				fl.close()
				fch[nmf]=data
		if "/info/" in addres:
			id=addres[addres.find('/info/')+6:]
			data = info(id)
			
		if "/editor" in addres:
			#if '/editor/' in addres: id=addres[addres.find('/editor/')+8:]
			#else: id=''
			data = editor()
		if 'serv/stop' in addres: 
			trigger = False
			data = 'stop'
		if 'settings/get/' in addres:
			key=addres[addres.find('/get/')+5:]
			data=settings.get(key)
		if 'settings/set/' in addres:
			key=addres[addres.find('/set/')+5:addres.find('/val/')]
			if 'val=' in addres:
				val=urllib.unquote_plus(addres[addres.find('val=')+4:])
			else:
				val=urllib.unquote_plus(addres[addres.find('/val/')+5:])
			data=settings.set(key, val)
			if 'editor_' in addres: data='/editor'#data='http://'+get_ip()+':'+str(port)+'/editor'
			else:                       data='/'#data='http://'+get_ip()+':'+str(port)
		if '/groups' in addres:
			if '/groups/' in addres:
				if '/groups/list' in addres: data = core.groups()
			else:
				data = groups()
		
		if '/group/' in addres:
			try:
				id = int(mfind(addres, '/group/','/'))
				gr = core.open_Groups()[id][0]
			except:
				id = ''
				gr = ''
			if '/add' in addres: 
				if 'val=' in addres: gnm =addres[addres.find('val=')+4:]
				else:                gnm =addres[addres.find('rename/')+7:]
				core.add_gr(utf(urllib.unquote_plus(gnm)))
			if '/lock'    in addres: core.lock_gr(id, 'true')
			if '/unlock'  in addres: core.lock_gr(id, 'false')
			if '/rem'     in addres: core.rem_gr(gr)
			if '/up'      in addres: core.move_gr(id, id-1)
			if '/down'    in addres: core.move_gr(id, id+1)
			if '/rename'  in addres: 
				if 'val=' in addres: gnm =addres[addres.find('val=')+4:]
				else:                gnm =addres[addres.find('/add/')+5:]
				core.rename_gr(id, utf(urllib.unquote_plus(gnm)))
			data='/groups'
			
			if '/unite' in addres:
				if '/unite/' in addres:
					id2 = int(addres[addres.find('/unite/')+7:])
					core.unite_gr(id, id2)
				else:
					data=unite_gr(id)

		if '/channels/dict' in addres:
			data = core.channels('all')
		if '/channels/json' in addres:
			data = core.jsonlist()
		if '/channels/tvh' in addres:
			data = core.tvhlist()
		if '/channels/list' in addres or '/playlist' in addres:
			if 'list/' in addres:  id=addres[addres.find('list/')+5:]
			else: 						id = ''
			if id == '': data = core.playlist()
			else:        data = core.playlist(id)
			
		if '/channel/' in addres:
			id1 = mfind(addres, '/channel/','/')
			if '/add' in addres: core.add_to_base(id1)
			if '/rem' in addres: core.rem_from_base(id1)
			if '/rename' in addres: 
				if 'val=' in addres: cnm =addres[addres.find('val=')+4:]
				else:                cnm =addres[addres.find('rename/')+7:]
				core.rename_cnl(id1, urllib.unquote_plus(cnm))
			if '/set_group/' in addres: 
				if 'val=' in addres: gs =addres[addres.find('val=')+4:]
				core.set_group_cnl(id1, urllib.unquote_plus(gs))
				
			data='/editor#'+id1#'http://'+get_ip()+':'+str(port)+'/editor'#+'/'+id1
			
			if '/unite' in addres:
				if '/unite/' in addres:
					id2 = addres[addres.find('/unite/')+7:]
					core.unite_cnl(id1, id2)
				else:
					data=unite(id1)
			
			if '/split' in addres: 
				if '/split/' in addres:
					nm = urllib.unquote_plus(addres[addres.find('/split/')+7:])
					core.split_cnl(id1, nm)
				else:
					data=split(id1)
			
		if '/stream/' in addres:
			id=addres[addres.find('stream/')+7:]
			redir=core.stream(id)
			if redir=='': data="ERR 404"
			else:         data=redir
			
		if '/restream/' in addres:
			id=addres[addres.find('restream/')+9:]
			stream=core.stream(id)
			if '/ace/' in stream: data='BS:'+stream
			else:                 data='HLS:'+stream
			print data
		if '/streams/' in addres:
			if '/streams/json' in addres:
				id=addres[addres.find('json/')+5:]
				data=core.json_streams(id)
			elif '/streams/list' in addres:
				id=addres[addres.find('list/')+5:]
				data=core.streams(id)
			else:
				id=addres[addres.find('streams/')+8:]
				data=core.sublist(id)
		if '/update/' in addres:
			id=addres[addres.find('/update/')+8:]
			core.upd_canals_by_id(id)
			data='/'#'http://'+get_ip()+':'+str(port)
		'''
		elif 'arh/json' in addres:
			data=arh_jsonlist()
		
		elif 'arh/channel/' in addres:
			if '/day/' in addres:
				day=addres[addres.find('/day/')+5:]
				id=addres[addres.find('channel/')+8:addres.find('/day/')]
			else:
				day='0'
				id=addres[addres.find('channel/')+8:]
			data=arh_items(id, day)

		elif 'arh/streams/' in addres:
			id=addres[addres.find('streams/')+8:]
			data=arh_streams(id)
		'''
		return data

#===================================================================

def abortRequested():
	try: 
		import xbmc
		r=xbmc.abortRequested
	except:
		r=False
	return r

print('----- PTV3_serv OK -----')
while trigger:
			if abortRequested(): break
			time.sleep(1)
			

try:serv.shutdown()
except:pass

print('----- PTV3_serv stopped -----')

