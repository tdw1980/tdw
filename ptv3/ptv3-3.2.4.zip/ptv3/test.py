def test_url(url):
	import urllib2
	#url=url.replace('ace/getstream', 'ace/manifest.m3u8')
	
	try:
		url=url.replace('ace/getstream?', 'ace/getstream?format=json&')
		response = urllib2.urlopen(url, timeout=16)
		return response.getcode()
	except:
		return 'err404'

#print test_url('http://127.0.0.1:6878/ace/getstream?id=18353975b420a87b2ec7f55aa9561cc00faf3a85')

import socket
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.connect(("gmail.com",80))
print(s.getsockname()[0])
s.close()

import os
import re
ip = re.search(re.compile(r'(?<=inet )(.*)(?=\/)', re.M), \
os.popen('ip addr show enp2s0').read()).groups()[0]
ADDR = (ip)
print ADDR