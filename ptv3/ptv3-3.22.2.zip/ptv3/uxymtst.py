#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys, urllib2, socket
import time, random
#strmlist = []
strmdict = {}
strmdict2 = {}
from threading import Thread
class MyThread(Thread):
	def __init__(self, param={}):
		self.url = param['url']
		self.sid = param['sid']
		self.sts = param['status']
		Thread.__init__(self)
	
	def run(self):
		if self.sid in strmdict.keys():
			#if test(self.url) != '404': strmdict[self.sid].append(self.url)
			status = get_status(self.url)
			if status >= self.sts: 
				if self.sid in strmdict.keys():
					if test(self.url) != '404': strmdict[self.sid].append(self.url)
			elif status >-1 :
				if self.sid in strmdict2.keys():
					if test(self.url) != '404': strmdict2[self.sid].append(self.url)

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def findall(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def scan_port(url):
	ip   = mfind(url,'//',':')
	port = int(mfind(url, ip+':','/'))
	print ip+':'+str(port)
	sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	sock.settimeout(0.1)
	try:
		connect = sock.connect((ip,port))
		try: connect.close()
		except: pass
		return True
	except:
		return False

def get_status(url):
	url2 = url[:url.find('/udp/')]+'/status'
	urllib2.install_opener(urllib2.build_opener())
	try:
		response = urllib2.urlopen(url2, timeout=1)
		if response.getcode() != 200: return -1
		data=response.read()
		L=findall(data, '<td>', '</td>')
		clients=int(L[3][4:])
		if clients> 0: print (url2+" "+str(clients))
		return clients
	except:
		return -1

def test(url):
	#if scan_port(url) == False: return '404'
	#print url
	urllib2.install_opener(urllib2.build_opener())
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 OPR/77.0.4054.203')
		response = urllib2.urlopen(req, timeout=3)
		r=response.getcode()
		if r != 200: return '404'
		data=response.read(64)#128
		#print repr(data)
		if str(data[0]) == 'G':
			#print 'GOOD'
			return '200'
		else:
			#print 'BAD'
			return '404'
	except:
		#print 'BAD'
		return '404'


def test2(url):
	#print url
	urllib2.install_opener(urllib2.build_opener())
	try:
		response = urllib2.urlopen(url, timeout=4)
		r=response.getcode()
		if r != 200: return '404'
		data=response.read()#128
		#print repr(data)
		if 'udpxy v' in data:
			#print 'GOOD'
			return '200'
		else:
			#print 'BAD'
			return '404'
	except:
		#print 'BAD'
		return '404'
#test('http://5.137.93.186:1234/udp/233.7.70.5:5000')225.54.205.132:5000

def test_f(url):
	if scan_port(url) == False: return '404'
	else: return '200'

def multitest (L, st=-1):
	if len(L)==0: return []
	if len(L)==1: 
		url=L[0]
		if test(url)!= '404': return [url]
		else: return []
	sid = random.randint(100000, 999999)
	strmdict[sid]=[]
	strmdict2[sid]=[]
	L2=[]
	random.shuffle(L)
	for url in L:
		if len(strmdict[sid])>2: break
		if url not in L2:
			L2.append(url)
			my_thread = MyThread({'url':url, 'sid': sid, 'status': st})
			my_thread.start()
			time.sleep(0.03)
			if len(strmdict[sid])>2: break
			#if test_f(url) != '404': strmdict[sid].append(url)
	
	if len(strmdict[sid])<2:time.sleep(1)
	if len(strmdict[sid])<1:time.sleep(0.5)
	if len(strmdict[sid])<1:time.sleep(0.5)
	if len(strmdict[sid])<1:time.sleep(0.5)
	if len(strmdict[sid])<1:time.sleep(0.5)
	
	if len(strmdict[sid])==0: strmlist = strmdict2[sid]
	else: strmlist = strmdict[sid]
	
	del strmdict[sid]
	del strmdict2[sid]
	print 'GOOD: '+ str(len(strmlist))
	if len(strmlist)>3: strmlist=strmlist[:3]
	return strmlist

#print multitest (['http://5.137.42.20:1234/udp/225.54.205.132:5000', 'http://5.137.93.152:1234/udp/225.54.205.132:5000', 'http://5.137.114.112:1234/udp/225.54.205.132:5000', 'http://5.137.120.180:1234/udp/225.54.205.132:5000', 'http://92.127.145.239:1234/udp/225.54.205.132:5000', 'http://92.127.183.253:1234/udp/225.54.205.132:5000', 'http://92.127.197.162:1234/udp/225.54.205.132:5000'])
