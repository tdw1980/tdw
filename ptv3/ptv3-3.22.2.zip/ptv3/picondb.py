# coding: utf-8
import urllib, urllib2, ssl

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def findall(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def getURL3(url,Referer = 'http://emulations.ru/'):
	urllib2.install_opener(urllib2.build_opener()) 
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def POST(target, post=None, referer=''):
	#print target
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36 OPR/72.0.3815.400')
		#req.add_header('Accept-Encoding', 'gzip, deflate, br')
		#req.add_header('Referer', referer)
		#req.add_header('X-Requested-With', 'XMLHttpRequest')
		#req.add_header('content-type', 'application/x-www-form-urlencoded; charset=UTF-8')
		resp = urllib2.urlopen(req, context=ctx)
		if resp.info().get('Content-Encoding') == 'gzip':
			from StringIO import StringIO
			import gzip
			buf = StringIO(resp.read())
			f = gzip.GzipFile(fileobj=buf)
			data = f.read()
		else:
			data=resp.read()
		resp.close()
		return data
	except Exception, e:
		print 'err'
		print e
		return ''

def get(t):
	t=t.replace(' HD', '').replace('(+1)', '').replace('(+2)', '').replace('(+3)', '').replace('(+4)', '').replace('(+5)', '').replace('(+6)', '').replace('(+7)', '').replace('(+8)', '')
	post='search='+urllib.quote_plus(t)
	h=POST('https://programma-peredach.com/search/', post)
	L=findall(h,'<img src="/img/ch', '.gif"')
	L2=[]
	for i in L:
		#L2.append(i.replace('<img src="','https://programma-peredach.com')+'.gif')
		L2.append(i.replace('<img src="','https://programma--peredach-com.translate.goog')+'.gif')
	L2.extend(get2(t))
	return L2



def get2(title):
	try:
		print ('== select_icon ==')
		#if " TV" not in title: title=title+" TV"
		title=title.replace(' HD', '').replace('(+1)', '').replace('(+2)', '').replace('(+3)', '').replace('(+4)', '').replace('(+5)', '').replace('(+6)', '').replace('(+7)', '').replace('(+8)', '')
		#url='https://tvpedia.fandom.com/ru/wiki/���������:Search?search='+urllib.quote_plus(title)+'&fulltext=Search&ns6=1&filters%5B%5D=is_image&rank=default'
		#url='http://telepedia.fandom.com/ru/wiki/%D0%A1%D0%BB%D1%83%D0%B6%D0%B5%D0%B1%D0%BD%D0%B0%D1%8F:%D0%9F%D0%BE%D0%B8%D1%81%D0%BA?scope=internal&query='+urllib.quote_plus(title)+'&ns%5B0%5D=6&filter=imageOnly&mobileaction=toggle_view_mobile'
		url='https://yandex.ru/suggest-video/suggest-tv2?v=4&uil=ru&lr=193&count_channels=4&count_programs=4&sn=50&part='+urllib.quote_plus(title)
		#print url
		try:hp=getURL3(url)
		except: hp=''
		print hp
		ss='"},"png":"\/\/'
		es='","png'
		L=findall(hp, ss, es)
		L2=[]
		for i in L:
			if 'avatars' in i: 
				L2.append('http:'+i[10:].replace('&amp;', '&').replace('\\/', '/'))#+'/z'
		return L2
	except:
		return []
#print get2('mezzo')
#print get_picons('mezzo')