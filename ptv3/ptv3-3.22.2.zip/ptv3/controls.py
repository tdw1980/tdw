# -*- coding: utf-8 -*-
import base64


def trigger(link):
	F='<a href="LINK"><img border=0 width=37 height=19 src="webui.files/off.jpg"></a>'
	F='<a href="LINK"><img border=0 width=37 height=19 src="data:image/png;base64,'+off+'"></a>'
	T='<a href="LINK"><img border=0 width=37 height=19 src="webui.files/on.jpg"></a>'
	T='<a href="LINK"><img border=0 width=37 height=19 src="data:image/png;base64,'+on+'"></a>'
	N='<a href="LINK"><img border=0 width=37 height=19 src="webui.files/def.jpg"></a>'

	if 'val/true' in link:
		return T.replace('LINK', link.replace('true','false'))
	elif 'val/false' in link:
		return F.replace('LINK', link.replace('false','true'))
	else:
		return N.replace('LINK', link[:link.rfind('/')+1]+'true')


def on_off(link):
	F='<a href="LINK"><img border=0 width=37 height=19 src="webui.files/off.jpg"></a>'
	F='<a href="LINK"><img border=0 width=37 height=19 src="data:image/png;base64,'+off+'"></a>'
	T='<a href="LINK"><img border=0 width=37 height=19 src="webui.files/on.jpg"></a>'
	T='<a href="LINK"><img border=0 width=37 height=19 src="data:image/png;base64,'+on+'"></a>'
	N='<a href="LINK"><img border=0 width=37 height=19 src="webui.files/def.jpg"></a>'
	
	if '/rem' in link:
		return T.replace('LINK', link)
	elif '/add' in link:
		return F.replace('LINK', link)

def lock_btn(link):
	L='<a href="LINK"><img border=0 width=37 height=19 src="/webui.files/lock2.jpg"></a>'
	U='<a href="LINK"><img border=0 width=37 height=19 src="/webui.files/unlock2.jpg"></a>'
	
	if '/lock' in link:
		return U.replace('LINK', link)
	elif '/unlock' in link:
		return L.replace('LINK', link)

def button (link):
	ico = ''
	if '/update/' in link: ico = 'ref'
	elif '/refresh' in link: ico = 'ref'
	elif '/unite' in link: ico = unt#'unt'
	elif '/split' in link: ico = spl#'spl'
	elif '/up'    in link: ico = 'up'
	elif '/icu'   in link: ico = 'up'
	elif '/down'  in link: ico = 'down'
	elif '/icd'   in link: ico = 'down'
	elif '/rem'   in link: ico = 'rem'
	elif '/lock'  in link: ico = 'lock'
	elif '/unlock'in link: ico = 'unlk'
	elif '/info'  in link: ico = inf#'inf'
	elif '/set_b' in link: ico = bepg#'bepg'
	elif '/set_e' in link: ico = 'eepg'
	elif '/set_s' in link: ico = sepg#'sepg'
	elif '/set_aa' in link: ico = ara#'ara'
	elif '/set_ab' in link: ico = arb#'arb'
	elif '/icb'   in link: ico = 'icb'
	elif '/ice'   in link: ico = 'ice'
	elif '/gr_ed' in link: ico = 'lgc'
	elif '/add_'  in link: ico = 'add'
	if len(ico)<100: B = '<a href="LINK"><img border=0 width=19 height=19 src="webui.files/'+ico+'.jpg"></a>'
	else: B = '<a href="LINK"><img border=0 width=19 height=19 src="data:image/png;base64,'+ico+'"></a>'
	return B.replace('LINK', link)

def button2 (link):
	ico = ''
	if '/update/' in link: ico = 'ref'
	elif '/unite' in link: ico = 'unt'
	elif '/split' in link: ico = 'spl'
	elif '/up'    in link: ico = 'up'
	elif '/down'  in link: ico = 'down'
	elif '/rem'   in link: ico = 'rem'
	elif '/lock'  in link: ico = 'lock'
	elif '/unlock'in link: ico = 'unlk'
	elif '/info'  in link: ico = 'inf'
	B=' <form><input type="hidden" name="val" value="'+link+'"><button>'+ico+'</button></form>'
	return B.replace('LINK', link)


def item(param):#&nbsp;<img border=0 width=20 height=19 src='[IMG]'>&nbsp;
	it=" <tr style='border:solid black 1.0pt;'>\
	  <td>&nbsp;[IMG]</td>\
	  <td>[NAME]</td>\
	  <td>[ON]</td>\
	  <td>&nbsp;&nbsp;&nbsp;[OPTION]</td>\
	  <td>[GROUP]</td>\
	  <td><a name='[CID]'>&nbsp;[CID]</a></td>\
	 </tr>"
	
	gr     = param['group']
	cid    = param['cid']
	option = param['option']
	name   = param['name']
	enable = param['enable']
	img    = param['picon']
	BIMG   = '<a href="/picon/get/'+cid+'"><img border=0 width=19 height=19 src="'+img+'"></a>'
	
	#spc  ='<a><img border=0 width=19 height=19 src="webui.files/space.jpg"></a>'
	#on =  f_on_off2('on_'+cid, 'false')#
	on = on_off('/channel/'+cid+'/rem')
	#off = f_on_off2('on_'+cid, 'true')#
	off = on_off('/channel/'+cid+'/add')
	unt = button ('/channel/'+cid+'/unite'+"#"+name[:2])
	spl = button ('/channel/'+cid+'/split')
	inf = button ('/info/'+cid)
	bepg= button ('/epg/set_b/'+cid+"#"+name[:2])
	eepg= button ('/epg/set_e/'+cid+"#"+name[:2])
	sepg= button ('/epg/set_s/'+cid+"#"+name[:2])
	aarh= button ('/archive/set_aa/'+cid+"#"+name[:2])
	barh= button ('/archive/set_ab/'+cid+"#"+name[:2])

	if '[V]' in option: 
		#onoff = f_on_off2('on_'+cid, 'false')
		onoff = on
	else:
		#onoff = f_on_off2('on_'+cid, 'true')
		onoff = off
	
	option = option.replace('[U]', unt).replace('[S]', spl).replace('[I]', inf).replace('[V]', '').replace('[X]', '').replace('[E]', bepg).replace('[SE]', sepg).replace('[EE]', eepg).replace('[A]', aarh).replace('[AE]', barh).replace('[Sp]', '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;')+'&nbsp;&nbsp;'
	
	
	it=it.replace('[NAME]',   input('/channel/'+cid+'/rename/', name, 200, enable))
	#it=it.replace('[NAME]',   f_text('nm_'+cid, name, 200, enable))
	it=it.replace('[CID]',    cid )
	it=it.replace('[ON]', onoff)
	it=it.replace('[OPTION]', option)
	#it=it.replace('[GROUP]',  f_text('gr_'+cid, gr, 200, enable))
	it=it.replace('[GROUP]',   input('/channel/'+cid+'/set_group/', gr, 200, enable))
	try:it=it.replace('[IMG]', BIMG)#img
	except:pass
	#try:it=it.decode('utf-8')
	#except: pass
	#try:it=it.encode('windows-1251')
	#except: pass
	return it

def item_f(param):# style='padding:0cm 1.4pt 0cm 1.4pt'
	it=" <tr style='border:solid black 1.0pt;'>\
	  <td>&nbsp;[IMG]</td>\
	  <td>[NAME]</td>\
	  <td>[ON]</td>\
	  <td>&nbsp;&nbsp;&nbsp;[OPTION]</td>\
	  <td>[GROUP]</td>\
	  <td><a name='[CID]'>&nbsp;[CID]</a></td>\
	 </tr>"
	
	gr     = param['group']
	cid    = param['cid']
	option = param['option']
	name   = param['name']
	enable = param['enable']
	img    = param['picon']
	BIMG   = '<a href="/picon/get/'+cid+'"><img border=0 width=19 height=19 src="'+img+'"></a>'
	
	#spc  ='<a><img border=0 width=19 height=19 src="webui.files/space.jpg"></a>'
	#on =  f_on_off2('on_'+cid, 'false')#on_off('/channel/'+cid+'/rem')
	#off = f_on_off2('on_'+cid, 'true')#on_off('/channel/'+cid+'/add')
	unt = button ('/channel/'+cid+'/unite'+"#"+name[:2])
	spl = button ('/channel/'+cid+'/split')
	inf = button ('/info/'+cid)
	bepg= button ('/epg/set_b/'+cid+"#"+name[:2])
	eepg= button ('/epg/set_e/'+cid+"#"+name[:2])
	sepg= button ('/epg/set_s/'+cid+"#"+name[:2])
	aarh= button ('/archive/set_aa/'+cid+"#"+name[:2])
	barh= button ('/archive/set_ab/'+cid+"#"+name[:2])
	
	if '[V]' in option: 
		onoff = f_on_off2('on_'+cid, 'false')
	else:
		onoff = f_on_off2('on_'+cid, 'true')
	
	option = option.replace('[U]', unt).replace('[S]', spl).replace('[I]', inf).replace('[V]', '').replace('[X]', '').replace('[E]', bepg).replace('[SE]', sepg).replace('[EE]', eepg).replace('[A]', aarh).replace('[AE]', barh).replace('[Sp]', '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;')+'&nbsp;&nbsp;'#.replace('[V]', on).replace('[X]', off)
	
	#it=it.replace('[NAME]',   input('/channel/'+cid+'/rename/', name, 200, enable))
	it=it.replace('[NAME]',   f_text('nm_'+cid, name, 200, enable))
	it=it.replace('[CID]',    cid )
	it=it.replace('[ON]', onoff)
	it=it.replace('[OPTION]', option)
	it=it.replace('[GROUP]',  f_text('gr_'+cid, gr, 200, enable))
	#it=it.replace('[IMG]', img)
	try:it=it.replace('[IMG]', BIMG)#img
	except:pass
	return it


def item2(link, name, img=''):
	it=" <tr style='mso-yfti-irow:1'>\
	  <td width=366 valign=top style='width:274.75pt;border:solid black 1.0pt;\
	  mso-border-themecolor:text1;border-top:none;mso-border-top-alt:solid black .5pt;\
	  mso-border-top-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:text1;\
	  padding:0cm 5.4pt 0cm 5.4pt'>\
	  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:normal'>\
	  <span lang=EN-US style='mso-ansi-language:EN-US'> <img border=0 width=20 height=20 src='[IMG]'> <a name='[MARC]' href='[LINK]'>[NAME]</a></span></p>\
	  </td>\
	 </tr>"
	 
	try: it=it.replace('[MARC]',  name[:2])
	except: pass
	it=it.replace('[NAME]',  name)
	it=it.replace('[LINK]',  link)
	it=it.replace('[IMG]',   img)
	
	#try:it=it.decode('utf-8')
	#except: pass
	#try:it=it.encode('windows-1251')
	#except: pass
	
	return it

def item2_f(cid, gr, name, img=''):
	it=" <tr style='mso-yfti-irow:1'>\
	  <td width=366 valign=top style='width:274.75pt;border:solid black 1.0pt;\
	  mso-border-themecolor:text1;border-top:none;mso-border-top-alt:solid black .5pt;\
	  mso-border-top-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:text1;\
	  padding:0cm 5.4pt 0cm 5.4pt'>\
	  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:normal'>\
	  <span lang=EN-US style='mso-ansi-language:EN-US'> [ON] <img border=0 width=20 height=20 src='[IMG]'> <a name='[MARC]'>[NAME]</a></span></p>\
	  </td>\
	 </tr>"
	
	#if '[V]' in option: 
	#	onoff = f_on_off2('on_'+cid, 'false')
	#else:
	onoff = f_on_off2(cid, 'true')
	
	try: it=it.replace('[MARC]',  name[:2])
	except: pass
	it=it.replace('[NAME]',  name)
	#it=it.replace('[LINK]',  link)
	it=it.replace('[IMG]',   img)
	it=it.replace('[ON]', onoff)
	#try:it=it.decode('utf-8')
	#except: pass
	#try:it=it.encode('windows-1251')
	#except: pass
	
	return it

def item3(param):
	it=" <tr style='border:solid black 1.0pt;'>\
	  <td>[NAME]</td>\
	  <td style='padding:0cm 5.4pt 0cm 5.4pt'><p>[OPTION]</p></td>\
	 </tr>"
	
	option = '[>] [<] [U] [L] [Sp] [I] [Sp] [X]'
	name = param['name']
	lock = param['lock']
	gid = str(param['id'])
	
	spc  ='<a><img border=0 width=19 height=19 src="webui.files/space.jpg"></a>'
	up   = button ('/group/'+gid+'/up')
	down = button ('/group/'+gid+'/down')
	unt  = button ('/group/'+gid+'/unite')
	rem  = button ('/group/'+gid+'/rem')
	lc   = button ('/gr_edit/'+name)
	if lock == 'true': lk = lock_btn('/group/'+gid+'/unlock')
	else:              lk = lock_btn('/group/'+gid+'/lock')
	option = option.replace('[<]', up).replace('[>]', down).replace('[U]', unt).replace('[L]', lk).replace('[X]', rem).replace('[I]', lc).replace('[Sp]', spc)
	
	it=it.replace('[NAME]',   input('/group/'+gid+'/rename/', name, 200))
	it=it.replace('[OPTION]', option)
	
	try:it=it.decode('utf-8')
	except: pass
	try:it=it.encode('windows-1251')
	except: pass
	return it

def item4(param):
	it=" <tr style='border:solid black 1.0pt;'>\
	  <td style='padding:0cm 5.4pt 0cm 5.4pt'>[NAME]</td>\
	  <td style='padding:0cm 5.4pt 0cm 5.4pt'><p>[LINK]</p></td>\
	  <td style='padding:0cm 5.4pt 0cm 5.4pt'><p>[B]</p></td>\
	 </tr>"
	
	lock=param['lock']
	sid=base64.b64encode(param['sid'])
	if lock: lk = lock_btn('/black_list/'+sid+'/unlock/'+param['id'])
	else:    lk = lock_btn('/black_list/'+sid+'/lock/'+param['id'])
	
	it=it.replace('[NAME]', param['serv'])
	try: it=it.replace('[LINK]', param['url'])
	except: it=it.replace('[LINK]', 'error url')
	it=it.replace('[B]', lk)
	
	try:it=it.decode('utf-8')
	except: pass
	try:it=it.encode('windows-1251')
	except: pass
	return it

def item5(param):
	it=" <tr style='border:solid black 1.0pt;'>\
	  <td style='padding:0cm 1.4pt 0cm 1.4pt'><img border=0 width=20 height=19 src='[IMG]'></td>\
	  <td>[NAME]</td>\
	  <td style='padding:0 5.4pt'>[OPTION]</td>\
	  <td><p>[GROUP]</p></td>\
	  <td style='padding:0 5.4pt'><a name='[CID]'>[CID]</a></td>\
	 </tr>"
	
	try:it=it.decode('utf-8')
	except: pass
	try:it=it.encode('windows-1251')
	except: pass
	return it


def item6(link, img=''):
	it=" <tr>\
	  <td>\
	  <a href='[LINK]'><img border=0 width=80 height=80 src='[IMG]'></a>\
	  </td>\
	 </tr>"
	 
	it=it.replace('[LINK]',   link )
	it=it.replace('[IMG]', img)
	
	try:it=it.decode('utf-8')
	except: pass
	try:it=it.encode('windows-1251')
	except: pass
		
	return it

def item7(param):
	it=" <tr style='border:solid black 1.0pt;'>\
	  <td>[NAME]</td>\
	  <td style='padding:0cm 5.4pt 0cm 5.4pt'><p>[OPTION]</p></td>\
	 </tr>"
	
	option = '[>] [<] [B] [E] [Sp] [X]'
	name = param['name']
	ncl = param['n']
	cid = str(param['id'])
	gr = str(param['group'])
	total = param['total']
	next=ncl+1
	if next>=total: next=0
	prev=ncl-1
	if prev<0: prev=total
	
	spc  ='<a><img border=0 width=19 height=19 src="webui.files/space.jpg"></a>'
	up   = button ('/group/'+gr+'/set_cn/'+cid+'/icd/'+str(next))
	down = button ('/group/'+gr+'/set_cn/'+cid+'/icu/'+str(prev))
	begin= button ('/group/'+gr+'/set_cn/'+cid+'/icb/0')
	end  = button ('/group/'+gr+'/set_cn/'+cid+'/ice/'+str(total))
	rem  = button ('/channel/'+cid+'/rem_group/'+gr)
	option = option.replace('[<]', up).replace('[>]', down).replace('[B]', begin).replace('[E]', end).replace('[X]', rem).replace('[Sp]', spc)
	
	it=it.replace('[OPTION]', option)
	it=it.replace('[NAME]', name)
	return it

def input(link, val='', width=105, enable=True):
	if enable: dis =''
	else: dis = 'disabled'
	t="<form style='width:"+str(width)+"pt;height:3.3pt;' action='[ADR]' method='get'><input style='padding:0cm 1.4pt; height:12pt; border:0; width:"+str(width-28)+"pt;' type='text' name='val' value='[VAL]'/><input type='submit' value='ok' "+dis+"/></form>"
	t=t.replace('[ADR]', link)
	t=t.replace('[VAL]', val)
	return t

def listbox(link, L=[], val='', width=65):
	
	t1='<form style="width:'+str(width)+'pt; height:3.3pt;" action="[LINK]" method="get">\
		<select style="border:0; padding:0cm 1.4pt;" size="1" name="val">'
	t2='	</select>\
		<input type="submit" value="ok"></form>'
	it = '		<option [SEL]>[VAL]</option>'
	lit = ''
	for i in L:
		if i == val: sel = 'selected'
		else:        sel = ''
		lit+=it.replace('[SEL]',sel).replace('[VAL]',i)
	t1=t1.replace('[LINK]',link)
	
	return t1+lit+t2


def f_text(ID, val='', width=110, enable=True):
	if enable: dis =''
	else: dis = 'disabled'
	t="<input style='padding:0cm 1.4pt; border:0; width:"+str(width)+"pt;' type='text' name='"+ID+"' value='"+val+"' "+dis+"/>"
	return t

def f_on_off(ID, val):
	if val=='true': ck =''
	else: ck = 'checked'
	t="<input type='checkbox' name='"+ID+"' value='true' "+ck+"/>"
	return t

def f_on_off2(ID, val):
	if val=='true': ck =''
	else: ck = 'checked'
	t="<label><input type='checkbox' name='"+ID+"' value='true' "+ck+"><span></span></label>"
	return t

def item_serv(param):
	it=" <tr style='border:solid black 1.0pt;'>\
	  <td width=301>- [NAME]</td>\
	  <td width=29 ><p align=center>[ID]</p></td>\
	  <td width=104><p align=center>tr_serv[ID]</p></td>\
	  <td width=94 ><p align=center>lb_pr[ID]</p></td>\
	  <td width=96 ><p align=center>tr_upd[ID]</p></td>\
	  <td width=94 ><p align=center>btn_upd[ID]</p></td>\
	  <td width=151><p align=center>id_upt[ID]</p></td>\
	 </tr>"
	
	name = param['name']
	sid = str(param['id'])
	
	it=it.replace('[ID]', sid)
	it=it.replace('[NAME]', name)
	return it

on='iVBORw0KGgoAAAANSUhEUgAAACUAAAATCAYAAAAXvcSzAAAABGdBTUEAALGPC/xhBQAAAAlwSFlzAAAOwwAADsMBx2+oZAAAAB90RVh0U29mdHdhcmUAUGFpbnQuTkVUID8/Pz8/PyAzLjUuMw6pplQAAAcnSURBVEhLjZYJV1vXFYX935rWSICYCcVMEpoAYXCSxk1JExMnhDaxkzTLbY1jxyuOVzzUccB4SKgTGzAEgQbQLD0JDLh2aiggCc3S7r73ycnqkLSXdd7E07rf22efc++BnxoORHAVt3CqcAGjuU9wLH0G7+Ez/C7zEd7JnMHJzDmcTJ7HB7mLeFs8K57DifTHOJk6i5OFs3g/OYY/PT6P0+HzOOu7hE+9V3AtcBkzT+4iijWUp/n/xlI6gtPRK/jV0lswLRxB+1I/WlYGUO/uR7OTsWRDm2sQbc4BtDmOoOnbHjS5bPyfDZ1LR9AxexiG2QFYpgYxMn8C19ZuYmbHCfuOG85tB2ZX7+Gm8w7jSwS3w/8b7pPdCegXX5QT6BwGNHlMqFnpQlXAgNqIFXWeHjR6bKhn1PK6xmNGY7gP1QEL6vw9aHUPoP0bG16fH8X9/Xn8HXvYQQpJ5JFGEVme88ghWdpH5GkMV+fHcS86/+Ngp2OX0EpVNN5OVEb10EQ6URPRy6hS9NDFCBiwotZnhS5IIKUPNVELNEEDqmMWNAT78Mv7VrzjP4UYHmGXKCkUCAGURBR5KJRvOATgHt+44f4Kd/xf/yfYpa1xGBYG0bBshk4x47lgG3SrZlQHTagL9aKS5wp/F6rDFipmRk3YhKqwAZpQF7RhPbShbtQvmDBMhb7DlgR6BkOBIG9EiGs+FM8FX4Z/aYKNL05gYX3pB7AoNjC4OIQGl54qcJJgFyqVbmjC3dAxZTWhHqmMLkiVeF/p70S1t4P3elRGDFKtGp8ZRvtLWIGfUwh91MkLOfX8PZikBHL5IoryushkprBZ2MTVhes/QH26fh3t8/1oDJhQG+hAfaxbfnlFyIiKYKdMT1W4F/XKAKqXqYjPhJaAGQ1+o1ROANcuMG2xMaYjwcmJVJ68RJJsPqXeEKAgr3N8XlRZi3l+QIa6JjC9Noe/btpVsLeDf0S93cpUdaNO+MffLtNVE+ulj7rpJ0J6Cezpp5EHMbz/B/w6NSpVFSrWevrw/Mxh3C48wD4nkKpIqYrYzyWQzMaxu7+HZGoP2Qzvk1tIJHfKYEWBzV+lEEs/xF8CX6pQNvtr0C1boI0YpZ+qAkaC0U+sKJEe4R2hkAA6sX2RneprGB8fpZrt0FHNZraKvge/hQMheilBHtVApSL9QqhEJo5kJo10NoNcithJAZckTk6+Kfl5tZPbwq3IVypUn/NV6DxWHCRQRYDpUWxMZT/TY0OVuxvNvl60sdR/Hz+DzzELm+cNesgIrSKgDGhctOAV+yhb7SP8gwkUJV8sUTGe01kmJp1iUIs0FUkSKh5Hhs9F4iSUUJZR4vvj3skylOM3qHZboVF6pI+qmKpDwZfYvS/iyOoI2mYGcWr7AsbxDXr8Q6hzGVEbMrEgOphyPVqdPXh5ephtYJOVJGCEd7LynM/nCcA0ZopIM3KptFQrVxD9qqySMBdvBOQN/x0V6qjjDbYC9ieWuTbcKauqxTeA4fifiTWFj3Kf4wum7LB7CPWLejRHTRJGpFXEISpqnXoRzpKXSCw3MVt5pKnOfjJLD2WRTFCtODtTfAf7KaY2X5I84lDiN+xSvQnfbRXqw9BZ1Lv6oI0ZaPAW9qVDqPWzPzmtGNkZ4/p3F+bwK6he7ESLYiJ0BzQBFgMLoIKFoPNb0TbbjytPb9LoKTmBUCDNgyj7IlPDIlPzVGD15dOykUogjiJ/IKo0+lTBrUBZqXuJb9E0dxhaGlwCBVtp9i6CWfC8w4amxV5p9KZVKwugDVXBdlRHRB/T4+dRI1uGWS5LQ85R/A1PCCQqShVMTFySBxGCRPWaVIfBRAvn8WOokn0S/l2fCiXGcWUMdfY+2asaY0bZIDUBPftQjxrsSTVBtTq19JMuqvrvIFNeGTaj1mvGoWkLvvhuAtvs6Ckm8nsWMXtJaPcMVQUSTzI87iIOx44X11xlkz8bcyznF1yjaLZzwWUrEF7REu5nShc00W65tAiwqghh2NW1YXZ2hese/aVl25CtwWVFz91B3M/N4ylbQ4IaZKmF6EUoCnUEkNBGrHsCCFQoj9j+Bj6euwyl9OhfocSYK7lw1PEmGubN8uufW+3CLxT6J9SBOqa2IaTCHFRUIAFTucb1L9IhC6SOi3Xzgg02+zFc2LrNHdMOG0SSUJw+x2AlCiihToJPd3leecI92/QEwomf2F+54cMHj8+hiV6qcHMtpOF1KwbupYyo52Kt4ValgsuMaBuV3i4cXG5lk+XWxsddhNjGcN9VN8P91r2jeM3xIe7uzmOjuE5liFBKMFF7VDGO5a0I7nimMbk49eMw/z6m8ABjqcsY2ngXLzw8jsHVYfSvDcP68BjMG6+jT8T6q+jfPAYbr3vXGOu83jwO28MRWJQ30e8bwcuLo3jfewafBa/ihjKJ66GbuOafxG1lCq5tz38BOnDgn7LFuaanH/hUAAAAAElFTkSuQmCC'

off='iVBORw0KGgoAAAANSUhEUgAAACUAAAATCAYAAAAXvcSzAAAABGdBTUEAALGPC/xhBQAAAAlwSFlzAAAOwwAADsMBx2+oZAAAAB90RVh0U29mdHdhcmUAUGFpbnQuTkVUID8/Pz8/PyAzLjUuMw6pplQAAAbySURBVEhLjZb7kxRXHcX5YyyFZd+P2XnPvgKhggUaIJFiNUWqoAJa+ItWRU2ikgcBRcOCbhAjxE2yBDDUVgiBsoyUmLA8FgLokOCShYFdWBZ2e2Z6enp6pj+e27NAaYyVrvlO377d1ffMOed77sz5fwcXz5Hbf5Cx/l2k+7ZzddtWrE0/h5d/Clt/Bi/+WPU8bHoRNj6nsWqzxpuehS0/0jPPaKz7L21U6fnNOv96G7x3GMb+yewyX+64dWaY43t+x8dv7mbq/aNUPhzGO/ER9tH3uL1rB2fWr+bPC5OcXpBgtCfFja4Et1U3EyFudcW5lgox1tMW1MSCJBN6JtPRTqYrSqank/TDPVxas4rb27dA+kuAO/vGW4y8NYh97V9QLkDJUZVURXB17VhgTeEfPsTwE71c7AhhpVrwU+0QbaUSb8FNNOOmmimkmrAj9cF1Nt6A81A7Vmcr2a42xsN1XEu2cfXRJTB04IuBDe9+jevvH4FsDrwSPhU8fZf8CtWjgl9xg3tM5+HSJ9zY8CSfJszCrRBqgIgqVo8fnh8U0UbN1UKqkVK8lkJsLuWYruPN+G115HW+2BmhvHfP54FdeHuQG4eldVFslD2VIKj0ETAR5etc1pc+wYQIJK9n06cZWfs4491RKrFmSDRBslGM1WlhAQprLtoioPMFZp6qBt/MR/WcWPWi88l1t5JelIIjQw+AZS+lOfHaHyTLjJAUcV2xoY+ICTA4Xjk4myprrmJAGbRFDYoW3pEDnH8oTj7RhtNeix+tpSxQnmEsFhFjbcEcKTEaq8MVe260mYpkJWWu53JbDE8+2fsA1Nl97zA5ckoM6Jf7RrDZRe+VkS+YL+H6pWDqPsKiKLPuML5+DVOSwYmJhXi9GBOoRAN2Ki4/RSjFmiRfI7YMbyXbcVXlRAslMeXFawROjaFG4cC+KrDjO3eBLQNr0UqlQmWWFjtXpJwr4FrTONm75O1pZkpZ8n4B3xc086Cxm5WF3bu4lAzhdOrF0YbAT25M/vrBBnjuJ2Qk4XU1xdSSBYqKF2DFYlx5zUvKe/Ik4UbutMuXz2+sgvp48E396oLeb8xdJcGVmYvyl2fb+IU8pUIO28ky4+lswJunDCjDVl6g/nqEkUUdZHsigVcI1Qbs8NhSeGdQebWRkeWLNR6AnZtxuo3/asTm16BDz7WFyLaEYd36KqjLQ38SSbb8a7pNQxnddF7RzePmcmIrTzGfI2cLlOYMqPsSGqYEmlPHGfnmw4GEZWNimb6guirv3PzWo3BIa4ycEKBXGFmcxDLsRL4iX31VZp8npiK4oTj0zvrq/N439IvFjN5/z8MV36UgSf2SZlxVwRNuF8ctUpR0Bk9wmIGA89Exzi1dyN3ueBAPXmcb+a6QQjPC5a8vgoP7FCHnKW7ZxMnuBIVOsSI/+cl56lRFR8Q0iaRX9gWgTg+8roXd4P1GDXN2XUegcuRnLOwZsTNTkEq2UsAOpDXy3Qdm5Bvaz0WlvBWAaqaYbGJaRi8uewT26v07fkG693F4d0ie2ordFVNH1gcRgfLLRMR0SAxvWFcF9eHrA/iTU2JDoWjk0GrG8OWyOJtd2cSSejMIUt0Ro7PlKTvUAO7LzzLW0UpOgHwFouk+W0zww6fgVy9wK9nKWKSJmRXLoH+HjL6UYrxJ2WakNrnVyIQZ979SBTX6wQdcOKTgdATKk1Sz8hgfB00moAaUkddIa/wWoFdMqAPg8gU+XbYo2G5MJBgGEFOmq/JdrdxVRLgmPJPNzCSjTHclccSUAWV+gMmr6fY6xh7pgbPDVVDmONbXp537ilbOa1E38FbRN6iq699jzMhmWAzAqzOZnCDf90uuxOQHZY/pODfcQCXYchSSSe15SUnUJWARdZuiodhumJTvInVBqJp98Up3Smy/9ACQOewzpzjWv1172qQMJeMaFgI2dDLby+xlFaQuCuLt7h14e4CT6jhbhjbbSdlsNfqXQLjagWYb8QSqnDIhqS4ze6O5JynNtuRoI7+SivDZU2vhs9H/BGWOcVF39LfSO502ySlw1YT3PKExgIx2jthxdC8zBq/uYFR/X2YkS0kSGdl8sRPsawpQotr/knVUOmr1r6FGLM4VGNNputfWQiHeSSaxkMya72rNf3we0L3D+STN33b2M3ZwP+6505JnXL6R14ypLH1dHSU7tJcL31/H35NhbsoThXAtOaWzJTnyks5ROjvhev1tqcNqr8GSRCaXLLW+E5lHNjSfiUiYzOJvKFS3fTGY/z6s438ho/wa/eMerg8Ocm33AJm+35B55mkur17J9ZVLKK9Wi/c+BqtU31mhMtcrq7VK41Wa+7YZL9d5Of4T6ry1un76e/D7V+HMyf8BaM6cfwP19Yc3X8EurQAAAABJRU5ErkJggg=='

unt='/9j/4AAQSkZJRgABAQEAYABgAAD/4QCyRXhpZgAATU0AKgAAAAgACQEaAAUAAAABAAAAegEbAAUAAAABAAAAggEoAAMAAAABAAIAAAExAAIAAAAXAAAAigMBAAUAAAABAAAAogMDAAEAAAABAAAAAFEQAAEAAAABAQAAAFERAAQAAAABAAAOw1ESAAQAAAABAAAOwwAAAAAAAXbyAAAD6AABdvIAAAPoUGFpbnQuTkVUID8/Pz8/PyAzLjUuMwAAAAGGoAAAsY//2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAATABMDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD7O/bT/ar1T9qjX7zw74b1Lx1/YsOratpFho/hXVoNNuvEB04Wgnfc8bvcs7XLskCEDy4C2HY4HyxDffE39l3+zfHXwkvPilZRWOpajp2v2F7J/alvZz2LxeaLloUEDxsJDw68eWxDHgjq30Ob4H/tc2vwh1seNvDPijTfGeoy+HfEmh6lFas9vqn2dI5NskLs2VhTBjdSfMdDgg1ofBn4azE/D3VF8IfEzQfG2n6u2peNdT1rTtTS01lZmmaSSNzmCMRrtMplVN2cq3ysG/pfA0MNl+EjSpxUqLjezSampKdnLW1mlHWzkpPVWPxDFVa2MxEqk5NVE7XTacWnG6Wl7pt6XSa2dz9GP2Xv+Ch3gn47/ALwz4s1bVNP8P6rq1qTe6fJIf8ARp43aKQL1+QujFc87SueaK+Q/wBjP/gkprnjb9mPwjrOtatJoGoataveGwmRhJDHJLI0RYY4LRlGweRuweaK/LsyyXhqnjKsI4pxSlJJJXSs9k7apd+p93gczzyeHpylQTbinduzei1a6eh9jft+fsw+Afj38GNS1Hxb4ZsdW1Lw/avNp14WeG5tTkHCyxsr7c8lCSpPOM18m/8ABKT9lnwH498ZaxqmuaH/AG1d6GwksxfXtxcQRtuwCYXkMb47b1ODyOaKKjJ8wxUOG8VGFWSUWkrSeidrpa6X69y8ywdCWdUJSgm2nfRa22v3t0P0qooor88PsT//2Q=='

spl='/9j/4AAQSkZJRgABAQEAYABgAAD/4QBoRXhpZgAATU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAAExAAIAAAASAAAATgAAAAAAAABgAAAAAQAAAGAAAAABUGFpbnQuTkVUIHYzLjUuMTEA/9sAQwABAQEBAQEBAQEBAQEBAgIDAgICAgIEAwMCAwUEBQUFBAQEBQYHBgUFBwYEBAYJBgcICAgICAUGCQoJCAoHCAgI/9sAQwEBAQECAgIEAgIECAUEBQgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgI/8AAEQgAEwATAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8A/az9rf8AbA+Lf7QPxl1H4XfDXXvFXhj4M2OsjQ92imRH1QiXy5Li4kTlkJ3FIyQu0KSN2TUnwM02+8C+OhrXwt8YftD+GtIt/GieD5tSm1yxezurxpdg82xeP/SYuVLAA7dy5KllNWdD+CPxQ8ADXvhjct8f9H0nSviFr0mp3HgaxvJ7i8gNlYPZtJ9mVisc67tsrK2zczbWKsp8Y8VeJZvgvJ8HPiF8SvhD44h+KP2q81W0sdZ1C404WAguQIXe0aEGRpNoeSY7WncM7EszMf8AGzNMyzSnmlTiHiKpNVlPmlKXNH2VpRj7OHKpyiouaSSUeZxklKPK2v8Aa7KsryqpldPhvhqnTdBw5Yxjyy9teMpe0qczhGTkoOTblLkUotxlzRi/3c+B37afwq+KHwn8E+OvE2v6R4P8R31qft+mu7H7NcRyNFJt6/IWjZlzztZc80V+aP7O/wDwTr8Z+OPgv4C8Ya3rx8J32pWr3gsbjeskULzOYmZQON8ZjfHX5+eaK/sjhPxN8Tq2VYWtLKYVHKnB8zlyuV4p8zjdWb3asrbWP4r4v8LfCuhm2KoxzedNRqTXLGPMo2k1yqVnzJbJ3d1rc/R79uL4H/Cj4lfCXX/F3jXwVpeteKdHtc6dqG6SG4twWHyeZGys6fMx2MSuTnGa/M3/AIJvfs/fBzx9411/WfGngTTPE97pP+kWK3kkskMUgcAM0Jby5MZ6OrDv1oori8UOFMrreKeUyrYanL2kJSleEXzON+VyutWrKzeqsrHb4VcXZtR8Js3VHFVI+znGMbTkuWMuXmUbP3U7u6Wju7n9BgGAABgUUUV/bB/DB//Z'

inf='/9j/4AAQSkZJRgABAQEAYABgAAD/4QBoRXhpZgAATU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAAExAAIAAAASAAAATgAAAAAAAABgAAAAAQAAAGAAAAABUGFpbnQuTkVUIHYzLjUuMTEA/9sAQwABAQEBAQEBAQEBAQEBAgIDAgICAgIEAwMCAwUEBQUFBAQEBQYHBgUFBwYEBAYJBgcICAgICAUGCQoJCAoHCAgI/9sAQwEBAQECAgIEAgIECAUEBQgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgI/8AAEQgAEwATAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8A+wP+Ci3/AAUj+OP7Sf7ROq/s+fA3XPGOifCbT786e0Hh2zkurvVIkOZbloYwXlIUGXaQDHsCqFKu8nL/ALYPjC2/4JufHL4O6h+xX+0X8bvFum6hoa6lrcPiWeSUSSiXAUSyQRgiQDc9uVYI6jepDbB8n+JfgJ8XvgL/AMFCNV+H8PxM0v4CeJ4devLyDxVrHiT/AIR60W1IaWbGoFk2LLGzooJBlWWPjEoz+hv/AAXk8WfCn9oHxN8Ffid8Evjx8CPipp2k6fJoN1pfh/xZaahqjXE9wZEaO0gZ2aMBcF+xZR3r+FcZj8dicHmOZYqbWLp1IqN21KKUndQ95Wsvi916WP4RxuPx2IweY5liptYunUio3bUopSfMoe8rWXxe69LH7qfs+f8ABTT4C/FH4LfDrx94211fC3izUtPWbULGG1lkSGYMyttK7gN23ds3Ns3bSzFckr8kf2Rf+CXXxs8Qfs3/AAo8QPd6VoZv9Pe++y315JDNGJZpHHyqpUqd2VYEhlKsPvUV+65TxPxRPC0pywybcYu9nrotdz96yjiriiphKU5YVNuMXez10Wu5+s//AAU8/Z8+C3xQ+A2s+NvHvw68PeJPFumG3t7HUJkZZoY3lCldyEbsB5Nu7OzexXaWOfyI/wCCWX7JH7OXiP43XD+IvhVoHiA2VrcX1r9ukmnEcsbIF4dyCuHYMhyrA4YEUUUcUZThZ8UYaU6UW2lf3Vrq9yOKsowk+KMLKdKLbSveK11e+h/VVGiRxxxxoqRqoVVUYCiiiiv3U/dz/9k='

sepg='/9j/4AAQSkZJRgABAQEAYABgAAD/4QBoRXhpZgAATU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAAExAAIAAAASAAAATgAAAAAAAABgAAAAAQAAAGAAAAABUGFpbnQuTkVUIHYzLjUuMTEA/9sAQwAFBAQFBAMFBQQFBgYFBggOCQgHBwgRDA0KDhQRFRQTERMTFhgfGxYXHhcTExslHB4gISMjIxUaJikmIikfIiMi/9sAQwEGBgYIBwgQCQkQIhYTFiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIi/8AAEQgAEwATAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8A9X0vS5/jzcajrPiDUbyP4eLcS2elaRYXDwR6nHG5Rrmd1wzhnX5U4ChRwTknYuvgJ4b0xXvfh3LeeENfRR5N9ptw+xiDuCyxMSkqbgMqw5Arivgx8P8AR7jxBouoa1c3lv47+HMMuiT6fHIqwtGTP5cxRk3lXjuCysGAPHvnbvP2b/A2n/CCfwpfazrdvoFvqh1uW7luoFkSQQeUcsYtoTbz93Oe/agCHT/2nPC2k2Y034gvJpviqxd7bUrW1t5JIhKjlCyEjO1sBgDyAwGTjJK8A8XfBzx18ZvGerePPDGl2v8AYmt3LPYtNciJpIUPlJJtbBAYIGGRyGBooA92/ais4vD/AIEi8b6D5mneLLO5hto9Us5WilMTNkxvtIEi5UYDAgc4xk58F+EHjHxD8YvjHovh34laxea3oTRyySafJIYoZWjQum9Y9ocBlU4bIOOaKKAPvuCGK2t44LaJIoIlCRxxqFVFAwAAOAAO1FFFAH//2Q=='

bepg='/9j/4AAQSkZJRgABAQEAYABgAAD/4QBuRXhpZgAATU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAAExAAIAAAAXAAAATgAAAAAAAABgAAAAAQAAAGAAAAABUGFpbnQuTkVUID8/Pz8/PyAzLjUuMwAA/9sAQwAFBAQFBAMFBQQFBgYFBggOCQgHBwgRDA0KDhQRFRQTERMTFhgfGxYXHhcTExslHB4gISMjIxUaJikmIikfIiMi/9sAQwEGBgYIBwgQCQkQIhYTFiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIi/8AAEQgAEwATAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8A5/49eOviT458Ry2Xhe11Sz8GfaVtLL7G2w6i7SeUHJBywaThV6dOM5ryXwrbfFjwN4xgTw3b67Y6p5X2ryQGMUsQbaWcH5GTd8pzxnjrXoPjbxbZ/D/xzomia1pl6uoeD761Yf8AEvtD9rihuvODrcFfOAeM8ANjPUda4G0+LK6imoab4ssVOhXKRi3g0u2hhFsY7gzj93gLIGYtvB5OQc/KBQB94+EfjNouqeEbC58VSLoevFWjv9NuFZWgmRijjB5AypIzzgiivF9L+Adx8Q9JtfFUKnw9Dq0Ymi0yViXiTojHAABdQHx2347UUAewfHTwD4Z8V+AL7Udf0iC61DToSbW6yySR89NykEryflOR7V8+fszfDbwlr3iW+vNa0SC9n0/95b/aHd0VgwwShO1vxBoooA+3KKKKAP/Z'


arb='/9j/4AAQSkZJRgABAQEAYABgAAD/4RB4RXhpZgAATU0AKgAAAAgAAwExAAIAAAASAAAIPodpAAQAAAABAAAIUOocAAcAAAgMAAAAMgAAAAAc6gAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFBhaW50Lk5FVCB2My41LjExAAAB6hwABwAACAwAAAhiAAAAABzqAAAACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/4QmcaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49J++7vycgaWQ9J1c1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCc/Pg0KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyI+PHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj48cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0idXVpZDpmYWY1YmRkNS1iYTNkLTExZGEtYWQzMS1kMzNkNzUxODJmMWIiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyI+PHhtcDpDcmVhdG9yVG9vbD5QYWludC5ORVQgdjMuNS4xMTwveG1wOkNyZWF0b3JUb29sPjwvcmRmOkRlc2NyaXB0aW9uPjwvcmRmOlJERj48L3g6eG1wbWV0YT4NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgPD94cGFja2V0IGVuZD0ndyc/Pv/bAEMABAMDBAMDBAQEBAUFBAUHCwcHBgYHDgoKCAsQDhEREA4QDxIUGhYSExgTDxAWHxcYGxsdHR0RFiAiHxwiGhwdHP/bAEMBBQUFBwYHDQcHDRwSEBIcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHP/AABEIABMAEwMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/APT/AItfFrV9b8RX2laVezWejWErQYhbabl14ZnI525yAvQjBxmvP9C8Y6/4XvEu9J1W5gdTlojITFL7Mh+U/XBrc8XG58GT+IPCN1pGmMZrxp4tRmg3XXlllZNkmflBVRxg8s1Qn4hhdc/tY+F/Cw/0X7L9kNh/o3393mbN33+2c9OMV9vh6cY4dQp004/LX/hz36cYxp2jG6/r8z6p8H/ELS/E3hrTtVmngtJ7mM+ZBJIAUcEqw+mQcHuMUV5h4A+Csl54Q0u51G9ubO7nRpWgUghVZiV/EqQfxor5+ph8Apte1f3HE6GEv/E/A9O+IvhDRPE2g3M2q6dFczWcTyQyklXQgdNykHHqOh7ivLvgp4B8OX73GoXelRXF1auPKaZmdVPPO0naT7kUUU8NOSwFWz6r9AoSf1Spr2PoKiiivHPNP//Z'

ara='/9j/4AAQSkZJRgABAQEAYABgAAD/4QBoRXhpZgAATU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAAExAAIAAAASAAAATgAAAAAAAABgAAAAAQAAAGAAAAABUGFpbnQuTkVUIHYzLjUuMTEA/9sAQwAEAwMEAwMEBAQEBQUEBQcLBwcGBgcOCgoICxAOEREQDhAPEhQaFhITGBMPEBYfFxgbGx0dHREWICIfHCIaHB0c/9sAQwEFBQUHBgcNBwcNHBIQEhwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwc/8AAEQgAEwATAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8A1vFvxR8SfH7472Xw/wBD1G6sfBkF80E6WkhjN1DESZpZGHJBCsFHTleMmnfGy9i8Eaf4e+JnwfvJNI0uO+uNIv4LMkQSSxyMEZ4slWDbH5Ycgp3qn8PY9J/Zr1L4qeIPEktnP4lspv7O0rSXuljuLuF3DGVRy2xg0Z3AcBH70/wb8Wfh/wDErwJ4y+HM/h/R/Adle2jXtnNLqOYHvFK7cs4UK2VjPB5CtX1fJyyi6ML042T2s77trruvuPd5eVp043hG3o77+vQ+j/hz+0L4Y8X+CdG1rVL6307UrqI/aLUkkRyKxVsf7JKkj2Ior55+Fv7KWreIfAOiarfX39n3F7E032aTO5UZ2KHj1Xa340V51bDYFVJL2ltWcdSjhVNrnPoj9oP4deF/GHgq+1LWtHgutQ02Em2ucsksfPTcpBK8/dOR7V86/sp/C3wh4i1++vNW0OC+n0/Elv57u6KwbglCdrfiDRRSwtaosDUtJ6eYUak1hZ2Z90UUUV4x5x//2Q=='