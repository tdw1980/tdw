# -*- coding: utf-8 -*-
import urllib2, time, cookielib, os

#sid_file = os.path.join(os.getcwd(), 'BS.sid')

#cj = cookielib.FileCookieJar(sid_file) 
#hr  = urllib2.HTTPCookieProcessor(cj) 
opener = urllib2.build_opener()#hr
urllib2.install_opener(opener)

try:
	import xbmcaddon
	addon = xbmcaddon.Addon(id='ptv3')
	root_dir = addon.getAddonInfo('path')
except:
	root_dir = os.getcwd()

#fl = open(os.path.join(root_dir,'webui.files',"vdata.ts"), "rb")
#temp_vd=fl.read()
#fl.close()

block_sz = 1024#81920

stack = []
dstack = {}
STOP = False

from threading import Thread
class MyThread(Thread):
	def __init__(self, url):
		self.comp = 0
		Thread.__init__(self)
		self.url=url
		req = urllib2.Request(url)
		self.resp = urllib2.urlopen(req, timeout=30000)
		print 'connection ok'
		#dstack[0]=temp_vd
		#self.n = n
	
	def run(self):
		global dstack
		if dstack != {}:return
		#try:
		while not STOP:
			try:buf=self.resp.read(block_sz)
			except: buf=''
			if len(buf)>1000:
				dstack[self.comp] = buf
				self.comp += 1
				time.sleep(0.001)
				#if self.comp<100: pass
				#elif str(self.comp)[-2:]=='00': print self.comp
			else:
				self.resp.close()
				req = urllib2.Request(self.url)
				self.resp = urllib2.urlopen(req, timeout=30000)
				#time.sleep(1)
				print '-RE-'
		self.resp.close()
		dstack = {}
		#except:
		#	stack[self.n]=stack[self.n-1]


class BS():
	def __init__(self, url):
		#req = urllib2.Request(url)
		#self.resp = urllib2.urlopen(req, timeout=3)
		#buf = self.resp.read(block_sz)
		self.last = None#buf
		self.url = url
		self.list = []
		self.run = 0
		self.complit = 0
		self.n = 0
		self.t1 = ''
		self.t2 = ''
		#self.stack = [None,None,None,None,None,None,None,None,None,None]
		self.stop(False)
		self.create_thread()

	def GET(self):
		try: data=self.resp.read(block_sz)
		except: data=None
		#response.close()
		return data

	def get_head(self, url):
		return url[:url.rfind('/')+1]

	def get_data(self):
		#print '============= get_data ==============='
		#print str(self.n)
		#if data != None: print 'OK'
		for i in range(100):
			if self.n not in dstack.keys(): time.sleep(0.1)
		
		try: 
			data=dstack[self.n]#self.GET()
			del dstack[self.n]
			self.n+=1
		except: 
			data=None
		if len(dstack)<2: 
			time.sleep(0.5)
		#print 'ok'
		return data
		
		if data!=None:
			if len(data)< 1000: 
				#data=None
				#print repr(self.t1)
				print '-RC-'
				req = urllib2.Request(self.url)
				self.resp = urllib2.urlopen(req, timeout=1000)
				data = self.GET()
				#print repr(data)
				#print data.find(self.t1[-100:-3])
			#else:
				#self.t1 = data
		return data
	
	def create_thread(self):
		print '--- create_strim_thread ---'
		my_thread = MyThread(self.url)
		my_thread.start()
		#time.sleep(1)
	
	def stop(self, s=True):
		global STOP
		STOP=s