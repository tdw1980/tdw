#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, cookielib, urllib, urllib2, time

serv_id = '11'
siteUrl = 'televizor.org'
httpSiteUrl = 'http://' + siteUrl

def ru(x):return unicode(x,'utf8', 'ignore')

def utf(t):
	try:t=t.decode('windows-1251')
	except: pass
	try:t=t.decode(sys.getfilesystemencoding())
	except: pass
	try:t=t.encode('utf-8')
	except: pass
	return t

def getURL(url, Referer = httpSiteUrl):
	urllib2.install_opener(urllib2.build_opener()) 
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	#req.add_header('User-Agent', 'DuneHD/1.0.3')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req, timeout=5)
	link=response.read()
	response.close()
	return link


def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2



class PZL:
	def Streams(self, url):
		#print url
		h=getURL(url)
		stream = mfind(h,'file:"','.m3u8')+'.m3u8'
		if 'zabava' in stream: return []
		#print stream
		return [stream,]


	def Canals(self):
		n1=0
		n2=0
		Lgr=['/%D0%94%D0%B5%D1%82%D1%81%D0%BA%D0%B8%D0%B5TV', '/HDTV', '/%D0%91%D0%B5%D0%BB%D0%BE%D1%80%D1%83%D1%81%D1%81%D0%BA%D0%B8%D0%B5TV', '/%D0%94%D1%80%D1%83%D0%B3%D0%B8%D0%B5TV', '/%D0%9A%D0%B8%D0%BD%D0%BETV', '/%D0%9C%D1%83%D0%B7%D1%8B%D0%BA%D0%B0%D0%BB%D1%8C%D0%BD%D1%8B%D0%B5TV', '/%D0%9F%D0%BE%D0%B7%D0%BD%D0%B0%D0%B2%D0%B0%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D1%8B%D0%B5TV', '/%D0%A0%D0%B0%D0%B7%D0%BD%D0%BE%D0%B5TV', '/%D0%A0%D0%BE%D1%81%D1%81%D0%B8%D0%B9%D1%81%D0%BA%D0%B8%D0%B5TV', '/%D0%A1%D0%BF%D0%BE%D1%80%D1%82TV', '/%D0%A3%D0%BA%D1%80%D0%B0%D0%B8%D0%BD%D1%81%D0%BA%D0%B8%D0%B5TV']
		h=''
		for gr in Lgr:
			print httpSiteUrl+gr
			try:
				#print len(h)
				h=h+getURL(httpSiteUrl+gr)
			except: 
				print 'err'
		L=mfindal(h, 'class="div_video1">', '</p>')
		LL=[]
		for i in L:
				try:
						i=i+'<'
						url   =  httpSiteUrl + mfind(i,'href="','"')
						img   =  httpSiteUrl +'/'+ mfind(i,'img src="','"')
						title =  mfind(i,'p_tv">','<').strip()
						if url!=httpSiteUrl: 
							h2=getURL(url)
							n1+=1
							if 'zabava' not in h2  and 'wifiretv' not in h2:
								n2+=1
								LL.append({'url':url, 'img':img, 'title':title, 'group':''})
								print str(len(L))+' / '+str(n1)+' / '+str(n2)
				except:
					pass
		return LL

#p=PZL()
#cn = p.Canals()[3]['url']
#p.Streams(cn)
#time.sleep(30)