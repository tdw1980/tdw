#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys, urllib2
import settings
import time, random
#-----------------------------------------
prov = 'lada'
serv_id = '37'
provider = 'ILD_TLT'
port = 4022

def FAST():
	if settings.get('fast_udp')=='false': return False
	else: return True

udpxylist = []

try:
	import xbmcaddon
	addon = xbmcaddon.Addon(id='ptv3')
	root_dir = addon.getAddonInfo('path')
except:
	root_dir = os.getcwd()


from threading import Thread
class MyThread(Thread):
	def __init__(self, param={}):
		Thread.__init__(self)
	
	def run(self):
		upd_xy()

def test(url):
	sys.path.append(root_dir)
	import uxymtst
	return uxymtst.test(url)

def update():
	try: up_tm = float(settings.get('udpxy_uptime'))
	except: up_tm = 0
	if time.time() - up_tm > 300:
		settings.set('udpxy_uptime', time.time())
		my_thread = MyThread()
		my_thread.start()
	else:
		print 'uptime: '+str(time.time() - up_tm)


def get_channels(n):
	try:
		sys.path.append(root_dir)
		import uxydb
		D = uxydb.get_info(n)
		return D
	except:
		return {'data': [], 'time':0}

def save_channels(n, L):
	try:
		sys.path.append(root_dir)
		import uxydb
		D={'data': L, 'time':time.time()}
		uxydb.add(n, D)
	except:
		print 'ERR ADD uxydb'

def get_ux_ip():
			global udpxylist
			import random
			if udpxylist == []: udpxylist = get_all_xy()
			uip = random.choice(udpxylist)
			return uip+':'+str(port)

def upd_wl():
	L = get_all_xy()
	try: 	Lwl = get_channels(provider+'/wl')['data']
	except: Lwl = []
	for i in L:
		if i not in Lwl: Lwl.append(i)
	save_channels(provider+'/wl', Lwl)

def get_all_xy():
	if FAST(): 
		try: uptm = float(settings.get('uptime_fast_'+provider))
		except: uptm = time.time()
		print (uptm)
		if int(time.time()) - uptm < 3600:
				print ('uptm ok')
				try: L = eval(settings.get('cache_fast_'+provider))
				except: L = []
				print (L)
				if L!=[]: return L
		try: L = get_channels(provider+'/fast')['data']
		except: L=[]
		settings.set('uptime_fast_'+provider, time.time())
		settings.set('cache_fast_'+provider, repr(L))
		if L!=[]: return L
	LL=[]
	Lip = get_channels(provider+'/ip')
	for i in Lip:
		try:
			L=get_channels(provider+'/'+i)['data']
			LL.extend(L)
		except:
			pass
	return LL #list(set())

def upd_xy():
	if FAST(): 
		try: L=upd_xy_fast()
		except: L=[]
		if L!=[]: return L
	print 'upd_xy next'
	import random
	import scanxy
	Lip = get_channels(provider+'/ip')
	Lcn = get_channels(provider+'/cl')
	pref_old=''
	random.shuffle(Lip)
	for pref in Lip:
		print pref
		tm = get_channels(provider+'/'+pref)['time']
		if time.time()-tm > 3600*12:
			L=scanxy.scaner(provider, pref, port)
			Lr = []
			for uip in L:
				mcast = random.choice(Lcn)['url'].replace(prov+':','')
				udpxy = uip+':'+str(port)
				stream = 'http://%s/udp/%s' % (udpxy, mcast)
				#print stream
				if test(stream) != '404':
					Lr.append(uip)
			print prov+' GOOD: '+ str(len(Lr))
			save_channels(provider+'/'+pref, Lr)
			upd_wl()
			return L
	upd_xy_fast()

def upd_xy_fast():
	print 'upd_xy_fast'
	import scanxy
	try: 	Lwl = get_channels(provider+'/wl')['data']
	except: Lwl = []
	Lcn = get_channels(provider+'/cl')
	Lr = []
	for uip in Lwl:
		mcast = random.choice(Lcn)['url'].replace(prov+':','')
		udpxy = uip+':'+str(port)
		stream = 'http://%s/udp/%s' % (udpxy, mcast)
		#print stream
		if test(stream) != '404': Lr.append(uip)
	print prov+' GOOD: '+ str(len(Lr))
	save_channels(provider+'/fast', Lr)
	return Lr

class PZL:
	def Streams(self, url):
			mcast = url.replace(prov+':','')
			cbl = []
			#try:
			udpxylist = get_all_xy()
			if udpxylist ==[]:
					update()
					return []
			else:
					sys.path.append(root_dir)
					import uxymtst
					strm_list = []
					for udpxy in udpxylist:
						stream = 'http://%s:%s/udp/%s' % (udpxy, port, mcast)
						strm_list.append(stream)
					if settings.get('test_url')=='true': L=uxymtst.multitest(strm_list,1)
					else: L=strm_list
					random.shuffle(L)
					if L==[]: update()
					return L
				
			#except: update()
			return []
	
	def Canals(self):
			L = get_channels(provider+'/cl')
			update()
			return L