#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, cookielib, urllib, urllib2, time

serv_id = '04'
siteUrl = 'ottv.xyz'
httpSiteUrl = 'http://' + siteUrl


def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)


def getURL(url, Referer = httpSiteUrl):
	urllib2.install_opener(urllib2.build_opener())
	req = urllib2.Request(url)
	req.add_header('accept-encoding', 'gzip, deflate, br')
	req.add_header('accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9')
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 OPR/77.0.4054.203')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	if response.info().get('Content-Encoding') == 'gzip':
		from StringIO import StringIO
		import gzip
		buf = StringIO(response.read())
		f = gzip.GzipFile(fileobj=buf)
		data = f.read()
	else:
		data = response.read()
	link=response.read()
	response.close()
	return data

def convert(url):
	import base64
	redir='http://arne-post.de/index.php?q='+urllib.quote_plus(url)+'&hl=240'#base64.b64encode()206
	return redir

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


class PZL:

	def Streams(self, url):
		#url = url.replace('telehub:','http://cdnpotok.com/onnet/')+'.php'
		#print url
		h=getURL(url)
		#print h
		import base64
		stream = base64.b64decode(mfind(h,'file:y("','"'))
		
		#print stream
		return [stream,]

	def Canals(self):
		h=getURL(httpSiteUrl)#convert(),''
		L=mfindal(h, '<span><a', '/a></span>')
		LL=[]
		LLL=[]
		for i in L:
				try:
					print '------------'
					#print i
					url   =  httpSiteUrl + mfind(i,'href="','"')
					print url
					img   =  httpSiteUrl + mfind(i,'src="','"')
					title =  mfind(i,'alt="','"').strip()
					print title
						
					if url not in LLL:
							LLL.append(url)
							LL.append({'url':url, 'img':img, 'title':title})
				except:
					pass
		return LL

#p=PZL()
#print p.Canals()
#time.sleep(1000)