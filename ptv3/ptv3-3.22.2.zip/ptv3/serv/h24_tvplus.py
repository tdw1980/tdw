#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, urllib, urllib2, time
#import settings

serv_id = '24'
siteUrl = 'tvplusonline.ru'
httpSiteUrl = 'http://www.' + siteUrl

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)


def GET(url, Referer = httpSiteUrl, prx=False):
	req = urllib2.Request(url)
	req.add_header('Cookie', 'device_token=HKiQsw6KMmdPrmTm6edJBA_1962950213_8148817_f76c0a3b-9671-45a6-ba76-768571723ede_; session_token=Q1QAnRMLtbjzbGHZQL-pWg_1647503813_c4ca4238a0b923820dcc509a6f75849b_8148817_1_')
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


def findall(http, ss, es):
	L=[]
	s=http.find(ss)
	http=http[s:]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


class PZL:
	def Streams(self, url):
		#print (url)
		id = url.replace('tvplus:','')
		url2 = httpSiteUrl+'/api/channels/hls/'+id
		h=GET(url2).replace('\\/','/')
		true=True
		false=False
		null=None
		strm = eval(h)['url']
		return [strm]
	
	def Canals(self):
		h = GET(httpSiteUrl+'/api/channels')
		true=True
		false=False
		null=None
		L = eval(h)
		LL=[]
		for i in L:
			#if 'Бесплатно' in i:
			if i['closed'] == 0:
				url = 'tvplus:'+str(i['name'])
				title = eval("u'"+i['title']+"'").encode('utf-8')
				#print (title)
				img = ''
				LL.append({'url':url, 'img':img, 'title':title})
		return LL
#p=PZL()
#p.Canals()
#p.Streams(i['url'].decode('utf-8'))
#time.sleep(10)