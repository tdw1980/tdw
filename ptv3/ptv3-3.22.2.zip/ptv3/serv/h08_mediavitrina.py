#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, cookielib, urllib, urllib2, time, ssl, json
context = ssl.SSLContext(ssl.PROTOCOL_TLSv1)

serv_id = '3'
siteUrl = 'vitrina.tv'
httpSiteUrl = 'https://' + siteUrl

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)


def GET(url, Referer = httpSiteUrl):
	urllib2.install_opener(urllib2.build_opener())
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('content-type', 'application/json; charset=utf-8')
	#req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

mv_token = ''
tkt = 0
def get_token():
	global mv_token, tkt
	if mv_token!='' and time.time()-tkt < 60*60*1: return mv_token
	
	r=GET('https://media.mediavitrina.ru/get_token', 'https://media.mediavitrina')
	j=eval(r)
	t=j['result']['token']
	mv_token = t
	tkt = time.time()
	return t

get_token()

class PZL:
	def Streams(self, url):
		print url
		url = url+'?token='+get_token()
		false = False
		true = True
		null = None

		L=eval(GET(url))['hls']
		return L
	
	def Canals(self):
		hp=GET('https://static-api.mediavitrina.ru/v1/vitrinatv_app/web/3/config.json')#.replace('\\/','/')
		false = False
		true = True
		null = None
		jsn = json.loads(hp)# eval(hp)
		#print jsn
		L=jsn['result']['channels']
		LL=[]
		for i in L:
			try:
				#if i['public']==True:
					url1   = i['web_player_url']
					#print url1
					t=GET(url1)
					#print t
					if 'media.mediavitrina.ru/api' in t: url = 'https://media.mediavitrina.ru/api/'+mfind(t,'media.mediavitrina.ru/api/',".json")
					elif 'media.mediavitrina.ru/proxyapi' in t: url = 'https://media.mediavitrina.ru/proxyapi/'+mfind(t,'media.mediavitrina.ru/proxyapi/',"'")
					url = url.replace('/v3/','/v2/')+'.json'
					title = i['channel_title']
					print title+' '+url
					LL.append({'url':url, 'img':'', 'title':title, 'group':''})
					
			except:
					print i
		return LL

#p=PZL()
#print p.Canals()