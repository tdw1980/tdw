#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, urllib, urllib2, time
#import settings

serv_id = '23'
siteUrl = 'hd8.hdgo.site'
httpSiteUrl = 'http://' + siteUrl

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)


def GET(url, Referer = httpSiteUrl, prx=False):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


def findall(http, ss, es):
	L=[]
	s=http.find(ss)
	http=http[s:]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


class PZL:
	def Streams(self, url):
		#print (url)
		#url = url.replace('tvin:', httpSiteUrl+'/view-tv-online/')
		h=GET(url)
		L=findall(h,'?file=', '"')
		LL=[]
		for i in L:
			if 'm3u' in i:
				strm=i[6:]
				if ' or ' in strm: 
					L2=strm.split(' or ')
					for st in L2:
						if 'm3u' in st: LL.append(st)
				else: LL.append(strm)
				
		return LL
	
	def Canals(self):
		h=''
		for i in range(32):
			h += GET(httpSiteUrl+'/channels/page/'+str(i))
		
		
		L=findall(h, 'short-img img-box', 'short-desc')
		LL=[]
		for i in L:
			#if 'Бесплатно' in i:
				url = mfind(i,'data-href="','"')
				title = mfind(i,'alt="','"')
				img = httpSiteUrl+mfind(i,'<img src="','"')
				LL.append({'url':url, 'img':img, 'title':title})
		return LL
#p=PZL()
#p.Canals()
#p.Streams(i['url'].decode('utf-8'))
#time.sleep(10)