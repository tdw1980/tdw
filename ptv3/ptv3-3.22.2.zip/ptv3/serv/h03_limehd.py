#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, cookielib, urllib, urllib2, time, ssl
context = ssl.SSLContext(ssl.PROTOCOL_TLSv1)

serv_id = '3'
siteUrl = 'limehd.tv'
httpSiteUrl = 'https://' + siteUrl

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)


def GET(url, Referer = httpSiteUrl):
	urllib2.install_opener(urllib2.build_opener())
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	req.add_header('c2RmO2w7a2xtYm93ZW9wbDM5MDQ1NGxnZGZh', 'c2Rmc2RmYmphc2tmc2pkZiZedDUyMzc0OHVzOWZaQ1YoODk5MFNGKDMyOTByc2Zrc2tkZm5zZG9pZigpKiZmODlzZA==')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


class PZL:
	def Streams(self, url):
		print url
		id=url[7:]
		#try:
		hp=GET(httpSiteUrl+'/api/v4/channel/'+id+'?tz=3')
		false = False
		true = True
		null = None
		jsn = eval(hp)
		link =jsn['url']
		print link
		return [link]
	
	def Canals(self):
		
		hp=GET(httpSiteUrl+'/api/v4/playlist?page=1&limit=399&onlyavailable=1&epg=0&epgcnt=0&tz=3')
		false = False
		true = True
		null = None
		jsn = eval(hp)
		L=jsn['channels']
		LL=[]
		for i in L:
			try:
				if i['public']==True:
					id    = i['address']
					url   = 'limehd:'+id
					title = i['name_ru']
					img   = i['image']
					LL.append({'url':url, 'img':img, 'title':title, 'group':''})
			except:
					print i
		return LL

#p=PZL()
#print p.Canals()