# coding: utf-8
# Module: server
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
import sys, os, json
import time
import urllib2

def getURL(url, Referer = ''):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36 OPR/78.0.4093.147')
	req.add_header('Accept', 'application/json')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link
	


def yatv():
	ncrd=str(long(time.time())*1000+1080)
	dtm=time.strftime('%Y-%m-%d')
	
	r = getURL('https://epg.domru.ru/channel/list?digit=1&domain=voronezh')
	
	r = r.replace('\\/','/').replace('false','False').replace('true','True').replace('\\"',"'").replace('null','None')
	#print r
	L = eval(r)
	Lcnl=[]
	Dcnl={}
	for i in L:
		Lcnl.append(i['xvid'])
		Dcnl[i['xvid']]=i['title']
	
	
	channelIds=''
	nc = 0
	for i in Lcnl:
		channelIds+='&xvid['+str(nc)+']='+str(i)
		nc+=1
		#if nc>10: break
	
	
	
	url2='https://epg.domru.ru/program/list?digit=1&date_from='+dtm+'+00:00&date_to='+dtm+'+23:59'+channelIds+'&domain=voronezh'
	print url2
	r2 = getURL(url2)
	r2 = r2.replace('\\/','/').replace('false','False').replace('true','True').replace('\\"',"'").replace('null','None')
	D2 = eval(r2)
	
	tmp=[]
	for k in D2.keys():
				i=D2[k]
				print k
		#if i['xvid'] not in tmp:
		#	print i['xvid']
		#	tmp.append(i['xvid'])

		#try:
				title=Dcnl[k]
				print title
				channel_id=str(k)
				idx=get_id(title)
				
				Le=[]
				De={}
				L2=D2[k]#events
				for j in L2:
					start      =    j['start']
					ptitle     =    j['title']
					try:plot   =    j['desc']
					except: plot = ''
					#try: type=j['tid']
					#except: 
					type=''
					img='https://voronezh.dom.ru/epgservice/ertelecomipfile/pic/'+j['icon']
					
					cdata = time.strftime('%Y%m%d')
					pdata = start[:10].replace('-','')
					if True:#pdata==cdata:
						start_at=start.replace('+03:00','').replace('T',' ')#2016-07-22T04:20:00+03:00
						#print "-==-=-=-=-=-=-=-=-=-=-"
						try:strptime=time.strptime(start_at , '%Y-%m-%d %H:%M:%S')
						except:
							time.sleep(1)
							try:strptime=time.strptime(start_at , '%Y-%m-%d %H:%M:%S')
							except: strptime=0
						if strptime!=0:
							tms=str(time.mktime(strptime))
							De[tms]={"title":rt(ptitle), 'img': img, 'plot': plot, 'type':type}
				De['title']=title
				
				if idx!="":
					if settings.get('epg_low')=='true': LOW_EPG(idx, De)
					elif settings.get('epg_mix')=='true': ADD_EPG(idx, De)
					else: EPG[idx]=De
		#except:
		#		pass


def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	if e=='': return r
	r2=r[:r.find(e)]
	return r2

def yatv_2():
	import json, time
	ncrd=str(long(time.time())*1000+1080)
	dtm=time.strftime('%Y-%m-%d')
	
	BLcnl=[803,802,799,798,788,787,786,784,782,781,780,776,775,774,772,770,768,767,765,764,762,761,760,759,758,757,756,755,754,753,752,751,750,749,748,747,746,745,738,735,730,728,727,726,725,724,723,722,721,719,718,717,716,714,711,709,708,706,705,703,699,698,696,695,694,693,692,690,688,687,686,681,680,679,676,673,672,670,669,668,667,665,664,663,662,661,660,657,654,652,651,650,648,647,642,640,639,637,636,633,631,630,629,628,626,625,624,623,620,616,614,613,611,610,606,605,604,603,602,599,598,597,594,592,589,588,587,585,584,582,581,580,574,571,568,566,564,563,561,560,558,557,556,555,554,550,549,546,545,544,543,541,540,539,536,535,534,531,530,529,527,526,522,521,519,518,517,515,514,512,510,508,507,506,504,503,502,500,498,497,490,489,488,487,486,485,483,482,481,480,476,474,473,471,469,466,465,464,463,462,461,460,458,457,455,454,453,452,451,450,449,448,447,445,444,442,441,439,437,435,433,431,429,428,422,420,419,416,415,414,413,411,410,409,407,406,405,403,401,400,399,398,397,394,393,392,389,388,387,385,384,383,381,380,379,378,377,376,375,374,373,372,371,370,369,368,367,366,365,364,363,362,361,360,359,358,357,356,355,354,353,352,351,350,349,348,347,346,345,344,343,342,341,340,339,338,337,336,335,334,333,332,331,330,329,328,327,326,325,324,323,322,321,320,319,318,317,316,315,314,313,312,311,310,309,308,307,306,305,304,303,302,301,300,299,298,297,296,295,294,293,292,291,290,289,288,287,286,285,284,283,282,281,280,279,278,277,276,275,274,273,272,271,270,269,268,267,266,265,264,263,262,261,260,259,258,257,256,255,254,253,252,251,250,249,248,243,240,228,227,226,224,223,222,219,216,215,213,210,207,205,202,200,199,194,192,190,189,187,186,182,179,170,169,160,158,156,153,149,146,141,136,135,134,133,132,130,128,126,125,124,118,117,114,113,90,87,83,81,79,76,74,72,67,61,60,59,53,47,46,45,44,43,41,39,38,37,36,35,34,28,27,26,25,24,19,13,10,9,7,6,2,1]

	for id in range(1,800):#Lcnl
		if id not in BLcnl:
			#try:
				url='https://tv.yandex.ru/channel/'+str(id)
				#print url
				cn =  mfind (getURL(url),'INITIAL_STATE__ =', '};' )+'}'
				D=json.loads(cn)['channel']
				
				title=D['channel']['title']
				#print title
				channel_id=id#str(i['channel']['id'])
				idx=get_id(title)
				#print id
				
				Le=[]
				De={}
				L2=D['schedule']['events']
				for j in L2:
					start      =    j['start']
					ptitle     =    j['program']['title']
					img        =    'https:'+j['program']['mainImageBaseUrl']+'/300x225'
					try:plot   =    j['program']['description']
					except: plot = ''
					try: type=j['program']['type']['name']
					except: type=''
					#if etitle == ptitle: etitle = ''
					#if etitle != '': ptitle=ptitle+' '+etitle
					
					cdata = time.strftime('%Y%m%d')
					pdata = start[:10].replace('-','')
					if True:#pdata==cdata:
						start_at=start.replace('+03:00','').replace('T',' ')#2016-07-22T04:20:00+03:00
						#print "-==-=-=-=-=-=-=-=-=-=-"
						try:strptime=time.strptime(start_at , '%Y-%m-%d %H:%M:%S')
						except:
							time.sleep(1)
							try:strptime=time.strptime(start_at , '%Y-%m-%d %H:%M:%S')
							except: strptime=0
						if strptime!=0:
							tms=str(time.mktime(strptime))
							De[tms]={"title":rt(ptitle), 'img': img, 'plot': plot, 'type':type}
				#E2=repr(Le)
				#Ed=repr(De)
				De['title']=title
				#pDialog.update(int(n*100/31), message=title)
				if idx!="":
					if settings.get('epg_low')=='true': LOW_EPG(idx, De)
					elif settings.get('epg_mix')=='true': ADD_EPG(idx, De)
					else: EPG[idx]=De
			#except:
			#	pass
'''

yatv_2()
#print getURL('https://ntvplus.ru/tv/ajax/tv?genre=all&date=30.09.2021&tz=0&search=&channel=&offset=0')#https://tv.yandex.ru/channel/eda-premium-742
#cn =  mfind (getURL('https://tv.yandex.ru/channel/eda-premium-742'),'INITIAL_STATE__ =', '};' )+'}'
#import json, time
#L=json.loads(cn)['channel']
#print L
time.sleep(1000)