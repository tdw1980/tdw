# -*- coding: utf-8 -*-
BLs=[
"asd:http://spacetv.in/stream/CMSJHFDLR2/172.m3u8",
"asd:http://4f9cc916.ottv.info/iptv/G4FZPPQUWQ68DR/140/index.m3u8",
]
