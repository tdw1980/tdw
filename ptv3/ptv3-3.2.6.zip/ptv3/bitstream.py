# -*- coding: utf-8 -*-
import urllib2, time
block_sz = 819200

stack = []
buf=None
run_t = 0
comp = 0

from threading import Thread
class MyThread(Thread):
	def __init__(self, resp):
		Thread.__init__(self)
		self.resp = resp
		#self.n = n
	
	def run(self):
		#try:
			global comp
			global buf
			buf=self.resp.read(block_sz)
			comp += 1
		#except:
		#	stack[self.n]=stack[self.n-1]


class BS():
	def __init__(self, url):
		req = urllib2.Request(url)
		self.resp = urllib2.urlopen(req)
		#buf = self.resp.read(block_sz)
		self.last = None#buf
		self.url = url
		self.list = []
		self.run = 0
		self.complit = 0
		self.n = 0
		
		#self.stack = [None,None,None,None,None,None,None,None,None,None]

	def GET(self):
		data=self.resp.read(block_sz)
		#response.close()
		return data

	def get_head(self, url):
		return url[:url.rfind('/')+1]

	def get_data(self):
		print '============= get_data ==============='
		print str(self.n)
		#self.create_thread(self.resp)
		#time.sleep(1)
		self.n+=1
		#if buf == self.last:
		#	data = None
		#	print 'none'
		#else: 
		#	data = buf
		#	self.last = buf
		#	self.complit +=1
		#if data==None: 
		#	self.n=0
		#else:
		
		#if data != None: print 'OK'
		return self.GET()
	
	def create_thread(self, resp):
		print 'create_thread '+str(self.run) +'/'+ str(self.complit)
		#buf=None
		if self.run == self.complit:
			my_thread = MyThread(resp)
			my_thread.start()
			self.run +=1