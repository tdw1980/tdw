# -*- coding: utf-8 -*-
import os
try:
	import xbmcaddon, xbmc
	addon = xbmcaddon.Addon(id='ptv3')
	set=xbmcaddon.Addon(id='ptv3')
	set.setSetting("ptv",'3')
	#db_dir = os.path.join(addon.getAddonInfo('path'),"settings")
	db_dir = os.path.join(xbmc.translatePath("special://masterprofile/"),"addon_data","ptv3")
except:
	db_dir = os.path.join(os.getcwd(), "settings" )

def set(key, val):
	try:
		fp=os.path.join(db_dir, key)
		fl = open(fp, "w")
		fl.write(repr(val))
		fl.close()
		return 'ok'
	except:
		return 'error set '+key

def get(key):
	try:
		fp=os.path.join(db_dir, key)
		fl = open(fp, "r")
		t=fl.read()
		fl.close()
		return eval(t)
	except:
		return ''

#print set('KEY', 'VALUE')
#print get('KEY')
