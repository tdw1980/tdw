# -*- coding: utf-8 -*-

def trigger(link):
	F='<a href="LINK"><img border=0 width=37 height=19 src="webui.files/off.jpg"></a>'
	T='<a href="LINK"><img border=0 width=37 height=19 src="webui.files/on.jpg"></a>'
	N='<a href="LINK"><img border=0 width=37 height=19 src="webui.files/def.jpg"></a>'

	if 'val/true' in link:
		return T.replace('LINK', link.replace('true','false'))
	elif 'val/false' in link:
		return F.replace('LINK', link.replace('false','true'))
	else:
		return N.replace('LINK', link[:link.rfind('/')+1]+'true')


def on_off(link):
	F='<a href="LINK"><img border=0 width=37 height=19 src="webui.files/off.jpg"></a>'
	T='<a href="LINK"><img border=0 width=37 height=19 src="webui.files/on.jpg"></a>'
	N='<a href="LINK"><img border=0 width=37 height=19 src="webui.files/def.jpg"></a>'
	
	if '/rem' in link:
		return T.replace('LINK', link)
	elif '/add' in link:
		return F.replace('LINK', link)

def lock_btn(link):
	L='<a href="LINK"><img border=0 width=37 height=19 src="webui.files/lock2.jpg"></a>'
	U='<a href="LINK"><img border=0 width=37 height=19 src="webui.files/unlock2.jpg"></a>'
	
	if '/lock' in link:
		return U.replace('LINK', link)
	elif '/unlock' in link:
		return L.replace('LINK', link)

def buton (link):
	ico = ''
	if '/update/' in link: ico = 'ref'
	elif '/unite' in link: ico = 'unt'
	elif '/split' in link: ico = 'spl'
	elif '/up'    in link: ico = 'up'
	elif '/down'  in link: ico = 'down'
	elif '/rem'   in link: ico = 'rem'
	elif '/lock'  in link: ico = 'lock'
	elif '/unlock'in link: ico = 'unlk'
	elif '/info'  in link: ico = 'inf'
	B = '<a href="LINK"><img border=0 width=19 height=19 src="webui.files/'+ico+'.jpg"></a>'
	return B.replace('LINK', link)

def item(param):
	it=" <tr style='border:solid black 1.0pt;'>\
	  <td style='padding:0cm 1.4pt 0cm 1.4pt'><img border=0 width=20 height=20 src='[IMG]'></td>\
	  <td>[NAME]</td>\
	  <td style='padding:0cm 5.4pt 0cm 5.4pt'><p>[OPTION]</p></td>\
	  <td><p>[GROUP]</p></td>\
	  <td style='padding:0cm 5.4pt 0cm 5.4pt'><a name='[CID]'>[CID]</a></td>\
	 </tr>"#<p></p>
	
	gr = param['group']
	cid = param['cid']
	option = param['option']
	name = param['name']
	enable = param['enable']
	img = 'http://td-soft.narod.ru/logo/picon/'+cid+'.png'
	
	spc  ='<a><img border=0 width=19 height=19 src="webui.files/space.jpg"></a>'
	on = on_off('/channel/'+cid+'/rem')
	off = on_off('/channel/'+cid+'/add')
	unt = buton ('/channel/'+cid+'/unite')
	spl = buton ('/channel/'+cid+'/split')
	inf = buton ('/info/'+cid)
	
	option = option.replace('[V]', on).replace('[X]', off).replace('[U]', unt).replace('[S]', spl).replace('[I]', inf).replace('[Sp]', spc)
	
	it=it.replace('[NAME]',   input('/channel/'+cid+'/rename/', name, 200, enable))
	it=it.replace('[CID]',    cid )
	it=it.replace('[OPTION]', option)
	it=it.replace('[GROUP]',  input('/channel/'+cid+'/set_group/', gr, 200, enable))
	it=it.replace('[IMG]', img)
	
	try:it=it.decode('utf-8')
	except: pass
	try:it=it.encode('windows-1251')
	except: pass
	return it

def item2(link, name, img=''):
	it=" <tr style='mso-yfti-irow:1'>\
	  <td width=366 valign=top style='width:274.75pt;border:solid black 1.0pt;\
	  mso-border-themecolor:text1;border-top:none;mso-border-top-alt:solid black .5pt;\
	  mso-border-top-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:text1;\
	  padding:0cm 5.4pt 0cm 5.4pt'>\
	  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:normal'>\
	  <span lang=EN-US style='mso-ansi-language:EN-US'> <img border=0 width=20 height=20 src='[IMG]'> <a href='[LINK]'>[NAME]</a><o:p></o:p></span></p>\
	  </td>\
	 </tr>"
	 
	it=it.replace('[NAME]',   name)
	it=it.replace('[LINK]',   link )
	it=it.replace('[IMG]', img)
	
	try:it=it.decode('utf-8')
	except: pass
	try:it=it.encode('windows-1251')
	except: pass
		
	return it

def item3(param):
	it=" <tr style='border:solid black 1.0pt;'>\
	  <td>[NAME]</td>\
	  <td style='padding:0cm 5.4pt 0cm 5.4pt'><p>[OPTION]</p></td>\
	 </tr>"
	
	option = '[>] [<] [U] [L] [Sp] [X]'
	name = param['name']
	lock = param['lock']
	gid = str(param['id'])
	
	spc  ='<a><img border=0 width=19 height=19 src="webui.files/space.jpg"></a>'
	up   = buton ('/group/'+gid+'/up')
	down = buton ('/group/'+gid+'/down')
	unt  = buton ('/group/'+gid+'/unite')
	rem  = buton ('/group/'+gid+'/rem')
	if lock == 'true': lk = lock_btn('/group/'+gid+'/unlock')
	else:              lk = lock_btn('/group/'+gid+'/lock')
	option = option.replace('[<]', up).replace('[>]', down).replace('[U]', unt).replace('[L]', lk).replace('[X]', rem).replace('[Sp]', spc)
	
	it=it.replace('[NAME]',   input('/group/'+gid+'/rename/', name, 200))
	it=it.replace('[OPTION]', option)
	
	try:it=it.decode('utf-8')
	except: pass
	try:it=it.encode('windows-1251')
	except: pass
	return it

def item4(param):
	it=" <tr style='border:solid black 1.0pt;'>\
	  <td style='padding:0cm 5.4pt 0cm 5.4pt'>[NAME]</td>\
	  <td style='padding:0cm 5.4pt 0cm 5.4pt'><p>[LINK]</p></td>\
	 </tr>"
	it=it.replace('[NAME]', param['serv'])
	it=it.replace('[LINK]', param['url'])
	
	try:it=it.decode('utf-8')
	except: pass
	try:it=it.encode('windows-1251')
	except: pass
	return it



def input(link, val='', width=110, enable=True):
	if enable: dis =''
	else: dis = 'disabled'
	t="<form style='width:"+str(width)+"pt;height:3.5pt;' action='[ADR]' method='get'><input style='width:"+str(width-28)+"pt;' type='text' name='val' value='[VAL]'/><input type='submit' value='ok' "+dis+"/></form>"
	t=t.replace('[ADR]', link)
	t=t.replace('[VAL]', val)
	return t
