# -*- coding: utf-8 -*-
BLs=[
"asd:http://spacetv.in/stream/CMSJHFDLR2/172.m3u8",
"asd:http://4f9cc916.ottv.info/iptv/G4FZPPQUWQ68DR/140/index.m3u8",
"searchace:b007ee2339cf3950df644166e715530c43a9ae30",
"searchace:bb48c31a2b1b9254b7e18466d51e3b772ff58d39",
"searchace:82ad6e0d5d093a869a893cf2320e16bfc727fc78",
"1tv_top:cb7315e76a3e18fb73625eae79cdc000731ba5ee",
"1tv_top:a6b7bdabccf055851133d3bb69ef4ca34ade9faa",
"1tv_top:f39bdec37607d493f675c403de978ebdd047d8ba",
"1tv_top:71128a8a0d08574134a8134cdb4e53e889d5e23e",
"1tv_top:d288e303032c9f4fa27d56d2ebe4a7ef40b13d5f",
]
