# -*- coding: utf-8 -*-
import urllib2, time, cookielib, os
sid_file = os.path.join(os.getcwd(), 'hls.sid')

cj = cookielib.FileCookieJar(sid_file) 
hr  = urllib2.HTTPCookieProcessor(cj) 
opener = urllib2.build_opener(hr) 
urllib2.install_opener(opener) 


class HLS():
	def __init__(self, hls_url):
		self.hls_url = hls_url
		self.hls_list = []
		self.hls_complit = []
		self.hls_n = 0
		self.hls_i = 0

	def GET(self, url, Referer = 'http://ya.ru/'):
		#print url
		#import urllib2
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
		req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
		req.add_header('Accept-Language', 'ru,en;q=0.9')
		req.add_header('Referer', Referer)
		response = urllib2.urlopen(req)
		data=response.read()
		response.close()
		return data

	def get_list(self, url):
		print 'get_list'
		resp=self.GET(url)
		if '#EXTINF' not in resp: return []
		list=resp.splitlines()
		
		L=[]
		for i in list:
			if '#' not in i:
				print i
				if len (i)>5:
					L.append(i)
					#if i[:4]=='http': 
		return L

	def get_head(self, url):
		return url[:url.rfind('/')+1]

	def get_data(self):
		print '============= get_data ==============='
		if self.hls_n+1>=len(self.hls_list): 
			self.hls_list = []
			self.hls_n = 0
		list = self.get_list(self.hls_url)
		if list == []: return 'error'
		if self.hls_list == []: self.hls_list = list
		L=self.hls_list
		print str(self.hls_n)+'/'+str(len(L))
		head = self.get_head(self.hls_url)
		#print head
		if L[self.hls_n][:4]!='http': data_url = head+L[self.hls_n]
		else: data_url = L[self.hls_n]
		
		self.hls_n+=1
		if data_url not in self.hls_complit:
			print data_url
			data = self.GET(data_url, head)
			self.hls_complit.append(data_url)
		else:
			time.sleep(3)
			data = None
		return data


#sHLS = HLS('https://strm.yandex.ru/kal/fashiontv/fashiontv0_169_1080p.json/index-v1-a1.m3u8?partner_id=270171&target_ref=https%3A%2F%2Fyastatic.net&uuid=42ee5f579c38ea04a6d92ccefdbeed99&vsid=ojhxcxb2wxf48pv&redundant=5')
#sHLS.get_data()
#sHLS.get_data()
#sHLS.get_data()
#get_data('https://strm.yandex.ru/kal/fashiontv/fashiontv0_169_1080p.json/index-v1-a1.m3u8?partner_id=270171&target_ref=https%3A%2F%2Fyastatic.net&uuid=42ee5f579c38ea04a6d92ccefdbeed99&vsid=ojhxcxb2wxf48pv&redundant=5')