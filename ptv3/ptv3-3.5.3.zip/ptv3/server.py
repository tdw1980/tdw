# coding: utf-8
# Module: server
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer
import threading, SocketServer, BaseHTTPServer
quit_event = threading.Event()


import sys, os, json
import time
import urllib, urllib2, socket
import base64

import settings
import core
#import epg
import hls

buf = []
trd = [0]
twr = [0]
for b in range (100):
	buf.append(None)


try:
	import xbmcaddon
	addon = xbmcaddon.Addon(id='ptv3')
	root_dir = addon.getAddonInfo('path')
except:
	root_dir = os.getcwd()

#settings.set('port', 8185)
try: port = int(settings.get('port'))
except: 
	port = 8185
	settings.set('port', 8185)
if port=='': 
	port = 8185
	settings.set('port', 8185)

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def get_ip():
	IP = settings.get('ip')
	if IP == '' or settings.get('ip_chek')!='false':
		if 'win' in sys.platform:
			try:
				L = socket.gethostbyname_ex(socket.gethostname())[2]
				for ip in L:
					if '192.168.' in ip: 
							IP = ip
							break

			except: IP = '127.0.0.1'
		else:
			try:
				Ln = []
				for n in range(6):
					Ln.append('enp'+str(n)+'s0')
					Ln.append('wlp'+str(n)+'s0')
				for f in Ln:
					r = os.popen('ip addr show '+f).read()
					if 'inet ' in r:
						ip = mfind(r,'inet ','/')
						if '192.168.' in ip: 
							IP = ip
							break
			except: IP = '127.0.0.1'
		if '.' not in IP : IP = '127.0.0.1'
		settings.set('ip', IP)
	return IP


ip = get_ip()


print('----- Starting PTV3 0.5.3 -----')
print('HELP:     http://'+ip+':'+str(port))
print('PLAYLIST: http://'+ip+':'+str(port)+'/playlist')
trigger = True


# =========================== Базовые функции ================================
def fs_enc(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode('utf-8').encode(sys_enc)

def fs_dec(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode(sys_enc).encode('utf-8')

def lower(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in range (65,90):
		t=t.replace(chr(i),chr(i+32))
	for i in RUS.keys():
		t=t.replace(i,RUS[i])
	return t

def utf(t):
	try:t=t.decode('windows-1251')
	except: pass
	try:t=t.decode(sys.getfilesystemencoding())
	except: pass
	try:t=t.encode('utf-8')
	except: pass
	return t

def win(t):
	try:t=t.decode('utf-8')
	except: pass
	try:t=t.decode(sys.getfilesystemencoding())
	except: pass
	try:t=t.encode('windows-1251')
	except: pass
	return t

def upper(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in RUS.keys():
		t=t.replace(RUS[i],i)
	for i in range (65,90):
		t=t.replace(chr(i+32),chr(i))
	return t

def CRC32(buf):
		import binascii
		buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		return str("%08X" % buf)

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2
	
def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "w")
	fl.write(s)
	fl.close()



# ================================ server =====================================
set_list=[
	'Id_port',
	'Id_ip',
	'Id_unlock',
	'Id_split_1',
	'Id_split_2',
	'Id_split_3',
	'Id_split_4',
	'Id_serv21',]

tr_list=[
	'tr_unlock',
	'tr_p2p_start',
	'tr_ip_chek',
	'tr_addcnl',
	'tr_epg_on',
	'tr_autoshift',
	'tr_upd21',
	'tr_upd31',
	'tr_upd37',
	'tr_upd38',
	'tr_upd52',
	'tr_upd53',
	'tr_upd81',
	'tr_upd82',
	'tr_upd83',
	'tr_upd84',
	'tr_epg_iptvx',
	'tr_epg_prtv',
	'tr_epg_vsetv_ua',
	'tr_epg_vsetv_by',
	'tr_epg_vsetv_ru',
	'tr_epg_yatv',
	'tr_epg_mail',
	'tr_split_1',
	'tr_split_2',
	'tr_split_3',
	'tr_split_4',
	'tr_serv21',]

lb_list=[
	'lb_pr53',
	'lb_shift',
	]

upt_list=[
	'Id_upt21',
	'Id_upt31',
	'Id_upt33',
	'Id_upt37',
	'Id_upt38',
	'Id_upt52',
	'Id_upt53',
	'Id_upt11',
	'Id_upt12',
	'Id_upt15',
	'Id_upt10',
	'Id_upt81',
	'Id_upt82',
	'Id_upt83',
	'Id_upt84',
	'Id_upt9',
	'Id_upt5']

btn_list=['btn_upd53',]

ib_list=[
	'ib_port',
	'ib_ip',
	'ib_p2p_serv',
	'ib_mym3u1',
	'ib_mym3u2',
	'ib_mym3u3',
	'ib_mym3u4',
	]

for pid in range(99):
	sid=str(99-pid)
	lb_list.append ('lb_pr'+sid)
	tr_list.append ('tr_serv'+sid)
	tr_list.append ('tr_upd'+sid)
	set_list.append('Id_serv'+sid)
	btn_list.append('btn_upd'+sid)

fl = open(os.path.join(root_dir,"webui.htm"), "r")
temp_ui=fl.read()
fl.close()

def splitter(ui):
	Ls=['split_1','split_2','split_3','split_4']
	for id in Ls:
		if settings.get(id) == 'false':
			ui=ui.replace('<!--s_'+id+'-->', '<!--')
			ui=ui.replace('<!--e_'+id+'-->', '-->')
	return ui

import controls
def WebUI():
		
		ui=temp_ui
		if settings.get('ip_chek')!='false': 
			get_ip()
			ui=ui.replace('ib_ip', 'Id_ip')
		for i in set_list:
			id = i[3:]
			s = str(settings.get(id))
			if s=='true':  s = "<span style='color:green'>V</span>"
			if s=='false': s = "<span style='color:red'>X</span>"
			ui=ui.replace(i, s)
	
		for i in tr_list:
			id = i[3:]
			val = str(settings.get(id))
			s = controls.trigger('/settings/set/'+id+'/val/'+val)
			ui=ui.replace(i, s)
		
		for i in lb_list:
			id = i[3:]
			val = str(settings.get(id))
			s = controls.listbox('/settings/set/'+id+'/val/', ['','1','2','3','4','5'], val)
			ui=ui.replace(i, s)
		
		for i in ib_list:
			id = i[3:]
			val = str(settings.get(id))
			if 'mym3u' in i: w = 200
			else:            w = 110
			s = controls.input('/settings/set/'+id+'/val/', val, w)
			ui=ui.replace(i, s)
		
		for i in btn_list:
			id = i[7:]
			s = controls.button('/update/'+id)
			ui=ui.replace(i, s)
		
		for i in upt_list:
			id = i[6:]
			tm = core.get_cahe_time(id)
			tm = time.strftime('%H:%M %d.%m.%y',time.localtime(core.get_cahe_time(id)))
			#tm=
			ui=ui.replace(i, tm)
			
			s = str(settings.get('upd'+i[6:]))
			if s=='true': s = "<span style='color:green'>V</span>"
			if s=='false': s = "<span style='color:red'>X</span>"
			ui=ui.replace(i.replace('upt','up'), s)

		total=str(len(core.channels('all')))
		try:total=str(len(core.channels('all')))
		except: total='err'
		ui=ui.replace('Id_total', total)
		ui = splitter(ui)
		return ui

class cn_editor():
	def __init__(self):
		fl = open(os.path.join(root_dir,"webui.files", "cnl.htm"), "r")
		self.data = fl.read()
		fl.close()
		self.Lepg=epg.get_channels_list()
	
	def head(self):
		dt=self.data
		return dt[:dt.find('<!--items-->')]
	
	def list(self):
		L = core.get_base()
		return L
	
	def item(self, i):
			gr=''
			for g in i['group']:
				gr+=" | "+g
			gr=gr[3:]
			if i['enable']: option="[V]"
			else:           option="[X]"
			option+="[U]&nbsp;"
			if i['split']: option+="[S]&nbsp;"
			else:          option+="[Sp]&nbsp;"
			if i['enable']:option+="[I]"
			else:          option+="[Sp]"
			if i['id'] in self.Lepg: option+="&nbsp;[E]"
			itm = controls.item({'name':i['title'], 'cid':i['id'], 'group':gr, 'picon':i['picon'], 'option':option, 'enable':i['enable']})
			return itm
	
	def end(self):
		dt=self.data
		return dt[dt.find('<!--items-->'):]

def editor():
		fl = open(os.path.join(root_dir,"webui.files", "cnl.htm"), "r")
		data = fl.read()
		fl.close()
		L = core.get_base()#get_DBC()#channels('all')
		items=''
		Lepg=epg.get_channels_list()
		for i in L:
			gr=''
			for g in i['group']:
				gr+=" | "+g
			gr=gr[3:]
			if i['enable']: option="[V]"
			else:           option="[X]"
			option+="[U]&nbsp;"
			if i['split']: option+="[S]&nbsp;"
			else:          option+="[Sp]&nbsp;"
			if i['enable']:option+="[I]"
			if i['id'] in Lepg: option+="&nbsp;[E]"
			itm = controls.item({'name':i['title'], 'cid':i['id'], 'group':gr, 'picon':i['picon'], 'option':option, 'enable':i['enable']})
			try:
				items+=itm
			except:
				print 'err item'
		
		return data.replace('<!--items-->',items) 

def set_epg():
		fl = open(os.path.join(root_dir,"webui.files", "epg.htm"), "r")
		ui = fl.read()
		fl.close()
		for i in tr_list:
			id = i[3:]
			val = str(settings.get(id))
			s = controls.trigger('/settings/set/'+id+'/val/'+val)
			ui=ui.replace(i, s)
		
		for i in lb_list:
			id = i[3:]
			val = str(settings.get(id))
			s = controls.listbox('/settings/set/'+id+'/val/', ["+11","+10","+9","+8","+7","+6","+5","+4","+3","+2","+1","0","-1","-2","-3","-4","-5","-6","-7","-8","-9","-10","-11"], val)
			ui=ui.replace(i, s)

		return ui


def info(id):
		fl = open(os.path.join(root_dir,"webui.files", "info.htm"), "r")
		data = fl.read()
		fl.close()
		inf=""
		inf = core.DBC[id]
		nml = inf['names']
		idl = []
		nms = ''
		for nm in nml:
			nms+=nm+"; "
			idl.append(core.get_ID(nm))
		data=data.replace('[ID]', id)
		data=data.replace('[NAME]', win(inf['title']))
		data=data.replace('[SPLIT]', win(nms))
		gr=''
		for g in core.get_cn_groups(id):
				gr+=" | "+g
		gr=gr[3:]
		data=data.replace('[GROUP]', win(gr))
		img = "<img border=0 width=120 height=120 src='http://td-soft.narod.ru/logo/picon/"+id+".png'>"
		data=data.replace('[IMG]', img)
		LL=[]
		D=core.get_serv_dict()
		for s in D.keys():
			L=D[s]
			for i in L:
				if core.get_ID(i['title']) in idl:
				#if core.get_ID(i['title']) == id: 
					sid = i['url']
					if sid in core.BLs: lock = True
					else:               lock = False
					LL.append({'serv': s, 'url': i['url'], 'id':id, 'lock':lock, 'sid':sid})
		
		items=''
		for j in LL:
			itm = controls.item4(j)
			items+=itm
		
		data=data.replace('<!--items-->', win(items))
		return data


def unite_gr(id1):
		fl = open(os.path.join(root_dir,"webui.files", "unite_gr.htm"), "r")
		data = fl.read()
		fl.close()
		
		items=''
		L=core.open_Groups()
		id2=0
		for i in L:
			if id2 == id1:
				data=data.replace('[TITLE]', i[0])
			else:
				img = '/webui.files/space.jpg'
				itm = controls.item2("/group/"+str(id1)+"/unite/"+str(id2), i[0], img)
				try:
					items+=itm
				except:
					print 'err item'
			id2+=1
		
		data=data.replace('<!--items-->', items)
		
		return data

def unite(id1):
		fl = open(os.path.join(root_dir,"webui.files", "unite.htm"), "r")
		data = fl.read()
		fl.close()
		
		items=''
		L=core.get_DBC()
		for i in L:
			if i['id'] == id1:
				data=data.replace('[TITLE]', i['title'])
			else:
				img = 'http://td-soft.narod.ru/logo/picon/'+i['id']+'.png'
				itm = controls.item2("/channel/"+id1+"/unite/"+i['id'], i['title'], img)
				try:
					items+=itm
				except:
					print 'err item'
		
		data=data.replace('<!--items-->', items)
		
		return data

def split(id1):
		fl = open(os.path.join(root_dir,"webui.files", "split.htm"), "r")
		data = fl.read()
		fl.close()
		
		items=''
		i=core.DBC[id1]
		data=data.replace('[TITLE]', i['title'])
		L=i['names']
		for nm in L:
				img = '/webui.files/spl.jpg'
				itm = controls.item2("/channel/"+id1+"/split/"+nm, nm, img)
				try:
					items+=itm
				except:
					print 'err item'
		
		data=data.replace('<!--items-->', items)
		
		return data

def groups():
		fl = open(os.path.join(root_dir,"webui.files", "gr.htm"), "r")
		data = fl.read()
		fl.close()
		L=core.open_Groups()
		
		data=data.replace('[NEW]', controls.input('/group/add/', '', 250))
		items=''
		id=0
		for i in L:
			try: lock = i[2]
			except: lock = 'false'
			itm = controls.item3({'name':i[0], 'list':i[1], 'id': id, 'lock':lock})
			items+=itm
			id+=1
		return data.replace('<!--items-->',items) 


def serv_urls(id):
		
		Lserv=core.get_enable_serv()
		inf = core.DBC[id]
		nml = inf['names']
		idl = []
		nms = ''
		for nm in nml:
			nms+=nm+"; "
			idl.append(core.get_ID(nm))
		LL=[]
		D=core.get_serv_dict()
		for s in D.keys():
			enable_serv = False
			for sn in Lserv:
				if sn in s: enable_serv = True
			L=D[s]
			for i in L:
				if core.get_ID(i['title']) in idl:
					sid = i['url']
					if sid in core.BLs: lock = True
					else:               lock = False
					
					LL.append({'serv': s, 'url': i['url'], 'id':id, 'lock':lock, 'serv_on': enable_serv})
		
		return LL


def get_params(params):
		if len(params)<4: return {}
		param=[]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
		return param

def edit_base(params_string):
	params=get_params(params_string)
	Lid = []
	for i in params.keys():
		id = i[3:]
		if id not in Lid: Lid.append(id)
		
	L = core.get_base()
	for i in L:
			gr=''
			for g in i['group']:
				gr+=" | "+g
			group=gr[3:]
			name=i['title']
			picon=i['picon']
			enable=i['enable']
			cid=i['id']
			
			bl = enable
			if 'on_'+cid in params.keys():
				if enable==False: 
					core.add_to_base(cid)
					bl=True
			else:
				if enable==True: 
					core.rem_from_base(cid)
					bl=False
			
			
			if cid in Lid and bl:
				if 'nm_'+cid in params.keys():
					val = urllib.unquote_plus(params['nm_'+cid])
					if name != val:
						core.rename_cnl(cid, val)
			
				if 'gr_'+cid in params.keys():
					val = urllib.unquote_plus(params['gr_'+cid])
					if group != val:
						core.set_group_cnl(cid, val)


from threading import Thread
class MyThread(Thread):
	def __init__(self, param):
		Thread.__init__(self)
		self.BS = param['BS']
		self.n = param['n']
	
	def run(self):
		trd[0]=1
		dat = self.BS.get_data()
		if dat != None:
			buf[self.n]=dat
			trd[0]=0
		else:
			trd[0]=-1

def create_thread(param):
		my_thread = MyThread(param)
		my_thread.start()


class MyThread2(Thread):
	def __init__(self, param):
		Thread.__init__(self)
		self.wfile = param['wfile']
		self.n = param['n']
	
	def run(self):
		twr[0]=1
		self.wfile.write(buf[self.n])
		#try:self.wfile.write(buf[self.n])
		#except: print 'err write'
		twr[0]=0

def create_thread2(param):
		my_thread = MyThread2(param)
		my_thread.start()

class MyThread3(Thread):
	def __init__(self, param):
		Thread.__init__(self)
		self.param = param
	
	def run(self):
		exec(self.param)

def run_string(param):
		my_thread = MyThread3(param)
		my_thread.start()

LGET=[]
LRE=[]
WFL=[None, None,0]
class HttpProcessor(BaseHTTPRequestHandler):
	
	def do_GET(self):
		data=get_on(self.path)
		try: head = data[:4]
		except: head = '    '
		
		WFL[1]=0
		if self.path in LGET: 
			#WFL[0]=self.wfile
			if head[:3]=='BS:':
				WFL[0]=self.wfile
				WFL[1]=1
				head = 'RS:'
		else: LGET.append(self.path)
		
		
		if data == 'ERR 404':
			self.send_response(404)
		else:
			if head =='http' or head =='udp:' or head[0] =='/':
				self.send_response(302)
				self.send_header('Location', data)
				self.send_header('content-type','image/jpeg')
			elif 'JFIF' in data:
				self.send_response(200)
				self.send_header('content-type','image/jpeg')
			else:
				self.send_response(200)
				self.send_header('content-type','text/html')
				if False:
					self.send_header('Content-Encoding', 'gzip')
					import StringIO
					import gzip
					out = StringIO.StringIO()
					with gzip.GzipFile(fileobj=out, mode="w") as f:
						f.write(data)
					data=out.getvalue()
		
		self.end_headers()
		
		if head[:3]=='CLE':
			CLE = cn_editor()
			self.wfile.write(CLE.head())
			L  = CLE.list()
			for i in L:
				itm = CLE.item(i)
				self.wfile.write(itm)
			self.wfile.write(CLE.end())
		
		elif head[:3]=='XML':
			XTV=epg.xmltv()
			r = XTV.cnl_part()
			p1 = r[0]
			L  = r[1]
			self.wfile.write(p1)
			n=0
			for cid in L:
				n+=1
				#print str(n)+'/'+str(len(L))
				p2=XTV.prg_part(cid)
				self.wfile.write(p2)
			self.wfile.write(XTV.end_part())
		
		elif head[:3]=='RS:': 
			pass
			
			n = 0
			c = WFL[2]
			s = 0
			twr[0]=0
			pt = time.time()
			while trigger:
				if twr[0]<1:
					if buf[c]!=None:
						#create_thread2({'wfile':WFL[0], 'n':c})
						c+=1
						if c>99: c=0
			#try:LRE.remove(WFL[0])
			#except: pass
			

		elif head[:3]=='BS:': 
			WFL[0]=self.wfile
			import bitstream
			curl=data[3:]
			BS=bitstream.BS(curl)
			b_part = None
			pn = 0
			#buf = []
			#tmp = BS.get_data()
			#buf[0]=tmp
			for b in range (10):
				buf[b]=None
			f = 0
			n = 0
			tn=0
			c = 0
			tc=0
			c_old = 999
			s = 0
			twr[0]=0
			rec = 0
			infb=''
			pt = time.time()
			while trigger:
				
				if trd[0] == -1:
					rec+=1
					if rec > 2:
						BS=bitstream.BS(curl)
						buf[c]=BS.get_data()
						print 'reconnect'
						rec = 0
				else:
					rec = 0
				
				if twr[0]<1:
					if buf[c]!=None and tc<tn and tn>5:
						#if WFL[1]<1 : 
						create_thread2({'wfile':WFL[0], 'n':c})#self.wfile not in LRE
						c2=c
						c+=1
						tc+=1
						if c>9: c=0
						WFL[2]=c
				
				if trd[0]<1:
						create_thread({'BS':BS, 'n':n})
						n+=1
						tn+=1
						f+=1
						if n>9: n = 0
				else:
					time.sleep(0.01)
				
				if c_old == c : s+=1#and buf[c]!=None
				else: s=0
				if s>1000: break
				c_old = c
				infa = "\n|"+str(tn)+"|"+str(tc)+"|"+str(s)+'\n'#+self.path
				
				if infa!=infb: print infa
				infb=infa
		
		elif head[:3]=='HLS': 
			import hls
			curl=data[4:]
			print curl
			HLS=hls.HLS(curl)#'https://strm.yandex.ru/kal/fashiontv/fashiontv0_169_1080p.json/index-v1-a1.m3u8?partner_id=270171&target_ref=https%3A%2F%2Fyastatic.net&uuid=42ee5f579c38ea04a6d92ccefdbeed99&vsid=ojhxcxb2wxf48pv&redundant=5'
			for i in range(10000000):
					part=HLS.get_data()
					if part == 'error': break
					if part !=None: self.wfile.write(part)
		else:
			self.wfile.write(data)
		#quit_event.set()
		
		try:LGET.remove(self.path)
		except: pass

class MyThreadingHTTPServer(SocketServer.ThreadingMixIn, BaseHTTPServer.HTTPServer):
	pass

serv = MyThreadingHTTPServer(("0.0.0.0",port), HttpProcessor)
threading.Thread(target=serv.serve_forever).start()



#===================================================================
fch={}

def get_on(addres):
		print addres
		global trigger
		addres=utf(addres)
		data='ERR 404'
		if addres == "/":
			data = WebUI()#help
		if "/webui.files/" in addres:
			nmf=addres[13:]
			if nmf in fch.keys():
				data = fch[nmf]
			else:
				fl = open(os.path.join(root_dir,"webui.files", nmf), "rb")#
				data = fl.read()
				fl.close()
				fch[nmf]=data
		if "/info/" in addres:
			id=addres[addres.find('/info/')+6:]
			if '#' in addres:
				sid=mfind(addres, '#', '/')
				if '/lock'   in addres: core.add_BLs(sid)
				if '/unlock' in addres: core.rem_BLs(sid)
			data = '/groups'
			
			data = info(id)
			
		if "/editor" in addres:
			if '/editor?' in addres: prm=edit_base(addres[addres.find('/editor?')+8:])
			else: prm=''
			data = 'CLE:'#editor()
		if 'serv/stop' in addres: 
			trigger = False
			data = 'stop'
		if 'settings/get/' in addres:
			key=addres[addres.find('/get/')+5:]
			data=settings.get(key)
		if 'settings/set/' in addres:
			key=addres[addres.find('/set/')+5:addres.find('/val/')]
			if 'val=' in addres:
				val=urllib.unquote_plus(addres[addres.find('val=')+4:])
			else:
				val=urllib.unquote_plus(addres[addres.find('/val/')+5:])
			data=settings.set(key, val)
			if 'editor_' in addres: data='/editor'#data='http://'+get_ip()+':'+str(port)+'/editor'
			elif 'epg_' in addres: data='/epg'
			#elif 'epgon' in addres: data='/epg'
			else:                       data='/'#data='http://'+get_ip()+':'+str(port)
		if '/groups' in addres:
			if '/groups/' in addres:
				if '/groups/list' in addres: data = core.groups()
			else:
				data = groups()
		
		if '/group/' in addres:
			try:
				id = int(mfind(addres, '/group/','/'))
				gr = core.open_Groups()[id][0]
			except:
				id = ''
				gr = ''
			if '/add' in addres: 
				if 'val=' in addres: gnm =addres[addres.find('val=')+4:]
				else:                gnm =addres[addres.find('rename/')+7:]
				core.add_gr(utf(urllib.unquote_plus(gnm)))
			if '/lock'    in addres: core.lock_gr(id, 'true')
			if '/unlock'  in addres: core.lock_gr(id, 'false')
			if '/rem'     in addres: core.rem_gr(gr)
			if '/up'      in addres: core.move_gr(id, id-1)
			if '/down'    in addres: core.move_gr(id, id+1)
			if '/rename'  in addres: 
				if 'val=' in addres: gnm =addres[addres.find('val=')+4:]
				else:                gnm =addres[addres.find('/add/')+5:]
				core.rename_gr(id, utf(urllib.unquote_plus(gnm)))
			data='/groups'
			
			if '/unite' in addres:
				if '/unite/' in addres:
					id2 = int(addres[addres.find('/unite/')+7:])
					core.unite_gr(id, id2)
				else:
					data=unite_gr(id)

		if '/channels/dict' in addres:
			data = core.channels('all')
		if '/channels/json' in addres:
			data = core.jsonlist()
		if '/channels/tvh' in addres:
			data = core.tvhlist()
		if '/channels/list' in addres or '/playlist' in addres:
			if 'list/' in addres:  id=addres[addres.find('list/')+5:]
			else: 						id = ''
			if id == '': data = core.playlist()
			else:        data = core.playlist(id)
			
		if '/channel/' in addres:
			id1 = mfind(addres, '/channel/','/')
			if '/add' in addres: core.add_to_base(id1)
			if '/rem' in addres: core.rem_from_base(id1)
			if '/rename' in addres: 
				if 'val=' in addres: cnm =addres[addres.find('val=')+4:]
				else:                cnm =addres[addres.find('rename/')+7:]
				core.rename_cnl(id1, urllib.unquote_plus(cnm))
			if '/set_group/' in addres: 
				if 'val=' in addres: gs =addres[addres.find('val=')+4:]
				core.set_group_cnl(id1, urllib.unquote_plus(gs))
				
			data='/editor#'+id1#'http://'+get_ip()+':'+str(port)+'/editor'#+'/'+id1
			
			if '/unite' in addres:
				if '/unite/' in addres:
					id2 = addres[addres.find('/unite/')+7:]
					core.unite_cnl(id1, id2)
				else:
					data=unite(id1)
			
			if '/split' in addres: 
				if '/split/' in addres:
					nm = urllib.unquote_plus(addres[addres.find('/split/')+7:])
					core.split_cnl(id1, nm)
				else:
					data=split(id1)
			
		if '/stream/' in addres:
			id=addres[addres.find('stream/')+7:]
			redir=core.stream(id)
			if redir=='': data="ERR 404"
			else:         data=redir
			
		if '/restream/' in addres:
			id=addres[addres.find('restream/')+9:]
			print id
			stream=core.stream(id)
			print stream
			if stream !='':
				if '/ace/'   in stream:    data='BS:' +stream# 
				elif '/udp/' in stream:    data='BS:' +stream# 
				else:                      data='HLS:'+stream
				print data
		if '/streams/' in addres:
			if '/streams/json_ds' in addres:
				id=addres[addres.find('json_ds/')+8:]
				data = json.dumps(core.streams_ds(id))
				#data=core.json_streams(id)
			elif '/streams/json' in addres:
				id=addres[addres.find('json/')+5:]
				data = json.dumps(core.streams(id))
			elif '/streams/list' in addres:
				id=addres[addres.find('list/')+5:]
				data=core.streams(id)
			else:
				id=addres[addres.find('streams/')+8:]
				data=core.sublist(id)
		if '/update/' in addres:
			id=addres[addres.find('/update/')+8:]
			core.upd_canals_by_id(id)
			data='/'#'http://'+get_ip()+':'+str(port)
		if '/back_list/' in addres:
			#sid=base64.b64decode(mfind(addres, '/back_list/', '/'))
			if '/lock'   in addres: bu=addres[addres.find('/back_list/')+11: addres.rfind('/lock')]
			if '/unlock' in addres: bu=addres[addres.find('/back_list/')+11: addres.rfind('/unlock')]
			try:sid=base64.b64decode(bu)
			except:sid=''
			if '/lock'   in addres: core.add_BLs(sid)
			if '/unlock' in addres: core.rem_BLs(sid)
			
			if '/json'   in addres: data = json.dumps({'back_list':'ok'})
			elif 'lock/' in addres: data = '/info/'+addres[addres.find('lock/')+5:]
			else: data = '/'
			
		if '/epg' in addres:
			if '/epg/' in addres:
				if  '/refresh' in addres:
					data="epg refresh"
					epg.upepg()
				
				if  '/data' in addres:
					try:	data = epg.get_inf_db('udata')
					except: data = '0'
				
				if  '/dict' in addres:
					data=repr(epg.EPG)
				
				if  '/json' in addres:
					data=json.dumps(epg.EPG)
				
				if  '/xmltv' in addres:
					data='XMLTV'#epg.xmltv()
					#import StringIO
					#import gzip
					#out = StringIO.StringIO()
					#with gzip.GzipFile(fileobj=out, mode="w") as f:
					#	f.write(data)
					#data=out.getvalue()
				
				if  '/id_list' in addres:
					data=repr(epg.get_channels_list())
				
				if  '/id_dict' in addres:
					data=repr(epg.get_nm_dict())
				
				if  '/id_json' in addres:
					data=json.dumps(epg.get_nm_dict())
				
				if  '/inf/' in addres:
					try:
						cid=addres[addres.rfind('/')+1:]
						if len(cid)>4:	data=repr(epg.get_channels_info(cid))
						else: 				data="id:"+'None'
					except:
						print "ERR EPG "+addres
						data="ERR 404"
			
			elif 'epg_' not in addres: data=set_epg()
			else: data='/epg'
		
		if '/y_img/' in addres or 's-tv.ru' in addres or 'tv.mail.ru' in addres:
			data=epg.get_img(addres)
		
		if '/cache_url/' in addres:
			cid=mfind(addres, '/cache_url/', '/')
			if '/list' in addres: data=serv_urls(cid)
			if '/json' in addres: data=json.dumps(serv_urls(cid))
		
		if '/ratio/' in addres:
			bu=addres[addres.find('/ratio/')+7: addres.rfind('/')]
			try:sid=base64.b64decode(bu)
			except:sid=''
			if sid!='':
				if '/good'   in addres: core.set_rating(sid, 'good')
				if '/bad'    in addres: core.set_rating(sid, 'bad')
				if '/get'    in addres: data = core.get_rating(sid)
				elif '/json' in addres: data = json.dumps(core.get_rating(sid))
				else: data='ratio ok'
			else:
				data='error base64'
			
		if '/test' in addres: data='BS:'+'http://62.106.108.175:4022/udp/232.0.1.26:1234'
		'''
		elif 'arh/json' in addres:
			data=arh_jsonlist()
		
		elif 'arh/channel/' in addres:
			if '/day/' in addres:
				day=addres[addres.find('/day/')+5:]
				id=addres[addres.find('channel/')+8:addres.find('/day/')]
			else:
				day='0'
				id=addres[addres.find('channel/')+8:]
			data=arh_items(id, day)

		elif 'arh/streams/' in addres:
			id=addres[addres.find('streams/')+8:]
			data=arh_streams(id)
		'''
		return data

#===================================================================

def abortRequested():
	try: 
		import xbmc
		r=xbmc.abortRequested
	except:
		r=False
	return r

print('----- PTV3_serv OK -----')
import epg
#run_string('import epg')
#time.sleep(5)
#print('----- EPG cd:'+str(cdata))
		
#if cdata>udata and settings.get("epg_on")!='false':
#			print('----- EPG update -----')
			#epg.upepg()
#			run_string('epg.upepg()')

#run_string('epg.xmltv()')

while trigger:
			if abortRequested(): break
			
			try:	udata = int(epg.get_inf_db('udata'))
			except: udata = 0
			cdata = int(time.strftime('%Y%m%d'))
			#print('----- EPG ud:'+str(udata))
			if cdata>udata and settings.get("epg_on")!='false':
						print('----- EPG update -----')
						epg.upepg()
						#run_string('epg.upepg()')
			
			time.sleep(5)

			

try:serv.shutdown()
except:pass

print('----- PTV3_serv stopped -----')

