# coding: utf-8
# Module: server
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys, os
import xbmc, xbmcgui, xbmcaddon
import updatetc
import time
import xbmcgui
__settings__ = xbmcaddon.Addon(id='plugin.video.torrent.checker')
addon = xbmcaddon.Addon(id='plugin.video.torrent.checker')
icon=None


def open_set():
		fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'uptm.py'))
		
		try:sz=os.path.getsize(fp)
		except:sz=0
		if sz==0:
			save_set(0)
			return 0
		
		fl = open(fp, "r")
		ls=fl.read().replace('\n','')#.replace('# -*- coding: utf-8 -*-Lgr=','')
		fl.close()
		return eval(ls)

def save_set(tm):
		fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'uptm.py'))
		fl = open(fp, "w")
		fl.write(repr(tm))
		fl.close()

time.sleep(5)
print('----- Starting Torrent Checker -----')
start_trigger = True
#n=0
while not xbmc.abortRequested:
	
	if int(__settings__.getSetting("Interval"))<7:
		if start_trigger:
			print('----- Torrent Checker started -----')
			#xbmcgui.Dialog().notification('Torrent Checker', 'Запущен', icon, 1000, False)
			start_trigger = False
			time.sleep(15)
			#updatetc.update()
		# ---------------------------------
		time.sleep(5)
		#n+=1
		iv = 2*int(__settings__.getSetting("Interval"))
		if iv==0: iv=1
		upint=iv*3600
		try:
			#lu=eval(__settings__.getSetting("LU"))
			lu=open_set()
		except:
			#__settings__.setSetting("LU", repr(time.time()))
			save_set(time.time())
			lu=time.time()
		n=time.time()-lu
		#print n-upint
		if n>= upint:
			n=0
			#time.sleep(15)
			updatetc.update()
			#at=time.strftime('Обновлено: %d.%m.%Y - %H:%M')
			#__settings__.setSetting("AT", at)
			#__settings__.setSetting("LU", repr(time.time()))
			save_set(time.time())
	else: 
		time.sleep(15)



print('----- Torrent Checker stopped -----')

