# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, urllib, urllib2, sys
import updatetc

PLUGIN_NAME   = 'torrent.checker'
handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.torrent.checker')
__settings__ = xbmcaddon.Addon(id='plugin.video.torrent.checker')

Pdir = addon.getAddonInfo('path')
icon = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'icon.png'))
xbmcplugin.setContent(int(sys.argv[1]), 'movies')

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)

try:
	import tthp
except:
	print "Error import t2http"


def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))


def inputbox(t):
	skbd = xbmc.Keyboard(t, 'Название:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return t

try:
	from kodidb import*
except: pass

def chek_in():
	try:
		k_db = KodiDB(xbmc.getInfoLabel('ListItem.FileName').decode('utf-8'), xbmc.getInfoLabel('ListItem.Path').decode('utf-8'), sys.argv[0] + sys.argv[2])
		k_db.PlayerPreProccessing()
		return k_db
	except: 
		return None
	
def chek_out(k_db):
	k_db.PlayerPostProccessing()
	xbmc.sleep(300)
	xbmc.executebuiltin('Container.Refresh')
	xbmc.sleep(200)
	if not xbmc.getCondVisibility('Library.IsScanningVideo'):
		xbmc.executebuiltin('UpdateLibrary("video", "", "false")')

def open_set():
		fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'uptm.py'))
		
		try:sz=os.path.getsize(fp)
		except:sz=0
		if sz==0:
			save_set(0)
			return 0
		
		fl = open(fp, "r")
		ls=fl.read().replace('\n','')#.replace('# -*- coding: utf-8 -*-Lgr=','')
		fl.close()
		return eval(ls)

def save_set(tm):
		fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'uptm.py'))
		fl = open(fp, "w")
		fl.write(repr(tm))
		fl.close()


def play(url, id=0):
	k_db=chek_in()
	
	if 'magnet:' in url: 
		play_t2h (url, id, __settings__.getSetting("DownloadDirectory"))
	elif 'acestream:' in url:
		play_ace_cid(url, id)
	else:
		engine=__settings__.getSetting("Engine")
		if engine=="0": play_ace (url, id)
		if engine=="1": play_t2h (url, id, __settings__.getSetting("DownloadDirectory"))
		if engine=="2": play_yatp(url, id)
		if engine=="3": play_torrenter(url, id)
		if engine=="4": play_elementum(url, id)
	if k_db != None: chek_out(k_db)


def play_ace(torr_link, ind=0):
	try:
		title=get_item_name(url, ind)
		from TSCore import TSengine as tsengine
		TSplayer=tsengine()
		out=TSplayer.load_torrent(torr_link,'TORRENT')
		#print out
		if out=='Ok': TSplayer.play_url_ind(int(ind),title, icon, icon, True)
		TSplayer.end()
		return out
	except: 
		return '0'

def play_t2h(uri, file_id=0, DDir=""):
	try:
		sys.path.append(os.path.join(xbmc.translatePath("special://home/"),"addons","script.module.torrent2http","lib"))
		from torrent2http import State, Engine, MediaType
		progressBar = xbmcgui.DialogProgress()
		from contextlib import closing
		if DDir=="": DDir=os.path.join(xbmc.translatePath("special://home/"),"userdata")
		progressBar.create('Torrent2Http', 'Запуск')
		# XBMC addon handle
		# handle = ...
		# Playable list item
		# listitem = ...
		# We can know file_id of needed video file on this step, if no, we'll try to detect one.
		# file_id = None
		# Flag will set to True when engine is ready to resolve URL to XBMC
		ready = False
		# Set pre-buffer size to 15Mb. This is a size of file that need to be downloaded before we resolve URL to XMBC 
		pre_buffer_bytes = 15*1024*1024
		
		engine = Engine(uri, download_path=DDir, enable_dht=True, dht_routers=["router.bittorrent.com:6881","router.utorrent.com:6881"], user_agent = 'uTorrent/2200(24683)')
		with closing(engine):
			# Start engine and instruct torrent2http to begin download first file, 
			# so it can start searching and connecting to peers  
			engine.start(file_id)
			progressBar.update(0, 'Torrent2Http', 'Загрузка торрента', "")
			while not xbmc.abortRequested and not ready:
				xbmc.sleep(500)
				status = engine.status()
				# Check if there is loading torrent error and raise exception 
				engine.check_torrent_error(status)
				# Trying to detect file_id
				if file_id is None:
					# Get torrent files list, filtered by video file type only
					files = engine.list(media_types=[MediaType.VIDEO])
					# If torrent metadata is not loaded yet then continue
					if files is None:
						continue
					# Torrent has no video files
					if not files:
						break
						progressBar.close()
					# Select first matching file                    
					file_id = files[0].index
					file_status = files[0]
				else:
					# If we've got file_id already, get file status
					file_status = engine.file_status(file_id)
					# If torrent metadata is not loaded yet then continue
					if not file_status:
						continue
				if status.state == State.DOWNLOADING:
					# Wait until minimum pre_buffer_bytes downloaded before we resolve URL to XBMC
					if file_status.download >= pre_buffer_bytes:
						ready = True
						break
					#print file_status
					#downloadedSize = status.total_download / 1024 / 1024
					getDownloadRate = status.download_rate / 1024 * 8
					#getUploadRate = status.upload_rate / 1024 * 8
					getSeeds = status.num_seeds
					
					progressBar.update(100*file_status.download/pre_buffer_bytes, xt('Предварительная буферизация: '+str(file_status.download/1024/1024)+" MB"), "Сиды: "+str(getSeeds), "Скорость: "+str(getDownloadRate)[:4]+' Mbit/s')#
					
				elif status.state in [State.FINISHED, State.SEEDING]:
					#progressBar.update(0, 'T2Http', 'We have already downloaded file', "")
					# We have already downloaded file
					ready = True
					break
				
				if progressBar.iscanceled():
					progressBar.update(0)
					progressBar.close()
					break
				# Here you can update pre-buffer progress dialog, for example.
				# Note that State.CHECKING also need waiting until fully finished, so it better to use resume_file option
				# for engine to avoid CHECKING state if possible.
				# ...
			progressBar.update(0)
			progressBar.close()
			if ready:
				# Resolve URL to XBMC
				item = xbmcgui.ListItem(path=file_status.url)
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
				playlist = xbmc.PlayList (xbmc.PLAYLIST_VIDEO)
				playlist.clear()
				playlist.add(url=file_status.url, listitem=item)
				xbmc.Player().play(playlist)
				xbmc.sleep(3000)
				#xbmc.Player().Play(item)
				xbmc.sleep(3000)
				# Wait until playing finished or abort requested
				while not xbmc.abortRequested and xbmc.Player().isPlaying():
					xbmc.sleep(500)
	except: pass

def play_yatp(url, ind):
	purl ="plugin://plugin.video.yatp/?action=play&torrent="+ urllib.quote_plus(url)+"&file_index="+str(ind)
	item = xbmcgui.ListItem(path=purl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def play_torrenter(url, ind):
	purl ="plugin://plugin.video.torrenter/?action=playSTRM&url="+ urllib.quote_plus(url)+"&file_index="+str(ind)
	item = xbmcgui.ListItem(path=purl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def play_elementum(url, ind):
	purl ="plugin://plugin.video.elementum/play?uri="+ urllib.quote_plus(url)+"&index="+str(ind)
	item = xbmcgui.ListItem(path=purl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def play_ace_cid(url, ep, id=''):
	progressBar = xbmcgui.DialogProgress()
	progressBar.create('ACE Stream', 'Запуск')
	#ASE_start()
	
	as_url=list_acestream(url)[int(ep)]
	if url!='':
		json=eval(GETtorr(as_url).replace('null','"null"'))["response"]
		progressBar.update(0, 'ACE Stream', 'Контент найден', "")
		stat_url=json["stat_url"]
		stop_url=json["command_url"]+'?method=stop'
		url=json["playback_url"]
		
		progressBar.update(0, 'ACE Stream', 'Подключение', "")
		while not xbmc.abortRequested:
			xbmc.sleep(500)
			j=eval(GETtorr(stat_url).replace('null','"null"'))["response"]
			print j
			if j=={}:
				pass
				progressBar.update(0, 'ACE Stream', 'Ожидание', "")
			else:
				status=j['status']
				if status=='dl': break
				try:
					download=j['downloaded']
					progress=j['total_progress']
					seeds=j['peers']
					speed=j['speed_down']
					progressBar.update(progress*10, xt('Предварительная буферизация: '+str(download/1024/1024)+" MB"), "Сиды: "+str(seeds), "Скорость: "+str(speed)+' Kbit/s')
				except: pass
			if progressBar.iscanceled():
				progressBar.update(0)
				progressBar.close()
				GETtorr(stop_url)
				return
		
		progressBar.update(0)
		progressBar.close()

		item = xbmcgui.ListItem(path=url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
		#xbmc.Player().play(url)
		xbmc.sleep(1000)
		
		while not xbmc.abortRequested and xbmc.Player().isPlaying():
						xbmc.sleep(500)
		GETtorr(stop_url)
	else:
		showMessage('','Поток не найден')


def get_item_name(url, ind):
	torrent_data = GETtorr(url)
	if torrent_data != None:
		import bencode
		torrent = bencode.bdecode(torrent_data)
		try:
			L = torrent['info']['files']
			name=L[ind]['path'][-1]
		except:
			name=torrent['info']['name']
		return name
	else:
		return ' '

def GETtorr(target, XML = False):
	try:
			req = urllib2.Request(url = target)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			if XML: req.add_header('X-Requested-With', 'XMLHttpRequest')
			resp = urllib2.urlopen(req)
			return resp.read()
	except Exception, e:
			print 'HTTP ERROR ' + str(e)
			return None

def add_item (name, mode="", path = Pdir, ind="0", cover=None, funart=None, com=""):
	if path[:4]=='plug':
		comment=urllib.unquote_plus(path).replace("plugin://","").replace("plugin.video.","")
		comment=comment[:comment.find('/')]
		comment=" "+com+" [COLOR 60F0F0F0][ "+comment+" ][/COLOR]"
	else: comment=" "+com
	if cover==None:	listitem = xbmcgui.ListItem(name+comment)
	else:			listitem = xbmcgui.ListItem(name+comment, iconImage=cover)
	listitem.setProperty('fanart_image', funart)
	uri = sys.argv[0] + '?mode='+mode
	uri += '&url='  + urllib.quote_plus(path.encode('utf-8'))#
	uri += '&name='  + urllib.quote_plus(xt(name))
	uri += '&ind='  + urllib.quote_plus(ind)
	if cover!=None:uri += '&cover='  + urllib.quote_plus(cover)
	if funart!=None and funart!="":uri += '&funart='  + urllib.quote_plus(funart)
	
	urr = sys.argv[0] + '?mode=rem'
	urr += '&path='  + urllib.quote_plus(path.encode('utf-8'))#
	urr += '&name='  + urllib.quote_plus(xt(name))
	urr += '&ind='  + urllib.quote_plus(ind)

	urr2 = sys.argv[0] + '?mode=rename'
	urr2 += '&url='  + urllib.quote_plus(path.encode('utf-8'))#
	urr2 += '&name='  + urllib.quote_plus(xt(name))
	urr2 += '&ind='  + urllib.quote_plus(ind)
	
	urr3 = sys.argv[0] + '?mode=rem_files'
	urr3 += '&url='  + urllib.quote_plus(path.encode('utf-8'))#
	urr3 += '&name='  + urllib.quote_plus(xt(name))
	urr3 += '&ind='  + urllib.quote_plus(ind)

	urr4 = sys.argv[0] + '?mode=add_comment'
	urr4 += '&url='  + urllib.quote_plus(path.encode('utf-8'))#
	urr4 += '&name='  + urllib.quote_plus(xt(name))
	urr4 += '&ind='  + urllib.quote_plus(ind)

	if mode=="epd_lst":listitem.addContextMenuItems([('[COLOR F050F050] Удалить задание[/COLOR]', 'Container.Update("plugin://plugin.video.torrent.checker/'+urr+'")'),('[COLOR F050F050] Переименовать [/COLOR]', 'Container.Update("plugin://plugin.video.torrent.checker/'+urr2+'")'),('[COLOR F050F050] Комментарий [/COLOR]', 'Container.Update("plugin://plugin.video.torrent.checker/'+urr4+'")'),('[COLOR F050F050] Обновить файлы [/COLOR]', 'Container.Update("plugin://plugin.video.torrent.checker/'+urr3+'")')])

	xbmcplugin.addDirectoryItem(handle, uri, listitem, True)


def root():
	try:
		at=time.strftime('Обновлено: %d.%m.%Y - %H:%M', time.localtime(open_set()))
		#at = __settings__.getSetting("AT")
		#at=time.strftime('Обновлено: %d.%m.%Y - %H:%M', open_set())
		#at = time.ctime(att)
	except: at = 'Необновлялось'
	add_item (at, 'up', 'url', '0')
	L=updatetc.get_list()
	ind=0
	for i in L:
		name  = i[0]
		url   = i[1]
		if len(i)>3: 
			if i[3]!="":com = "- "+i[3]
			else: com = ""
		else: com = ""
		add_item (name, 'epd_lst', url, str(ind),com=com)
		ind+=1
	xbmcplugin.endOfDirectory(handle)

def epd_lst(name, url, ind):
	f=updatetc.get_filtr(int(ind))
	#L=tthp.list(url)#updatetc.file_list(name)
	L=tor_list(url)
	
	add_item ('[B][ - ] Удалить правила переименования[/B] ', 'rem_filtr', url, str(ind))
	add_item ('[B][+] Добавить правило переименования: '+str(len(f))+'[/B]: ', 'add_filtr', L[0], str(ind))#.name.replace('\\'," ")
	
	for i in L:
		epd_name=i#.name#.replace('\\'," ").replace('/'," ")
		for b in ['\\','/','*',':','|','"','>','<','?']:
			epd_name=epd_name.replace(b,".")
		epd_name_f=""
		for j in f:
			opid=j[0]
			if opid=="t":epd_name_f+=j[1]
			else:epd_name_f+=epd_name[j[0]:j[1]+1]
		epd_name_f+=".strm"
		if f==[]:epd_name_f=epd_name+".strm"
		add_item (epd_name+chr(10)+epd_name_f, 'none', url, str(ind))
	xbmcplugin.endOfDirectory(handle)

def tor_list(url):
	if 'magnet:' in url: return list_magnet(url)
	if 'acestream:' in url: return list_acestream(url, False)
	try:
	#if True:
			req = urllib2.Request(url)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			resp = urllib2.urlopen(req)
			torrent_data = resp.read()
	except: return []
	L2=[]
	if torrent_data != None:
		import bencode
		torrent = bencode.bdecode(torrent_data)
		try:
			L = torrent['info']['files']
			for i in L:
				if foldlen(L):
					path=''
					for p in i['path']:
						p=ru(p)
						path=path+"."+p
					path=path[1:]
					L2.append(path)
				else:
					L2.append(ru(i['path'][-1]))
		except:
				path=torrent['info']['name']
				L2.append(path)
	return L2

def list_magnet(uri):
	cache=magnet_cache(uri)
	if cache!=[]: return cache
	
	from contextlib import closing
	sys.path.append(os.path.join(xbmc.translatePath("special://home/"),"addons","script.module.torrent2http","lib"))
	# Create instance of Engine 
	from torrent2http import State, Engine, MediaType
	engine = Engine(uri)
	files = []
	# Ensure we'll close engine on exception 
	progressBar = xbmcgui.DialogProgress()
	progressBar.create('Torrent2Http', 'Запуск')
	with closing(engine):
	# Start engine 
		engine.start()
		# Wait until files received 
		while not files and not xbmc.abortRequested:
			progressBar.update(0, 'Torrent2Http', 'Примагничиваемся', "")
			
			# Will list only video files in torrent
			files = engine.list(media_types=[MediaType.VIDEO])
			# Check if there is loading torrent error and raise exception 
			engine.check_torrent_error()
			xbmc.sleep(200)
			if progressBar.iscanceled():
						progressBar.update(0)
						progressBar.close()
						return []
			
	progressBar.close()
	print files
	
	if files==None: return []
	L=[]
	for i in files:
		L.append(i[0])

	save_cache(uri, L)
	return L

def list_acestream(ace, return_url=True):
	srv='127.0.0.1'#__settings__.getSetting("p2p_serv")
	prt='6878'#__settings__.getSetting("p2p_port")
	CID=ace.replace('acestream://','')
	lnk='http://'+srv+':'+prt+'/ace/getstream?id='+CID+"&format=json"
	m3u=GETtorr(lnk)
	L = m3u.splitlines()
	Lt=[]
	Lu=[]
	for e in L:
		if '#EXTINF' in e: Lt.append(e.replace('#EXTINF:-1,',''))
		if 'http:' in e: Lu.append(e)
	if return_url: return Lu
	else: return Lt


def magnet_cache(uri):
	hash=uri[uri.find('btih:')+5:uri.find('&')]
	path=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'cache', hash))
	if os.path.exists(path)== True:
		fl = open(path, "r")
		cache = eval(fl.read())
		fl.close()
		return cache
	else:
		return []

def save_cache(uri, cache):
	print 'save_cache'
	hash=uri[uri.find('btih:')+5:uri.find('&')]
	print hash
	path=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'cache', hash))
	
	fl = open(path, "w")
	fl.write(repr(cache))
	fl.close()

def foldlen(L):
	l1 = len (L[0]['path'][0])
	for i in L:
		l=0
		p = i['path']
		if len(p)>1:
			l2=len(p[0])
			if l1 != l2: return False
	return True

def save_episodes(name, url):
	ind=len(updatetc.get_list())
	updatetc.add_list([name, url,[]])
	xbmc.executebuiltin('Container.Update("plugin://plugin.video.torrent.checker/?mode=save_episodes_r&url='+urllib.quote_plus(url)+'&ind='+str(ind)+'&name='+name+'")')
	
def save_episodes_r(name, url, ind):
	try:updatetc.rem(name)
	except: pass
	
	print "-=-=-=-= save_episodes =-=-=-=-=-"
	#print url
	f=updatetc.get_filtr(int(ind))
	#L=tthp.list(url)#updatetc.file_list(name)
	L=tor_list(url)
	
	add_item ('[B][ - ] Удалить правила переименования[/B] ', 'rem_filtr', url, str(ind))
	add_item ('[B][+] Добавить правило переименования: '+str(len(f))+'[/B]: ', 'add_filtr', L[0], str(ind))
	add_item ('[B][ СОХРАНИТЬ ][/B]', 'save_episodes2', L[0].replace('\\'," ").replace('/'," "), str(ind))
	for i in L:
		epd_name=i#.name#.replace('\\'," ").replace('/'," ")
		for b in ['\\','/','*',':','|','"','>','<','?']:
			epd_name=epd_name.replace(b,".")
		epd_name_f=""
		for j in f:
			opid=j[0]
			if opid=="t":epd_name_f+=j[1]
			else:epd_name_f+=epd_name[j[0]:j[1]+1]
		epd_name_f+=".strm"
		if f==[]:epd_name_f=epd_name+".strm"
		add_item (epd_name+chr(10)+epd_name_f, 'none', url, str(ind))
	xbmcplugin.endOfDirectory(handle)


def save_episodes2(name, ind):
	try:
		updatetc.update_last()
		updatetc.rem_list(ind)
	except: pass

def save_episodes_ext(name, url, L2, s, e, nf, info={}):
	#name=name.decode('utf-8')
	#L=tthp.list(url)
	L=tor_list(url)
	n=0
	if len (L)>0 and nf==1: 
		if info=={}: updatetc.save_tvshow_nfo(name, info={'title':name})
		else: updatetc.save_tvshow_nfo(name, info)
	for i in L:
		ind = n# i.index
		epd=L2[n]
		updatetc.save_strm(name, epd, url, ind)
		if nf==1:
			#if info=={}: info={'title':epd}
			if isinstance(epd, unicode): epd=epd.encode('utf-8')
			updatetc.save_nfo(name, epd.replace(".strm","") ,s[n] , e[n], info)
		n+=1
	showMessage("Сохранено:", str(len(L))+' файлов', 2000)
	xbmc.executebuiltin('UpdateLibrary("video", "", "false")')


def add_filtr(name, ind):
	sel = xbmcgui.Dialog()
	opl=["Текст", "Диапазон"]
	k = sel.select("Тип:", opl)
	if k==0:
		t=inputbox(name)
		if t<>"":updatetc.filtr_list(int(ind), ("t", t))
	elif k==1:
		s=name#updatetc.file_list(name)[0]
		n = sel.select("Начало диапазона:", list(s))
		k = sel.select("Конец диапазона:", list(s))
		updatetc.filtr_list(int(ind), (n, k))
	xbmc.executebuiltin("Container.Refresh")

def add(name, url, manual=True):
	if url[:4]=='plug_off':
		updatetc.add_list([name, urllib.quote_plus(url),[]], manual)
	else:
		updatetc.add_list([name, url,[]], manual)
	showMessage('Torrent Checker', 'Добавлено: '+name)

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

params = get_params()

try:mode = urllib.unquote_plus(params["mode"])
except:mode =""
try:name = urllib.unquote_plus(params["name"])
except:name =""
try:url = urllib.unquote_plus(params["url"])
except:url =""
try:ind = urllib.unquote_plus(params["ind"])
except:ind ="0"
try:L = eval(urllib.unquote_plus(params["L"]))
except:L =[]
try:ss = eval(urllib.unquote_plus(params["s"]))
except:ss = []
try:ee = eval(urllib.unquote_plus(params["e"]))
except:ee = []
try:nf = int(urllib.unquote_plus(params["nf"]))
except:nf = 0
try:info = eval(urllib.unquote_plus(params["info"]))
except:info = {}
try:manual = eval(urllib.unquote_plus(params["manual"]))
except:manual = True

if mode==""         : root()
if mode=="up"       :
					  xbmc.sleep(1000)
					  xbmcplugin.endOfDirectory(handle, False, False)
					  updatetc.update()
					  save_set(time.time())
if mode=="add"      : add(name, url, manual)
if mode=="play"     : play(url, int(ind))#updatetc.play(url, int(ind))
if mode=="rename"   : updatetc.rename_list(int(ind))
if mode=="epd_lst"  : 
	if url[:4]!='plug':epd_lst(name, url, ind)
if mode=="add_filtr": add_filtr(url, ind)
if mode=="rem_filtr": 
	updatetc.rem_filtr(int(ind))
	xbmc.executebuiltin("Container.Refresh")
if mode=="rem_files": 
	try:updatetc.rem(name)
	except: print "-=-==-=-=- неудалось удалить файлы -=-=-=-=-=-"
	updatetc.update()
if mode=="rem": 
	updatetc.rem_list(int(ind))
	xbmc.executebuiltin("Container.Refresh")
if mode=="add_comment":
	updatetc.add_comment(int(ind))
if mode=="save_episodes":
	save_episodes(name, url)
if mode=="save_episodes2":
	save_episodes2(name, int(ind))
if mode=="save_episodes_r":
	save_episodes_r(name, url, int(ind))
if mode=="save_episodes_ext":
	info=eval(__settings__.getSetting("info"))
	save_episodes_ext(name, url, L, ss, ee, nf, info)

if mode=="save_episodes_api":
	import RenameBox
	#L=tthp.list(url)
	L=tor_list(url)
	L1=[]
	L2=[]
	for i in L:
		nm=i#.name
		for b in ['\\','/','*',':','|','"','>','<','?']:
			nm=nm.replace(b,".")
		L1.append(nm)
		L2.append(nm+".strm")
	L3=[['t',name],[0,0],[0,0],L1,L2,0,url]
	__settings__.setSetting(id="RenameBox", value=repr(L3))
	__settings__.setSetting(id="info", value=repr(info))
	RenameBox.run("RenameBox")
	
	
