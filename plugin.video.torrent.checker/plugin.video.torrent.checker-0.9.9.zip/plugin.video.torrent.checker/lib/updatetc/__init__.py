# -*- coding: utf-8 -*-
from updatetc import*