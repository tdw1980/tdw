# coding: utf-8
# Module: server
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys, os
import xbmc, xbmcgui, xbmcaddon
import updatetc
import time
import xbmcgui
__settings__ = xbmcaddon.Addon(id='plugin.video.torrent.checker')
addon = xbmcaddon.Addon(id='plugin.video.torrent.checker')
icon=None


def open_set():
	try:
		fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'uptm.py'))
		
		try:sz=os.path.getsize(fp)
		except:sz=0
		if sz==0:
			save_set(0)
			return 0
		
		fl = open(fp, "r")
		ls=fl.read().replace('\n','')
		fl.close()
		return eval(ls)
	except:
		save_set(time.time())
		return time.time()

def save_set(tm):
		fp=xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'uptm.py'))
		fl = open(fp, "w")
		fl.write(repr(tm))
		fl.close()

time.sleep(5)
print('----- Starting Torrent Checker -----')
start_trigger = True

while not xbmc.abortRequested:
	if int(__settings__.getSetting("Interval"))<7:
		if start_trigger:
			print('----- Torrent Checker started -----')
			start_trigger = False
		# ---------------------------------
		time.sleep(5)
		iv = 2*int(__settings__.getSetting("Interval"))
		if iv==0: iv=1
		upint=iv*3600
		lu=open_set()
		n=time.time()-lu
		#print upint-n
		if n >= upint:
			time.sleep(15)
			#updatetc.update()
			xbmc.executebuiltin('RunPlugin("plugin://plugin.video.torrent.checker/?mode=up")')
			save_set(time.time())
	else: 
		time.sleep(5)


print('----- Torrent Checker stopped -----')

