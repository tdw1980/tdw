xbmc.kodi
xbmckodi
ID: 0be8ca965707402c91daa0016c13097e
������: 039c4b88e67d4acca5bf13060756b1bb
Callback URL: https://oauth.yandex.ru/verification_code