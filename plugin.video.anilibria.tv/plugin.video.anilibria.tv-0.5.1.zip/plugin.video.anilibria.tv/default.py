#!/usr/bin/python
# -*- coding: utf-8 -*-

# *  Copyright (C) 2018 TDW

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, urllib, urllib2, time
import anilibria

PLUGIN_NAME   = 'Anilibria.tv'
siteUrl = 'anilibria.tv'
httpSiteUrl = 'http://' + siteUrl
handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.anilibria.tv')
__settings__ = xbmcaddon.Addon(id='plugin.video.anilibria.tv')
xbmcplugin.setContent(int(sys.argv[1]), 'movies')

icon  = os.path.join( addon.getAddonInfo('path'), 'icon.png')
dbDir = addon.getAddonInfo('path')
LstDir = addon.getAddonInfo('path')


#======================== стандартные функции ==========================

def fs_enc(path):
	path=xbmc.translatePath(path)
	sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
	try:path2=path.decode('utf-8')
	except: pass
	try:path2=path2.encode(sys_enc)
	except: 
		try: path2=path2.encode(sys_enc)
		except: path2=path
	return path2


def fs_dec(path):
	sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
	return path.decode(sys_enc).encode('utf-8')

def fs(s):return s.decode('windows-1251').encode('utf-8')
def win(s):return s.decode('utf-8').encode('windows-1251')
def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)
def rt(x):#('&#39;','’'), ('&#145;','‘')
	L=[('&amp;',"&"),('&#133;','…'),('&#38;','&'),('&#34;','"'), ('&#39;','"'), ('&#145;','"'), ('&#146;','"'), ('&#147;','“'), ('&#148;','”'), ('&#149;','•'), ('&#150;','–'), ('&#151;','—'), ('&#152;','?'), ('&#153;','™'), ('&#154;','s'), ('&#155;','›'), ('&#156;','?'), ('&#157;',''), ('&#158;','z'), ('&#159;','Y'), ('&#160;',''), ('&#161;','?'), ('&#162;','?'), ('&#163;','?'), ('&#164;','¤'), ('&#165;','?'), ('&#166;','¦'), ('&#167;','§'), ('&#168;','?'), ('&#169;','©'), ('&#170;','?'), ('&#171;','«'), ('&#172;','¬'), ('&#173;',''), ('&#174;','®'), ('&#175;','?'), ('&#176;','°'), ('&#177;','±'), ('&#178;','?'), ('&#179;','?'), ('&#180;','?'), ('&#181;','µ'), ('&#182;','¶'), ('&#183;','·'), ('&#184;','?'), ('&#185;','?'), ('&#186;','?'), ('&#187;','»'), ('&#188;','?'), ('&#189;','?'), ('&#190;','?'), ('&#191;','?'), ('&#192;','A'), ('&#193;','A'), ('&#194;','A'), ('&#195;','A'), ('&#196;','A'), ('&#197;','A'), ('&#198;','?'), ('&#199;','C'), ('&#200;','E'), ('&#201;','E'), ('&#202;','E'), ('&#203;','E'), ('&#204;','I'), ('&#205;','I'), ('&#206;','I'), ('&#207;','I'), ('&#208;','?'), ('&#209;','N'), ('&#210;','O'), ('&#211;','O'), ('&#212;','O'), ('&#213;','O'), ('&#214;','O'), ('&#215;','?'), ('&#216;','O'), ('&#217;','U'), ('&#218;','U'), ('&#219;','U'), ('&#220;','U'), ('&#221;','Y'), ('&#222;','?'), ('&#223;','?'), ('&#224;','a'), ('&#225;','a'), ('&#226;','a'), ('&#227;','a'), ('&#228;','a'), ('&#229;','a'), ('&#230;','?'), ('&#231;','c'), ('&#232;','e'), ('&#233;','e'), ('&#234;','e'), ('&#235;','e'), ('&#236;','i'), ('&#237;','i'), ('&#238;','i'), ('&#239;','i'), ('&#240;','?'), ('&#241;','n'), ('&#242;','o'), ('&#243;','o'), ('&#244;','o'), ('&#245;','o'), ('&#246;','o'), ('&#247;','?'), ('&#248;','o'), ('&#249;','u'), ('&#250;','u'), ('&#251;','u'), ('&#252;','u'), ('&#253;','y'), ('&#254;','?'), ('&#255;','y'), ('&laquo;','"'), ('&raquo;','"'), ('&nbsp;',' ')]
	for i in L:
		x=x.replace(i[0], i[1])
	return x

def lower(s):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.lower().encode('utf-8')
	return s

def mid(s, n):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.center(n)
	try:s=s.encode('utf-8')
	except: pass
	return s

def mids(s, n):
	l="                                              "
	s=l[:n-len(s)]+s+l[:n-len(s)]
	return s

def FC(s, color="FFFFFF00"):
	s="[COLOR "+color+"]"+s+"[/COLOR]"
	return s

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "wb")
	fl.write(s)
	fl.close()

def deb_print(s):
	if __settings__.getSetting("DebMod")=='true': print s

def inputbox():
	skbd = xbmc.Keyboard()
	skbd.setHeading('Поиск:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return ""

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

#====================== подготовка данных для интерфейса ================

Cat=anilibria.type
Genre=anilibria.genres
Year=anilibria.years
#Year.sort()
#Year.reverse()
#Ongoing=['Любой','Сейчас выходит','Вышедшие']
#Sort=['Популярные','Новые']

#============================== основная часть ============================

def getList(id):
	try:L = eval(__settings__.getSetting(id))
	except:L =[]
	S=""
	for i in L:
		if i[:1]=="[": S=S+", "+i
	return S[1:]


import sqlite3 as db
db_name = os.path.join( dbDir, "info.db" )
c = db.connect(database=db_name)
cu = c.cursor()
def add_to_db(n, item):
		deb_print ('KP add_to_db '+n)
		item=item.replace("'","XXCC").replace('"',"XXDD")
		err=0
		tor_id="n"+n.replace('-','').replace('.','')
		litm=str(len(item))
		try:
			cu.execute("CREATE TABLE "+tor_id+" (db_item VARCHAR("+litm+"), i VARCHAR(1));")
			c.commit()
			deb_print ('KP add_to_db CREATE TABLE '+tor_id)
		except: 
			err=1
			print "Ошибка БД"+ n
		if err==0:
			cu.execute('INSERT INTO '+tor_id+' (db_item, i) VALUES ("'+item+'", "1");')
			c.commit()
			deb_print ('KP add_to_db INSERT INTO '+tor_id)
			#c.close()

def get_inf_db(n):
		deb_print ('KP get_inf_db '+n)
		tor_id="n"+n.replace('-','').replace('.','')
		cu.execute(str('SELECT db_item FROM '+tor_id+';'))
		c.commit()
		deb_print ('KP get_inf_db SELECT '+tor_id)
		Linfo = cu.fetchall()
		info=Linfo[0][0].replace("XXCC","'").replace("XXDD",'"')
		deb_print ('KP get_inf_db return_info OK')
		return info

def rem_inf_db(n):
		deb_print ('KP rem_inf_db '+n)
		tor_id="n"+n.replace('-','').replace('.','')
		try:
			cu.execute("DROP TABLE "+tor_id+";")
			c.commit()
			deb_print ('KP rem_inf_db DROP TABLE '+n)
		except: pass

def get_labels(info):
	Linf=['genre', 'year', 'rating', 'cast', 'director', 'plot', 'title', 'originaltitle', 'studio']
	Labels={}
	for inf in Linf:
		try:Labels[inf] = info[inf]
		except: pass
	return Labels


def AddItem(Title = "", mode = "", id='0', url='', total=100):
			if id !='0':
				try:    info=get_info(id)
				except: info={}
				try:    cover = anilibria.unlock(info["cover"])
				except: cover = icon
				try:    fanart = anilibria.unlock(info["fanart"])
				except: fanart = ''
			else:
				cover = icon
				fanart = ''
				info={'id':id}
			
			if mode=="OpenTorrent":
					if 'magnet:' in url: cover = os.path.join( addon.getAddonInfo('path'), 'U.png')
					else:				 cover = os.path.join( addon.getAddonInfo('path'), 'T.png')

			listitem = xbmcgui.ListItem(Title, iconImage=cover, thumbnailImage=cover)
			listitem.setInfo(type = "Video", infoLabels = get_labels(info))
			try: listitem.setArt({ 'poster': cover, 'fanart' : fanart, 'thumb': cover, 'icon': cover})
			except: pass
			listitem.setProperty('fanart_image', fanart)
			
			purl = sys.argv[0] + '?mode='+mode+'&id='+id
			if url !="": purl = purl +'&url='+urllib.quote_plus(url)
			#print purl
			if mode=="Torrents":
				listitem.addContextMenuItems([('[B]В избранное[/B]', 'Container.Update("plugin://plugin.video.anilibria.tv/?mode=Add2List&id='+id+'")'), ('[B]Список раздач[/B]', 'Container.Update("plugin://plugin.video.anilibria.tv/?mode=Torrents2&id='+id+'")'), ('[B]Обновить описание[/B]', 'Container.Update("plugin://plugin.video.anilibria.tv/?mode=update_info&id='+id+'")')])
			if mode=="OpenTorrent":
				le=['','ace', 't2http', 'yatp', 'torrenter', 'elementum', 'xbmctorrent', 'ace_proxy', 'quasar', 'torrserver']
				tengine = le[int(__settings__.getSetting("TAMengine"))]

				purl='plugin://plugin.video.tam/?mode=open&url='+urllib.quote_plus(url)+ '&info=' + urllib.quote_plus(repr(info))+ '&engine='+tengine
				listitem.addContextMenuItems([('[B]Сохранить сериал[/B]', 'Container.Update("plugin://plugin.video.tam/?mode=save&url='+urllib.quote_plus(url)+'&purl='+urllib.quote_plus('plugin://plugin.video.anilibria.tv/?mode=Torrents2&id='+id)+ '&info=' + urllib.quote_plus(repr(info))+'")'),])

			if mode=="Wish":
				listitem.addContextMenuItems([('[B]Удалить[/B]', 'Container.Update("plugin://plugin.video.anilibria.tv/?mode=RemItem&id='+id+'")'),])
			
			xbmcplugin.addDirectoryItem(handle, purl, listitem, True, total)


def SrcNavi(md="Navigator", curl=''):
	L=[]
	if md=="ListAll":
		try:
			L=eval(get_inf_db('anilibria'))
			L=anilibria.upd_all(L)
			rem_inf_db('anilibria')
			add_to_db('anilibria', repr(L))
		except:
			L=anilibria.get_all()
			rem_inf_db('anilibria')
			add_to_db('anilibria', repr(L))
			return
		
	elif md=="Genres": 
		sel = xbmcgui.Dialog()
		Lg=anilibria.genres
		r = sel.select("Жанр:", Lg)
		if r>-1:
			g=Lg[r]
			L=anilibria.get_genre(g)

	elif md=="Years": 
		sel = xbmcgui.Dialog()
		Ly=anilibria.years
		r = sel.select("Жанр:", Ly)
		if r>-1:
			y=Ly[r]
			L=anilibria.get_year(y)

	elif md=="New":
		L=anilibria.get_new()

	elif md=="Best":
		L=anilibria.get_best()

	else:
		L=anilibria.search(md)
	
	for id in L:
		#try:
			info = get_info(id)
			title=info['title']
			if title!=id: 
				AddItem(title, "Torrents", id, total=len(L)-2)
			else:
				update_info(id, False)
		#except:
		#	print 'ошибка получения описания'


def update_info(id, up=True):
	try:
		rem_inf_db(id)
		if up: xbmc.executebuiltin('Container.Refresh')
	except:
		pass

def du(s):
	return eval('u"'+s.replace('\u','\\u')+'"')

def get_info(ID):
	try:
		info=eval(xt(get_inf_db(ID)))
		deb_print ('KP get_info ОК')
		return info
	except:
		info = anilibria.get_info(ID)
		try:    add_to_db(ID, repr(info))
		except: print "ERR: " + ID
		deb_print ('KP return info')
		return info



#==============  Menu  ====================
def Root():
	try:L=eval(__settings__.getSetting("W_list"))
	except: L=[]
	AddItem("Поиск", "Search")
	if __settings__.getSetting("HistoryON") == 'true': AddItem("История", "History")
	#AddItem("Каталог", "Navigator")
	AddItem("Все", "All")
	AddItem("Новые", "New")
	AddItem("Популярные", "Best")
	AddItem("Жанр", "Genres")
	AddItem("Год", "Years")
	if len(L)>0: AddItem("Избранное", "Wish_list")
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

def Search(s=''):
	if s=="": 
		s=inputbox()
		add_history(s)
	if s!="": 
		SrcNavi(s)


def Navigator():
	#Cat    =__settings__.getSetting("Cat")
	Genre  =__settings__.getSetting("Genre")
	Year   =__settings__.getSetting("Year")
	Ongoing=__settings__.getSetting("Ongoing")
	#Sort   =__settings__.getSetting("Sort")

	#if Cat=="":     Cat=  "--"
	if Genre=="":   Genre="--"
	if Year=="":    Year= "--"
	if Ongoing=="": Ongoing="--"
	#if Sort=="": Sort="Популярные"
	
	#AddItem("Категория: [COLOR FFFFFF00]" +Cat+    "[/COLOR]",   "SelCat")
	AddItem("Жанр:      [COLOR FFFFFF00]" +Genre+  "[/COLOR]",   "SelGenre")
	AddItem("Год:       [COLOR FFFFFF00]" +Year+   "[/COLOR]",   "SelYear")
	AddItem("Статус:    [COLOR FFFFFF00]" +Ongoing+"[/COLOR]",   "SelOngoing")
	#AddItem("Порядок:   [COLOR FFFFFF00]" +Sort+   "[/COLOR]",   "SelSort")
	
	AddItem("[B][COLOR FF00FF00][ Искать ][/COLOR][/B]", "SrcNavi")

def Torrents(id, additm=True):
	info=get_info(id)
	L=anilibria.get_torrents(id)
	for i in L:
		AddItem(i['title'], "OpenTorrent", id, i['torrent'])
	return L


def SetViewMode():
	n = int(__settings__.getSetting("ListView"))
	if n>0:
		xbmc.executebuiltin("Container.SetViewMode(0)")
		for i in range(1,n):
			xbmc.executebuiltin("Container.NextViewMode")

def History():
	try:L=eval(__settings__.getSetting("History"))
	except: L=[]
	for i in L:
		AddItem(i, 'HSearch', '0', i)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

def add_history(t):
	try:L=eval(__settings__.getSetting("History"))
	except: L=[]
	if t not in L:
		NL=[]
		NL.append(t)
		NL.extend(L[:15])
		__settings__.setSetting("History", repr(NL))

try:    mode = urllib.unquote_plus(get_params()["mode"])
except: mode = None
try:    url = urllib.unquote_plus(get_params()["url"])
except: url = None
try:    info = eval(urllib.unquote_plus(get_params()["info"]))
except: info = {}
try:    id = str(get_params()["id"])
except: id = '0'
try:    ind = int(get_params()["ind"])
except: ind = 0


if mode == None:
	#__settings__.setSetting(id="Cat",     value="")
	#__settings__.setSetting(id="Genre",  value="")
	#__settings__.setSetting(id="Year",    value="")
	#__settings__.setSetting(id="Ongoing", value="")
	#__settings__.setSetting(id="Sort",    value="")
	Root()

if mode == "Search":
	Search()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == 'HSearch':
	Search(url)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == 'History':
	History()

if mode == "Navigator":
	Navigator()
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Genres":
	SrcNavi("Genres")
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Years":
	SrcNavi("Years")
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "All":
	SrcNavi("ListAll")
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(handle)

if mode == "New":
	SrcNavi("New")
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)

if mode == "Best":
	SrcNavi("Best")
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.endOfDirectory(handle)


if mode == "Torrents" or mode == "Torrents2":
	Torrents(id)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(handle)
	xbmc.sleep(300)
	SetViewMode()

if mode == "Add2List":
	try:L=eval(__settings__.getSetting("W_list"))
	except: L=[]
	if id not in L:
		L.append(id)
		__settings__.setSetting("W_list", repr(L))

if mode == "RemItem":
	try:L=eval(__settings__.getSetting("W_list"))
	except: L=[]
	L.remove(id)
	__settings__.setSetting("W_list", repr(L))
	xbmc.executebuiltin("Container.Refresh()")

if mode == "Wish_list":
	try:L=eval(__settings__.getSetting("W_list"))
	except: L=[]
	for id in L:
		info=get_info(str(id))
		rus=info["title"]
		AddItem(rus, 'Wish', id)
	xbmcplugin.endOfDirectory(handle)

if mode == "Wish":
	Torrents(id)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(handle)
	xbmc.sleep(300)
	SetViewMode()
	#xbmc.executebuiltin("Container.SetViewMode(51)")

if mode == "update_info":
	update_info(id)


if mode == "check":
	check()


c.close()
