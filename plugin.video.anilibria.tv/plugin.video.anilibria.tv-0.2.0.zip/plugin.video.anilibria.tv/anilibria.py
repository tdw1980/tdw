# -*- coding: utf-8 -*-
import sys, os
import urllib, urllib2

temp_dir = "c:\\"

genres={
	"безумие":"arrFilter_73_1834509007",
	"боевик":"arrFilter_73_757538426",
	"боевые искусства":"arrFilter_73_1047308191",
	"вампиры":"arrFilter_73_1070049857",
	"военное":"arrFilter_73_3495832144",
	"гарем":"arrFilter_73_632349209",
	"демоны":"arrFilter_73_3225647015",
	"детектив":"arrFilter_73_40088026",
	"Дзёсей":"arrFilter_73_1025197503",
	"драма":"arrFilter_73_1224881819",
	"игры":"arrFilter_73_2825432531",
	"исторический":"arrFilter_73_2138277072",
	"комедия":"arrFilter_73_3281778481",
	"космос":"arrFilter_73_2368537175",
	"магия":"arrFilter_73_2043150143",
	"мелодрама":"arrFilter_73_1901111963",
	"меха":"arrFilter_73_2109499118",
	"мистика":"arrFilter_73_1930432581",
	"музыка":"arrFilter_73_3316398797",
	"научная фантастика":"arrFilter_73_3841405650",
	"пародия":"arrFilter_73_2835505958",
	"повседневность":"arrFilter_73_2526784277",
	"полиция":"arrFilter_73_3418321000",
	"приключения":"arrFilter_73_2065825725",
	"психологическое":"arrFilter_73_36855235",
	"романтика":"arrFilter_73_3436758029",
	"сёдзе":"arrFilter_73_2322658028",
	"сёдзе-ай":"arrFilter_73_2066381173",
	"сёнен":"arrFilter_73_2319436993",
	"сёнен-ай":"arrFilter_73_692705199",
	"самураи":"arrFilter_73_3674470190",
	"сверхъестественное":"arrFilter_73_2097932669",
	"сейнен":"arrFilter_73_3488709761",
	"спорт":"arrFilter_73_2882971692",
	"супер сила":"arrFilter_73_2826841766",
	"триллер":"arrFilter_73_4122162994",
	"ужасы":"arrFilter_73_3616975243",
	"фантастика":"arrFilter_73_2353863208",
	"фэнтези":"arrFilter_73_2829706088",
	"школа":"arrFilter_73_335756293",
	"экшен":"arrFilter_73_3481712254",
	"этти":"arrFilter_73_1825300754",
	}

years={
	"2001":"arrFilter_99_3516218479",
	"2005":"arrFilter_99_3606640758",
	"2006":"arrFilter_99_1341237708",
	"2007":"arrFilter_99_955685210",
	"2008":"arrFilter_99_2823390411",
	"2009":"arrFilter_99_3746477149",
	"2010":"arrFilter_99_3213442488",
	"2011":"arrFilter_99_3364752686",
	"2012":"arrFilter_99_1367825556",
	"2013":"arrFilter_99_645950466",
	"2014":"arrFilter_99_3102013857",
	"2015":"arrFilter_99_3487811895",
	"Весна 2009":"arrFilter_99_1190117281",
	"Весна 2010":"arrFilter_99_640169540",
	"Весна 2011":"arrFilter_99_1362036434",
	"Весна 2012":"arrFilter_99_3357955944",
	"Весна 2014":"arrFilter_99_558232157",
	"Весна 2015":"arrFilter_99_1447215819",
	"Весна 2016":"arrFilter_99_3477836657",
	"Весна 2017":"arrFilter_99_3092030439",
	"Весна 2018":"arrFilter_99_687062646",
	"Вечный":"arrFilter_99_3331467091",
	"Зима 2011":"arrFilter_99_552694742",
	"зима 2013":"arrFilter_99_3603876098",
	"Зима 2014":"arrFilter_99_1352370009",
	"Зима 2015":"arrFilter_99_664582095",
	"Зима 2016":"arrFilter_99_3197494901",
	"Зима 2017":"arrFilter_99_3381843683",
	"Зима 2018":"arrFilter_99_1496173426",
	"Июль 2015":"arrFilter_99_778158202",
	"лето 2011":"arrFilter_99_1963088483",
	"Лето 2012":"arrFilter_99_4097495073",
	"Лето 2013":"arrFilter_99_2201870519",
	"Лето 2014":"arrFilter_99_492401940",
	"Лето 2015":"arrFilter_99_1784563074",
	"Лето 2016":"arrFilter_99_4082570296",
	"Лето 2017":"arrFilter_99_2219844782",
	"Лето 2018":"arrFilter_99_351222079",
	"Осень 1996":"arrFilter_99_2414082347",
	"Осень 2003":"arrFilter_99_858727052",
	"Осень 2004":"arrFilter_99_2907420463",
	"осень 2008":"arrFilter_99_1771668444",
	"Осень 2011":"arrFilter_99_3292164833",
	"Осень 2012":"arrFilter_99_1563632475",
	"Осень 2013":"arrFilter_99_708056013",
	"Осень 2014":"arrFilter_99_3025176174",
	"Осень 2015":"arrFilter_99_3277305592",
	"Осень 2016":"arrFilter_99_1516169026",
	"Осень 2017":"arrFilter_99_760862676",
	}

type={
	"ТВ-сериал":"%D0%A2%D0%92",
	"Фильмы":"%D0%9F%D0%BE%D0%BB%D0%BD%D0%BE%D0%BC%D0%B5%D1%82%D1%80%D0%B0%D0%B6%D0%BD%D1%8B%D0%B9",
	"OVA, ONA, Special":"OVA",
	"Дорама":"%D0%94%D0%BE%D1%80%D0%B0%D0%BC%D0%B0",
	}

ongoing={
	"В работе":"arrFilter_84_450215437",
	"Завершен":"arrFilter_84_2226203566",
	}

def ru(x):return unicode(x,'utf8', 'ignore')

def CRC32(buf):
		import binascii
		buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		return str("%08X" % buf)

def convert(url):
	import base64
	sign=base64.b64encode(url)
	redir='http://www.proxy.zee18.info/index.php?q='+urllib.quote_plus(sign)
	return redir

def GET(url, Referer = 'https://anilibria.tv/'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


def findall(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def save_inf(s):
	p = os.path.join(ru(temp_dir),"temp.txt")
	f = open(p, "w")
	f.write(s)
	f.close()
	return p

def get_new():
	L2=[]
	for p in range (1,3):
		url='https://www.anilibria.tv/tracker/relizy.php?PAGEN_1='+str(p)
		print url
		r=GET(url)
		L=findall(r,"<div class='torrent_descr_wrap'>", "<img class='torrent_pic'")
		for i in L:
			id = mfind(i,'/release/','.html')
			if id not in L2: L2.append(id)
	return L2

def get_all():
	L2=[]
	for p in range (1,56):
		url='https://www.anilibria.tv/tracker/relizy.php?PAGEN_1='+str(p)
		print url
		r=GET(url)
		L=findall(r,"<div class='torrent_descr_wrap'>", "<img class='torrent_pic'")
		for i in L:
			id = mfind(i,'/release/','.html')
			if id not in L2: L2.append(id)
	return L2

def upd_all(L2):
	for p in range (1,3):
		url='https://www.anilibria.tv/tracker/relizy.php?PAGEN_1='+str(p)
		r=GET(url)
		L=findall(r,"<div class='torrent_descr_wrap'>", "<img class='torrent_pic'")
		for i in L:
			id = mfind(i,'/release/','.html')
			if id not in L2: L2.append(id)
	return L2

def get_genre(g=''):
	L2=[]
	for p in range (1,15):
		url='http://www.anilibria.tv/tracker/relizy2.php?genre='+g+'&PAGEN_1='+str(p)
		print url
		r=GET(url)
		if 'bx_active" title="">1' in r and p>1: return L2
		
		L=findall(r,"torrent_block_main",'<p class="torrent_name">')
		
		for i in L:
			id     = mfind(i,'/release/','.html')
			if id not in L2: L2.append(id)
		if 'bx_active' not in r: return L2
	return L2

def get_year(y=''):
	L2=[]
	for p in range (1,15):
		url='http://www.anilibria.tv/tracker/relizy2.php?date='+y.replace(' ', '%20')+'&PAGEN_1='+str(p)
		print url
		r=GET(url)
		if 'bx_active" title="">1' in r and p>1: return L2
		L=findall(r,"torrent_block_main",'<p class="torrent_name">')
		
		for i in L:
			id     = mfind(i,'/release/','.html')
			if id not in L2: L2.append(id)
		if 'bx_active' not in r: return L2
	return L2


def search(s):
	url='https://www.anilibria.tv/search/index.php?q='+s+'&where=iblock_Tracker&how=r'
	print url
	r=GET(url)
	L=findall(r,'search_result_title','search_body_text')
	L2=[]
	for i in L:
		id = mfind(i,'/release/','.html')
		if id not in L2: L2.append(id)
	return L2


def get_info(id):
	print id
	try:
		url='https://www.anilibria.tv/release/'+id+'.html'
		i=GET(url)
		
		ogt            = mfind(i,'og:title" content="','" />')
		title          = ogt[ogt.find(' / ')+3:]
		originaltitle  = ogt[:ogt.find(' / ')]
		
		year           = mfind(i,'?date=','">')
		if ' ' in year: year=year[year.find(' ')+1:]
		
		cover          = 'https://www.anilibria.tv'+mfind(i,"detail_torrent_pic' border='0' src='","'")
		fanart         = cover
		plot           = mfind(i,'og:description" content="','"')
		gt             = mfind(i,'<b>Жанры:</b>','<br/>')
		#print gt
		Lg = findall(gt,"'>",'</')
		genre = ""
		for g in Lg:
			genre=genre+g.replace("'>", '')+", "
		genre=genre[:-2]
		info = {
			'title':title,
			'originaltitle':originaltitle,
			'year':year,
			'fanart':fanart,
			'cover':cover,
			'plot':plot,
			'genre':genre,
			'id':id,
			}
		#print info
		return info
	except:
			info = {
			'title':id,
			'originaltitle':id,
			'year':'1999',
			'fanart':'',
			'cover':'',
			'plot':'plot',
			'genre':'genre',
			'id':id,
			}
			return info

#get_info('paranormalnoe-byuro-rassledovanij-muhyo-i-rodzhi')

def get_torrents(id):
	if len(id)> 1000:
		i=id
	else:
		url='https://www.anilibria.tv/release/'+id+'.html'
		i=GET(url)
	Lt=[]
	L = findall(i,"<div class='download-torrent'>",'</a></span>')
	for t in L:
				title = mfind(t, '><span>', '<')
				torrent = 'https://www.anilibria.tv/'+mfind(t, "link' href='", "'")
				itm = {'title': title , 'torrent': torrent}
				Lt.append(itm)
	return Lt

#print get_torrents('naruto-uragannye-hroniki')
#print get_torrents('paranormalnoe-byuro-rassledovanij-muhyo-i-rodzhi')

def get_filtr():
	url='https://www.anilibria.tv/tracker/relizy.php'
	r=GET(url)
	L=r.splitlines()
	L2=[]
	for i in L:
		if 'bx_filter_param_text' in i:
			id = mfind(i,'data-role="count_','">')
			ttl= mfind(i,'title="','"')
			print '"'+ttl+'":"'+id+'",'
			L2.append(id)
	return L2
