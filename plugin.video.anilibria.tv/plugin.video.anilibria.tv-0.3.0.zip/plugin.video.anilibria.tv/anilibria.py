# -*- coding: utf-8 -*-
import sys, os, time
import urllib, urllib2

temp_dir = "c:\\"

genres=[
	"безумие",
	"боевик",
	"боевые искусства",
	"вампиры",
	"военное",
	"гарем",
	"демоны",
	"детектив",
	"Дзёсей",
	"драма",
	"игры",
	"исторический",
	"комедия",
	"космос",
	"магия",
	"мелодрама",
	"меха",
	"мистика",
	"музыка",
	"научная фантастика",
	"пародия",
	"повседневность",
	"полиция",
	"приключения",
	"психологическое",
	"романтика",
	"сёдзе",
	"сёдзе-ай",
	"сёнен",
	"сёнен-ай",
	"самураи",
	"сверхъестественное",
	"сейнен",
	"спорт",
	"супер сила",
	"триллер",
	"ужасы",
	"фантастика",
	"фэнтези",
	"школа",
	"экшен",
	"этти",
	"ужасы",
	"фантастика",
	"фэнтези",
	"школа",
	"экшен",
	"этти"
	]


years=[
	"1996",
	"2001",
	]

for y in range (2002, time.gmtime()[0]+1):
	years.append(str(y))

years.reverse()

type={
	"ТВ-сериал":"%D0%A2%D0%92",
	"Фильмы":"%D0%9F%D0%BE%D0%BB%D0%BD%D0%BE%D0%BC%D0%B5%D1%82%D1%80%D0%B0%D0%B6%D0%BD%D1%8B%D0%B9",
	"OVA, ONA, Special":"OVA",
	"Дорама":"%D0%94%D0%BE%D1%80%D0%B0%D0%BC%D0%B0",
	}

ongoing={
	"В работе":"arrFilter_84_450215437",
	"Завершен":"arrFilter_84_2226203566",
	}

def ru(x):return unicode(x,'utf8', 'ignore')

def CRC32(buf):
		import binascii
		buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		return str("%08X" % buf)

def convert(url):
	import base64
	sign=base64.b64encode(url)
	redir='http://www.proxy.zee18.info/index.php?q='+urllib.quote_plus(sign)
	return redir

def POST(target, post=None, referer='https://anilibria.tv/'):
	try:
		req = urllib2.Request(url = target, data = post)
#		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36 OPR/55.0.2994.61')
#		req.add_header('Accept', '*/*')
#		req.add_header('Accept-Encoding', 'gzip, deflate')
		req.add_header('Referer', referer)
#		req.add_header('X-Requested-With', 'XMLHttpRequest')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		print 'err'
		print e
		return ''

def GET(url, Referer = 'https://anilibria.tv/'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


def findall(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def save_inf(s):
	p = os.path.join(ru(temp_dir),"temp.txt")
	f = open(p, "w")
	f.write(s)
	f.close()
	return p



def get_list(page=1, year='', genre='', sort=1):
	url='https://www.anilibria.tv/public/catalog.php'
	post = 'page='+str(page)+'&search=%7B%22year%22%3A%22'+str(year)+'%22%2C%22genre%22%3A%22'+str(genre)+'%22%7D&xpage=catalog&sort='+str(sort)
	r=POST(url, post)
	print r
	L=findall(r,"<td><a ", "<\/a><\/td>")
	L2=[]
	for i in L:
		#print i
		id = mfind(i,'release\/','.html')
		if id not in L2: L2.append(id)
	return L2

#get_list(15, '2019')

def get_new():
	L2=[]
	for p in range (1,3):
		L=get_list(p)
		for id in L:
			if id not in L2: L2.append(id)
	return L2

def get_best():
	L2=[]
	for p in range (1,3):
		L=get_list(p, '', '', 2)
		for id in L:
			if id not in L2: L2.append(id)
	return L2


def get_all():
	L2=[]
	for p in range (1,56):
		L=get_list(p)
		for id in L:
			if id not in L2: L2.append(id)
	return L2

def upd_all(L2):
	for p in range (1,3):
		L=get_list(p)
		for id in L:
			if id not in L2: L2.append(id)
	return L2

def get_genre(g=''):
	L2=[]
	for p in range (1,15):
		L=get_list(p, '', g)
		if L==[]: 
			print 'stop'
			return L2
		else:
			print L
		for id in L:
			if id not in L2: L2.append(id)
		#if 'bx_active' not in r: return L2
	return L2

def get_year(y=''):
	L2=[]
	for p in range (1,15):
		L=get_list(p, y)
		if L==[]: return L2
		for id in L:
			if id not in L2: L2.append(id)
		#if 'bx_active' not in r: return L2
	return L2


def search(s):
	url='https://www.anilibria.tv/public/search.php'
	post = 'search='+str(s)+'&small=1'
	r=POST(url, post)

	L=findall(r,"release\/", ".html")
	L2=[]
	for i in L:
		#print i
		id = i[9:]
		if id not in L2: L2.append(id)
	return L2


def get_info(id):
	print id
	try:
		url='https://www.anilibria.tv/release/'+id+'.html'
		i=GET(url)
		
		ogt            = mfind(i,"property='og:title' content='","' />")
		originaltitle  = ogt[ogt.find(' / ')+3:].strip()
		title          = ogt[:ogt.find(' / ')].strip()
		
		year           = mfind(i,'<b>Год:</b>','<').strip()
		if ' ' in year: year=year[year.find(' ')+1:]
		
		cover          = 'https://www.anilibria.tv'+mfind(i,'detail_torrent_pic" border="0" src="','.jpg')+'.jpg'
		fanart         = cover
		plot           = mfind(i,'detail-description" style="font-size: 15.7px;">',"<")
		genre          = mfind(i,'<b>Жанры:</b>','<')
		#print gt
		'''
		Lg = findall(gt,"'>",'</')
		genre = ""
		for g in Lg:
			genre=genre+g.replace("'>", '')+", "
		genre=genre[:-2]
		'''
		info = {
			'title':title,
			'originaltitle':originaltitle,
			'year':year,
			'fanart':fanart,
			'cover':cover,
			'plot':plot,
			'genre':genre,
			'id':id,
			}
		#print info
		return info
	except:
			info = {
			'title':id,
			'originaltitle':id,
			'year':'1999',
			'fanart':'',
			'cover':'',
			'plot':'plot',
			'genre':'genre',
			'id':id,
			}
			return info

#get_info('paranormalnoe-byuro-rassledovanij-muhyo-i-rodzhi')

def get_torrents(id):
	if len(id)> 1000:
		i=id
	else:
		url='https://www.anilibria.tv/release/'+id+'.html'
		i=GET(url)
	Lt=[]
	L = findall(i,'<td id="torrentTableInfo','Cкачать</a></td>')
	for t in L:
				title = mfind(t, 'col1">', '<')
				torrent = 'https://www.anilibria.tv/'+mfind(t, 'torrent-download-link" href="', '"')
				itm = {'title': title , 'torrent': torrent}
				Lt.append(itm)
	return Lt

#print get_torrents('naruto-uragannye-hroniki')
#print get_torrents('paranormalnoe-byuro-rassledovanij-muhyo-i-rodzhi')

def get_filtr():
	url='https://www.anilibria.tv/tracker/relizy.php'
	r=GET(url)
	L=r.splitlines()
	L2=[]
	for i in L:
		if 'bx_filter_param_text' in i:
			id = mfind(i,'data-role="count_','">')
			ttl= mfind(i,'title="','"')
			print '"'+ttl+'":"'+id+'",'
			L2.append(id)
	return L2
